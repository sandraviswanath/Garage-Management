export const Currency: string = "₹";
export const logo = "/assets/images/Logo.png";
