 import { sidebarMenuType, sidebarItemType, sidebarChildrenType } from "@/Types/LayoutDataType";

export const filterMenuByRole = (menuList: sidebarMenuType[], userRole: string): sidebarMenuType[] => {
  
  // 🔹 Function for filtering sub-menu (children)
  const filterChildren = (children: sidebarChildrenType[]): sidebarChildrenType[] => {
    return children
      .filter(child => {
        if (!child.roles) return true;
        return child.roles.includes(userRole);
      })
      .map(child => {
        const filteredChild = { ...child };
        if (filteredChild.children) {
          // if there are sub-children (subChildrenType[])
          filteredChild.children = filteredChild.children.filter(sub => {
            if (!sub.path) return false; // basic safety
            return true;
          });
        }
        return filteredChild;
      })
      .filter(child => !(child.type === "sub" && child.children && child.children.length === 0));
  };

  // 🔹 Function for filtering top-level items
  const filterItems = (items: sidebarItemType[]): sidebarItemType[] => {
    return items
      .filter(item => {
        if (!item.roles) return true;
        return item.roles.includes(userRole);
      })
      .map(item => {
        const filteredItem = { ...item };
        if (filteredItem.children) {
          filteredItem.children = filterChildren(filteredItem.children);
        }
        return filteredItem;
      })
      .filter(item => !(item.type === "sub" && item.children && item.children.length === 0));
  };

  // 🔹 Apply filters to each category
  return menuList
    .map(category => ({
      ...category,
      Items: filterItems(category.Items),
    }))
    .filter(category => category.Items.length > 0);
};
