// "use client";
// import React, { useContext } from "react";
// import SidebarLogo from "./SidebarLogo";
// import SidebarMenu from "./SidebarMenu";
// // import ConfigDB from "config/ThemeConfig";
// // import CustomizerContext from "helper/Customizer";
// // import layoutContext from "helper/Layout";
// import Link from "next/link";
// import Image from "next/image";
// import CustomizerContext from "@/helper/Customizer";
// import layoutContext from "@/helper/Layout";
// import ConfigDB from "@/config/ThemeConfig";
// import { ImgPath } from "@/utils/Constant";
// // import { ImgPath } from "utils/Constant";

// const Sidebar = () => {
//   const { sidebarIconType } = useContext(CustomizerContext);
//   const { sideBarToggle } = useContext(layoutContext);

//   const IconType = sidebarIconType || ConfigDB.data.settings.sidebar.iconType;
//   return (
//     <div
//       className={`sidebar-wrapper ${sideBarToggle ? "close_icon" : ""}`}
//       sidebar-layout={IconType}
//     >
//       <div>
//         <SidebarLogo />
//         <div className="logo-icon-wrapper">
//           <Link href={"/dashboard/default"}>
//             <Image
//               width={35}
//               height={35}
//               className="img-fluid"
//               src={`${ImgPath}/logo/logo-icon.png`}
//               alt=""
//             />
//           </Link>
//         </div>
//         <SidebarMenu />
//       </div>
//     </div>
//   );
// };

// export default Sidebar;

// Sidebar.tsx
"use client";
import React, { useContext } from "react";
import SidebarLogo from "./SidebarLogo";
import SidebarMenu from "./SidebarMenu";
import CustomizerContext from "@/helper/Customizer";
import layoutContext from "@/helper/Layout";
import ConfigDB from "@/config/ThemeConfig";
import Link from "next/link";
import Image from "next/image";
import { ImgPath } from "@/utils/Constant";
// import { MenuList } from "../menu";
// import { filterMenuByRole } from "@/utils/menuFilter";
// import { useAuth } from "@/path-to-your-auth-hook"; // Adjust path
import { filterMenuByRole } from "@/utils/menuFilter";
import { MenuList } from "./menu";
import { useAuth } from "@/helper/AuthContext";
import { logo } from "@/utils/Utils";
const Sidebar = () => {
  const { sidebarIconType } = useContext(CustomizerContext);
  const { sideBarToggle } = useContext(layoutContext);
  const { state } = useAuth();
  //  console.log(state,"role menu")
  const role = state.user?.role_name;
  // console.log(role,"role menu")
  // const role = "admin";
  // const role = "receptionist";
  const IconType = sidebarIconType || ConfigDB.data.settings.sidebar.iconType;

  // Filter menu based on user role
  const filteredMenuList = role ? filterMenuByRole(MenuList, role) : [];

  return (
    <div
      className={`sidebar-wrapper ${sideBarToggle ? "close_icon" : ""}`}
      sidebar-layout={IconType}
    >
      <div>
        <SidebarLogo />
        <div className="logo-icon-wrapper">
          <Link href={"/dashboard/default"}>
            <Image
              width={35}
              height={35}
              className="img-fluid"
              // src={`${ImgPath}/logo/logo-icon.png`}
              src={logo}
              alt=""
            />
          </Link>
        </div>
        <SidebarMenu menuList={filteredMenuList} />
      </div>
    </div>
  );
};

export default Sidebar;
