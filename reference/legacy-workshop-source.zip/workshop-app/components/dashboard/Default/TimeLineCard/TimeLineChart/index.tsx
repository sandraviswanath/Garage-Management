// import { TimeLineChartData } from '@/Data/Dashboard/DefaultData/Chart'
// import dynamic from 'next/dynamic'
// import React from 'react'
// import { CardBody } from 'reactstrap'
// // import { TimeLineChartData } from '../../../../../../Data/Dashboard/DefaultData/Chart'

// const ReactApexChart = dynamic(() => import('react-apexcharts'), { ssr: false })

// const TimeLineChart = () => {
//     return (
//         <CardBody className='pt-0'>
//             <div className='schedule-container'>
//                 <ReactApexChart height={355} type='rangeBar' options={TimeLineChartData.options} series={TimeLineChartData.series} />
//             </div>
//         </CardBody>
//     )
// }

// export default TimeLineChart

import { TimeLineChartData } from "@/Data/Dashboard/DefaultData/Chart";
import dynamic from "next/dynamic";
import React from "react";
import { CardBody } from "reactstrap";

const ReactApexChart = dynamic(() => import("react-apexcharts"), {
  ssr: false,
});

interface JobCard {
  id: string;
  job_number: string;
  customer_name: string;
  registration_number: string;
  status: string;
  created_at: string;
  updated_at: string;
}

interface TimeLineChartProps {
  recentJobCards?: JobCard[];
}

const TimeLineChart = ({ recentJobCards = [] }: TimeLineChartProps) => {
  // Create simple timeline of job creation dates
  const getSimpleTimeline = () => {
    if (recentJobCards.length === 0) {
      return TimeLineChartData;
    }

    // Sort by creation date and get last 10 jobs
    const sortedJobs = [...recentJobCards]
      .sort(
        (a, b) =>
          new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
      )
      .slice(0, 10);

    // Get dates for the last 7 days
    const dates = Array.from({ length: 7 }, (_, i) => {
      const date = new Date();
      date.setDate(date.getDate() - i);
      return date.toISOString().split("T")[0];
    }).reverse();

    // Count jobs per day
    const jobsPerDay = dates.map((date) => {
      return sortedJobs.filter((job) => job.created_at.split(" ")[0] === date)
        .length;
    });

    return {
      series: [
        {
          name: "Jobs Created",
          data: jobsPerDay,
        },
      ],
      options: {
        chart: {
          height: 350,
          type: "line" as const,
          toolbar: {
            show: false,
          },
        },
        stroke: {
          width: 3,
          curve: "smooth" as const,
        },
        xaxis: {
          categories: dates.map((date) => {
            const d = new Date(date);
            return d.toLocaleDateString("en-US", { weekday: "short" });
          }),
          title: {
            text: "Last 7 Days",
          },
        },
        yaxis: {
          title: {
            text: "Number of Jobs",
          },
          min: 0,
        },
        title: {
          text: "Daily Job Creation Trend",
          align: "left" as const,
          style: {
            fontSize: "16px",
            fontWeight: "bold",
          },
        },
        colors: ["#7366ff"],
        markers: {
          size: 5,
          hover: {
            size: 8,
          },
        },
      },
    };
  };

  const chartData = getSimpleTimeline();

  return (
    <CardBody className="pt-0">
      <div className="schedule-container">
        <ReactApexChart
          height={355}
          type="line"
          options={chartData.options}
          series={chartData.series}
        />
      </div>

      {/* Quick Stats */}
      {recentJobCards.length > 0 && (
        <div className="mt-3">
          <div className="d-flex justify-content-around text-center">
            <div>
              <h5 className="mb-0 text-primary">{recentJobCards.length}</h5>
              <small className="text-muted">Total Jobs</small>
            </div>
            <div>
              <h5 className="mb-0 text-success">
                {recentJobCards.filter((j) => j.status === "completed").length}
              </h5>
              <small className="text-muted">Completed</small>
            </div>
            <div>
              <h5 className="mb-0 text-warning">
                {recentJobCards.filter((j) => j.status === "assigned").length}
              </h5>
              <small className="text-muted">In Progress</small>
            </div>
          </div>
        </div>
      )}
    </CardBody>
  );
};

export default TimeLineChart;
