// import React from "react";
// import { Card, CardHeader, Col } from "reactstrap";
// import TimeLineChart from "./TimeLineChart";
// import { DailyDropdown, Timeline } from "@/utils/Constant";
// import DropdownCommon from "@/CommonElements/Dashboard/DropdownCommon";

// const TimeLineCard = () => {
//   return (
//     <Col xxl={4} md={6} className="appointment-sec box-col-6">
//       <div className="appointment">
//         <Card>
//           <CardHeader className="card-no-border">
//             <div className="header-top">
//               <h5 className="m-0">{Timeline}</h5>
//               <div className="card-header-right-icon">
//                 <DropdownCommon
//                   icon={false}
//                   options={DailyDropdown}
//                   btn={{ caret: true, color: "Outline-primary" }}
//                 />
//               </div>
//             </div>
//           </CardHeader>
//           <TimeLineChart />
//         </Card>
//       </div>
//     </Col>
//   );
// };

// export default TimeLineCard;

import React from "react";
import { Card, CardHeader, Col } from "reactstrap";
import TimeLineChart from "./TimeLineChart";
import { DailyDropdown, Timeline } from "@/utils/Constant";
import DropdownCommon from "@/CommonElements/Dashboard/DropdownCommon";

// Define JobCard interface locally
interface JobCard {
  id: string;
  job_number: string;
  customer_name: string;
  registration_number: string;
  status: string;
  total_estimate: string;
  created_at: string;
  updated_at: string;
  expected_completion?: string;
  assigned_to_user?: string | null;
  reported_issue?: string;
}

interface TimeLineCardProps {
  recentJobCards?: JobCard[];
}

const TimeLineCard = ({ recentJobCards = [] }: TimeLineCardProps) => {
  return (
    <Col xxl={4} md={6} className="appointment-sec box-col-6">
      <div className="appointment">
        <Card>
          <CardHeader className="card-no-border">
            <div className="header-top">
              <h5 className="m-0">{Timeline}</h5>
              <div className="card-header-right-icon">
                <DropdownCommon
                  icon={false}
                  options={DailyDropdown}
                  btn={{ caret: true, color: "Outline-primary" }}
                />
              </div>
            </div>
          </CardHeader>
          <TimeLineChart recentJobCards={recentJobCards} />
        </Card>
      </div>
    </Col>
  );
};

export default TimeLineCard;
