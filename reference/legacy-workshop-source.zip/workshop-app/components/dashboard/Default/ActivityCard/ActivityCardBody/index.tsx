// import { ActivityData } from '@/Data/Dashboard/DefaultData'
// import React from 'react'
// import { CardBody } from 'reactstrap'

// const ActivityCardBody = () => {
//     return (
//         <CardBody className='pt-0'>
//             <ul>
//                 {ActivityData.map((item, i) => (
//                     <li key={i} className='d-flex' >
//                         <div className={`activity-dot-${item.color}`} />
//                         <div className='w-100 ms-3'>
//                             <p className='d-flex justify-content-between mb-2' >
//                                 <span className='date-content light-background'>{item.subTitle}</span>
//                                 <span>{item.time}</span>
//                             </p>
//                             <h6>
//                                 {item.title}
//                                 <span className='dot-notification' />
//                             </h6>
//                             <p className='f-light'>{item.dis}</p>
//                         </div>
//                     </li>
//                 ))}
//             </ul>
//         </CardBody>
//     )
// }

// export default ActivityCardBody

// ActivityCardBody.tsx
// import React from "react";
// import { CardBody } from "reactstrap";

// interface JobCard {
//   id: string;
//   job_number: string;
//   customer_name: string;
//   registration_number: string;
//   status: string;
//   total_estimate: string;
//   created_by_user: string;
//   assigned_to_user: string | null;
//   created_at: string;
//   updated_at: string;
//   reported_issue?: string;
// }

// interface TechnicianPerformance {
//   assigned_to: string;
//   total_jobs: string;
//   assigned_username: string;
// }

// interface ActivityCardBodyProps {
//   recentJobCards?: JobCard[];
//   technicianPerformance?: TechnicianPerformance[];
// }

// const ActivityCardBody: React.FC<ActivityCardBodyProps> = ({
//   recentJobCards = [],
//   technicianPerformance = [],
// }) => {
//   // If no data, show placeholder or loading
//   if (recentJobCards.length === 0) {
//     return (
//       <CardBody className="pt-0">
//         <div className="text-center py-4">
//           <p className="text-muted">No recent activities found</p>
//         </div>
//       </CardBody>
//     );
//   }

//   // Get the most recent 5 job cards
//   const recentActivities = recentJobCards.slice(0, 5);

//   // Function to get status color
//   const getStatusColor = (status: string): string => {
//     switch (status.toLowerCase()) {
//       case "completed":
//         return "success";
//       case "assigned":
//         return "warning";
//       case "in_progress":
//         return "primary";
//       case "open":
//         return "info";
//       default:
//         return "secondary";
//     }
//   };

//   // Function to format date
//   const formatDate = (dateString: string) => {
//     const date = new Date(dateString);
//     return date.toLocaleDateString("en-US", {
//       month: "short",
//       day: "numeric",
//       hour: "2-digit",
//       minute: "2-digit",
//     });
//   };

//   // Function to truncate text
//   const truncateText = (text: string, maxLength: number = 50) => {
//     if (text.length <= maxLength) return text;
//     return text.substring(0, maxLength) + "...";
//   };

//   return (
//     <CardBody className="pt-0">
//       <ul>
//         {recentActivities.map((job, index) => (
//           <li key={job.id || index} className="d-flex">
//             <div className={`activity-dot-${getStatusColor(job.status)}`} />
//             <div className="w-100 ms-3">
//               <p className="d-flex justify-content-between mb-2">
//                 <span className="date-content light-background">
//                   {job.registration_number}
//                 </span>
//                 <span>{formatDate(job.created_at)}</span>
//               </p>
//               <h6>
//                 {job.customer_name} - Job #{job.job_number}
//                 <span className="dot-notification" />
//               </h6>
//               <p className="f-light mb-1">
//                 <span
//                   className={`badge badge-light-${getStatusColor(job.status)}`}
//                 >
//                   {job.status.charAt(0).toUpperCase() + job.status.slice(1)}
//                 </span>
//                 {job.assigned_to_user && (
//                   <span className="ms-2">
//                     Assigned to: <strong>{job.assigned_to_user}</strong>
//                   </span>
//                 )}
//               </p>
//               {job.reported_issue && (
//                 <p className="f-light mb-1">
//                   Issue: {truncateText(job.reported_issue, 60)}
//                 </p>
//               )}
//               <p className="f-light">
//                 Estimate:{" "}
//                 <strong>
//                   ${parseFloat(job.total_estimate || "0").toFixed(2)}
//                 </strong>
//               </p>
//             </div>
//           </li>
//         ))}
//       </ul>

//       {/* Show technician performance summary if available */}
//       {technicianPerformance.length > 0 && (
//         <div className="mt-3 pt-3 border-top">
//           <h6 className="mb-2">Technician Performance</h6>
//           <div className="d-flex flex-wrap gap-2">
//             {technicianPerformance.map((tech, index) => (
//               <span
//                 key={tech.assigned_to || index}
//                 className="badge badge-light-primary"
//               >
//                 {tech.assigned_username}: {tech.total_jobs} jobs
//               </span>
//             ))}
//           </div>
//         </div>
//       )}
//     </CardBody>
//   );
// };

// export default ActivityCardBody;

// ActivityCardBody.tsx - Alternative version
import React from "react";
import { CardBody } from "reactstrap";

interface JobCard {
  id: string;
  job_number: string;
  customer_name: string;
  registration_number: string;
  status: string;
  total_estimate: string;
  created_by_user: string;
  assigned_to_user: string | null;
  created_at: string;
}

interface ActivityCardBodyProps {
  recentJobCards?: JobCard[];
}

const ActivityCardBody: React.FC<ActivityCardBodyProps> = ({
  recentJobCards = [],
}) => {
  // Helper function to get color based on status
  const getStatusColor = (status: string): string => {
    switch (status.toLowerCase()) {
      case "completed":
        return "success";
      case "assigned":
        return "warning";
      case "in_progress":
        return "primary";
      case "open":
        return "info";
      default:
        return "secondary";
    }
  };

  // Transform job cards to the format expected by ActivityData
  const activities = recentJobCards.slice(0, 5).map((job) => ({
    title: `${job.customer_name} - Job #${job.job_number}`,
    subTitle: job.registration_number,
    dis: `Status: ${job.status} | Assigned to: ${
      job.assigned_to_user || "Not assigned"
    } | Total: $${parseFloat(job.total_estimate || "0").toFixed(2)}`,
    time: new Date(job.created_at).toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
    }),
    color: getStatusColor(job.status),
  }));

  // If no activities, show placeholder
  if (activities.length === 0) {
    return (
      <CardBody className="pt-0">
        <ul>
          {[1, 2, 3].map((item) => (
            <li key={item} className="d-flex">
              <div className="activity-dot-secondary" />
              <div className="w-100 ms-3">
                <p className="d-flex justify-content-between mb-2">
                  <span className="date-content light-background">No data</span>
                  <span>--:--</span>
                </p>
                <h6>
                  No recent activities
                  <span className="dot-notification" />
                </h6>
                <p className="f-light">Check back later for updates</p>
              </div>
            </li>
          ))}
        </ul>
      </CardBody>
    );
  }

  return (
    <CardBody className="pt-0">
      <ul>
        {activities.map((item, index) => (
          <li key={index} className="d-flex">
            <div className={`activity-dot-${item.color}`} />
            <div className="w-100 ms-3">
              <p className="d-flex justify-content-between mb-2">
                <span className="date-content light-background">
                  {item.subTitle}
                </span>
                <span>{item.time}</span>
              </p>
              <h6>
                {item.title}
                <span className="dot-notification" />
              </h6>
              <p className="f-light">{item.dis}</p>
            </div>
          </li>
        ))}
      </ul>
    </CardBody>
  );
};

export default ActivityCardBody;
