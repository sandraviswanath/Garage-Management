// import DropdownCommon from 'CommonElements/Dashboard/DropdownCommon'
// import React from 'react'
// import { Card, CardHeader, Col } from 'reactstrap'
// import { Activity, DailyDropdown } from '@/utils/Constant'
// import ActivityCardBody from './ActivityCardBody'
// import DropdownCommon from '@/CommonElements/Dashboard/DropdownCommon'

// const ActivityCard = () => {
//     return (
//         <Col xxl={4} xl={5} md={6} sm={7} className='notification box-col-6'>
//             <Card className='height-equal'>
//                 <CardHeader className='card-no-border'>
//                     <div className='header-top'>
//                         <h5 className='m-0'>{Activity}</h5>
//                         <div className='card-header-right-icon'>
//                             <DropdownCommon icon={false} options={DailyDropdown} btn={{ caret: true, color: 'Outline-primary' }} />
//                         </div>
//                     </div>
//                 </CardHeader>
//                 <ActivityCardBody />
//             </Card>
//         </Col>
//     )
// }

// export default ActivityCard

import React from "react";
import { Card, CardHeader, Col } from "reactstrap";
import { Activity, DailyDropdown } from "@/utils/Constant";
import ActivityCardBody from "./ActivityCardBody";
import DropdownCommon from "@/CommonElements/Dashboard/DropdownCommon";

// Define the interfaces locally or import them
interface JobCard {
  id: string;
  job_number: string;
  customer_name: string;
  registration_number: string;
  status: string;
  total_estimate: string;
  created_by_user: string;
  assigned_to_user: string | null;
  vehicle_id: string;
  created_at: string;
  updated_at: string;
  reported_issue?: string;
  diagnosis?: string;
  priority?: string;
}

interface TechnicianPerformance {
  assigned_to: string;
  total_jobs: string;
  assigned_username: string;
}

interface ActivityCardProps {
  recentJobCards?: JobCard[];
  technicianPerformance?: TechnicianPerformance[];
}

const ActivityCard = ({
  recentJobCards = [],
  technicianPerformance = [],
}: ActivityCardProps) => {
  return (
    <Col xxl={4} xl={6} md={6} sm={7} className="notification box-col-6">
      <Card className="height-equal">
        <CardHeader className="card-no-border">
          <div className="header-top">
            <h5 className="m-0">{Activity}</h5>
            <div className="card-header-right-icon">
              <DropdownCommon
                icon={false}
                options={DailyDropdown}
                btn={{ caret: true, color: "Outline-primary" }}
              />
            </div>
          </div>
        </CardHeader>
        <ActivityCardBody
          recentJobCards={recentJobCards}
          //   technicianPerformance={technicianPerformance}
        />
      </Card>
    </Col>
  );
};

export default ActivityCard;
