// import React from 'react'
// import { Col, Row } from 'reactstrap'
// import Widgets1 from '@/CommonElements/Widgets1'
// import { WidgetsData, WidgetsData3 } from '@/Data/Dashboard/DefaultData'

// const SalePurchase = () => {
//     return (
//         <Col xxl='auto' xl={3} sm={6} className='box-col-6'>
//             <Row>
//                 <Col xl={12}>
//                     <Widgets1 data={WidgetsData} />
//                 </Col>
//                 <Col xl={12}>
//                     <Widgets1 data={WidgetsData3} />
//                 </Col>
//             </Row>
//         </Col>
//     )
// }

// export default SalePurchase

// SalePurchase.tsx
import React from "react";
import { Col, Row } from "reactstrap";
import Widgets1 from "@/CommonElements/Widgets1";

interface SalePurchaseProps {
  revenue?: number;
  activeJobs?: number;
  pendingInvoices?: number;
  jobsInProgress?: number;
}

const SalePurchase = ({ revenue, activeJobs }: SalePurchaseProps) => {
  const activeJobsData = {
    title: "Active jobs",
    gros: 50,
    total: activeJobs?.toString() || "0",
    color: "secondary",
    icon: "cart",
  };

  const revenueData = {
    title: "Monthly revenue",
    gros: 70,
    total: `$${revenue?.toLocaleString() || "0"}`,
    color: "primary",
    icon: "tag",
  };

  return (
    <Col xxl="auto" xl={3} sm={6} className="box-col-6">
      <Row>
        <Col xl={12}>
          <Widgets1 data={activeJobsData} />
        </Col>
        <Col xl={12}>
          <Widgets1 data={revenueData} />
        </Col>
      </Row>
    </Col>
  );
};

export default SalePurchase;
