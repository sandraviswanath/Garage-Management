// import Widgets1 from '@/CommonElements/Widgets1'
// import { WidgetsData2, WidgetsData4 } from '@/Data/Dashboard/DefaultData'
// import React from 'react'
// import { Col, Row } from 'reactstrap'

// const GoodsReturn = () => {
//     return (
//         <Col xxl={'auto'} xl={3} sm={6} className='box-col-6'>
//             <Row>
//                 <Col xl={12}>
//                     <Widgets1 data={WidgetsData2} />
//                 </Col>
//                 <Col xl={12}>
//                     <Widgets1 data={WidgetsData4} />
//                 </Col>
//             </Row>
//         </Col>
//     )
// }

// export default GoodsReturn

import Widgets1 from "@/CommonElements/Widgets1";
import { WidgetsData2, WidgetsData4 } from "@/Data/Dashboard/DefaultData";
import React from "react";
import { Col, Row } from "reactstrap";
interface SalePurchaseProps {
  revenue?: number;
  activeJobs?: number;
  pendingInvoices?: number;
  jobsInProgress?: number;
}
const GoodsReturn = ({
  pendingInvoices,
  jobsInProgress,
}: SalePurchaseProps) => {
  const pendingInvoicesData = {
    title: "Pending invoices",
    gros: 20,
    total: pendingInvoices?.toString() || "0",
    color: "warning",
    icon: "return-box",
  };

  const jobsInProgressData = {
    title: "Jobs in progress",
    gros: 70,
    total: jobsInProgress?.toString() || "0",
    color: "success",
    icon: "rate",
  };

  return (
    <Col xxl={"auto"} xl={3} sm={6} className="box-col-6">
      <Row>
        <Col xl={12}>
          <Widgets1 data={pendingInvoicesData} />
        </Col>
        <Col xl={12}>
          <Widgets1 data={jobsInProgressData} />
        </Col>
      </Row>
    </Col>
  );
};

export default GoodsReturn;
