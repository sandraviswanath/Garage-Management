// import Widgets2 from "@/CommonElements/Widgets2";
// import { Widgets2Data, Widgets2Data2 } from "@/Data/Dashboard/DefaultData";
// import React from "react";
// import { Col, Row } from "reactstrap";

// const OrderProfit = () => {
//   return (
//     <Col xxl="auto" xl={12} sm={6} className="box-col-6">
//       <Row>
//         <Col xxl={12} xl={6} className="box-col-12">
//           <Widgets2 data={Widgets2Data} />
//         </Col>
//         <Col xxl={12} xl={6} className="box-col-12">
//           <Widgets2 chartClass="profit-chart " data={Widgets2Data2} />
//         </Col>
//       </Row>
//     </Col>
//   );
// };

// export default OrderProfit;

import Widgets2 from "@/CommonElements/Widgets2";
import React from "react";
import { Col, Row } from "reactstrap";

interface OrderProfitProps {
  jobsPerDay?: number;
  jobsPerMonth?: number;
  jobsPerWeek?: number;
}

const OrderProfit = ({
  jobsPerDay = 0,
  jobsPerMonth = 0,
  jobsPerWeek = 0,
}: OrderProfitProps) => {
  // Card 1: Daily
  const dailyCard = {
    title: "Daily Jobs",
    total: jobsPerDay.toString(), // Convert to string
    gross: "Target: 5 jobs/day",
    color: "primary",
    icon: "sunrise",
    percentage:
      jobsPerDay >= 5 ? "+100%" : `+${((jobsPerDay / 5) * 100).toFixed(0)}%`,
    chart: {
      series: [jobsPerDay],
      color: "primary",
      options: {
        chart: {
          height: 80,
          type: "radialBar" as const,
        },
        plotOptions: {
          radialBar: {
            hollow: {
              size: "60%",
            },
            dataLabels: {
              show: true,
              name: {
                show: false,
              },
              value: {
                show: true,
                fontSize: "20px",
                fontWeight: "bold",
                offsetY: 8,
              },
            },
          },
        },
        fill: {
          type: "solid",
          colors: ["#7366ff"],
        },
        stroke: {
          lineCap: "round" as const,
        },
      },
    },
    type: "radialBar" as const,
  };

  // Card 2: Weekly
  const weeklyCard = {
    title: "Weekly Jobs",
    total: jobsPerWeek.toString(), // Convert to string
    gross: "Target: 25 jobs/week",
    color: "success",
    icon: "calendar",
    percentage:
      jobsPerWeek >= 25
        ? "+100%"
        : `+${((jobsPerWeek / 25) * 100).toFixed(0)}%`,
    chart: {
      series: [jobsPerWeek],
      color: "success",
      options: {
        chart: {
          height: 80,
          type: "radialBar" as const,
        },
        plotOptions: {
          radialBar: {
            hollow: {
              size: "60%",
            },
            dataLabels: {
              show: true,
              name: {
                show: false,
              },
              value: {
                show: true,
                fontSize: "20px",
                fontWeight: "bold",
                offsetY: 8,
              },
            },
          },
        },
        fill: {
          type: "solid",
          colors: ["#51bb25"],
        },
        stroke: {
          lineCap: "round" as const,
        },
      },
    },
    type: "radialBar" as const,
  };

  // Card 3: Monthly
  const monthlyCard = {
    title: "Monthly Jobs",
    total: jobsPerMonth.toString(), // Convert to string
    gross: "Target: 100 jobs/month",
    color: "warning",
    icon: "trending-up",
    percentage:
      jobsPerMonth >= 100
        ? "+100%"
        : `+${((jobsPerMonth / 100) * 100).toFixed(0)}%`,
    chart: {
      series: [Math.min(jobsPerMonth, 100)],
      color: "warning",
      options: {
        chart: {
          height: 80,
          type: "radialBar" as const,
        },
        plotOptions: {
          radialBar: {
            hollow: {
              size: "60%",
            },
            dataLabels: {
              show: true,
              name: {
                show: false,
              },
              value: {
                show: true,
                fontSize: "20px",
                fontWeight: "bold",
                offsetY: 8,
              },
            },
          },
        },
        fill: {
          type: "solid",
          colors: ["#f8d62b"],
        },
        stroke: {
          lineCap: "round" as const,
        },
      },
    },
    type: "radialBar" as const,
  };

  return (
    <Col xxl="auto" xl={12} sm={6} className="box-col-6">
      <Row>
        <Col xxl={12} xl={4} className="box-col-12 mb-3">
          <Widgets2 data={dailyCard} />
        </Col>

        <Col xxl={12} xl={4} className="box-col-12 mb-3">
          <Widgets2 data={weeklyCard} />
        </Col>

        <Col xxl={12} xl={4} className="box-col-12 mb-3">
          <Widgets2 data={monthlyCard} />
        </Col>
      </Row>
    </Col>
  );
};

export default OrderProfit;
