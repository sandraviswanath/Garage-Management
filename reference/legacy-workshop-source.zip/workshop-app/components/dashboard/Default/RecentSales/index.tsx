// import DropdownCommon from "@/CommonElements/Dashboard/DropdownCommon";
// import React from "react";
// import { Card, CardHeader, Col } from "reactstrap";
// import { DailyDropdown, RecentSalesTitle } from "@/utils/Constant";
// import SalesBody from "./SalesBody";

// const RecentSales = () => {
//   return (
//     <Col xxl={4} md={6} className="appointment-sec box-col-6">
//       <div className="appointment">
//         <Card>
//           <CardHeader className="card-no-border">
//             <div className="header-top">
//               {/* <h5 className='m-0'>{RecentSalesTitle}</h5> */}
//               <h5 className="m-0">Quick Links</h5>
//               <div className="card-header-right-icon">
//                 <DropdownCommon
//                   icon={false}
//                   options={DailyDropdown}
//                   btn={{ caret: true, color: "Outline-primary" }}
//                 />
//               </div>
//             </div>
//           </CardHeader>
//           <SalesBody />
//         </Card>
//       </div>
//     </Col>
//   );
// };

// export default RecentSales;

import DropdownCommon from "@/CommonElements/Dashboard/DropdownCommon";
import React from "react";
import { Card, CardHeader, Col } from "reactstrap";
import { DailyDropdown } from "@/utils/Constant";
import SalesBody from "./SalesBody";

// Define interfaces locally
interface TechnicianPerformance {
  assigned_to: string;
  total_jobs: string;
  assigned_username: string;
}

interface JobCard {
  id: string;
  job_number: string;
  customer_name: string;
  registration_number: string;
  status: string;
  total_estimate: string;
  created_by_user: string;
  assigned_to_user: string | null;
  vehicle_id: string;
  created_at: string;
  updated_at: string;
}

interface RecentSalesProps {
  technicianPerformance?: TechnicianPerformance[];
  recentJobCards?: JobCard[];
}

const RecentSales = ({
  technicianPerformance = [],
  recentJobCards = [],
}: RecentSalesProps) => {
  return (
    <Col xxl={4} md={6} className="appointment-sec box-col-6">
      <div className="appointment">
        <Card>
          <CardHeader className="card-no-border">
            <div className="header-top">
              <h5 className="m-0">Technician Performance</h5>
              <div className="card-header-right-icon">
                <DropdownCommon
                  icon={false}
                  options={DailyDropdown}
                  btn={{ caret: true, color: "Outline-primary" }}
                />
              </div>
            </div>
          </CardHeader>
          <SalesBody
            technicianPerformance={technicianPerformance}
            // recentJobCards={recentJobCards}
          />
        </Card>
      </div>
    </Col>
  );
};

export default RecentSales;

// import DropdownCommon from "@/CommonElements/Dashboard/DropdownCommon";
// import React from "react";
// import { Card, CardHeader, Col } from "reactstrap";
// import { DailyDropdown } from "@/utils/Constant";
// import SalesBody from "./SalesBody";

// const RecentSales = () => {
//   return (
//     <Col xxl={4} md={6} className="appointment-sec box-col-6">
//       <div className="appointment">
//         <Card>
//           <CardHeader className="card-no-border">
//             <div className="header-top">
//               <h5 className="m-0">Quick Actions</h5>
//               <div className="card-header-right-icon">
//                 <DropdownCommon
//                   icon={false}
//                   options={DailyDropdown}
//                   btn={{ caret: true, color: "Outline-primary" }}
//                 />
//               </div>
//             </div>
//           </CardHeader>
//           <SalesBody />
//         </Card>
//       </div>
//     </Col>
//   );
// };

// export default RecentSales;
