// import { RecentSalesData } from "@/Data/Dashboard/DefaultData";
// import Link from "next/link";
// import React from "react";
// import { CardBody, Table } from "reactstrap";
// import { ImgPath } from "@/utils/Constant";

// const SalesBody = () => {
//   return (
//     <CardBody className="pt-0">
//       <div className="appointment-table table-responsive">
//         <Table className="table-bordernone">
//           <tbody>
//             {RecentSalesData &&
//               RecentSalesData.map((item, i) => (
//                 <tr key={i}>
//                   <td>
//                     <img
//                       className="img-fluid img-40 rounded-circle"
//                       src={`${ImgPath}/${item.image}`}
//                       alt="user"
//                     />
//                   </td>
//                   <td className="img-content-box">
//                     <Link
//                       className="d-block f-w-500"
//                       href={`/admin/jobcards/create`}
//                     >
//                       {item.title}
//                       {/* Create Job cards */}
//                     </Link>
//                     <span className="f-light">{item.subTitle}</span>
//                   </td>
//                   <td className="text-end">
//                     {/* <p className="m-0 font-success">{item.badge}</p> */}
//                     <Link href="/admin/jobcards/create">
//                       <button className="btn btn-outline-success btn-xs">
//                         View
//                       </button>
//                     </Link>
//                   </td>
//                 </tr>
//               ))}
//           </tbody>
//         </Table>
//       </div>
//     </CardBody>
//   );
// };

// export default SalesBody;

// import Link from "next/link";
// import React from "react";
// import { CardBody, Table } from "reactstrap";

// const SalesBody = () => {
//   const menuItems = [
//     {
//       title: "Create Job cards",
//       description: "Create job cards",
//       href: "/admin/jobcards/create",
//       icon: (
//         <svg
//           className="img-fluid img-40"
//           fill="currentColor"
//           viewBox="0 0 24 24"
//         >
//           <path d="M19 3h-4.18C14.4 1.84 13.3 1 12 1c-1.3 0-2.4.84-2.82 2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 0c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm2 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z" />
//         </svg>
//       ),
//     },
//     {
//       title: "Pending Invoices",
//       description: "Pending invoices",
//       href: "/admin/invoices",
//       icon: (
//         <svg
//           className="img-fluid img-40"
//           fill="currentColor"
//           viewBox="0 0 24 24"
//         >
//           <path d="M20 4H4c-1.11 0-1.99.89-1.99 2L2 18c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V6c0-1.11-.89-2-2-2zm-5 14H4v-4h11v4zm0-5H4V9h11v4zm5 5h-4V9h4v9z" />
//         </svg>
//       ),
//     },
//     {
//       title: "Create Invoice",
//       description: "Create invoice",
//       href: "/admin/invoices/create",
//       icon: (
//         <svg
//           className="img-fluid img-40"
//           fill="currentColor"
//           viewBox="0 0 24 24"
//         >
//           <path d="M19 3h-4.18C14.4 1.84 13.3 1 12 1c-1.3 0-2.4.84-2.82 2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 0c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm2 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z" />
//         </svg>
//       ),
//     },
//     {
//       title: "Search Vehicles",
//       description: "Search vehicles",
//       href: "/admin/vehicles",
//       icon: (
//         <svg
//           className="img-fluid img-40"
//           fill="currentColor"
//           viewBox="0 0 24 24"
//         >
//           <path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z" />
//         </svg>
//       ),
//     },
//   ];

//   return (
//     <CardBody className="pt-0">
//       <div className="appointment-table table-responsive">
//         <Table className="table-bordernone">
//           <tbody>
//             {menuItems.map((item, index) => (
//               <tr key={index}>
//                 <td>
//                   <div className="img-fluid img-40 rounded-circle d-flex align-items-center justify-content-center bg-light text-primary">
//                     {item.icon}
//                   </div>
//                 </td>
//                 <td className="img-content-box">
//                   <Link className="d-block f-w-500" href={item.href}>
//                     {item.title}
//                   </Link>
//                   <span className="f-light">{item.description}</span>
//                 </td>
//                 <td className="text-end">
//                   <Link href={item.href}>
//                     <button className="btn btn-outline-success btn-xs">
//                       View
//                     </button>
//                   </Link>
//                 </td>
//               </tr>
//             ))}
//           </tbody>
//         </Table>
//       </div>
//     </CardBody>
//   );
// };

// export default SalesBody;
// import Link from "next/link";
// import React from "react";
// import { CardBody, Table } from "reactstrap";

// interface TechnicianPerformance {
//   assigned_to: string;
//   total_jobs: string;
//   assigned_username: string;
// }

// interface JobCard {
//   id: string;
//   job_number: string;
//   customer_name: string;
//   registration_number: string;
//   status: string;
//   total_estimate: string;
//   created_by_user: string;
//   assigned_to_user: string | null;
//   vehicle_id: string;
//   created_at: string;
// }

// interface SalesBodyProps {
//   technicianPerformance?: TechnicianPerformance[];
//   recentJobCards?: JobCard[];
// }

// const SalesBody = ({
//   technicianPerformance = [],
//   recentJobCards = [],
// }: SalesBodyProps) => {
//   // If you want to keep the quick links but show technician stats as well:
//   const showTechnicianPerformance = technicianPerformance.length > 0;

//   if (!showTechnicianPerformance) {
//     // Fallback to quick links if no technician data
//     const menuItems = [
//       {
//         title: "Create Job cards",
//         description: "Create job cards",
//         href: "/admin/jobcards/create",
//         icon: (
//           <svg
//             className="img-fluid img-40"
//             fill="currentColor"
//             viewBox="0 0 24 24"
//           >
//             <path d="M19 3h-4.18C14.4 1.84 13.3 1 12 1c-1.3 0-2.4.84-2.82 2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 0c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm2 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z" />
//           </svg>
//         ),
//       },
//       {
//         title: "Pending Invoices",
//         description: "Pending invoices",
//         href: "/admin/invoices",
//         icon: (
//           <svg
//             className="img-fluid img-40"
//             fill="currentColor"
//             viewBox="0 0 24 24"
//           >
//             <path d="M20 4H4c-1.11 0-1.99.89-1.99 2L2 18c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V6c0-1.11-.89-2-2-2zm-5 14H4v-4h11v4zm0-5H4V9h11v4zm5 5h-4V9h4v9z" />
//           </svg>
//         ),
//       },
//       {
//         title: "Create Invoice",
//         description: "Create invoice",
//         href: "/admin/invoices/create",
//         icon: (
//           <svg
//             className="img-fluid img-40"
//             fill="currentColor"
//             viewBox="0 0 24 24"
//           >
//             <path d="M19 3h-4.18C14.4 1.84 13.3 1 12 1c-1.3 0-2.4.84-2.82 2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 0c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm2 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z" />
//           </svg>
//         ),
//       },
//       {
//         title: "Search Vehicles",
//         description: "Search vehicles",
//         href: "/admin/vehicles",
//         icon: (
//           <svg
//             className="img-fluid img-40"
//             fill="currentColor"
//             viewBox="0 0 24 24"
//           >
//             <path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z" />
//           </svg>
//         ),
//       },
//     ];

//     return (
//       <CardBody className="pt-0">
//         <div className="appointment-table table-responsive">
//           <Table className="table-bordernone">
//             <tbody>
//               {menuItems.map((item, index) => (
//                 <tr key={index}>
//                   <td>
//                     <div className="img-fluid img-40 rounded-circle d-flex align-items-center justify-content-center bg-light text-primary">
//                       {item.icon}
//                     </div>
//                   </td>
//                   <td className="img-content-box">
//                     <Link className="d-block f-w-500" href={item.href}>
//                       {item.title}
//                     </Link>
//                     <span className="f-light">{item.description}</span>
//                   </td>
//                   <td className="text-end">
//                     <Link href={item.href}>
//                       <button className="btn btn-outline-success btn-xs">
//                         View
//                       </button>
//                     </Link>
//                   </td>
//                 </tr>
//               ))}
//             </tbody>
//           </Table>
//         </div>
//       </CardBody>
//     );
//   }

//   // Show technician performance data
//   return (
//     <CardBody className="pt-0">
//       <div className="appointment-table table-responsive">
//         <Table className="table-bordernone">
//           <thead>
//             <tr>
//               <th>Technician</th>
//               <th className="text-center">Jobs</th>
//               <th className="text-end">Performance</th>
//             </tr>
//           </thead>
//           <tbody>
//             {technicianPerformance.map((tech, index) => {
//               const jobCount = parseInt(tech.total_jobs);
//               const performance =
//                 jobCount >= 3
//                   ? "Excellent"
//                   : jobCount >= 2
//                   ? "Good"
//                   : "Average";
//               const performanceColor =
//                 jobCount >= 3
//                   ? "success"
//                   : jobCount >= 2
//                   ? "warning"
//                   : "secondary";

//               return (
//                 <tr key={tech.assigned_to || index}>
//                   <td>
//                     <div className="d-flex align-items-center">
//                       <div className="img-fluid img-40 rounded-circle d-flex align-items-center justify-content-center bg-light-primary text-primary me-2">
//                         <span className="f-w-600">
//                           {tech.assigned_username.charAt(0)}
//                         </span>
//                       </div>
//                       <div>
//                         <span className="d-block f-w-500">
//                           {tech.assigned_username}
//                         </span>
//                         <small className="text-muted">Technician</small>
//                       </div>
//                     </div>
//                   </td>
//                   <td className="text-center">
//                     <h5 className="mb-0">{tech.total_jobs}</h5>
//                     <small className="text-muted">Completed</small>
//                   </td>
//                   <td className="text-end">
//                     <span className={`badge badge-light-${performanceColor}`}>
//                       {performance}
//                     </span>
//                   </td>
//                 </tr>
//               );
//             })}
//           </tbody>
//         </Table>

//         {/* Summary Statistics */}
//         <div className="mt-3 pt-3 border-top">
//           <div className="row text-center">
//             <div className="col-6 border-end">
//               <h5 className="mb-0">
//                 {technicianPerformance.reduce(
//                   (sum, tech) => sum + parseInt(tech.total_jobs),
//                   0
//                 )}
//               </h5>
//               <small className="text-muted">Total Jobs</small>
//             </div>
//             <div className="col-6">
//               <h5 className="mb-0">{technicianPerformance.length}</h5>
//               <small className="text-muted">Active Technicians</small>
//             </div>
//           </div>
//         </div>
//       </div>
//     </CardBody>
//   );
// };

// export default SalesBody;

import Link from "next/link";
import React from "react";
import { CardBody, Table, Row, Col } from "reactstrap";

interface TechnicianPerformance {
  assigned_to: string;
  total_jobs: string;
  assigned_username: string;
}

interface SalesBodyProps {
  technicianPerformance?: TechnicianPerformance[];
}

const SalesBody = ({ technicianPerformance = [] }: SalesBodyProps) => {
  const menuItems = [
    {
      title: "Create Job cards",
      description: "Create job cards",
      href: "/admin/jobcards/create",
      icon: "📝",
    },
    {
      title: "Pending Invoices",
      description: "Pending invoices",
      href: "/admin/invoices",
      icon: "📋",
    },
    {
      title: "Create Invoice",
      description: "Create invoice",
      href: "/admin/invoices/create",
      icon: "🧾",
    },
    {
      title: "Search Vehicles",
      description: "Search vehicles",
      href: "/admin/vehicles",
      icon: "🚗",
    },
  ];

  return (
    <CardBody className="pt-0">
      {/* Quick Links Section */}
      <div className="mb-4">
        <h6 className="mb-3">Quick Actions</h6>
        <Row className="g-2">
          {menuItems.map((item, index) => (
            <Col xs={6} key={index}>
              <Link href={item.href} className="text-decoration-none">
                <div className="card h-100 border hover-shadow">
                  <div className="card-body text-center p-2">
                    <div className="mb-2">{item.icon}</div>
                    <h6 className="mb-1 f-w-500">{item.title}</h6>
                    <small className="text-muted">{item.description}</small>
                  </div>
                </div>
              </Link>
            </Col>
          ))}
        </Row>
      </div>

      {/* Technician Performance Section */}
      {technicianPerformance.length > 0 && (
        <div className="mt-4 pt-3 border-top">
          <h6 className="mb-3">Technician Performance</h6>
          <div className="table-responsive">
            <Table className="table-bordernone">
              <tbody>
                {technicianPerformance.map((tech, index) => (
                  <tr key={index}>
                    <td>
                      <div className="d-flex align-items-center">
                        <div
                          className="rounded-circle bg-light-primary d-flex align-items-center justify-content-center me-2"
                          style={{ width: "36px", height: "36px" }}
                        >
                          <span className="f-w-600">
                            {tech.assigned_username.charAt(0)}
                          </span>
                        </div>
                        <span className="f-w-500">
                          {tech.assigned_username}
                        </span>
                      </div>
                    </td>
                    <td className="text-center">
                      <span className="badge badge-light-primary">
                        {tech.total_jobs} jobs
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </div>
        </div>
      )}
    </CardBody>
  );
};

export default SalesBody;

// import Link from "next/link";
// import React from "react";
// import { CardBody, Table, Row, Col } from "reactstrap";

// const SalesBody = () => {
//   const menuItems = [
//     {
//       title: "Create Job cards",
//       description: "Create job cards",
//       href: "/admin/jobcards/create",
//       icon: "📝",
//     },
//     {
//       title: "Pending Invoices",
//       description: "Pending invoices",
//       href: "/admin/invoices",
//       icon: "📋",
//     },
//     {
//       title: "Create Invoice",
//       description: "Create invoice",
//       href: "/admin/invoices/create",
//       icon: "🧾",
//     },
//     {
//       title: "Search Vehicles",
//       description: "Search vehicles",
//       href: "/admin/vehicles",
//       icon: "🚗",
//     },
//   ];

//   return (
//     <CardBody className="pt-0">
//       {/* Quick Links Section */}
//       <div className="mb-4">
//         <h6 className="mb-3">Quick Actions</h6>
//         <Row className="g-2">
//           {menuItems.map((item, index) => (
//             <Col xs={6} key={index}>
//               <Link href={item.href} className="text-decoration-none">
//                 <div className="card h-100 border hover-shadow">
//                   <div className="card-body text-center p-2">
//                     <div className="mb-2">{item.icon}</div>
//                     <h6 className="mb-1 f-w-500">{item.title}</h6>
//                     <small className="text-muted">{item.description}</small>
//                   </div>
//                 </div>
//               </Link>
//             </Col>
//           ))}
//         </Row>
//       </div>

//       {/* Additional Stats or Info */}
//       {/* <div className="mt-4 pt-3 border-top">
//         <h6 className="mb-3">Dashboard Tips</h6>
//         <ul className="list-unstyled mb-0">
//           <li className="mb-2">
//             <small className="text-muted">
//               • Check pending invoices regularly
//             </small>
//           </li>
//           <li className="mb-2">
//             <small className="text-muted">
//               • Assign jobs to available technicians
//             </small>
//           </li>
//           <li className="mb-2">
//             <small className="text-muted">
//               • Update job status when completed
//             </small>
//           </li>
//           <li>
//             <small className="text-muted">• Generate invoices promptly</small>
//           </li>
//         </ul>
//       </div> */}
//     </CardBody>
//   );
// };

// export default SalesBody;
