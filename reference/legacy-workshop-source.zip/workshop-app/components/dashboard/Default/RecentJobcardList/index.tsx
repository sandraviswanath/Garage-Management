// import React from "react";

// function RecentJobcardList() {
//   return (
//     <div className="col-xl-12">
//       <div className="card">
//         <div className="card-no-border card-header">
//           <div className="header-top">
//             <h5>Recent Jobcards</h5>
//           </div>
//         </div>
//         <div className="pt-0 card-body">
//           <div className="recent-table table-responsive currency-table">
//             <table className="table">
//               <thead>
//                 <tr>
//                   <th className="f-light">Customer</th>
//                   <th className="f-light">Job Type</th>
//                   <th className="f-light">Vehicle</th>
//                   <th className="f-light">Estimated Cost</th>
//                   <th className="f-light">Technician</th>

//                   <th className="f-light">Action</th>
//                 </tr>
//               </thead>
//               <tbody>
//                 <tr>
//                   <td>
//                     <div className="d-flex align-items-center gap-2">
//                       <div className="currency-icon warning">
//                         <svg>
//                           <use href="/cuba-context/svg/sprite.svg#beta" />
//                         </svg>
//                       </div>
//                       <div>
//                         <h6 className="f-14 mb-0 f-w-400">Bitcoin</h6>
//                       </div>
//                     </div>
//                   </td>
//                   <td>$13098.09</td>
//                   <td>
//                     <div className="change-currency font-success">
//                       <svg
//                         xmlns="http://www.w3.org/2000/svg"
//                         width={24}
//                         height={24}
//                         viewBox="0 0 24 24"
//                         fill="none"
//                         stroke="currentColor"
//                         strokeWidth={2}
//                         strokeLinecap="round"
//                         strokeLinejoin="round"
//                         className="me-1"
//                       >
//                         <polyline points="23 6 13.5 15.5 8.5 10.5 1 18" />
//                         <polyline points="17 6 23 6 23 12" />
//                       </svg>
//                       5.9
//                     </div>
//                   </td>
//                   <td>$74871.47</td>
//                   <td>1.09634721</td>
//                   <td>
//                     <button className="btn badge-light-primary">Trade</button>
//                   </td>
//                 </tr>
//               </tbody>
//             </table>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// }

// export default RecentJobcardList;

import React from "react";

interface JobCard {
  id: string;
  job_number: string;
  customer_name: string;
  registration_number: string;
  status: string;
  total_estimate: string;
  created_by_user: string;
  assigned_to_user: string | null;
  vehicle_id: string;
  // You can add more fields as needed
}

interface RecentJobcardListProps {
  jobCards: JobCard[];
}

function RecentJobcardList({ jobCards = [] }: RecentJobcardListProps) {
  // Helper function to get status badge color
  const getStatusBadge = (status: string) => {
    switch (status.toLowerCase()) {
      case "open":
        return "badge-light-warning";
      case "in_progress":
      case "in progress":
        return "badge-light-primary";
      case "completed":
        return "badge-light-success";
      case "cancelled":
        return "badge-light-danger";
      default:
        return "badge-light-secondary";
    }
  };

  // Format currency
  const formatCurrency = (amount: string) => {
    const num = parseFloat(amount);
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 2,
    }).format(num);
  };

  return (
    <div className="col-xl-12">
      <div className="card">
        <div className="card-no-border card-header">
          <div className="header-top">
            <h5>Recent Jobcards</h5>
          </div>
        </div>
        <div className="pt-0 card-body">
          <div className="recent-table table-responsive currency-table">
            <table className="table">
              <thead>
                <tr>
                  <th className="f-light">Job Number</th>
                  <th className="f-light">Customer</th>
                  <th className="f-light">Vehicle</th>
                  <th className="f-light">Status</th>
                  <th className="f-light">Estimated Cost</th>
                  <th className="f-light">Created By</th>
                  <th className="f-light">Assigned To</th>
                  <th className="f-light">Action</th>
                </tr>
              </thead>
              <tbody>
                {jobCards.length > 0 ? (
                  jobCards.map((job) => (
                    <tr key={job.id}>
                      <td>
                        {/* <div className="d-flex align-items-center gap-2">
                          <div className="currency-icon warning">
                            <svg>
                              <use href="/cuba-context/svg/sprite.svg#beta" />
                            </svg>
                          </div>
                          <div>
                            <h6 className="f-14 mb-0 f-w-400">
                              {job.job_number}
                            </h6>
                          </div>
                        </div> */}
                        <h6 className="f-14 mb-0 f-w-400">{job.job_number}</h6>
                      </td>
                      <td>{job.customer_name}</td>
                      <td>{job.registration_number}</td>
                      <td>
                        <span className={`badge ${getStatusBadge(job.status)}`}>
                          {job.status.charAt(0).toUpperCase() +
                            job.status.slice(1)}
                        </span>
                      </td>
                      <td>{formatCurrency(job.total_estimate)}</td>
                      <td>{job.created_by_user}</td>
                      <td>{job.assigned_to_user || "Not Assigned"}</td>
                      <td>
                        <button className="btn badge-light-primary">
                          View Details
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={8} className="text-center py-4">
                      No recent job cards found
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

export default RecentJobcardList;
