// import React from "react";
// import { Button, Card, CardBody, Col, Media } from "reactstrap";
// import {
//   ImgPath,
//   Welcometext,
//   Welcometocuba,
//   WhatsNew,
// } from "@/utils/Constant";
// import ClockMain from "./Clock";

// const GreetingCard = () => {
//   return (
//     <Col xxl={4} sm={6} className="box-col-6">
//       <Card className="profile-box">
//         <CardBody>
//           <Media className="media-wrapper justify-content-between">
//             <Media body>
//               <div className="greeting-user">
//                 <h4 className="f-w-600">{Welcometocuba}</h4>
//                 <p>{Welcometext}</p>
//                 <div className="whatsnew-btn">
//                   <Button color="" className="btn btn-outline-white" href="#">
//                     {WhatsNew}
//                   </Button>
//                 </div>
//               </div>
//             </Media>
//             <ClockMain />
//             <div className="cartoon">
//               <img
//                 className="img-fluid"
//                 src={`${ImgPath}/dashboard/cartoon.svg`}
//                 alt="vector women with leptop"
//               />
//             </div>
//           </Media>
//         </CardBody>
//       </Card>
//     </Col>
//   );
// };

// export default GreetingCard;

// import React from "react";
// import { Button, Card, CardBody, Col, Media } from "reactstrap";
// import {
//   ImgPath,
//   Welcometext,
//   Welcometocuba,
//   WhatsNew,
// } from "@/utils/Constant";
// import ClockMain from "./Clock";

// interface GreetingCardProps {
//   username?: string;
//   dailyJobs?: number;
//   totalJobsThisMonth?: number;
// }

// const GreetingCard = ({
//   username,
//   dailyJobs = 0,
//   totalJobsThisMonth = 0,
// }: GreetingCardProps) => {
//   return (
//     <Col xxl={4} sm={6} className="box-col-6">
//       <Card className="profile-box">
//         <CardBody>
//           <Media className="media-wrapper justify-content-between">
//             <Media body>
//               <div className="greeting-user">
//                 <h4 className="f-w-600">Welcome, {username || "Admin"}!</h4>
//                 <p>{Welcometext} Here's your dashboard overview for today.</p>

//                 {/* Display job statistics */}
//                 <div className="job-stats mt-3">
//                   <div className="d-flex align-items-center mb-2">
//                     <span className="f-w-500 me-2">Today's Jobs:</span>
//                     <span
//                       className={`badge ${
//                         dailyJobs > 0
//                           ? "badge-light-success"
//                           : "badge-light-secondary"
//                       } f-w-600`}
//                     >
//                       {dailyJobs}
//                     </span>
//                   </div>

//                   <div className="d-flex align-items-center">
//                     <span className="f-w-500 me-2">This Month:</span>
//                     <span className="badge badge-light-primary f-w-600">
//                       {totalJobsThisMonth} jobs
//                     </span>
//                   </div>
//                 </div>

//                 <div className="whatsnew-btn mt-3">
//                   <Button color="" className="btn btn-outline-white" href="#">
//                     {WhatsNew}
//                   </Button>
//                 </div>
//               </div>
//             </Media>
//             <ClockMain />
//             <div className="cartoon">
//               <img
//                 className="img-fluid"
//                 src={`${ImgPath}/dashboard/cartoon.svg`}
//                 alt="vector women with leptop"
//               />
//             </div>
//           </Media>
//         </CardBody>
//       </Card>
//     </Col>
//   );
// };

// export default GreetingCard;

import React from "react";
import { Button, Card, CardBody, Col, Media } from "reactstrap";
import {
  ImgPath,
  Welcometext,
  Welcometocuba,
  WhatsNew,
} from "@/utils/Constant";
import ClockMain from "./Clock";

interface GreetingCardProps {
  username?: string;
  dailyJobs?: number;
  totalJobsThisMonth?: number;
}

const GreetingCard = ({
  username,
  dailyJobs = 0,
  totalJobsThisMonth = 0,
}: GreetingCardProps) => {
  return (
    <Col xxl={4} sm={6} className="box-col-6">
      <Card className="profile-box">
        <CardBody>
          <Media className="media-wrapper justify-content-between">
            <Media body>
              <div className="greeting-user">
                <h4 className="f-w-600 mb-1">
                  {Welcometocuba}, {username || "Admin"}!
                </h4>
                <p className="mb-2">{Welcometext}</p>

                {/* Quick Stats */}
                <div className="quick-stats d-flex gap-3 mb-3">
                  <div className="stat-item">
                    <span className="f-w-500">Today:</span>
                    <span className="ms-1 f-w-600 text-primary">
                      {dailyJobs}
                    </span>
                  </div>
                  <div className="stat-item">
                    <span className="f-w-500">Month:</span>
                    <span className="ms-1 f-w-600 text-success">
                      {totalJobsThisMonth}
                    </span>
                  </div>
                </div>

                <div className="whatsnew-btn">
                  <Button color="" className="btn btn-outline-white" href="#">
                    {WhatsNew}
                  </Button>
                </div>
              </div>
            </Media>
            <ClockMain />
            <div className="cartoon">
              <img
                className="img-fluid"
                src={`${ImgPath}/dashboard/cartoon.svg`}
                alt="vector women with leptop"
              />
            </div>
          </Media>
        </CardBody>
      </Card>
    </Col>
  );
};

export default GreetingCard;
