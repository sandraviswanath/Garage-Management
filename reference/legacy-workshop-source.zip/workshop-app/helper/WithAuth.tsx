// import { useRouter } from "next/router";
// // import { useRouter } from "next/navigation";
// import { useEffect } from "react";

// const withAuth = <P extends object>(
//   WrappedComponent: React.ComponentType<P>
// ) => {
//   const AuthenticatedComponent: React.FC<P> = (props) => {
//     const router = useRouter();

//     useEffect(() => {
//       const token = localStorage.getItem("token");

//       if (!token) {
//         router.push("/login");
//       }
//     }, []);

//     return <WrappedComponent {...props} />;
//   };

//   return AuthenticatedComponent;
// };

// export default withAuth;

// components/withAuth.tsx

"use client";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { jwtDecode } from "jwt-decode";

type Role = "admin" | "receptionist" | "technician";

const withAuth = <P extends object>(
  WrappedComponent: React.ComponentType<P>,
  allowedRoles: Role[] = []
): React.FC<P> => {
  return (props: P) => {
    const [authState, setAuthState] = useState({
      isAuthenticated: false,
      loading: true,
    });
    const router = useRouter();

    useEffect(() => {
      const verifyToken = () => {
        const token = localStorage.getItem("token");
        if (!token) {
          router.push("/login");
          return;
        }

        try {
          const decoded: { exp?: number } = jwtDecode(token);
          if (decoded.exp && decoded.exp * 1000 < Date.now()) {
            localStorage.removeItem("token");
            router.push("/login");
            return;
          }

          const role = localStorage.getItem("role");
          if (
            allowedRoles.length &&
            (!role || !allowedRoles.includes(role as Role))
          ) {
            const rolePaths = {
              receptionist: "/receptionist",
              admin: "/admin",
              technician: "/technician",
            };
            router.push(
              rolePaths[role as keyof typeof rolePaths] || "/unauthorized"
            );
            return;
          }

          setAuthState({ isAuthenticated: true, loading: false });
        } catch (error) {
          localStorage.removeItem("token");
          localStorage.removeItem("role");
          router.push("/login");
        }
      };

      verifyToken();
    }, [router]);

    if (authState.loading || !authState.isAuthenticated) {
      return (
        <div className="app-preloader fixed z-50 grid h-full w-full place-content-center bg-slate-50 dark:bg-navy-900">
          <div className="relative inline-block size-48" />
        </div>
      );
    }

    // ✅ Render only after verified
    return <WrappedComponent {...props} />;
  };
};

export default withAuth;
