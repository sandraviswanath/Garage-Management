// import {
//   createContext,
//   useContext,
//   useReducer,
//   useEffect,
//   ReactNode,
// } from "react";

// type User = {
//   user_name: string;
//   user_type: string;
//   default_lang: string;
//   full_name: string;
//   email: string;
//   avatar: string;
//   user_photo: string | null;

//   package_id: string;
//   token: string;
//   [key: string]: any;
// };

// interface AuthState {
//   user: User | null;
//   accessToken: string | null;
//   refreshToken: string | null;
// }

// interface AuthContextProps {
//   state: AuthState;
//   setAuthData: (data: {
//     user: User;
//     accessToken: string;
//     refreshToken: string;
//   }) => void;
//   updateUser: (updatedUserFields: Partial<User>) => void;
//   clearAuthData: () => void;
//   isAuthenticated: () => boolean;
// }

// const AuthContext = createContext<AuthContextProps | null>(null);

// export const useAuth = () => {
//   const context = useContext(AuthContext);
//   if (!context) {
//     throw new Error("useAuth must be used within an AuthProvider");
//   }
//   return context;
// };

// const initialState: AuthState = {
//   user: null,

//   accessToken: null,
//   refreshToken: null,
// };

// const authReducer = (state: AuthState, action: any): AuthState => {
//   switch (action.type) {
//     case "SET_USER":
//       return {
//         ...state,
//         user: action.payload.user,
//         accessToken: action.payload.accessToken,
//         refreshToken: action.payload.refreshToken,
//       };
//     case "UPDATE_USER":
//       return {
//         ...state,
//         user: {
//           ...state.user,
//           ...action.payload,
//         },
//       };
//     case "CLEAR_USER":
//       return initialState;
//     default:
//       return state;
//   }
// };

// export const AuthProvider = ({ children }: { children: ReactNode }) => {
//   const [state, dispatch] = useReducer(authReducer, initialState);

//   useEffect(() => {
//     const storedAuthData = localStorage.getItem("authData");
//     if (storedAuthData) {
//       const parsedAuthData = JSON.parse(storedAuthData);
//       dispatch({
//         type: "SET_USER",
//         payload: {
//           name: parsedAuthData.name,
//           username: parsedAuthData.username,
//           user_photo: parsedAuthData.user_photo,
//           user: parsedAuthData.user,
//           accessToken: parsedAuthData.accessToken,
//           refreshToken: parsedAuthData.refreshToken,
//           code: parsedAuthData.code,
//         },
//       });
//     }
//   }, []);

//   const setAuthData = (data: {
//     user: User;
//     accessToken: string;
//     refreshToken: string;
//   }) => {
//     const authData = {
//       user: data.user,
//       accessToken: data.accessToken,
//       refreshToken: data.refreshToken,
//     };

//     dispatch({ type: "SET_USER", payload: authData });
//     localStorage.setItem("authData", JSON.stringify(authData));
//     localStorage.setItem("token", data.accessToken);
//     localStorage.setItem("role", data.user.user_type);
//   };

//   const updateUser = (updatedUserFields: Partial<User>) => {
//     const storedAuthData = localStorage.getItem("authData");
//     if (!storedAuthData) return;

//     try {
//       const parsed = JSON.parse(storedAuthData);
//       const updatedUser = {
//         ...parsed.user,
//         ...updatedUserFields,
//       };
//       const updatedAuthData = {
//         ...parsed,
//         user: updatedUser,
//       };

//       dispatch({ type: "UPDATE_USER", payload: updatedUserFields });
//       localStorage.setItem("authData", JSON.stringify(updatedAuthData));
//     } catch (err) {
//       console.error("Error updating user:", err);
//     }
//   };

//   const clearAuthData = () => {
//     dispatch({ type: "CLEAR_USER" });
//     localStorage.removeItem("authData");
//     localStorage.removeItem("token");
//     localStorage.removeItem("role");
//     // localStorage.removeItem('short_code');
//   };

//   const isAuthenticated = () => {
//     return !!localStorage.getItem("token");
//   };

//   return (
//     // <AuthContext.Provider value={{ state, setAuthData, clearAuthData, isAuthenticated }}>
//     //   {children}
//     // </AuthContext.Provider>
//     <AuthContext.Provider
//       value={{
//         state,
//         setAuthData,
//         updateUser,
//         clearAuthData,
//         isAuthenticated,
//       }}
//     >
//       {children}
//     </AuthContext.Provider>
//   );
// };

import {
  createContext,
  useContext,
  useReducer,
  useEffect,
  ReactNode,
} from "react";

type User = {
  id: string;
  role_id: string;
  username: string;
  email: string;
  phone: string | null;
  display_name: string;
  is_active: string;
  meta: string;
  created_at: string;
  updated_at: string;
  api_token: string;
  last_login: string;
  role_name: string;
  [key: string]: any;
};

interface AuthState {
  name: string | null;
  user: User | null;
  username: string | null;
  photo: string | null;
  accessToken: string | null;
  refreshToken: string | null;
}

interface AuthContextProps {
  state: AuthState;
  setAuthData: (data: {
    user: User;
    name: string;
    username: string;
    photo?: string;
    accessToken: string;
    refreshToken: string;
  }) => void;
  clearAuthData: () => void;
  isAuthenticated: () => boolean;
}

const AuthContext = createContext<AuthContextProps | null>(null);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};

const initialState: AuthState = {
  name: null,
  user: null,
  username: null,
  photo: null,
  accessToken: null,
  refreshToken: null,
};

const authReducer = (state: AuthState, action: any): AuthState => {
  switch (action.type) {
    case "SET_USER":
      return {
        ...state,
        user: action.payload.user,
        name: action.payload.name,
        username: action.payload.username,
        photo: action.payload.photo || null,
        accessToken: action.payload.accessToken,
        refreshToken: action.payload.refreshToken,
      };
    case "CLEAR_USER":
      return initialState;
    default:
      return state;
  }
};

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [state, dispatch] = useReducer(authReducer, initialState);

  useEffect(() => {
    const storedAuthData = localStorage.getItem("authData");
    if (storedAuthData) {
      const parsedAuthData = JSON.parse(storedAuthData);
      dispatch({
        type: "SET_USER",
        payload: {
          name: parsedAuthData.name,
          username: parsedAuthData.username,
          photo: parsedAuthData.photo || null,
          user: parsedAuthData.user,
          accessToken: parsedAuthData.accessToken,
          refreshToken: parsedAuthData.refreshToken,
        },
      });
    }
  }, []);

  const setAuthData = (data: {
    user: User;
    name: string;
    username: string;
    photo?: string;
    accessToken: string;
    refreshToken: string;
  }) => {
    const payload = {
      ...data,
      photo: data.photo || null,
    };

    dispatch({
      type: "SET_USER",
      payload: payload,
    });

    localStorage.setItem("authData", JSON.stringify(payload));
    localStorage.setItem("token", data.accessToken);
    localStorage.setItem("role", data.user.role_name);
  };

  const clearAuthData = () => {
    dispatch({ type: "CLEAR_USER" });
    localStorage.removeItem("authData");
    localStorage.removeItem("token");
    localStorage.removeItem("role");
  };

  const isAuthenticated = () => {
    return !!localStorage.getItem("token");
  };

  return (
    <AuthContext.Provider
      value={{ state, setAuthData, clearAuthData, isAuthenticated }}
    >
      {children}
    </AuthContext.Provider>
  );
};
