import React from 'react'

function page() {
  return (
    <div>
      technician
    </div>
  )
}

export default page
