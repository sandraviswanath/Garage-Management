"use client";
import Breadcrumbs from "@/CommonElements/Breadcrumbs";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  Badge,
  Button,
  TabContent,
  TabPane,
  Nav,
  NavItem,
  NavLink,
  Table,
  Progress,
  Input,
  Form,
  FormGroup,
  Label,
} from "reactstrap";
import React, { useState } from "react";
import { useRouter } from "next/navigation";

// Types
interface TechnicianJobDetail {
  id: number;
  jobNumber: string;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  vehicleNumber: string;
  vehicleModel: string;
  vehicleYear: string;
  vin: string;
  jobType: "repair" | "service" | "inspection" | "custom";
  status: "assigned" | "in-progress" | "paused" | "completed" | "cancelled";
  reportedIssue: string;
  assignedTechnician: string;
  estimatedCost: number;
  actualCost?: number;
  createdAt: string;
  estimatedCompletion: string;
  specialInstructions: string;
  priority: "low" | "medium" | "high" | "urgent";
  progress: number;

  jobItems: JobItem[];
  partsUsed: PartUsed[];
  photos: JobPhoto[];
  technicianNotes: TechnicianNote[];
  timeLogs: TimeLog[];
}

interface JobItem {
  id: number;
  description: string;
  estimatedHours: number;
  actualHours?: number;
  rate: number;
  total: number;
//   status: "pending" | "in-progress" | "completed";
status: string; 
  notes: string;
}

interface PartUsed {
  id: number;
  partName: string;
  partNumber: string;
  quantity: number;
  unitPrice: number;
  total: number;
  used: boolean;
}

interface JobPhoto {
  id: number;
  type: "before" | "during" | "after" | "issue";
  url: string;
  description: string;
  date: string;
  uploadedBy: string;
}

interface TechnicianNote {
  id: number;
  content: string;
  author: string;
  timestamp: string;
  type: "progress" | "issue" | "resolution";
}

interface TimeLog {
  id: number;
  startTime: string;
  endTime?: string;
  duration?: number; // in minutes
  activity: string;
  status: "active" | "completed";
}

// Mock data
const technicianJobDetailData: TechnicianJobDetail = {
  id: 1,
  jobNumber: "JC-2024-001",
  customerName: "John Doe",
  customerPhone: "+1 234 567 890",
  customerEmail: "john@example.com",
  vehicleNumber: "ABC123",
  vehicleModel: "Toyota Camry 2022",
  vehicleYear: "2022",
  vin: "1HGCM82633A123456",
  jobType: "service",
  status: "in-progress",
  reportedIssue: "Regular maintenance service including oil change, filter replacement, and general inspection",
  assignedTechnician: "Mike Smith",
  estimatedCost: 250.0,
  actualCost: 245.5,
  createdAt: "2024-01-15",
  estimatedCompletion: "2024-01-16",
  specialInstructions: "Customer requested synthetic oil only",
  priority: "medium",
  progress: 75,

  jobItems: [
    {
      id: 1,
      description: "Oil Change - Synthetic",
      estimatedHours: 0.5,
      actualHours: 0.5,
      rate: 75,
      total: 37.5,
      status: "completed",
      notes: "Completed successfully",
    },
    {
      id: 2,
      description: "Oil Filter Replacement",
      estimatedHours: 0.3,
      actualHours: 0.3,
      rate: 75,
      total: 22.5,
      status: "completed",
      notes: "Filter replaced",
    },
    {
      id: 3,
      description: "Air Filter Replacement",
      estimatedHours: 0.2,
      rate: 75,
      total: 15.0,
      status: "in-progress",
      notes: "In progress - waiting for part",
    },
    {
      id: 4,
      description: "Brake Inspection",
      estimatedHours: 0.5,
      rate: 75,
      total: 37.5,
      status: "pending",
      notes: "",
    },
  ],

  partsUsed: [
    {
      id: 1,
      partName: "Engine Oil Synthetic",
      partNumber: "OIL-SYN-5W30",
      quantity: 1,
      unitPrice: 45.99,
      total: 45.99,
      used: true,
    },
    {
      id: 2,
      partName: "Oil Filter",
      partNumber: "FIL-OIL-123",
      quantity: 1,
      unitPrice: 12.5,
      total: 12.5,
      used: true,
    },
    {
      id: 3,
      partName: "Air Filter",
      partNumber: "FIL-AIR-456",
      quantity: 1,
      unitPrice: 25.0,
      total: 25.0,
      used: false,
    },
  ],

  photos: [
    {
      id: 1,
      type: "before",
      url: "/before1.jpg",
      description: "Engine bay before service",
      date: "2024-01-15",
      uploadedBy: "Mike Smith",
    },
    {
      id: 2,
      type: "during",
      url: "/during1.jpg",
      description: "Oil filter replacement in progress",
      date: "2024-01-15",
      uploadedBy: "Mike Smith",
    },
  ],

  technicianNotes: [
    {
      id: 1,
      content: "Started oil change process. Vehicle in good condition.",
      author: "Mike Smith",
      timestamp: "2024-01-15 09:30",
      type: "progress",
    },
    {
      id: 2,
      content: "Found worn air filter that needs replacement. Waiting for part delivery.",
      author: "Mike Smith",
      timestamp: "2024-01-15 11:15",
      type: "issue",
    },
  ],

  timeLogs: [
    {
      id: 1,
      startTime: "2024-01-15 09:00",
      endTime: "2024-01-15 10:30",
      duration: 90,
      activity: "Initial inspection and oil change",
      status: "completed",
    },
    {
      id: 2,
      startTime: "2024-01-15 11:00",
      endTime: "2024-01-15 11:30",
      duration: 30,
      activity: "Filter replacement",
      status: "completed",
    },
    {
      id: 3,
      startTime: "2024-01-15 14:00",
      endTime: undefined,
      duration: undefined,
      activity: "Air filter replacement",
      status: "active",
    },
  ],
};

function TechnicianJobDetailPage({ params }: { params: { id: string } }) {
  const router = useRouter();
  const [activeTab, setActiveTab] = useState("1");
  const [job, setJob] = useState(technicianJobDetailData);
  const [newNote, setNewNote] = useState("");
  const [newPhoto, setNewPhoto] = useState<{ file: File | null; description: string; type: string }>({
    file: null,
    description: "",
    type: "during",
  });
  const [activeTimer, setActiveTimer] = useState<TimeLog | null>(
    technicianJobDetailData.timeLogs.find(log => log.status === "active") || null
  );

  const renderStatusBadge = (status: string) => {
    const statusConfig = {
      assigned: { class: "bg-secondary", label: "Assigned" },
      "in-progress": { class: "bg-warning", label: "In Progress" },
      paused: { class: "bg-info", label: "Paused" },
      completed: { class: "bg-success", label: "Completed" },
      cancelled: { class: "bg-danger", label: "Cancelled" },
    };

    const config = statusConfig[status as keyof typeof statusConfig];
    return <Badge className={config.class}>{config.label}</Badge>;
  };

  const handleStatusChange = (newStatus: TechnicianJobDetail["status"]) => {
    setJob({ ...job, status: newStatus });
  };

  const handleTaskStatusChange = (taskId: number, newStatus: string) => {
    const updatedTasks = job.jobItems.map(item =>
      item.id === taskId ? { ...item, status: newStatus } : item
    );
    
    // Update overall progress
    const completedTasks = updatedTasks.filter(t => t.status === "completed").length;
    const totalTasks = updatedTasks.length;
    const newProgress = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;

    setJob({
      ...job,
      jobItems: updatedTasks,
      progress: newProgress,
    });
  };

  const handleAddNote = () => {
    if (!newNote.trim()) return;

    const note: TechnicianNote = {
      id: Date.now(),
      content: newNote,
      author: "Mike Smith",
      timestamp: new Date().toISOString(),
      type: "progress",
    };

    setJob({
      ...job,
      technicianNotes: [note, ...job.technicianNotes],
    });

    setNewNote("");
  };

  const handleMarkPartUsed = (partId: number, used: boolean) => {
    setJob({
      ...job,
      partsUsed: job.partsUsed.map(part =>
        part.id === partId ? { ...part, used } : part
      ),
    });
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const file = files[0];
    const newPhotoItem: JobPhoto = {
      id: Date.now(),
      type: newPhoto.type as any,
      url: URL.createObjectURL(file),
      description: newPhoto.description || `Photo ${job.photos.length + 1}`,
      date: new Date().toISOString().split('T')[0],
      uploadedBy: "Mike Smith",
    };

    setJob({
      ...job,
      photos: [...job.photos, newPhotoItem],
    });

    setNewPhoto({ file: null, description: "", type: "during" });
  };

  const handleStartTimer = (activity: string) => {
    if (activeTimer) {
      // Stop current timer first
      handleStopTimer();
    }

    const newTimer: TimeLog = {
      id: Date.now(),
      startTime: new Date().toISOString(),
      activity,
      status: "active",
    };

    setActiveTimer(newTimer);
    setJob({
      ...job,
      timeLogs: [...job.timeLogs, newTimer],
    });
  };

  const handleStopTimer = () => {
    if (!activeTimer) return;

    const endTime = new Date().toISOString();
    const start = new Date(activeTimer.startTime);
    const end = new Date(endTime);
    const duration = Math.round((end.getTime() - start.getTime()) / (1000 * 60)); // minutes

    const updatedTimer = {
      ...activeTimer,
      endTime,
      duration,
      status: "completed" as const,
    };

    setJob({
      ...job,
      timeLogs: job.timeLogs.map(log =>
        log.id === activeTimer.id ? updatedTimer : log
      ),
    });

    setActiveTimer(null);
  };

  const calculateTotalTime = () => {
    return job.timeLogs
      .filter(log => log.duration)
      .reduce((total, log) => total + (log.duration || 0), 0);
  };

  return (
    <div className="page-body">
      <Breadcrumbs
        title={`Job ${job.jobNumber}`}
        mainTitle="Job Details"
        parent="My Jobs"
      />

      <Container fluid>
        <Row>
          <Col lg={4}>
            {/* Job Info Card */}
            <Card className="mb-4">
              <CardBody>
                <div className="text-center mb-4">
                  <h4 className="text-primary">{job.jobNumber}</h4>
                  {renderStatusBadge(job.status)}
                </div>

                <div className="mb-3 text-muted">
                  <strong>Customer Information</strong>
                  <div className="mt-2">
                    <div className="d-flex justify-content-between py-2 border-bottom">
                      <span>Name:</span>
                      <span>{job.customerName}</span>
                    </div>
                    <div className="d-flex justify-content-between py-2 border-bottom">
                      <span>Phone:</span>
                      <span>{job.customerPhone}</span>
                    </div>
                  </div>
                </div>

                <div className="mb-3 text-muted">
                  <strong>Vehicle Information</strong>
                  <div className="mt-2">
                    <div className="d-flex justify-content-between py-2 border-bottom">
                      <span>Vehicle No:</span>
                      <span>{job.vehicleNumber}</span>
                    </div>
                    <div className="d-flex justify-content-between py-2 border-bottom">
                      <span>Model:</span>
                      <span>{job.vehicleModel}</span>
                    </div>
                  </div>
                </div>

                <div className="mb-3 text-muted">
                  <strong>Job Information</strong>
                  <div className="mt-2">
                    <div className="d-flex justify-content-between py-2 border-bottom">
                      <span>Priority:</span>
                      <Badge color={
                        job.priority === 'high' ? 'danger' : 
                        job.priority === 'medium' ? 'warning' : 'primary'
                      }>
                        {job.priority}
                      </Badge>
                    </div>
                    <div className="d-flex justify-content-between py-2 border-bottom">
                      <span>Due Date:</span>
                      <span>{new Date(job.estimatedCompletion).toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>

                {job.specialInstructions && (
                  <div className="alert alert-warning">
                    <strong>Special Instructions:</strong><br />
                    {job.specialInstructions}
                  </div>
                )}
              </CardBody>
            </Card>

            {/* Quick Actions Card */}
            <Card>
              <CardBody>
                <h6 className="mb-3 text-muted">Quick Actions</h6>
                <div className="d-grid gap-2">
                  {job.status === "assigned" && (
                    <Button
                      color="success"
                      onClick={() => handleStatusChange("in-progress")}
                    >
                      <i className="fa fa-play me-2"></i>
                      Start Job
                    </Button>
                  )}
                  
                  {job.status === "in-progress" && (
                    <>
                      <Button
                        color="warning"
                        onClick={() => handleStatusChange("paused")}
                      >
                        <i className="fa fa-pause me-2"></i>
                        Pause Job
                      </Button>
                      <Button
                        color="success"
                        onClick={() => handleStatusChange("completed")}
                      >
                        <i className="fa fa-check me-2"></i>
                        Complete Job
                      </Button>
                    </>
                  )}
                  
                  {job.status === "paused" && (
                    <Button
                      color="info"
                      onClick={() => handleStatusChange("in-progress")}
                    >
                      <i className="fa fa-play me-2"></i>
                      Resume Job
                    </Button>
                  )}

                  <Button
                    color="outline-primary"
                    onClick={() => router.push("/technician/jobs")}
                  >
                    Back to My Jobs
                  </Button>
                </div>
              </CardBody>
            </Card>

            {/* Time Tracking Card */}
            <Card className="mt-4">
              <CardBody>
                <h6 className="mb-3 text-muted">Time Tracking</h6>
                
                {activeTimer ? (
                  <div className="text-center">
                    <div className="mb-3">
                      <h5 className="text-warning">Timer Running</h5>
                      <p className="mb-1 text-muted">{activeTimer.activity}</p>
                      <small className="text-muted">
                        Started: {new Date(activeTimer.startTime).toLocaleTimeString()}
                      </small>
                    </div>
                    <Button color="danger" onClick={handleStopTimer} className="w-100">
                      <i className="fa fa-stop me-2"></i>
                      Stop Timer
                    </Button>
                  </div>
                ) : (
                  <div className="d-grid gap-2">
                    <Button 
                      color="primary" 
                      onClick={() => handleStartTimer("General repair work")}
                    >
                      <i className="fa fa-play me-2"></i>
                      Start Timer
                    </Button>
                  </div>
                )}

                <div className="mt-3">
                  <small className="text-muted">
                    Total Time: {Math.round(calculateTotalTime() / 60)}h {calculateTotalTime() % 60}m
                  </small>
                </div>
              </CardBody>
            </Card>
          </Col>

          <Col lg={8}>
            {/* Progress Card */}
            <Card className="mb-4">
              <CardBody>
                <div className="d-flex justify-content-between align-items-center mb-2 text-muted">
                  <h6 className="mb-0">Job Progress</h6>
                  <span>{job.progress}% complete</span>
                </div>
                <Progress value={job.progress} className="mb-2" />
                <div className="row text-center">
                  <div className="col-4 text-muted">
                    <small className="text-muted">Tasks</small>
                    <div>
                      {job.jobItems.filter(t => t.status === "completed").length} / {job.jobItems.length}
                    </div>
                  </div>
                  <div className="col-4 text-muted">
                    <small className="text-muted">Parts Used</small>
                    <div>
                      {job.partsUsed.filter(p => p.used).length} / {job.partsUsed.length}
                    </div>
                  </div>
                  <div className="col-4 text-muted">
                    <small className="text-muted">Photos</small>
                    <div>{job.photos.length}</div>
                  </div>
                </div>
              </CardBody>
            </Card>

            {/* Tabs */}
            <Card>
              <CardBody>
                <Nav tabs>
                  <NavItem>
                    <NavLink
                      className={activeTab === "1" ? "active" : ""}
                      onClick={() => setActiveTab("1")}
                    >
                      Tasks
                    </NavLink>
                  </NavItem>
                  <NavItem>
                    <NavLink
                      className={activeTab === "2" ? "active" : ""}
                      onClick={() => setActiveTab("2")}
                    >
                      Parts
                    </NavLink>
                  </NavItem>
                  <NavItem>
                    <NavLink
                      className={activeTab === "3" ? "active" : ""}
                      onClick={() => setActiveTab("3")}
                    >
                      Photos
                    </NavLink>
                  </NavItem>
                  <NavItem>
                    <NavLink
                      className={activeTab === "4" ? "active" : ""}
                      onClick={() => setActiveTab("4")}
                    >
                      Notes
                    </NavLink>
                  </NavItem>
                  <NavItem>
                    <NavLink
                      className={activeTab === "5" ? "active" : ""}
                      onClick={() => setActiveTab("5")}
                    >
                      Time Log
                    </NavLink>
                  </NavItem>
                </Nav>

                <TabContent activeTab={activeTab} className="pt-3">
                  {/* Tasks Tab */}
                  <TabPane tabId="1">
                    <Table bordered>
                      <thead>
                        <tr>
                          <th>Task Description</th>
                          <th>Est. Hours</th>
                          <th>Status</th>
                          <th>Notes</th>
                          <th>Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {job.jobItems.map((task) => (
                          <tr key={task.id}>
                            <td>{task.description}</td>
                            <td>{task.estimatedHours}</td>
                            {/* <td className="no-wrap">
                              <select
                                className="form-select"
                                value={task.status}
                                onChange={(e) =>
                                  handleTaskStatusChange(task.id, e.target.value)
                                }
                              >
                                <option value="pending">Pending</option>
                                <option value="in-progress">In Progress</option>
                                <option value="completed">Completed</option>
                              </select>
                            </td> */}
                            <td style={{ minWidth: "160px", whiteSpace: "nowrap" }}>
  <select
    className="form-select w-100"
    value={task.status}
    onChange={(e) => handleTaskStatusChange(task.id, e.target.value)}
  >
    <option value="pending">Pending</option>
    <option value="in-progress">In Progress</option>
    <option value="completed">Completed</option>
  </select>
</td>
                            <td>
                              <Input
                                type="text"
                                placeholder="Add notes..."
                                value={task.notes}
                                onChange={(e) => {
                                  const updatedTasks = job.jobItems.map(t =>
                                    t.id === task.id ? { ...t, notes: e.target.value } : t
                                  );
                                  setJob({ ...job, jobItems: updatedTasks });
                                }}
                              />
                            </td>
                            <td>
                              {task.status === "in-progress" && (
                                <Button
                                  color="primary"
                                  size="sm"
                                  onClick={() => handleStartTimer(task.description)}
                                >
                                  <i className="fa fa-clock"></i>
                                </Button>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </Table>
                  </TabPane>

                  {/* Parts Tab */}
                  <TabPane tabId="2">
                    <Table bordered>
                      <thead>
                        <tr>
                          <th>Part Name</th>
                          <th>Part Number</th>
                          <th>Quantity</th>
                          <th>Price</th>
                          <th>Used</th>
                          <th>Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {job.partsUsed.map((part) => (
                          <tr key={part.id}>
                            <td>{part.partName}</td>
                            <td>{part.partNumber}</td>
                            <td>{part.quantity}</td>
                            <td>${part.unitPrice}</td>
                            <td>
                              <FormGroup check>
                                <Input
                                  type="checkbox"
                                  checked={part.used}
                                  onChange={(e) => handleMarkPartUsed(part.id, e.target.checked)}
                                />
                              </FormGroup>
                            </td>
                            <td>
                              <Button color="info" size="sm">
                                <i className="fa fa-info"></i>
                              </Button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </Table>
                  </TabPane>

                  {/* Photos Tab */}
                  <TabPane tabId="3">
                    <div className="mb-3">
                      <Form>
                        <Row className="text-muted">
                          <Col md={4}>
                            <FormGroup>
                              <Label for="photoType">Photo Type</Label>
                              <Input
                                type="select"
                                id="photoType"
                                value={newPhoto.type}
                                onChange={(e) => setNewPhoto({ ...newPhoto, type: e.target.value })}
                                className="border"
                              >
                                <option value="before">Before</option>
                                <option value="during">During</option>
                                <option value="after">After</option>
                                <option value="issue">Issue</option>
                              </Input>
                            </FormGroup>
                          </Col>
                          <Col md={5}>
                            <FormGroup>
                              <Label for="photoDescription">Description</Label>
                              <Input
                                type="text"
                                id="photoDescription"
                                placeholder="Enter photo description"
                                value={newPhoto.description}
                                onChange={(e) => setNewPhoto({ ...newPhoto, description: e.target.value })}
                              />
                            </FormGroup>
                          </Col>
                          <Col md={3}>
                            <FormGroup>
                              <Label>Upload</Label>
                              <div>
                                <Input
                                  type="file"
                                  accept="image/*"
                                  onChange={handlePhotoUpload}
                                />
                              </div>
                            </FormGroup>
                          </Col>
                        </Row>
                      </Form>
                    </div>

                    <Row>
                      {job.photos.map((photo) => (
                        <Col key={photo.id} lg={4} md={6} className="mb-3">
                          <Card>
                            <CardBody className="text-center">
                              <div className="bg-light rounded p-4 mb-2">
                                <i className="fa fa-image fa-2x text-muted"></i>
                              </div>
                              <Badge
                                color={
                                  photo.type === "before" ? "warning" :
                                  photo.type === "after" ? "success" : "info"
                                }
                                className="mb-2"
                              >
                                {photo.type.toUpperCase()}
                              </Badge>
                              <p className="mb-1 small text-muted">{photo.description}</p>
                              <small className="text-muted">
                                {new Date(photo.date).toLocaleDateString()}
                              <br />
                                by {photo.uploadedBy}
                              </small>
                            </CardBody>
                          </Card>
                        </Col>
                      ))}
                    </Row>
                  </TabPane>

                  {/* Notes Tab */}
                  <TabPane tabId="4">
                    <div className="mb-3 text-muted">
                      <FormGroup>
                        <Label for="newNote">Add Note</Label>
                        <Input
                          type="textarea"
                          id="newNote"
                          rows={3}
                          placeholder="Enter your notes about the job..."
                          value={newNote}
                          onChange={(e) => setNewNote(e.target.value)}
                        />
                      </FormGroup>
                      <Button color="primary" onClick={handleAddNote}>
                        Add Note
                      </Button>
                    </div>

                    <div className="notes-list text-muted">
                      {job.technicianNotes.map((note) => (
                        <Card key={note.id} className="mb-2">
                          <CardBody className="p-3">
                            <div className="d-flex justify-content-between align-items-start mb-2 text-muted">
                              <strong>{note.author}</strong>
                              <small className="text-muted">
                                {new Date(note.timestamp).toLocaleString()}
                              </small>
                            </div>
                            <p className="mb-0 text-muted">{note.content}</p>
                            <Badge color="secondary" className="mt-2">
                              {note.type}
                            </Badge>
                          </CardBody>
                        </Card>
                      ))}
                    </div>
                  </TabPane>

                  {/* Time Log Tab */}
                  <TabPane tabId="5">
                    <Table bordered>
                      <thead>
                        <tr>
                          <th>Activity</th>
                          <th>Start Time</th>
                          <th>End Time</th>
                          <th>Duration</th>
                          <th>Status</th>
                        </tr>
                      </thead>
                      <tbody>
                        {job.timeLogs.map((log) => (
                          <tr key={log.id}>
                            <td>{log.activity}</td>
                            <td>{new Date(log.startTime).toLocaleString()}</td>
                            <td>
                              {log.endTime ? new Date(log.endTime).toLocaleString() : '-'}
                            </td>
                            <td>
                              {log.duration ? `${Math.floor(log.duration / 60)}h ${log.duration % 60}m` : '-'}
                            </td>
                            <td>
                              <Badge color={log.status === 'active' ? 'success' : 'secondary'}>
                                {log.status}
                              </Badge>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </Table>
                  </TabPane>
                </TabContent>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Container>
    </div>
  );
}

export default TechnicianJobDetailPage;