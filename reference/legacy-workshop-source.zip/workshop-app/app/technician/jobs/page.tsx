"use client";
import Breadcrumbs from "@/CommonElements/Breadcrumbs";
import CustomPagination from "@/CommonElements/Pagination";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  Input,
  Button,
  Table,
  Badge,
  Dropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
} from "reactstrap";
import React, { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";

// Types
interface TechnicianJob {
  id: number;
  jobNumber: string;
  customerName: string;
  vehicleNumber: string;
  vehicleModel: string;
  jobType: "repair" | "service" | "inspection" | "custom";
  status: "assigned" | "in-progress" | "paused" | "completed" | "cancelled";
  reportedIssue: string;
  assignedTechnician: string;
  estimatedCost: number;
  actualCost?: number;
  createdAt: string;
  estimatedCompletion: string;
  priority: "low" | "medium" | "high" | "urgent";
  progress: number; // 0-100 percentage
  lastUpdated: string;
}

// Mock data - only jobs assigned to current technician
const technicianJobsData: TechnicianJob[] = [
  {
    id: 1,
    jobNumber: "JC-2024-001",
    customerName: "John Doe",
    vehicleNumber: "ABC123",
    vehicleModel: "Toyota Camry 2022",
    jobType: "service",
    status: "in-progress",
    reportedIssue: "Regular maintenance service",
    assignedTechnician: "Mike Smith",
    estimatedCost: 250.0,
    actualCost: 245.5,
    createdAt: "2024-01-15",
    estimatedCompletion: "2024-01-16",
    priority: "medium",
    progress: 75,
    lastUpdated: "2024-01-15 14:30",
  },
  {
    id: 2,
    jobNumber: "JC-2024-004",
    customerName: "Sarah Wilson",
    vehicleNumber: "GHI789",
    vehicleModel: "BMW X5 2022",
    jobType: "repair",
    status: "assigned",
    reportedIssue: "AC not cooling properly",
    assignedTechnician: "Mike Smith",
    estimatedCost: 350.0,
    createdAt: "2024-01-17",
    estimatedCompletion: "2024-01-19",
    priority: "high",
    progress: 0,
    lastUpdated: "2024-01-17 09:15",
  },
  {
    id: 3,
    jobNumber: "JC-2024-005",
    customerName: "Robert Brown",
    vehicleNumber: "JKL012",
    vehicleModel: "Mercedes C300 2023",
    jobType: "repair",
    status: "paused",
    reportedIssue: "Engine warning light on",
    assignedTechnician: "Mike Smith",
    estimatedCost: 500.0,
    createdAt: "2024-01-16",
    estimatedCompletion: "2024-01-18",
    priority: "high",
    progress: 40,
    lastUpdated: "2024-01-17 11:20",
  },
  {
    id: 4,
    jobNumber: "JC-2024-006",
    customerName: "Emily Davis",
    vehicleNumber: "MNO345",
    vehicleModel: "Honda Accord 2021",
    jobType: "inspection",
    status: "completed",
    reportedIssue: "Annual safety inspection",
    assignedTechnician: "Mike Smith",
    estimatedCost: 120.0,
    actualCost: 120.0,
    createdAt: "2024-01-14",
    estimatedCompletion: "2024-01-15",
    priority: "low",
    progress: 100,
    lastUpdated: "2024-01-15 16:45",
  },
];

function TechnicianJobsPage() {
  const router = useRouter();
  const [currentPage, setCurrentPage] = useState(1);
  const [jobs, setJobs] = useState<TechnicianJob[]>(technicianJobsData);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [jobTypeFilter, setJobTypeFilter] = useState("all");
  const itemsPerPage = 10;

  // Current technician (in real app, this would come from auth context)
  const currentTechnician = "Mike Smith";

  // Filter jobs - only show assigned to current technician
  const filteredJobs = jobs.filter((job) => {
    const matchesSearch =
      job.jobNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      job.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      job.vehicleNumber.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus =
      statusFilter === "all" || job.status === statusFilter;
    const matchesJobType =
      jobTypeFilter === "all" || job.jobType === jobTypeFilter;

    return matchesSearch && matchesStatus && matchesJobType;
  });

  // Pagination
  const totalPages = Math.ceil(filteredJobs.length / itemsPerPage);
  const paginatedJobs = filteredJobs.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  // Status badge render function
  const renderStatusBadge = (status: string) => {
    const statusConfig = {
      assigned: { class: "bg-secondary", label: "Assigned" },
      "in-progress": { class: "bg-warning", label: "In Progress" },
      paused: { class: "bg-info", label: "Paused" },
      completed: { class: "bg-success", label: "Completed" },
      cancelled: { class: "bg-danger", label: "Cancelled" },
    };

    const config = statusConfig[status as keyof typeof statusConfig] || {
      class: "bg-secondary",
      label: status,
    };

    return <Badge className={config.class}>{config.label}</Badge>;
  };

  // Priority badge render function
  const renderPriorityBadge = (priority: string) => {
    const priorityConfig = {
      low: { class: "bg-primary", label: "Low" },
      medium: { class: "bg-warning", label: "Medium" },
      high: { class: "bg-danger", label: "High" },
      urgent: { class: "bg-dark", label: "Urgent" },
    };

    const config = priorityConfig[priority as keyof typeof priorityConfig] || {
      class: "bg-secondary",
      label: priority,
    };

    return <Badge className={config.class}>{config.label}</Badge>;
  };

  // Progress bar component
  const renderProgressBar = (progress: number) => {
    return (
      <div className="progress" style={{ height: "8px" }}>
        <div
          className={`progress-bar ${
            progress < 50 ? "bg-warning" : progress < 100 ? "bg-info" : "bg-success"
          }`}
          role="progressbar"
          style={{ width: `${progress}%` }}
          aria-valuenow={progress}
          aria-valuemin={0}
          aria-valuemax={100}
        ></div>
      </div>
    );
  };

  // Quick status actions
  const handleQuickAction = (jobId: number, action: string) => {
    setJobs(
      jobs.map((job) => {
        if (job.id === jobId) {
          let newStatus = job.status;
          let newProgress = job.progress;

          switch (action) {
            case "start":
              newStatus = "in-progress";
              newProgress = Math.max(job.progress, 10);
              break;
            case "pause":
              newStatus = "paused";
              break;
            case "complete":
              newStatus = "completed";
              newProgress = 100;
              break;
          }

          return {
            ...job,
            status: newStatus,
            progress: newProgress,
            lastUpdated: new Date().toISOString(),
          };
        }
        return job;
      })
    );
  };

  return (
    <div className="page-body">
      <Breadcrumbs
        title="My Jobs"
        mainTitle="My Jobs"
        parent="Technician Dashboard"
      />

      <Container fluid>
        <Row>
          <Col sm={12}>
            <Card className="technician-job-card">
              <CardBody>
                {/* Header with Search and Filters */}
                <div className="row align-items-center mb-4 g-3">
                  {/* Welcome Message */}
                  <div className="col-12 col-md-4">
                    <h5 className="mb-0 text-muted">Welcome, {currentTechnician}!</h5>
                    <small className="text-muted">
                      You have {jobs.filter(j => j.status !== 'completed').length} active jobs
                    </small>
                  </div>

                  {/* Search Bar */}
                  <div className="col-12 col-md-3">
                    <div className="position-relative">
                      <Input
                        type="search"
                        placeholder="Search my jobs..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="form-control"
                      />
                      <i
                        className="fa fa-search position-absolute"
                        style={{
                          right: "10px",
                          top: "50%",
                          transform: "translateY(-50%)",
                          color: "#aaa",
                        }}
                      ></i>
                    </div>
                  </div>

                  {/* Status Filter */}
                  <div className="col-12 col-md-2">
                    <select
                      className="form-select p-2 border"
                      style={{ fontSize: "0.9rem" }}
                      value={statusFilter}
                      onChange={(e) => setStatusFilter(e.target.value)}
                    >
                      <option value="all">All Status</option>
                      <option value="assigned">Assigned</option>
                      <option value="in-progress">In Progress</option>
                      <option value="paused">Paused</option>
                      <option value="completed">Completed</option>
                    </select>
                  </div>

                  {/* Job Type Filter */}
                  <div className="col-12 col-md-2">
                    <select
                      className="form-select p-2 border"
                      style={{ fontSize: "0.9rem" }}
                      value={jobTypeFilter}
                      onChange={(e) => setJobTypeFilter(e.target.value)}
                    >
                      <option value="all">All Types</option>
                      <option value="repair">Repair</option>
                      <option value="service">Service</option>
                      <option value="inspection">Inspection</option>
                    </select>
                  </div>
                </div>

                {/* Stats Cards */}
                <div className="row mb-4">
                  <div className="col-md-3 col-sm-6">
                    <Card className="bg-primary text-white">
                      <CardBody className="p-3">
                        <div className="d-flex align-items-center">
                          <div className="flex-grow-1 text-white">
                            <h4 className="mb-0">
                              {jobs.filter(j => j.status === 'assigned').length}
                            </h4>
                            <small>Assigned Jobs</small>
                          </div>
                          <div className="flex-shrink-0">
                            <i className="fa fa-tasks fa-2x opacity-50 text-white"></i>
                          </div>
                        </div>
                      </CardBody>
                    </Card>
                  </div>
                  <div className="col-md-3 col-sm-6">
                    <Card className="bg-warning text-white">
                      <CardBody className="p-3">
                        <div className="d-flex align-items-center text-white">
                          <div className="flex-grow-1">
                            <h4 className="mb-0">
                              {jobs.filter(j => j.status === 'in-progress').length}
                            </h4>
                            <small>In Progress</small>
                          </div>
                          <div className="flex-shrink-0">
                            <i className="fa fa-wrench fa-2x opacity-50 text-white"></i>
                          </div>
                        </div>
                      </CardBody>
                    </Card>
                  </div>
                  <div className="col-md-3 col-sm-6">
                    <Card className="bg-info text-white">
                      <CardBody className="p-3">
                        <div className="d-flex align-items-center text-white">
                          <div className="flex-grow-1">
                            <h4 className="mb-0">
                              {jobs.filter(j => j.status === 'paused').length}
                            </h4>
                            <small>Paused</small>
                          </div>
                          <div className="flex-shrink-0">
                            <i className="fa fa-pause fa-2x opacity-50 text-white"></i>
                          </div>
                        </div>
                      </CardBody>
                    </Card>
                  </div>
                  <div className="col-md-3 col-sm-6">
                    <Card className="bg-success text-white">
                      <CardBody className="p-3">
                        <div className="d-flex align-items-center text-white">
                          <div className="flex-grow-1">
                            <h4 className="mb-0">
                              {jobs.filter(j => j.status === 'completed').length}
                            </h4>
                            <small>Completed</small>
                          </div>
                          <div className="flex-shrink-0">
                            <i className="fa fa-check fa-2x opacity-50 text-white"></i>
                          </div>
                        </div>
                      </CardBody>
                    </Card>
                  </div>
                </div>

                {/* Jobs Table */}
                <div className="table-responsive">
                  <Table hover className="technician-jobs-table mb-0">
                    <thead>
                      <tr>
                        <th>Job Number</th>
                        <th>Customer</th>
                        <th>Vehicle</th>
                        <th>Issue</th>
                        <th>Priority</th>
                        <th>Progress</th>
                        <th>Status</th>
                        <th>Due Date</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {paginatedJobs.length === 0 ? (
                        <tr>
                          <td colSpan={9} className="text-center py-4">
                            No jobs found
                          </td>
                        </tr>
                      ) : (
                        paginatedJobs.map((job) => (
                          <tr key={job.id} className={job.priority === 'urgent' ? 'table-danger' : ''}>
                            <td className="no-wrap">
                              <strong
                                className="text-primary cursor-pointer"
                                onClick={() =>
                                  router.push(`/technician/jobs/${job.id}`)
                                }
                              >
                                {job.jobNumber}
                              </strong>
                            </td>
                            <td>{job.customerName}</td>
                            <td>
                              <div>
                                <div>{job.vehicleNumber}</div>
                                <small className="text-muted">
                                  {job.vehicleModel}
                                </small>
                              </div>
                            </td>
                            <td>
                              <div
                                className="text-truncate"
                                style={{ maxWidth: "150px" }}
                                title={job.reportedIssue}
                              >
                                {job.reportedIssue}
                              </div>
                            </td>
                            <td>{renderPriorityBadge(job.priority)}</td>
                            <td style={{ width: "120px" }}>
                              <div className="d-flex align-items-center">
                                <small className="me-2">{job.progress}%</small>
                                {renderProgressBar(job.progress)}
                              </div>
                            </td>
                            <td>{renderStatusBadge(job.status)}</td>
                            <td>
                              {new Date(job.estimatedCompletion).toLocaleDateString()}
                            </td>
                            <td>
                              <div className="d-flex gap-1">
                                <button
                                  className="action-btn text-white border btn-primary"
                                  onClick={() =>
                                    router.push(`/technician/jobs/${job.id}`)
                                  }
                                  title="View Details"
                                >
                                  <i className="fa fa-eye"></i>
                                </button>
                                
                                {job.status === "assigned" && (
                                  <button
                                    className="action-btn text-white border btn-success"
                                    onClick={() => handleQuickAction(job.id, "start")}
                                    title="Start Job"
                                  >
                                    <i className="fa fa-play"></i>
                                  </button>
                                )}
                                
                                {job.status === "in-progress" && (
                                  <>
                                    <button
                                      className="action-btn text-white border btn-warning"
                                      onClick={() => handleQuickAction(job.id, "pause")}
                                      title="Pause Job"
                                    >
                                      <i className="fa fa-pause"></i>
                                    </button>
                                    <button
                                      className="action-btn text-white border btn-success"
                                      onClick={() => handleQuickAction(job.id, "complete")}
                                      title="Complete Job"
                                    >
                                      <i className="fa fa-check"></i>
                                    </button>
                                  </>
                                )}
                                
                                {job.status === "paused" && (
                                  <button
                                    className="action-btn text-white border btn-info"
                                    onClick={() => handleQuickAction(job.id, "start")}
                                    title="Resume Job"
                                  >
                                    <i className="fa fa-play"></i>
                                  </button>
                                )}
                              </div>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </Table>
                </div>

                {/* Pagination and Info */}
                <div className="d-flex flex-column flex-md-row justify-content-between align-items-center gap-3 mt-4">
                  <div className="text-center text-md-start text-muted">
                    Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
                    {Math.min(
                      currentPage * itemsPerPage,
                      filteredJobs.length
                    )}{" "}
                    of {filteredJobs.length} entries
                  </div>
                  <CustomPagination
                    currentPage={currentPage}
                    totalPages={totalPages}
                    onPageChange={setCurrentPage}
                    showFirstLast={true}
                    maxVisiblePages={5}
                    paginationType="primary"
                    className="justify-content-center justify-content-md-end"
                  />
                </div>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Container>

      <style jsx>{`
        .technician-job-card {
          box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
          border: 1px solid rgba(0, 0, 0, 0.125);
        }

        .action-btn {
          padding: 0.25rem 0.5rem;
          border-radius: 5px;
          font-size: 0.75rem;
        }

        .technician-jobs-table {
          font-size: 0.875rem;
        }

        .technician-jobs-table td {
          vertical-align: middle;
        }

        .cursor-pointer {
          cursor: pointer;
        }

        @media (max-width: 768px) {
          .technician-job-card .card-body {
            padding: 1rem;
          }

          .table-responsive {
            border: 1px solid #dee2e6;
            border-radius: 0.375rem;
          }

          .technician-jobs-table {
            min-width: 800px;
          }
        }
      `}</style>
    </div>
  );
}

export default TechnicianJobsPage;