
"use client"
import Breadcrumbs from "@/CommonElements/Breadcrumbs";
import ActivityCard from "@/components/dashboard/Default/ActivityCard";
import GreetingCard from "@/components/dashboard/Default/GreetingCard";
import OverBalance from "@/components/dashboard/Default/OverBalance";
import PaperNote from "@/components/dashboard/Default/PaperNote";
import PreAccountCard from "@/components/dashboard/Default/PreAcoountCard/Index";
import RecentOrders from "@/components/dashboard/Default/RecentOrders";
import RecentSales from "@/components/dashboard/Default/RecentSales";
import TimeLineCard from "@/components/dashboard/Default/TimeLineCard";
import TotalUserAndFollower from "@/components/dashboard/Default/TotalUserAndFollower";
import GoodsReturn from "@/components/dashboard/Default/WidgetsWrapper/GoodsReturn";
import OrderProfit from "@/components/dashboard/Default/WidgetsWrapper/OrderProfit";
import SalePurchase from "@/components/dashboard/Default/WidgetsWrapper/SalePurchase";
import { Dashboard, Default_Util } from "@/utils/Constant";
import React from "react";
import { Container, Row } from "reactstrap";


const ReceptionistDashboard = () => {
  return (
    <div className="page-body">
      <Breadcrumbs
        title={Default_Util}
        mainTitle={Default_Util}
        parent={Dashboard}
      />
      <Container fluid={true}>
        <Row className="widget-grid">
          <GreetingCard />
          <SalePurchase />
          <GoodsReturn />
          <OrderProfit />
          <OverBalance />
          <RecentOrders />
          <ActivityCard />
          <RecentSales />
          <TimeLineCard />
          <PreAccountCard />
          <TotalUserAndFollower />
          <PaperNote />
        </Row>
      </Container>
    </div>
  );
};

export default  ReceptionistDashboard;