// "use client";
// import Breadcrumbs from "@/CommonElements/Breadcrumbs";
// // import CustomTable, { TableColumn } from "@/CommonElements/CustomTable";
// import {
//   Container,
//   Row,
//   Col,
//   Card,
//   CardBody,
//   Badge,
//   Button,
//   TabContent,
//   TabPane,
//   Nav,
//   NavItem,
//   NavLink,
// } from "reactstrap";
// import React, { useState } from "react";
// import { useRouter } from "next/navigation";
// import CustomTable, { TableColumn } from "@/CommonElements/CustomTable";

// // Mock data
// const customerData = {
//   id: 1,
//   name: "John Doe",
//   email: "john@example.com",
//   phone: "+1 234 567 890",
//   vehicleNumber: "ABC123",
//   vehicleModel: "Toyota Camry",
//   vehicleYear: "2022",
//   vin: "1HGCM82633A123456",
//   status: "active",
//   joinDate: "2023-01-15",
//   totalSpent: 1250.75,
//   totalOrders: 15,
//   openJobs: 2,
// };

// const serviceHistory = [
//   {
//     id: 1,
//     date: "2024-01-15",
//     serviceType: "Oil Change",
//     description: "Full synthetic oil change",
//     amount: 89.99,
//     status: "completed",
//     technician: "Mike Smith",
//   },
//   {
//     id: 2,
//     date: "2024-01-10",
//     serviceType: "Brake Service",
//     description: "Front brake pad replacement",
//     amount: 245.5,
//     status: "completed",
//     technician: "Sarah Johnson",
//   },
//   {
//     id: 3,
//     date: "2024-01-20",
//     serviceType: "Tire Rotation",
//     description: "Scheduled maintenance",
//     amount: 45.0,
//     status: "in-progress",
//     technician: "Mike Smith",
//   },
//   {
//     id: 4,
//     date: "2024-01-25",
//     serviceType: "AC Service",
//     description: "AC compressor replacement",
//     amount: 350.0,
//     status: "scheduled",
//     technician: "Pending",
//   },
// ];

// function CustomerProfilePage({ params }: { params: { id: string } }) {
//   const router = useRouter();
//   const [activeTab, setActiveTab] = useState("1");
//   const customer = customerData;

//   const serviceColumns: TableColumn[] = [
//     {
//       key: "date",
//       label: "Date",
//       render: (value) => new Date(value).toLocaleDateString(),
//     },
//     {
//       key: "serviceType",
//       label: "Service Type",
//     },
//     {
//       key: "description",
//       label: "Description",
//     },
//     {
//       key: "amount",
//       label: "Amount",
//       render: (value) => `$${value}`,
//     },
//     {
//       key: "status",
//       label: "Status",
//       render: (value) => {
//         const statusConfig = {
//           completed: { class: "bg-success", label: "Completed" },
//           "in-progress": { class: "bg-warning", label: "In Progress" },
//           scheduled: { class: "bg-info", label: "Scheduled" },
//         };

//         const config = statusConfig[value as keyof typeof statusConfig];

//         return <Badge className={config.class}>{config.label}</Badge>;
//       },
//     },
//     {
//       key: "technician",
//       label: "Technician",
//     },
//   ];

//   return (
//     <div className="page-body">
//       <Breadcrumbs
//         title={`Customer - ${customer.name}`}
//         mainTitle="Customer Profile"
//         parent="Customer Management"
//       />

//       <Container fluid>
//         <Row>
//           {/* Customer Info Card */}
//           <Col md={4}>
//             <Card>
//               <CardBody>
//                 <div className="text-center mb-4">
//                   <div className="avatar-lg mx-auto mb-3">
//                     <div className="avatar-title bg-primary rounded-circle text-white display-4">
//                       {customer.name
//                         .split(" ")
//                         .map((n) => n[0])
//                         .join("")}
//                     </div>
//                   </div>
//                   <h4>{customer.name}</h4>
//                   <Badge
//                     color={
//                       customer.status === "active" ? "success" : "secondary"
//                     }
//                   >
//                     {customer.status}
//                   </Badge>
//                 </div>

//                 <div className="mb-3">
//                   <strong>Contact Information</strong>
//                   <div className="mt-2">
//                     <div className="d-flex justify-content-between py-2 border-bottom">
//                       <span>Email:</span>
//                       <span>{customer.email}</span>
//                     </div>
//                     <div className="d-flex justify-content-between py-2 border-bottom">
//                       <span>Phone:</span>
//                       <span>{customer.phone}</span>
//                     </div>
//                     <div className="d-flex justify-content-between py-2 border-bottom">
//                       <span>Member Since:</span>
//                       <span>
//                         {new Date(customer.joinDate).toLocaleDateString()}
//                       </span>
//                     </div>
//                   </div>
//                 </div>

//                 <div className="mb-3">
//                   <strong>Vehicle Information</strong>
//                   <div className="mt-2">
//                     <div className="d-flex justify-content-between py-2 border-bottom">
//                       <span>Vehicle No:</span>
//                       <span>{customer.vehicleNumber}</span>
//                     </div>
//                     <div className="d-flex justify-content-between py-2 border-bottom">
//                       <span>Model:</span>
//                       <span>{customer.vehicleModel}</span>
//                     </div>
//                     <div className="d-flex justify-content-between py-2 border-bottom">
//                       <span>Year:</span>
//                       <span>{customer.vehicleYear}</span>
//                     </div>
//                     <div className="d-flex justify-content-between py-2">
//                       <span>VIN:</span>
//                       <span>{customer.vin}</span>
//                     </div>
//                   </div>
//                 </div>

//                 <div className="d-grid gap-2">
//                   <Button
//                     color="primary"
//                     onClick={() =>
//                       router.push(`/customer/${customer.id}?edit=true`)
//                     }
//                   >
//                     Edit Customer
//                   </Button>
//                   <Button
//                     color="outline-primary"
//                     onClick={() => router.push("/customer")}
//                   >
//                     Back to List
//                   </Button>
//                 </div>
//               </CardBody>
//             </Card>
//           </Col>

//           {/* Stats and Service History */}
//           <Col md={8}>
//             {/* Stats Cards */}
//             <Row className="mb-4">
//               <Col md={4}>
//                 <Card className="text-center bg-primary text-white">
//                   <CardBody>
//                     <h3>${customer.totalSpent}</h3>
//                     <p className="mb-0">Total Spent</p>
//                   </CardBody>
//                 </Card>
//               </Col>
//               <Col md={4}>
//                 <Card className="text-center bg-success text-white">
//                   <CardBody>
//                     <h3>{customer.totalOrders}</h3>
//                     <p className="mb-0">Total Services</p>
//                   </CardBody>
//                 </Card>
//               </Col>
//               <Col md={4}>
//                 <Card
//                   className={`text-center ${
//                     customer.openJobs > 0 ? "bg-warning" : "bg-secondary"
//                   } text-white`}
//                 >
//                   <CardBody>
//                     <h3>{customer.openJobs}</h3>
//                     <p className="mb-0">Open Jobs</p>
//                   </CardBody>
//                 </Card>
//               </Col>
//             </Row>

//             {/* Tabs */}
//             <Card>
//               <CardBody>
//                 <Nav tabs>
//                   <NavItem>
//                     <NavLink
//                       className={activeTab === "1" ? "active" : ""}
//                       onClick={() => setActiveTab("1")}
//                     >
//                       Service History
//                     </NavLink>
//                   </NavItem>
//                   <NavItem>
//                     <NavLink
//                       className={activeTab === "2" ? "active" : ""}
//                       onClick={() => setActiveTab("2")}
//                     >
//                       Notes & Comments
//                     </NavLink>
//                   </NavItem>
//                 </Nav>

//                 <TabContent activeTab={activeTab} className="pt-3">
//                   <TabPane tabId="1">
//                     <CustomTable
//                       data={serviceHistory}
//                       columns={serviceColumns}
//                       hover={true}
//                     />
//                   </TabPane>
//                   <TabPane tabId="2">
//                     <p>Customer notes and comments will appear here...</p>
//                   </TabPane>
//                 </TabContent>
//               </CardBody>
//             </Card>
//           </Col>
//         </Row>
//       </Container>
//     </div>
//   );
// }

// export default CustomerProfilePage;

"use client";
import Breadcrumbs from "@/CommonElements/Breadcrumbs";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  Badge,
  Button,
  TabContent,
  TabPane,
  Nav,
  NavItem,
  NavLink,
  Table,
} from "reactstrap";
import React, { useState } from "react";
import { useRouter } from "next/navigation";

// Mock data
const customerData = {
  id: 1,
  name: "John Doe",
  email: "john@example.com",
  phone: "+1 234 567 890",
  vehicleNumber: "ABC123",
  vehicleModel: "Toyota Camry",
  vehicleYear: "2022",
  vin: "1HGCM82633A123456",
  status: "active",
  joinDate: "2023-01-15",
  totalSpent: 1250.75,
  totalOrders: 15,
  openJobs: 2,
};

const serviceHistory = [
  {
    id: 1,
    date: "2024-01-15",
    serviceType: "Oil Change",
    description: "Full synthetic oil change",
    amount: 89.99,
    status: "completed",
    technician: "Mike Smith",
  },
  {
    id: 2,
    date: "2024-01-10",
    serviceType: "Brake Service",
    description: "Front brake pad replacement",
    amount: 245.5,
    status: "completed",
    technician: "Sarah Johnson",
  },
  {
    id: 3,
    date: "2024-01-20",
    serviceType: "Tire Rotation",
    description: "Scheduled maintenance",
    amount: 45.0,
    status: "in-progress",
    technician: "Mike Smith",
  },
  {
    id: 4,
    date: "2024-01-25",
    serviceType: "AC Service",
    description: "AC compressor replacement",
    amount: 350.0,
    status: "scheduled",
    technician: "Pending",
  },
];

function CustomerProfilePage({ params }: { params: { id: string } }) {
  const router = useRouter();
  const [activeTab, setActiveTab] = useState("1");
  const customer = customerData;

  const renderServiceStatusBadge = (status: string) => {
    const statusConfig = {
      completed: { class: "bg-success", label: "Completed" },
      "in-progress": { class: "bg-warning", label: "In Progress" },
      scheduled: { class: "bg-info", label: "Scheduled" },
    };

    const config = statusConfig[status as keyof typeof statusConfig] || {
      class: "bg-secondary",
      label: status,
    };

    return <Badge className={config.class}>{config.label}</Badge>;
  };

  return (
    <div className="page-body">
      <Breadcrumbs
        title={`Customer - ${customer.name}`}
        mainTitle="Customer Profile"
        parent="Customer Management"
      />

      <Container fluid>
        <Row>
          {/* Customer Info Card */}
          <Col md={4}>
            <Card>
              <CardBody>
                <div className="text-center mb-4">
                  <div className="avatar-lg mx-auto mb-3">
                    <div className="avatar-title bg-primary rounded-circle text-white display-4">
                      {customer.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </div>
                  </div>
                  <h4 className="text-muted">{customer.name}</h4>
                  <Badge
                    color={
                      customer.status === "active" ? "success" : "secondary"
                    }
                  >
                    {customer.status}
                  </Badge>
                </div>

                <div className="mb-3 text-muted">
                  <strong>Contact Information</strong>
                  <div className="mt-2">
                    <div className="d-flex justify-content-between py-2 border-bottom">
                      <span>Email:</span>
                      <span>{customer.email}</span>
                    </div>
                    <div className="d-flex justify-content-between py-2 border-bottom">
                      <span>Phone:</span>
                      <span>{customer.phone}</span>
                    </div>
                    <div className="d-flex justify-content-between py-2 border-bottom">
                      <span>Member Since:</span>
                      <span>
                        {new Date(customer.joinDate).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="mb-3 text-muted">
                  <strong>Vehicle Information</strong>
                  <div className="mt-2">
                    <div className="d-flex justify-content-between py-2 border-bottom">
                      <span>Vehicle No:</span>
                      <span>{customer.vehicleNumber}</span>
                    </div>
                    <div className="d-flex justify-content-between py-2 border-bottom">
                      <span>Model:</span>
                      <span>{customer.vehicleModel}</span>
                    </div>
                    <div className="d-flex justify-content-between py-2 border-bottom">
                      <span>Year:</span>
                      <span>{customer.vehicleYear}</span>
                    </div>
                    <div className="d-flex justify-content-between py-2">
                      <span>VIN:</span>
                      <span>{customer.vin}</span>
                    </div>
                  </div>
                </div>

                <div className="d-grid gap-2">
                  <Button
                    color="primary"
                    onClick={() =>
                      router.push(`/admin/customer/${customer.id}?edit=true`)
                    }
                  >
                    Edit Customer
                  </Button>
                  <Button
                    color="outline-primary"
                    onClick={() => router.push("/admin/customer")}
                  >
                    Back to List
                  </Button>
                </div>
              </CardBody>
            </Card>
          </Col>

          {/* Stats and Service History */}
          <Col md={8}>
            {/* Stats Cards */}
            <Row className="mb-4">
              <Col md={4}>
                <Card className="text-center bg-primary text-white">
                  <CardBody className="text-white">
                    <h3>${customer.totalSpent}</h3>
                    <p className="mb-0">Total Spent</p>
                  </CardBody>
                </Card>
              </Col>
              <Col md={4}>
                <Card className="text-center bg-success text-white">
                  <CardBody className="text-white">
                    <h3>{customer.totalOrders}</h3>
                    <p className="mb-0">Total Services</p>
                  </CardBody>
                </Card>
              </Col>
              <Col md={4}>
                <Card
                  className={`text-center ${
                    customer.openJobs > 0 ? "bg-warning" : "bg-secondary"
                  } text-white`}
                >
                  <CardBody className="text-white">
                    <h3>{customer.openJobs}</h3>
                    <p className="mb-0">Open Jobs</p>
                  </CardBody>
                </Card>
              </Col>
            </Row>

            {/* Tabs */}
            <Card>
              <CardBody>
                <Nav tabs>
                  <NavItem>
                    <NavLink
                      className={activeTab === "1" ? "active" : ""}
                      onClick={() => setActiveTab("1")}
                    >
                      Service History
                    </NavLink>
                  </NavItem>
                  <NavItem>
                    <NavLink
                      className={activeTab === "2" ? "active" : ""}
                      onClick={() => setActiveTab("2")}
                    >
                      Notes & Comments
                    </NavLink>
                  </NavItem>
                </Nav>

                <TabContent activeTab={activeTab} className="pt-3">
                  <TabPane tabId="1">
                    <div className="table-responsive">
                      <Table
                        hover
                        className="service-history-table mb-0"
                      >
                        <thead>
                          <tr>
                            <th scope="col">Date</th>
                            <th scope="col">Service Type</th>
                            <th scope="col" className="d-none d-md-table-cell">
                              Description
                            </th>
                            <th scope="col">Amount</th>
                            <th scope="col">Status</th>
                            <th scope="col" className="d-none d-sm-table-cell">
                              Technician
                            </th>
                            <th scope="col">Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {serviceHistory.length === 0 ? (
                            <tr>
                              <td colSpan={7} className="text-center py-4">
                                No service history found
                              </td>
                            </tr>
                          ) : (
                            serviceHistory.map((service) => (
                              <tr key={service.id}>
                                <td>
                                  {new Date(service.date).toLocaleDateString()}
                                </td>
                                <td>
                                  <strong>{service.serviceType}</strong>
                                </td>
                                <td className="d-none d-md-table-cell">
                                  {service.description}
                                </td>
                                <td>
                                  <strong>${service.amount}</strong>
                                </td>
                                <td>
                                  {renderServiceStatusBadge(service.status)}
                                </td>
                                <td className="d-none d-sm-table-cell">
                                  {service.technician}
                                </td>
                                <td>
                                  <div className="d-flex gap-1">
                                    <Button
                                      color="primary"
                                      size="sm"
                                      className="action-btn"
                                      onClick={() =>
                                        console.log(
                                          `View service ${service.id}`
                                        )
                                      }
                                      title="View Details"
                                    >
                                      {/* <i className="fa-regular fa-eye" /> */}
                                      <i className="fa fa-eye"></i>
                                    </Button>
                                    <Button
                                      color="warning"
                                      size="sm"
                                      className="action-btn"
                                      onClick={() =>
                                        console.log(
                                          `Edit service ${service.id}`
                                        )
                                      }
                                      title="Edit Service"
                                    >
                                      {/* <i className="fa-regular fa-pen-to-square" /> */}
                                      <i className="icofont icofont-pencil-alt-5"></i>
                                    </Button>
                                  </div>
                                </td>
                              </tr>
                            ))
                          )}
                        </tbody>
                      </Table>
                    </div>
                  </TabPane>
                  <TabPane tabId="2">
                    <div className="p-3">
                      <h6 className="text-muted">Customer Notes</h6>
                      <div className="border rounded p-3 mb-3 text-muted">
                        <div className="d-flex justify-content-between align-items-center mb-2 text-muted">
                          <strong className="text-muted">Regular Customer</strong>
                          <small className="text-muted">2024-01-15</small>
                        </div>
                        <p className="mb-0">
                          Customer prefers synthetic oil changes and has been
                          very satisfied with our service. Always arrives on
                          time for appointments.
                        </p>
                      </div>

                      <div className="border rounded p-3 text-muted">
                        <div className="d-flex justify-content-between align-items-center mb-2">
                          <strong>Vehicle Maintenance</strong>
                          <small className="text-muted">2024-01-10</small>
                        </div>
                        <p className="mb-0">
                          Vehicle is well-maintained. Customer follows
                          recommended service schedule. Noted that brake pads
                          were wearing evenly.
                        </p>
                      </div>

                      <div className="mt-3">
                        <Button color="primary" size="sm">
                          <i className="fa fa-plus me-2"></i>
                          Add New Note
                        </Button>
                      </div>
                    </div>
                  </TabPane>
                </TabContent>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Container>

      <style jsx>{`
        .avatar-lg {
          width: 80px;
          height: 80px;
        }

        .avatar-title {
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 1.5rem;
          font-weight: 600;
        }

        .action-btn {
          padding: 0.25rem 0.5rem;
          font-size: 0.75rem;
        }

        .service-history-table {
          font-size: 0.875rem;
        }

        .service-history-table td {
          vertical-align: middle;
        }

        @media (max-width: 768px) {
          .table-responsive {
            border: 1px solid #dee2e6;
            border-radius: 0.375rem;
          }

          .service-history-table {
            min-width: 700px;
            margin-bottom: 0;
          }
        }

        @media (max-width: 576px) {
          .action-btn {
            padding: 0.2rem 0.4rem;
            font-size: 0.7rem;
          }

          .service-history-table {
            font-size: 0.8rem;
          }

          .avatar-lg {
            width: 60px;
            height: 60px;
          }

          .avatar-title {
            font-size: 1.25rem;
          }
        }
      `}</style>
    </div>
  );
}

export default CustomerProfilePage;
