// "use client";
// import HoverableRowsClass from "@/CommonElements/BasicTable/HoverableRows";
// import Breadcrumbs from "@/CommonElements/Breadcrumbs";
// import CustomPagination from "@/CommonElements/Pagination";
// import { Dashboard, Default_Util } from "@/utils/Constant";
// import React, { useState } from "react";
// import { Container, Row } from "reactstrap";

// function page() {
//   const [currentPage, setCurrentPage] = useState(1);

//   return (
//     <div className="page-body">
//       {/* <Breadcrumbs
//         title={Default_Util}
//         mainTitle={Default_Util}
//         parent={Dashboard}
//       /> */}
//       <Breadcrumbs
//         title={"Customer Management"}
//         mainTitle={"Customer Management"}
//         parent={"Customer"}
//       />
//       {/* <div className="container-fluid datatable-init">
//         <div className="row">
//           <div className="col-sm-12">
//             <div className="card">
//               <div className="card-header pb-0 card-no-border">
//                 <h5>State Saving</h5>
//               </div>
//               <div className="card-body">
//                 <div className="table-responsive custom-scrollbar state-saving-table">
//                   <div
//                     id="basic-9_wrapper"
//                     className="dt-container dt-bootstrap5"
//                   >
//                     <div className="row mt-2 justify-content-between">
//                       <div className="col-md-auto me-auto ">
//                         <div className="dt-length">
//                           <select
//                             name="basic-9_length"
//                             aria-controls="basic-9"
//                             className="form-select form-select-sm"
//                             id="dt-length-2"
//                           >
//                             <option value={10}>10</option>
//                             <option value={25}>25</option>
//                             <option value={50}>50</option>
//                             <option value={100}>100</option>
//                           </select>
//                           <label htmlFor="dt-length-2"> entries per page</label>
//                         </div>
//                       </div>
//                       <div className="col-md-auto ms-auto ">
//                         <div className="dt-search">
//                           <label htmlFor="dt-search-2">Search:</label>
//                           <input
//                             type="search"
//                             className="form-control form-control-sm"
//                             id="dt-search-2"
//                             placeholder=""
//                             aria-controls="basic-9"
//                           />
//                         </div>
//                       </div>
//                     </div>
//                     <div className="row mt-2 justify-content-md-center">
//                       <div className="col-12 ">
//                         <table
//                           className="display border table-striped dataTable"
//                           id="basic-9"
//                           aria-describedby="basic-9_info"
//                           style={{ width: 920 }}
//                         >
//                           <colgroup>
//                             <col
//                               data-dt-column={0}
//                               style={{ width: "167.828px" }}
//                             />
//                             <col
//                               data-dt-column={1}
//                               style={{ width: "201.328px" }}
//                             />
//                             <col
//                               data-dt-column={2}
//                               style={{ width: "142.062px" }}
//                             />
//                             <col
//                               data-dt-column={3}
//                               style={{ width: "74.1094px" }}
//                             />
//                             <col
//                               data-dt-column={4}
//                               style={{ width: "131.141px" }}
//                             />
//                             <col
//                               data-dt-column={5}
//                               style={{ width: "108.031px" }}
//                             />
//                             <col
//                               data-dt-column={6}
//                               style={{ width: "95.5px" }}
//                             />
//                           </colgroup>
//                           <thead>
//                             <tr role="row">
//                               <th
//                                 data-dt-column={0}
//                                 rowSpan={1}
//                                 colSpan={1}
//                                 className="dt-orderable-asc dt-orderable-desc"
//                                 aria-label="Name: Activate to sort"
//                                 tabIndex={0}
//                               >
//                                 <span className="dt-column-title" role="button">
//                                   Name
//                                 </span>
//                                 <span className="dt-column-order" />
//                               </th>
//                               <th
//                                 data-dt-column={1}
//                                 rowSpan={1}
//                                 colSpan={1}
//                                 className="dt-orderable-asc dt-orderable-desc"
//                                 aria-label="Position: Activate to sort"
//                                 tabIndex={0}
//                               >
//                                 <span className="dt-column-title" role="button">
//                                   Position
//                                 </span>
//                                 <span className="dt-column-order" />
//                               </th>
//                               <th
//                                 data-dt-column={2}
//                                 rowSpan={1}
//                                 colSpan={1}
//                                 className="dt-orderable-asc dt-orderable-desc dt-ordering-desc"
//                                 aria-sort="descending"
//                                 aria-label="Office: Activate to remove sorting"
//                                 tabIndex={0}
//                               >
//                                 <span className="dt-column-title" role="button">
//                                   Office
//                                 </span>
//                                 <span className="dt-column-order" />
//                               </th>
//                               <th
//                                 data-dt-column={3}
//                                 rowSpan={1}
//                                 colSpan={1}
//                                 className="dt-type-numeric dt-orderable-asc dt-orderable-desc"
//                                 aria-label="Age: Activate to sort"
//                                 tabIndex={0}
//                               >
//                                 <span className="dt-column-title" role="button">
//                                   Age
//                                 </span>
//                                 <span className="dt-column-order" />
//                               </th>
//                               <th
//                                 data-dt-column={4}
//                                 rowSpan={1}
//                                 colSpan={1}
//                                 className="dt-orderable-asc dt-orderable-desc"
//                                 aria-label="Start Date: Activate to sort"
//                                 tabIndex={0}
//                               >
//                                 <span className="dt-column-title" role="button">
//                                   Start Date
//                                 </span>
//                                 <span className="dt-column-order" />
//                               </th>
//                               <th
//                                 data-dt-column={5}
//                                 rowSpan={1}
//                                 colSpan={1}
//                                 className="dt-type-numeric dt-orderable-asc dt-orderable-desc"
//                                 aria-label="Salary: Activate to sort"
//                                 tabIndex={0}
//                               >
//                                 <span className="dt-column-title" role="button">
//                                   Salary
//                                 </span>
//                                 <span className="dt-column-order" />
//                               </th>
//                               <th
//                                 data-dt-column={6}
//                                 rowSpan={1}
//                                 colSpan={1}
//                                 className="dt-orderable-asc dt-orderable-desc"
//                                 aria-label="Action: Activate to sort"
//                                 tabIndex={0}
//                               >
//                                 <span className="dt-column-title" role="button">
//                                   Action
//                                 </span>
//                                 <span className="dt-column-order" />
//                               </th>
//                             </tr>
//                           </thead>
//                           <tbody>
//                             <tr>
//                               <td>Sakura Yamamoto</td>
//                               <td>
//                                 <span className="badge rounded-pill badge-light-primary">
//                                   Support Engineer
//                                 </span>
//                               </td>
//                               <td className="sorting_1">Tokyo</td>
//                               <td className="dt-type-numeric">37</td>
//                               <td>19/08/2014</td>
//                               <td className="dt-type-numeric">$139,575</td>
//                               <td>
//                                 <ul className="action">
//                                   <li className="edit">
//                                     {" "}
//                                     <a href="#!">
//                                       <i className="fa-regular fa-pen-to-square" />
//                                     </a>
//                                   </li>
//                                   <li className="delete">
//                                     <a href="#!">
//                                       <i className="fa-solid fa-trash-can" />
//                                     </a>
//                                   </li>
//                                 </ul>
//                               </td>
//                             </tr>
//                             <tr>
//                               <td>Shou Itou</td>
//                               <td>
//                                 <span className="badge rounded-pill badge-light-primary">
//                                   Regional Marketing
//                                 </span>
//                               </td>
//                               <td className="sorting_1">Tokyo</td>
//                               <td className="dt-type-numeric">20</td>
//                               <td>14/08/2008</td>
//                               <td className="dt-type-numeric">$163,000</td>
//                               <td>
//                                 <ul className="action">
//                                   <li className="edit">
//                                     {" "}
//                                     <a href="#!">
//                                       <i className="fa-regular fa-pen-to-square" />
//                                     </a>
//                                   </li>
//                                   <li className="delete">
//                                     <a href="#!">
//                                       <i className="fa-solid fa-trash-can" />
//                                     </a>
//                                   </li>
//                                 </ul>
//                               </td>
//                             </tr>
//                             <tr>
//                               <td>Rhona Davidson</td>
//                               <td>
//                                 <span className="badge rounded-pill badge-light-warning">
//                                   Integration Specialist
//                                 </span>
//                               </td>
//                               <td className="sorting_1">Tokyo</td>
//                               <td className="dt-type-numeric">55</td>
//                               <td>14/10/2010</td>
//                               <td className="dt-type-numeric">$327,900</td>
//                               <td>
//                                 <ul className="action">
//                                   <li className="edit">
//                                     {" "}
//                                     <a href="#!">
//                                       <i className="fa-regular fa-pen-to-square" />
//                                     </a>
//                                   </li>
//                                   <li className="delete">
//                                     <a href="#!">
//                                       <i className="fa-solid fa-trash-can" />
//                                     </a>
//                                   </li>
//                                 </ul>
//                               </td>
//                             </tr>
//                             <tr>
//                               <td>Airi Satou</td>
//                               <td>
//                                 <span className="badge rounded-pill badge-light-secondary">
//                                   Accountant
//                                 </span>
//                               </td>
//                               <td className="sorting_1">Tokyo</td>
//                               <td className="dt-type-numeric">33</td>
//                               <td>28/11/2008</td>
//                               <td className="dt-type-numeric">$162,700</td>
//                               <td>
//                                 <ul className="action">
//                                   <li className="edit">
//                                     {" "}
//                                     <a href="#!">
//                                       <i className="fa-regular fa-pen-to-square" />
//                                     </a>
//                                   </li>
//                                   <li className="delete">
//                                     <a href="#!">
//                                       <i className="fa-solid fa-trash-can" />
//                                     </a>
//                                   </li>
//                                 </ul>
//                               </td>
//                             </tr>
//                             <tr>
//                               <td>Garrett Winters</td>
//                               <td>
//                                 <span className="badge rounded-pill badge-light-secondary">
//                                   Accountant
//                                 </span>
//                               </td>
//                               <td className="sorting_1">Tokyo</td>
//                               <td className="dt-type-numeric">63</td>
//                               <td>25/07/2015</td>
//                               <td className="dt-type-numeric">$170,750</td>
//                               <td>
//                                 <ul className="action">
//                                   <li className="edit">
//                                     {" "}
//                                     <a href="#!">
//                                       <i className="fa-regular fa-pen-to-square" />
//                                     </a>
//                                   </li>
//                                   <li className="delete">
//                                     <a href="#!">
//                                       <i className="fa-solid fa-trash-can" />
//                                     </a>
//                                   </li>
//                                 </ul>
//                               </td>
//                             </tr>
//                             <tr>
//                               <td>Michael Bruce</td>
//                               <td>
//                                 <span className="badge rounded-pill badge-light-danger">
//                                   Javascript Developer
//                                 </span>
//                               </td>
//                               <td className="sorting_1">Singapore</td>
//                               <td className="dt-type-numeric">29</td>
//                               <td>27/06/2011</td>
//                               <td className="dt-type-numeric">$183,000</td>
//                               <td>
//                                 <ul className="action">
//                                   <li className="edit">
//                                     {" "}
//                                     <a href="#!">
//                                       <i className="fa-regular fa-pen-to-square" />
//                                     </a>
//                                   </li>
//                                   <li className="delete">
//                                     <a href="#!">
//                                       <i className="fa-solid fa-trash-can" />
//                                     </a>
//                                   </li>
//                                 </ul>
//                               </td>
//                             </tr>
//                             <tr>
//                               <td>Serge Baldwin</td>
//                               <td>
//                                 <span className="badge rounded-pill badge-light-primary">
//                                   Data Coordinator
//                                 </span>
//                               </td>
//                               <td className="sorting_1">Singapore</td>
//                               <td className="dt-type-numeric">64</td>
//                               <td>09/04/2015</td>
//                               <td className="dt-type-numeric">$138,575</td>
//                               <td>
//                                 <ul className="action">
//                                   <li className="edit">
//                                     {" "}
//                                     <a href="#!">
//                                       <i className="fa-regular fa-pen-to-square" />
//                                     </a>
//                                   </li>
//                                   <li className="delete">
//                                     <a href="#!">
//                                       <i className="fa-solid fa-trash-can" />
//                                     </a>
//                                   </li>
//                                 </ul>
//                               </td>
//                             </tr>
//                             <tr>
//                               <td>Olivia Liang</td>
//                               <td>
//                                 <span className="badge rounded-pill badge-light-primary">
//                                   Support Engineer
//                                 </span>
//                               </td>
//                               <td className="sorting_1">Singapore</td>
//                               <td className="dt-type-numeric">64</td>
//                               <td>13/02/2017</td>
//                               <td className="dt-type-numeric">$234,500</td>
//                               <td>
//                                 <ul className="action">
//                                   <li className="edit">
//                                     {" "}
//                                     <a href="#!">
//                                       <i className="fa-regular fa-pen-to-square" />
//                                     </a>
//                                   </li>
//                                   <li className="delete">
//                                     <a href="#!">
//                                       <i className="fa-solid fa-trash-can" />
//                                     </a>
//                                   </li>
//                                 </ul>
//                               </td>
//                             </tr>
//                             <tr>
//                               <td>Jennifer Chang</td>
//                               <td>
//                                 <span className="badge rounded-pill badge-light-warning">
//                                   Regional Director
//                                 </span>
//                               </td>
//                               <td className="sorting_1">Singapore</td>
//                               <td className="dt-type-numeric">28</td>
//                               <td>14/11/2023</td>
//                               <td className="dt-type-numeric">$357,650</td>
//                               <td>
//                                 <ul className="action">
//                                   <li className="edit">
//                                     {" "}
//                                     <a href="#!">
//                                       <i className="fa-regular fa-pen-to-square" />
//                                     </a>
//                                   </li>
//                                   <li className="delete">
//                                     <a href="#!">
//                                       <i className="fa-solid fa-trash-can" />
//                                     </a>
//                                   </li>
//                                 </ul>
//                               </td>
//                             </tr>
//                             <tr>
//                               <td>Michelle House</td>
//                               <td>
//                                 <span className="badge rounded-pill badge-light-warning">
//                                   Integration Specialist
//                                 </span>
//                               </td>
//                               <td className="sorting_1">Sidney</td>
//                               <td className="dt-type-numeric">37</td>
//                               <td>02/06/2011</td>
//                               <td className="dt-type-numeric">$95,400</td>
//                               <td>
//                                 <ul className="action">
//                                   <li className="edit">
//                                     {" "}
//                                     <a href="#!">
//                                       <i className="fa-regular fa-pen-to-square" />
//                                     </a>
//                                   </li>
//                                   <li className="delete">
//                                     <a href="#!">
//                                       <i className="fa-solid fa-trash-can" />
//                                     </a>
//                                   </li>
//                                 </ul>
//                               </td>
//                             </tr>
//                           </tbody>
//                           <tfoot>
//                             <tr role="row">
//                               <th data-dt-column={0} rowSpan={1} colSpan={1}>
//                                 <span className="dt-column-title">Name</span>
//                               </th>
//                               <th data-dt-column={1} rowSpan={1} colSpan={1}>
//                                 <span className="dt-column-title">
//                                   Position
//                                 </span>
//                               </th>
//                               <th data-dt-column={2} rowSpan={1} colSpan={1}>
//                                 <span className="dt-column-title">Office</span>
//                               </th>
//                               <th
//                                 data-dt-column={3}
//                                 rowSpan={1}
//                                 colSpan={1}
//                                 className="dt-type-numeric"
//                               >
//                                 <span className="dt-column-title">Age</span>
//                               </th>
//                               <th data-dt-column={4} rowSpan={1} colSpan={1}>
//                                 <span className="dt-column-title">
//                                   Start date
//                                 </span>
//                               </th>
//                               <th
//                                 data-dt-column={5}
//                                 rowSpan={1}
//                                 colSpan={1}
//                                 className="dt-type-numeric"
//                               >
//                                 <span className="dt-column-title">Salary</span>
//                               </th>
//                               <th data-dt-column={6} rowSpan={1} colSpan={1}>
//                                 <span className="dt-column-title">Action </span>
//                               </th>
//                             </tr>
//                           </tfoot>
//                         </table>
//                       </div>
//                     </div>
//                     <div className="row mt-2 justify-content-between">
//                       <div className="col-md-auto me-auto ">
//                         <div
//                           className="dt-info"
//                           aria-live="polite"
//                           id="basic-9_info"
//                           role="status"
//                         >
//                           Showing 1 to 10 of 57 entries
//                         </div>
//                       </div>
//                       <div className="col-md-auto ms-auto ">
//                         <div className="dt-paging paging_full_numbers">
//                           <ul className="pagination">
//                             <li className="dt-paging-button page-item disabled">
//                               <a
//                                 className="page-link first"
//                                 aria-controls="basic-9"
//                                 aria-disabled="true"
//                                 aria-label="First"
//                                 data-dt-idx="first"
//                                 tabIndex={-1}
//                               >
//                                 «
//                               </a>
//                             </li>
//                             <li className="dt-paging-button page-item disabled">
//                               <a
//                                 className="page-link previous"
//                                 aria-controls="basic-9"
//                                 aria-disabled="true"
//                                 aria-label="Previous"
//                                 data-dt-idx="previous"
//                                 tabIndex={-1}
//                               >
//                                 ‹
//                               </a>
//                             </li>
//                             <li className="dt-paging-button page-item active">
//                               <a
//                                 href="#"
//                                 className="page-link"
//                                 aria-controls="basic-9"
//                                 aria-current="page"
//                                 data-dt-idx={0}
//                                 tabIndex={0}
//                               >
//                                 1
//                               </a>
//                             </li>
//                             <li className="dt-paging-button page-item">
//                               <a
//                                 href="#"
//                                 className="page-link"
//                                 aria-controls="basic-9"
//                                 data-dt-idx={1}
//                                 tabIndex={0}
//                               >
//                                 2
//                               </a>
//                             </li>
//                             <li className="dt-paging-button page-item">
//                               <a
//                                 href="#"
//                                 className="page-link"
//                                 aria-controls="basic-9"
//                                 data-dt-idx={2}
//                                 tabIndex={0}
//                               >
//                                 3
//                               </a>
//                             </li>
//                             <li className="dt-paging-button page-item">
//                               <a
//                                 href="#"
//                                 className="page-link"
//                                 aria-controls="basic-9"
//                                 data-dt-idx={3}
//                                 tabIndex={0}
//                               >
//                                 4
//                               </a>
//                             </li>
//                             <li className="dt-paging-button page-item">
//                               <a
//                                 href="#"
//                                 className="page-link"
//                                 aria-controls="basic-9"
//                                 data-dt-idx={4}
//                                 tabIndex={0}
//                               >
//                                 5
//                               </a>
//                             </li>
//                             <li className="dt-paging-button page-item">
//                               <a
//                                 href="#"
//                                 className="page-link"
//                                 aria-controls="basic-9"
//                                 data-dt-idx={5}
//                                 tabIndex={0}
//                               >
//                                 6
//                               </a>
//                             </li>
//                             <li className="dt-paging-button page-item">
//                               <a
//                                 href="#"
//                                 className="page-link next"
//                                 aria-controls="basic-9"
//                                 aria-label="Next"
//                                 data-dt-idx="next"
//                                 tabIndex={0}
//                               >
//                                 ›
//                               </a>
//                             </li>
//                             <li className="dt-paging-button page-item">
//                               <a
//                                 href="#"
//                                 className="page-link last"
//                                 aria-controls="basic-9"
//                                 aria-label="Last"
//                                 data-dt-idx="last"
//                                 tabIndex={0}
//                               >
//                                 »
//                               </a>
//                             </li>
//                           </ul>
//                         </div>
//                       </div>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>
//       </div> */}
//       <Container className="basic_table" fluid>
//         <Row>
//           <HoverableRowsClass />
//           <CustomPagination
//             currentPage={currentPage}
//             totalPages={15}
//             onPageChange={setCurrentPage}
//             showFirstLast={false}
//             maxVisiblePages={3}
//           />
//         </Row>
//       </Container>

//       {/* <CustomPagination
//         currentPage={currentPage}
//         totalPages={20}
//         onPageChange={setCurrentPage}
//         paginationType="primary"
//       /> */}
//     </div>
//   );
// }

// export default page;

// "use client";
// import Breadcrumbs from "@/CommonElements/Breadcrumbs";
// import CustomPagination from "@/CommonElements/Pagination";
// import {
//   Container,
//   Row,
//   Col,
//   Card,
//   CardBody,
//   Input,
//   Button,
//   Dropdown,
//   DropdownToggle,
//   DropdownMenu,
//   DropdownItem,
// } from "reactstrap";
// import React, { useState, useEffect } from "react";
// import Link from "next/link";
// import { useRouter } from "next/navigation";
// import CustomTable, { TableColumn } from "@/CommonElements/CustomTable";

// // Types
// interface Customer {
//   id: number;
//   name: string;
//   email: string;
//   phone: string;
//   vehicleNumber: string;
//   vehicleModel: string;
//   status: "active" | "inactive" | "pending";
//   joinDate: string;
//   totalSpent: number;
//   totalOrders: number;
//   openJobs: number;
// }

// // Mock data
// const customersData: Customer[] = [
//   {
//     id: 1,
//     name: "John Doe",
//     email: "john@example.com",
//     phone: "+1 234 567 890",
//     vehicleNumber: "ABC123",
//     vehicleModel: "Toyota Camry 2022",
//     status: "active",
//     joinDate: "2023-01-15",
//     totalSpent: 1250.75,
//     totalOrders: 15,
//     openJobs: 2,
//   },
//   {
//     id: 2,
//     name: "Jane Smith",
//     email: "jane@example.com",
//     phone: "+1 234 567 891",
//     vehicleNumber: "XYZ789",
//     vehicleModel: "Honda Civic 2021",
//     status: "active",
//     joinDate: "2023-03-20",
//     totalSpent: 845.5,
//     totalOrders: 8,
//     openJobs: 1,
//   },
//   {
//     id: 3,
//     name: "Mike Johnson",
//     email: "mike@example.com",
//     phone: "+1 234 567 892",
//     vehicleNumber: "DEF456",
//     vehicleModel: "Ford F-150 2023",
//     status: "inactive",
//     joinDate: "2023-02-10",
//     totalSpent: 2100.0,
//     totalOrders: 22,
//     openJobs: 0,
//   },
//   {
//     id: 4,
//     name: "Sarah Wilson",
//     email: "sarah@example.com",
//     phone: "+1 234 567 893",
//     vehicleNumber: "GHI789",
//     vehicleModel: "BMW X5 2022",
//     status: "pending",
//     joinDate: "2023-04-05",
//     totalSpent: 150.25,
//     totalOrders: 3,
//     openJobs: 1,
//   },
// ];

// function CustomerPage() {
//   const router = useRouter();
//   const [currentPage, setCurrentPage] = useState(1);
//   const [customers, setCustomers] = useState<Customer[]>(customersData);
//   const [searchTerm, setSearchTerm] = useState("");
//   const [statusFilter, setStatusFilter] = useState("all");
//   const [dropdownOpen, setDropdownOpen] = useState(false);
//   const itemsPerPage = 10;

//   const toggleDropdown = () => setDropdownOpen((prevState) => !prevState);

//   // Filter customers based on search and filters
//   const filteredCustomers = customers.filter((customer) => {
//     const matchesSearch =
//       customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
//       customer.phone.includes(searchTerm) ||
//       customer.vehicleNumber.toLowerCase().includes(searchTerm.toLowerCase());

//     const matchesStatus =
//       statusFilter === "all" || customer.status === statusFilter;

//     return matchesSearch && matchesStatus;
//   });

//   // Pagination
//   const totalPages = Math.ceil(filteredCustomers.length / itemsPerPage);
//   const paginatedCustomers = filteredCustomers.slice(
//     (currentPage - 1) * itemsPerPage,
//     currentPage * itemsPerPage
//   );

//   // Status badge render function
//   const renderStatusBadge = (value: string) => {
//     const statusConfig = {
//       active: { class: "bg-success", label: "Active" },
//       inactive: { class: "bg-secondary", label: "Inactive" },
//       pending: { class: "bg-warning", label: "Pending" },
//     };

//     const config = statusConfig[value as keyof typeof statusConfig] || {
//       class: "bg-secondary",
//       label: value,
//     };

//     return (
//       <span className={`badge ${config.class} text-white`}>{config.label}</span>
//     );
//   };

//   const columns: TableColumn[] = [
//     {
//       key: "id",
//       label: "ID",
//       sortable: true,
//     },
//     {
//       key: "name",
//       label: "Customer Name",
//       sortable: true,
//       render: (value: string, row: Customer) => (
//         <div>
//           <div
//             className="fw-bold text-primary cursor-pointer"
//             onClick={() => router.push(`/customer/${row.id}`)}
//           >
//             {value}
//           </div>
//           <small className="text-muted d-block">{row.email}</small>
//           <small className="text-muted d-md-none">{row.phone}</small>
//         </div>
//       ),
//     },
//     {
//       key: "phone",
//       label: "Phone",
//       sortable: false,
//       hideOnMobile: true,
//     },
//     {
//       key: "vehicleNumber",
//       label: "Vehicle No.",
//       sortable: true,
//     },
//     {
//       key: "vehicleModel",
//       label: "Vehicle Model",
//       sortable: true,
//       hideOnMobile: true,
//     },
//     {
//       key: "status",
//       label: "Status",
//       sortable: true,
//       render: (value: string) => renderStatusBadge(value),
//     },
//     {
//       key: "totalOrders",
//       label: "Orders",
//       sortable: true,
//       render: (value: number) => (
//         <span className="fw-bold text-primary">{value}</span>
//       ),
//     },
//     {
//       key: "totalSpent",
//       label: "Spent",
//       sortable: true,
//       hideOnMobile: true,
//       render: (value: number) => `$${value.toLocaleString()}`,
//     },
//     {
//       key: "openJobs",
//       label: "Open Jobs",
//       sortable: true,
//       render: (value: number) => (
//         <span
//           className={`fw-bold ${value > 0 ? "text-warning" : "text-success"}`}
//         >
//           {value}
//         </span>
//       ),
//     },
//     {
//       key: "actions",
//       label: "Actions",
//       sortable: false,
//       render: (_: any, row: Customer) => (
//         <div className="d-flex gap-1">
//           <Button
//             color="primary"
//             size="sm"
//             className="action-btn"
//             onClick={() => router.push(`/customer/${row.id}`)}
//             title="View"
//           >
//             <i className="fa-regular fa-eye" />
//           </Button>
//           <Button
//             color="warning"
//             size="sm"
//             className="action-btn"
//             onClick={() => router.push(`/customer/${row.id}?edit=true`)}
//             title="Edit"
//           >
//             <i className="fa-regular fa-pen-to-square" />
//           </Button>
//           <Button
//             color="danger"
//             size="sm"
//             className="action-btn"
//             onClick={() => handleDeleteCustomer(row.id)}
//             title="Delete"
//           >
//             <i className="fa-solid fa-trash-can" />
//           </Button>
//         </div>
//       ),
//     },
//   ];

//   const handleDeleteCustomer = (id: number) => {
//     if (confirm("Are you sure you want to delete this customer?")) {
//       setCustomers(customers.filter((customer) => customer.id !== id));
//     }
//   };

//   return (
//     <div className="page-body">
//       <Breadcrumbs
//         title="Customer Management"
//         mainTitle="Customer Management"
//         parent="Dashboard"
//       />

//       <Container fluid>
//         <Row>
//           <Col sm={12}>
//             <Card className="customer-card">
//               <CardBody>
//                 {/* Header with Search and Add Button */}
//                 <div className="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3 mb-4">
//                   <div className="d-flex flex-column flex-md-row gap-3 align-items-start align-items-md-center w-100">
//                     {/* Search Box */}
//                     <div className="search-box w-100 w-md-auto">
//                       <div className="position-relative">
//                         <Input
//                           type="search"
//                           placeholder="Search customers..."
//                           value={searchTerm}
//                           onChange={(e) => setSearchTerm(e.target.value)}
//                           className="form-control"
//                         />
//                         <i className="fa fa-search search-icon position-absolute"></i>
//                       </div>
//                     </div>

//                     {/* Status Filter */}
//                     {/* <Dropdown
//                       isOpen={dropdownOpen}
//                       toggle={toggleDropdown}
//                       className="w-100 w-md-auto"
//                     >
//                       <DropdownToggle
//                         caret
//                         color="outline-secondary"
//                         className="w-100"
//                       >
//                         Status: {statusFilter === "all" ? "All" : statusFilter}
//                       </DropdownToggle>
//                       <DropdownMenu>
//                         <DropdownItem onClick={() => setStatusFilter("all")}>
//                           All Status
//                         </DropdownItem>
//                         <DropdownItem onClick={() => setStatusFilter("active")}>
//                           Active
//                         </DropdownItem>
//                         <DropdownItem
//                           onClick={() => setStatusFilter("inactive")}
//                         >
//                           Inactive
//                         </DropdownItem>
//                         <DropdownItem
//                           onClick={() => setStatusFilter("pending")}
//                         >
//                           Pending
//                         </DropdownItem>
//                       </DropdownMenu>
//                     </Dropdown> */}
//                   </div>

//                   {/* Add Customer Button */}
//                   <Link href="/customer/add" className="w-100 w-md-auto">
//                     <Button color="primary" className="w-100">
//                       <i className="fa fa-plus me-2"></i>
//                       Add Customer
//                     </Button>
//                   </Link>
//                 </div>

//                 {/* Customer Table */}
//                 <div className="table-responsive-custom">
//                   <CustomTable
//                     data={paginatedCustomers}
//                     columns={columns}
//                     heading="Customers"
//                     headingSpan="Manage your customers and their vehicles"
//                     hover={true}
//                     striped={true}
//                     responsive={true}
//                     responsiveClass="customer-responsive-table"
//                   />
//                 </div>

//                 {/* Pagination and Info */}
//                 <div className="d-flex flex-column flex-md-row justify-content-between align-items-center gap-3 mt-4">
//                   <div className="text-center text-md-start">
//                     Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
//                     {Math.min(
//                       currentPage * itemsPerPage,
//                       filteredCustomers.length
//                     )}{" "}
//                     of {filteredCustomers.length} entries
//                   </div>
//                   <CustomPagination
//                     currentPage={currentPage}
//                     totalPages={totalPages}
//                     onPageChange={setCurrentPage}
//                     showFirstLast={true}
//                     maxVisiblePages={5}
//                     paginationType="primary"
//                     className="justify-content-center justify-content-md-end"
//                   />
//                 </div>
//               </CardBody>
//             </Card>
//           </Col>
//         </Row>
//       </Container>

//       <style jsx>{`
//         .customer-card {
//           box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
//           border: 1px solid rgba(0, 0, 0, 0.125);
//         }

//         .search-box .search-icon {
//           top: 50%;
//           right: 15px;
//           transform: translateY(-50%);
//           color: #6c757d;
//         }

//         .action-btn {
//           padding: 0.25rem 0.5rem;
//           font-size: 0.75rem;
//         }

//         @media (max-width: 768px) {
//           .customer-card .card-body {
//             padding: 1rem;
//           }

//           .table-responsive-custom {
//             border: 1px solid #dee2e6;
//             border-radius: 0.375rem;
//             overflow-x: auto;
//           }
//         }

//         @media (max-width: 576px) {
//           .action-btn {
//             padding: 0.2rem 0.4rem;
//             font-size: 0.7rem;
//           }
//         }
//       `}</style>
//     </div>
//   );
// }

// export default CustomerPage;

"use client";
import Breadcrumbs from "@/CommonElements/Breadcrumbs";
import CustomPagination from "@/CommonElements/Pagination";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  Input,
  Button,
  Table,
  Dropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
} from "reactstrap";
import React, { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";

// Types
interface Customer {
  id: number;
  name: string;
  email: string;
  phone: string;
  vehicleNumber: string;
  vehicleModel: string;
  status: "active" | "inactive" | "pending";
  joinDate: string;
  totalSpent: number;
  totalOrders: number;
  openJobs: number;
}

// Mock data
const customersData: Customer[] = [
  {
    id: 1,
    name: "John Doe",
    email: "john@example.com",
    phone: "+1 234 567 890",
    vehicleNumber: "ABC123",
    vehicleModel: "Toyota Camry 2022",
    status: "active",
    joinDate: "2023-01-15",
    totalSpent: 1250.75,
    totalOrders: 15,
    openJobs: 2,
  },
  {
    id: 2,
    name: "Jane Smith",
    email: "jane@example.com",
    phone: "+1 234 567 891",
    vehicleNumber: "XYZ789",
    vehicleModel: "Honda Civic 2021",
    status: "active",
    joinDate: "2023-03-20",
    totalSpent: 845.5,
    totalOrders: 8,
    openJobs: 1,
  },
  {
    id: 3,
    name: "Mike Johnson",
    email: "mike@example.com",
    phone: "+1 234 567 892",
    vehicleNumber: "DEF456",
    vehicleModel: "Ford F-150 2023",
    status: "inactive",
    joinDate: "2023-02-10",
    totalSpent: 2100.0,
    totalOrders: 22,
    openJobs: 0,
  },
  {
    id: 4,
    name: "Sarah Wilson",
    email: "sarah@example.com",
    phone: "+1 234 567 893",
    vehicleNumber: "GHI789",
    vehicleModel: "BMW X5 2022",
    status: "pending",
    joinDate: "2023-04-05",
    totalSpent: 150.25,
    totalOrders: 3,
    openJobs: 1,
  },
  {
    id: 5,
    name: "Robert Brown",
    email: "robert@example.com",
    phone: "+1 234 567 894",
    vehicleNumber: "JKL012",
    vehicleModel: "Mercedes C-Class 2023",
    status: "active",
    joinDate: "2023-05-12",
    totalSpent: 3200.0,
    totalOrders: 25,
    openJobs: 3,
  },
  {
    id: 6,
    name: "Emily Davis",
    email: "emily@example.com",
    phone: "+1 234 567 895",
    vehicleNumber: "MNO345",
    vehicleModel: "Audi Q5 2022",
    status: "active",
    joinDate: "2023-06-18",
    totalSpent: 1800.5,
    totalOrders: 12,
    openJobs: 0,
  },
];

function CustomerPage() {
  const router = useRouter();
  const [currentPage, setCurrentPage] = useState(1);
  const [customers, setCustomers] = useState<Customer[]>(customersData);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const itemsPerPage = 5;

  const toggleDropdown = () => setDropdownOpen((prevState) => !prevState);

  // Filter customers based on search and filters
  const filteredCustomers = customers.filter((customer) => {
    const matchesSearch =
      customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      customer.phone.includes(searchTerm) ||
      customer.vehicleNumber.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus =
      statusFilter === "all" || customer.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  // Pagination
  const totalPages = Math.ceil(filteredCustomers.length / itemsPerPage);
  const paginatedCustomers = filteredCustomers.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  // Status badge render function
  const renderStatusBadge = (value: string) => {
    const statusConfig = {
      active: { class: "bg-success", label: "Active" },
      inactive: { class: "bg-secondary", label: "Inactive" },
      pending: { class: "bg-warning", label: "Pending" },
    };

    const config = statusConfig[value as keyof typeof statusConfig] || {
      class: "bg-secondary",
      label: value,
    };

    return (
      <span className={`badge ${config.class} text-white`}>{config.label}</span>
    );
  };

  const handleDeleteCustomer = (id: number) => {
    if (confirm("Are you sure you want to delete this customer?")) {
      setCustomers(customers.filter((customer) => customer.id !== id));
    }
  };

  return (
    <div className="page-body">
      <Breadcrumbs
        title="Customer Management"
        mainTitle="Customer Management"
        parent="Dashboard"
      />

      <Container fluid>
        <Row>
          <Col sm={12}>
            <Card className="customer-card">
              <CardBody>
                {/* Header with Search and Add Button */}
                {/* <div className="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3 mb-4"> */}
                {/* <div className="d-flex flex-column flex-md-row gap-3 align-items-start align-items-md-center w-100">
                   
                    <div className="search-box w-100 w-md-auto">
                      <div className="position-relative">
                        <Input
                          type="search"
                          placeholder="Search customers..."
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                          className="form-control"
                        />
                        <i className="fa fa-search search-icon position-absolute"></i>
                      </div>
                    </div>

                    
                 


                   <Dropdown
                      isOpen={dropdownOpen}
                      toggle={toggleDropdown}
                      className="w-100 w-md-auto"
                    >
                      <DropdownToggle
                        caret
                        color="outline-secondary"
                        className="w-100"
                      >
                        Status: {statusFilter === "all" ? "All" : statusFilter}
                      </DropdownToggle>
                      <DropdownMenu>
                        <DropdownItem onClick={() => setStatusFilter("all")}>
                          All Status
                        </DropdownItem>
                        <DropdownItem onClick={() => setStatusFilter("active")}>
                          Active
                        </DropdownItem>
                        <DropdownItem
                          onClick={() => setStatusFilter("inactive")}
                        >
                          Inactive
                        </DropdownItem>
                        <DropdownItem
                          onClick={() => setStatusFilter("pending")}
                        >
                          Pending
                        </DropdownItem>
                      </DropdownMenu>
                    </Dropdown>

                    
                  </div> */}

                {/* Add Customer Button */}
                {/* <Link href="/customer/add" className="w-100 w-md-auto">
                    <Button color="primary" className="w-100">
                      <i className="fa fa-plus me-2"></i>
                      Add Customer
                    </Button>
                  </Link>
                </div> */}
                <div className="row align-items-center mb-4 g-3">
                  {/* Search Bar - Left (1/4 width) */}
                  <div className="col-12 col-md-3">
                    <div className="position-relative">
                      <Input
                        type="search"
                        placeholder="Search customers..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="form-control"
                      />
                      <i
                        className="fa fa-search position-absolute"
                        style={{
                          right: "10px",
                          top: "50%",
                          transform: "translateY(-50%)",
                          color: "#aaa",
                        }}
                      ></i>
                    </div>
                  </div>

                  {/* Spacer (middle empty space) */}
                  <div className="d-none d-md-block col-md-6"></div>

                  {/* Add Customer Button - Right (1/4 width) */}
                  <div className="col-12 col-md-3 d-flex justify-content-md-end">
                    <Link
                      href="/admin/customer/add"
                      className="w-100 w-md-auto"
                    >
                      <Button color="primary" className="w-100 w-md-auto">
                        <i className="fa fa-plus me-2"></i>
                        Add Customer
                      </Button>
                    </Link>
                  </div>
                </div>

                {/* Customer Table */}
                <div className="table-responsive">
                  <Table hover className="customer-table mb-0">
                    <thead>
                      <tr>
                        <th>ID</th>
                        <th>Customer Name</th>
                        <th>Phone</th>
                        <th>Vehicle No.</th>
                        <th> Model</th>
                        <th>Status</th>
                        <th>Orders</th>
                        <th>Total Spent</th>
                        <th>Open Jobs</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {paginatedCustomers.length === 0 ? (
                        <tr>
                          <td colSpan={10} className="text-center py-4">
                            No customers found
                          </td>
                        </tr>
                      ) : (
                        paginatedCustomers.map((customer) => (
                          <tr key={customer.id}>
                            <td>
                              <strong>{customer.id}</strong>
                            </td>
                            <td>
                              <div
                                className="fw-bold text-primary cursor-pointer"
                                onClick={() =>
                                  router.push(`/admin/customer/${customer.id}`)
                                }
                              >
                                {customer.name}
                              </div>
                              <small className="text-muted d-block">
                                {customer.email}
                              </small>
                            </td>

                            <td className="no-wrap">{customer.phone}</td>
                            <td>
                              <span className="badge bg-light text-dark text-muted">
                                {customer.vehicleNumber}
                              </span>
                            </td>
                            <td>{customer.vehicleModel}</td>
                            <td>{renderStatusBadge(customer.status)}</td>
                            {/* <td>
                              <span className="fw-bold text-primary">
                                {customer.totalOrders}
                              </span>
                            </td> */}
                            <td>{customer.totalOrders}</td>
                            {/* <td className="d-none d-sm-table-cell">
                              <strong>
                                ${customer.totalSpent.toLocaleString()}
                              </strong>
                            </td> */}
                            <td>${customer.totalSpent.toLocaleString()}</td>
                            <td>{customer.openJobs}</td>
                            <td>
                              <div className="d-flex gap-1">
                                <button
                                  color="primary"
                                  // size="sm"
                                  // className="action-btn"
                                    className="action-btn text-white border btn-primary"
                                  onClick={() =>
                                    router.push(
                                      `/admin/customer/${customer.id}`
                                    )
                                  }
                                  title="View"
                                >
                                  {/* <i
                                    className="fa-regular fa-eye"
                                    style={{ color: "white" }}
                                  /> */}
                                  <i className="fa fa-eye"></i>
                                </button>
                                <button
                                  color="warning"
                                    className="action-btn text-white border btn-warning"
                                  // size="sm"
                                  // className="action-btn"
                                  onClick={() =>
                                    router.push(
                                      `/admin/customer/${customer.id}?edit=true`
                                    )
                                  }
                                  title="Edit"
                                >
                                  {/* <i className="fa-regular fa-pen-to-square" /> */}
                                  <i className="icofont icofont-pencil-alt-5"></i>
                                </button>
                                <button
                                  color="danger"
                                  // size="sm"
                                  // className="action-btn"
                                    className="action-btn text-white border btn-danger"
                                  onClick={() =>
                                    handleDeleteCustomer(customer.id)
                                  }
                                  title="Delete"
                                >
                                  {/* <i className="fa-solid fa-trash-can" /> */}
                                  <i className="icofont icofont-ui-delete"></i>
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </Table>
                </div>

                {/* Pagination and Info */}
                <div className="d-flex flex-column flex-md-row justify-content-between align-items-center gap-3 mt-4">
                  <div className="text-center text-md-start text-muted">
                    Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
                    {Math.min(
                      currentPage * itemsPerPage,
                      filteredCustomers.length
                    )}{" "}
                    of {filteredCustomers.length} entries
                  </div>
                  <CustomPagination
                    currentPage={currentPage}
                    totalPages={totalPages}
                    onPageChange={setCurrentPage}
                    showFirstLast={true}
                    maxVisiblePages={5}
                    paginationType="primary"
                    className="justify-content-center justify-content-md-end"
                  />
                </div>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Container>

      <style jsx>{`
        .customer-card {
          box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
          border: 1px solid rgba(0, 0, 0, 0.125);
        }

        // .action-btn {
        //   padding: 0.1rem 0.1rem;
        //   font-size: 0.75rem;
        // }
  .action-btn {
           padding: 0.25rem 0.5rem;
         border-radius:5px;
          font-size: 0.75rem;
        }
        .customer-table {
          font-size: 0.875rem;
          table-layout: auto; /* allow table to expand horizontally */
    white-space: nowrap; /* prevent wrapping for all cells */
        }

        .customer-table td {
          vertical-align: middle;
             white-space: nowrap; /* prevent wrapping per cell */
        }
  .no-wrap {
    white-space: nowrap; /* specifically for phone numbers */
  }
        @media (max-width: 768px) {
          .customer-card .card-body {
            padding: 1rem;
          }

          .table-responsive {
            border: 1px solid #dee2e6;
            border-radius: 0.375rem;
          }

          .customer-table {
            min-width: 1000px;
          }
        }
      `}</style>
    </div>
  );
}

export default CustomerPage;
