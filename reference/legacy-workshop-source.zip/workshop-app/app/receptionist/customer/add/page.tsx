"use client";
import Breadcrumbs from "@/CommonElements/Breadcrumbs";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  Form,
  FormGroup,
  Label,
  Input,
  Button,
  Alert,
} from "reactstrap";
import React, { useState } from "react";
import { useRouter } from "next/navigation";

function AddCustomerPage() {
  const router = useRouter();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    vehicleNumber: "",
    vehicleModel: "",
    vehicleYear: "",
    vin: "",
    status: "active",
  });
  const [showAlert, setShowAlert] = useState(false);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Here you would typically make an API call
    console.log("Customer data:", formData);

    // Show success message
    setShowAlert(true);

    // Redirect after 2 seconds
    setTimeout(() => {
      router.push("/customer");
    }, 2000);
  };

  return (
    <div className="page-body">
      <Breadcrumbs
        title="Add New Customer"
        mainTitle="Add New Customer"
        parent="Customer Management"
      />

      <Container fluid>
        <Row>
          {/* <Col sm={12} md={8} lg={6}> */}
          <Col sm={12}>
            <Card>
              <CardBody>
                {showAlert && (
                  <Alert color="success" className="mb-3">
                    Customer added successfully! Redirecting...
                  </Alert>
                )}

                <Form onSubmit={handleSubmit}>
                  <Row className="text-muted">
                    <Col md={6}>
                      <FormGroup>
                        <Label for="name">Full Name *</Label>
                        <Input
                          type="text"
                          name="name"
                          id="name"
                          value={formData.name}
                          onChange={handleChange}
                          required
                        />
                      </FormGroup>
                    </Col>

                    <Col md={6}>
                      <FormGroup>
                        <Label for="email">Email Address</Label>
                        <Input
                          type="email"
                          name="email"
                          id="email"
                          value={formData.email}
                          onChange={handleChange}
                        />
                      </FormGroup>
                    </Col>
                  </Row>

                  <Row className="text-muted">
                    <Col md={6}>
                      <FormGroup>
                        <Label for="phone">Phone Number *</Label>
                        <Input
                          type="tel"
                          name="phone"
                          id="phone"
                          value={formData.phone}
                          onChange={handleChange}
                          required
                        />
                      </FormGroup>
                    </Col>

                    <Col md={6}>
                      <FormGroup>
                        <Label for="status">Status</Label>
                        <select
                          name="status"
                          id="status"
                          className="form-select border"
                          value={formData.status}
                          onChange={handleChange}
                        >
                          <option value="active">Active</option>
                          <option value="inactive">Inactive</option>
                          <option value="pending">Pending</option>
                        </select>
                      </FormGroup>
                    </Col>
                  </Row>

                  <hr className="my-4" />
                  <h6 className="mb-3 text-muted">Vehicle Information</h6>

                  <Row className="text-muted">
                    <Col md={6}>
                      <FormGroup>
                        <Label for="vehicleNumber">Vehicle Number *</Label>
                        <Input
                          type="text"
                          name="vehicleNumber"
                          id="vehicleNumber"
                          value={formData.vehicleNumber}
                          onChange={handleChange}
                          required
                        />
                      </FormGroup>
                    </Col>

                    <Col md={6}>
                      <FormGroup>
                        <Label for="vehicleModel">Vehicle Model *</Label>
                        <Input
                          type="text"
                          name="vehicleModel"
                          id="vehicleModel"
                          value={formData.vehicleModel}
                          onChange={handleChange}
                          required
                        />
                      </FormGroup>
                    </Col>
                  </Row>

                  <Row className="text-muted">
                    <Col md={6}>
                      <FormGroup>
                        <Label for="vehicleYear">Vehicle Year</Label>
                        <Input
                          type="number"
                          name="vehicleYear"
                          id="vehicleYear"
                          value={formData.vehicleYear}
                          onChange={handleChange}
                          min="1990"
                          max="2024"
                        />
                      </FormGroup>
                    </Col>

                    <Col md={6}>
                      <FormGroup>
                        <Label for="vin">VIN Number</Label>
                        <Input
                          type="text"
                          name="vin"
                          id="vin"
                          value={formData.vin}
                          onChange={handleChange}
                        />
                      </FormGroup>
                    </Col>
                  </Row>

                  <div className="d-flex gap-2 mt-4">
                    <Button type="submit" color="primary">
                      Add Customer
                    </Button>
                    <Button
                      type="button"
                      color="secondary"
                      onClick={() => router.push("/admin/customer")}
                    >
                      Cancel
                    </Button>
                  </div>
                </Form>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Container>
    </div>
  );
}

export default AddCustomerPage;
