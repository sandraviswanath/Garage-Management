"use client";
import Breadcrumbs from "@/CommonElements/Breadcrumbs";
import CustomPagination from "@/CommonElements/Pagination";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  Input,
  Button,
  Table,
  Badge,
  Dropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
} from "reactstrap";
import React, { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";

// Types
interface JobCard {
  id: number;
  jobNumber: string;
  customerName: string;
  vehicleNumber: string;
  vehicleModel: string;
  jobType: "repair" | "service" | "inspection" | "custom";
  status: "open" | "in-progress" | "completed" | "cancelled";
  reportedIssue: string;
  assignedTechnician: string;
  estimatedCost: number;
  actualCost?: number;
  createdAt: string;
  estimatedCompletion: string;
}

// Mock data
const jobCardsData: JobCard[] = [
  {
    id: 1,
    jobNumber: "JC-2024-001",
    customerName: "John Doe",
    vehicleNumber: "ABC123",
    vehicleModel: "Toyota Camry 2022",
    jobType: "service",
    status: "in-progress",
    reportedIssue: "Regular maintenance service",
    assignedTechnician: "Mike Smith",
    estimatedCost: 250.0,
    actualCost: 245.5,
    createdAt: "2024-01-15",
    estimatedCompletion: "2024-01-16",
  },
  {
    id: 2,
    jobNumber: "JC-2024-002",
    customerName: "Jane Smith",
    vehicleNumber: "XYZ789",
    vehicleModel: "Honda Civic 2021",
    jobType: "repair",
    status: "open",
    reportedIssue: "Brake noise and vibration",
    assignedTechnician: "Sarah Johnson",
    estimatedCost: 450.0,
    createdAt: "2024-01-16",
    estimatedCompletion: "2024-01-18",
  },
  {
    id: 3,
    jobNumber: "JC-2024-003",
    customerName: "Mike Johnson",
    vehicleNumber: "DEF456",
    vehicleModel: "Ford F-150 2023",
    jobType: "inspection",
    status: "completed",
    reportedIssue: "Pre-purchase inspection",
    assignedTechnician: "David Wilson",
    estimatedCost: 120.0,
    actualCost: 120.0,
    createdAt: "2024-01-14",
    estimatedCompletion: "2024-01-15",
  },
  {
    id: 4,
    jobNumber: "JC-2024-004",
    customerName: "Sarah Wilson",
    vehicleNumber: "GHI789",
    vehicleModel: "BMW X5 2022",
    jobType: "repair",
    status: "in-progress",
    reportedIssue: "AC not cooling properly",
    assignedTechnician: "Mike Smith",
    estimatedCost: 350.0,
    createdAt: "2024-01-17",
    estimatedCompletion: "2024-01-19",
  },
];

function JobCardsPage() {
  const router = useRouter();
  const [currentPage, setCurrentPage] = useState(1);
  const [jobCards, setJobCards] = useState<JobCard[]>(jobCardsData);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [jobTypeFilter, setJobTypeFilter] = useState("all");
  const itemsPerPage = 10;

  // Filter job cards
  const filteredJobCards = jobCards.filter((jobCard) => {
    const matchesSearch =
      jobCard.jobNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      jobCard.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      jobCard.vehicleNumber.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus =
      statusFilter === "all" || jobCard.status === statusFilter;
    const matchesJobType =
      jobTypeFilter === "all" || jobCard.jobType === jobTypeFilter;

    return matchesSearch && matchesStatus && matchesJobType;
  });

  // Pagination
  const totalPages = Math.ceil(filteredJobCards.length / itemsPerPage);
  const paginatedJobCards = filteredJobCards.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  // Status badge render function
  const renderStatusBadge = (status: string) => {
    const statusConfig = {
      open: { class: "bg-primary", label: "Open" },
      "in-progress": { class: "bg-warning", label: "In Progress" },
      completed: { class: "bg-success", label: "Completed" },
      cancelled: { class: "bg-danger", label: "Cancelled" },
    };

    const config = statusConfig[status as keyof typeof statusConfig] || {
      class: "bg-secondary",
      label: status,
    };

    return <Badge className={config.class}>{config.label}</Badge>;
  };

  // Job type badge render function
  const renderJobTypeBadge = (jobType: string) => {
    const typeConfig = {
      repair: { class: "bg-danger", label: "Repair" },
      service: { class: "bg-info", label: "Service" },
      inspection: { class: "bg-secondary", label: "Inspection" },
      custom: { class: "bg-dark", label: "Custom" },
    };

    const config = typeConfig[jobType as keyof typeof typeConfig] || {
      class: "bg-secondary",
      label: jobType,
    };

    return <Badge className={config.class}>{config.label}</Badge>;
  };

  const handleDeleteJobCard = (id: number) => {
    if (confirm("Are you sure you want to delete this job card?")) {
      setJobCards(jobCards.filter((jobCard) => jobCard.id !== id));
    }
  };

  const handleStatusChange = (
    jobCardId: number,
    newStatus: JobCard["status"]
  ) => {
    setJobCards(
      jobCards.map((jobCard) =>
        jobCard.id === jobCardId ? { ...jobCard, status: newStatus } : jobCard
      )
    );
  };

  return (
    <div className="page-body">
      <Breadcrumbs
        title="Job Card Management"
        mainTitle="Job Card Management"
        parent="Dashboard"
      />

      <Container fluid>
        <Row>
          <Col sm={12}>
            <Card className="job-card">
              <CardBody>
                {/* Header with Search and Create Button */}
                <div className="row align-items-center mb-4 g-3">
                  {/* Search Bar */}
                  <div className="col-12 col-md-3">
                    <div className="position-relative">
                      <Input
                        type="search"
                        placeholder="Search job cards..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="form-control"
                      />
                      <i
                        className="fa fa-search position-absolute"
                        style={{
                          right: "10px",
                          top: "50%",
                          transform: "translateY(-50%)",
                          color: "#aaa",
                        }}
                      ></i>
                    </div>
                  </div>

                  {/* Status Filter */}
                  <div className="col-12 col-md-2">
                    <select
                      className="form-select p-2 border"
                      style={{ fontSize: "0.9rem" }}
                      value={statusFilter}
                      onChange={(e) => setStatusFilter(e.target.value)}
                    >
                      <option value="all">All Status</option>
                      <option value="open">Open</option>
                      <option value="in-progress">In Progress</option>
                      <option value="completed">Completed</option>
                      <option value="cancelled">Cancelled</option>
                    </select>
                  </div>

                  {/* Job Type Filter */}
                  <div className="col-12 col-md-2">
                    <select
                      className="form-select p-2 border"
                      style={{ fontSize: "0.9rem" }}
                      value={jobTypeFilter}
                      onChange={(e) => setJobTypeFilter(e.target.value)}
                    >
                      <option value="all">All Types</option>
                      <option value="repair">Repair</option>
                      <option value="service">Service</option>
                      <option value="inspection">Inspection</option>
                      <option value="custom">Custom</option>
                    </select>
                  </div>

                  {/* Spacer */}
                  <div className="d-none d-md-block col-md-3"></div>

                  {/* Create Job Card Button */}
                  <div className="col-12 col-md-2 d-flex justify-content-md-end">
                    <Link
                      href="/admin/jobcards/create"
                      className="w-100 w-md-auto"
                    >
                      <Button color="primary" className="w-100 w-md-auto">
                        <i className="fa fa-plus me-2"></i>
                        {/* Create Job Card */}
                          Create
                      </Button>
                    </Link>
                  </div>
                </div>

                {/* Job Cards Table */}
                <div className="table-responsive">
                  <Table hover className="job-cards-table mb-0">
                    <thead>
                      <tr>
                        <th>Job Number</th>
                        <th>Customer</th>
                        <th>Vehicle</th>
                        <th>Job Type</th>
                        <th>Reported Issue</th>
                        <th>Technician</th>
                        <th>Estimated Cost</th>
                        <th>Status</th>
                        <th>Created</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {paginatedJobCards.length === 0 ? (
                        <tr>
                          <td colSpan={10} className="text-center py-4">
                            No job cards found
                          </td>
                        </tr>
                      ) : (
                        paginatedJobCards.map((jobCard) => (
                          <tr key={jobCard.id}>
                            <td className="no-wrap">
                              <strong
                                className="text-primary cursor-pointer"
                                onClick={() =>
                                  router.push(`/admin/jobcards/${jobCard.id}`)
                                }
                              >
                                {jobCard.jobNumber}
                              </strong>
                            </td>
                            <td>{jobCard.customerName}</td>
                            <td>
                              <div>
                                <div>{jobCard.vehicleNumber}</div>
                                <small className="text-muted">
                                  {jobCard.vehicleModel}
                                </small>
                              </div>
                            </td>
                            <td>{renderJobTypeBadge(jobCard.jobType)}</td>
                            <td>
                              <div
                                className="text-truncate"
                                style={{ maxWidth: "200px" }}
                                title={jobCard.reportedIssue}
                              >
                                {jobCard.reportedIssue}
                              </div>
                            </td>
                            <td>{jobCard.assignedTechnician}</td>
                            <td>
                              <strong>${jobCard.estimatedCost}</strong>
                            </td>
                            <td>
                              <Dropdown>
                                <DropdownToggle
                                  tag="span"
                                  className="cursor-pointer"
                                  style={{ cursor: "pointer" }}
                                >
                                  {renderStatusBadge(jobCard.status)}
                                </DropdownToggle>
                                <DropdownMenu>
                                  <DropdownItem
                                    onClick={() =>
                                      handleStatusChange(jobCard.id, "open")
                                    }
                                  >
                                    Mark as Open
                                  </DropdownItem>
                                  <DropdownItem
                                    onClick={() =>
                                      handleStatusChange(
                                        jobCard.id,
                                        "in-progress"
                                      )
                                    }
                                  >
                                    Mark as In Progress
                                  </DropdownItem>
                                  <DropdownItem
                                    onClick={() =>
                                      handleStatusChange(
                                        jobCard.id,
                                        "completed"
                                      )
                                    }
                                  >
                                    Mark as Completed
                                  </DropdownItem>
                                  <DropdownItem
                                    onClick={() =>
                                      handleStatusChange(
                                        jobCard.id,
                                        "cancelled"
                                      )
                                    }
                                  >
                                    Mark as Cancelled
                                  </DropdownItem>
                                </DropdownMenu>
                              </Dropdown>
                            </td>
                            <td>
                              {new Date(jobCard.createdAt).toLocaleDateString()}
                            </td>
                            <td>
                              <div className="d-flex gap-1 ">
                                <button
                                  color="primary"
                                 className="action-btn text-white border btn-primary"
                                  onClick={() =>
                                    router.push(`/admin/jobcards/${jobCard.id}`)
                                  }
                                  title="View"
                                >
                                  <i className="fa fa-eye"></i>
                                </button>
                                <button
                                  color="warning"
                                 className="action-btn text-white border btn-warning"
                                  onClick={() =>
                                    router.push(
                                      `/admin/jobcards/${jobCard.id}?edit=true`
                                    )
                                  }
                                  title="Edit"
                                >
                                  <i className="icofont icofont-pencil-alt-5"></i>
                                </button>
                                <button
                                  color="info"
                              className="action-btn text-white border btn-info"
                                  onClick={() => window.print()}
                                  title="Print"
                                >
                                  <i className="fa fa-print"></i>
                                </button>
                                <button
                                  color="danger"
                                     className="action-btn text-white border btn-danger"
                                  onClick={() =>
                                    handleDeleteJobCard(jobCard.id)
                                  }
                                  title="Delete"
                                >
                                  <i className="icofont icofont-ui-delete"></i>
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </Table>
                </div>

                {/* Pagination and Info */}
                <div className="d-flex flex-column flex-md-row justify-content-between align-items-center gap-3 mt-4">
                  <div className="text-center text-md-start text-muted">
                    Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
                    {Math.min(
                      currentPage * itemsPerPage,
                      filteredJobCards.length
                    )}{" "}
                    of {filteredJobCards.length} entries
                  </div>
                  <CustomPagination
                    currentPage={currentPage}
                    totalPages={totalPages}
                    onPageChange={setCurrentPage}
                    showFirstLast={true}
                    maxVisiblePages={5}
                    paginationType="primary"
                    className="justify-content-center justify-content-md-end"
                  />
                </div>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Container>

      {/* <style jsx>{`
        .job-card {
          box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
          border: 1px solid rgba(0, 0, 0, 0.125);
        }

        .action-btn {
          padding: 0.25rem 0.5rem;
          font-size: 0.75rem;
        }

        .cursor-pointer {
          cursor: pointer;
        }

        .job-cards-table {
          font-size: 0.875rem;
        }

        .job-cards-table td {
          vertical-align: middle;
        }

        @media (max-width: 768px) {
          .table-responsive {
            border: 1px solid #dee2e6;
            border-radius: 0.375rem;
          }

          .job-cards-table {
            min-width: 1000px;
            margin-bottom: 0;
          }
        }

        @media (max-width: 576px) {
          .action-btn {
            padding: 0.2rem 0.4rem;
            font-size: 0.7rem;
          }
        }
      `}</style> */}
      <style jsx>{`
        .job-card {
          box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
          border: 1px solid rgba(0, 0, 0, 0.125);
        }

           .action-btn {
           padding: 0.25rem 0.5rem;
         border-radius:5px;
          font-size: 0.75rem;
        }

        .job-table {
          font-size: 0.875rem;
        }

        .job-table td {
          vertical-align: middle;
        }

        @media (max-width: 768px) {
          .job-card .card-body {
            padding: 1rem;
          }

          .table-responsive {
            border: 1px solid #dee2e6;
            border-radius: 0.375rem;
          }

          .job-table {
            min-width: 800px;
          }
        }
      `}</style>
    </div>
  );
}

export default JobCardsPage;
