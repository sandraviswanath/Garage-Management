"use client";
import Breadcrumbs from "@/CommonElements/Breadcrumbs";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  Form,
  FormGroup,
  Label,
  Input,
  Button,
  Alert,
  Table,
  Badge,
} from "reactstrap";
import React, { useState } from "react";
import { useRouter } from "next/navigation";

// Mock data
const customersData = [
  {
    id: 1,
    name: "John Doe",
    vehicleNumber: "ABC123",
    vehicleModel: "Toyota Camry 2022",
  },
  {
    id: 2,
    name: "Jane Smith",
    vehicleNumber: "XYZ789",
    vehicleModel: "Honda Civic 2021",
  },
  {
    id: 3,
    name: "Mike Johnson",
    vehicleNumber: "DEF456",
    vehicleModel: "Ford F-150 2023",
  },
];

const techniciansData = [
  { id: 1, name: "Mike Smith", specialization: "General" },
  { id: 2, name: "Sarah Johnson", specialization: "Brakes & Suspension" },
  { id: 3, name: "David Wilson", specialization: "Engine & Transmission" },
];

const partsInventory = [
  {
    id: 1,
    name: "Engine Oil Synthetic",
    sku: "OIL-SYN-5W30",
    price: 45.99,
    stock: 25,
  },
  { id: 2, name: "Oil Filter", sku: "FIL-OIL-001", price: 12.5, stock: 50 },
  {
    id: 3,
    name: "Brake Pads Front",
    sku: "PAD-BRK-F001",
    price: 85.0,
    stock: 15,
  },
  { id: 4, name: "Air Filter", sku: "FIL-AIR-001", price: 25.0, stock: 30 },
];

// Mock job cards data for generating job numbers
const jobCardsData = [
  { id: 1, jobNumber: "JC-2024-001" },
  { id: 2, jobNumber: "JC-2024-002" },
  { id: 3, jobNumber: "JC-2024-003" },
];

function CreateJobCardPage() {
  const router = useRouter();
  const [showAlert, setShowAlert] = useState(false);
  const [formData, setFormData] = useState({
    customerId: "",
    vehicleNumber: "",
    vehicleModel: "",
    jobType: "service",
    reportedIssue: "",
    assignedTechnician: "",
    estimatedCompletion: "",
    specialInstructions: "",
  });

  const [jobItems, setJobItems] = useState<
    Array<{
      id: number;
      description: string;
      estimatedHours: number;
      rate: number;
      total: number;
    }>
  >([]);

  const [partsUsed, setPartsUsed] = useState<
    Array<{
      id: number;
      partId: number;
      partName: string;
      quantity: number;
      unitPrice: number;
      total: number;
    }>
  >([]);

  const [newJobItem, setNewJobItem] = useState({
    description: "",
    estimatedHours: 0,
    rate: 75, // Default technician rate
  });

  const [selectedPart, setSelectedPart] = useState({
    partId: "",
    quantity: 1,
  });

  // Calculate totals
  const labourTotal = jobItems.reduce((sum, item) => sum + item.total, 0);
  const partsTotal = partsUsed.reduce((sum, part) => sum + part.total, 0);
  const grandTotal = labourTotal + partsTotal;

  const handleFormChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));

    // Auto-fill vehicle details when customer is selected
    if (name === "customerId") {
      const customer = customersData.find((c) => c.id === parseInt(value));
      if (customer) {
        setFormData((prev) => ({
          ...prev,
          vehicleNumber: customer.vehicleNumber,
          vehicleModel: customer.vehicleModel,
        }));
      }
    }
  };

  const handleAddJobItem = () => {
    if (newJobItem.description && newJobItem.estimatedHours > 0) {
      const total = newJobItem.estimatedHours * newJobItem.rate;
      setJobItems([
        ...jobItems,
        {
          id: Date.now(),
          ...newJobItem,
          total,
        },
      ]);
      setNewJobItem({ description: "", estimatedHours: 0, rate: 75 });
    }
  };

  const handleRemoveJobItem = (id: number) => {
    setJobItems(jobItems.filter((item) => item.id !== id));
  };

  const handleAddPart = () => {
    if (selectedPart.partId) {
      const part = partsInventory.find(
        (p) => p.id === parseInt(selectedPart.partId)
      );
      if (part && selectedPart.quantity > 0) {
        const total = part.price * selectedPart.quantity;
        setPartsUsed([
          ...partsUsed,
          {
            id: Date.now(),
            partId: part.id,
            partName: part.name,
            quantity: selectedPart.quantity,
            unitPrice: part.price,
            total,
          },
        ]);
        setSelectedPart({ partId: "", quantity: 1 });
      }
    }
  };

  const handleRemovePart = (id: number) => {
    setPartsUsed(partsUsed.filter((part) => part.id !== id));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Generate job number - FIXED: using jobCardsData instead of undefined variable
    const jobNumber = `JC-${new Date().getFullYear()}-${String(
      jobCardsData.length + 1
    ).padStart(3, "0")}`;

    const jobCardData = {
      ...formData,
      jobNumber,
      jobItems,
      partsUsed,
      labourTotal,
      partsTotal,
      grandTotal,
      createdAt: new Date().toISOString().split("T")[0],
      status: "open" as const,
    };

    console.log("Job Card Data:", jobCardData);
    setShowAlert(true);

    setTimeout(() => {
      router.push("/admin/jobcards");
    }, 2000);
  };

  return (
    <div className="page-body">
      <Breadcrumbs
        title="Create Job Card"
        mainTitle="Create Job Card"
        parent="Job Card Management"
      />

      <Container fluid>
        <Row>
          <Col lg={12}>
            <Card>
              <CardBody>
                {showAlert && (
                  <Alert color="success" className="mb-3">
                    Job card created successfully! Redirecting...
                  </Alert>
                )}

                <Form onSubmit={handleSubmit}>
                  {/* Customer & Vehicle Section */}
                  <div className="mb-4 text-muted">
                    <h5 className="mb-3">Customer & Vehicle Information</h5>
                    <Row>
                      <Col md={6}>
                        <FormGroup>
                          <Label for="customerId">Select Customer *</Label>
                          <select
                            name="customerId"
                            id="customerId"
                            className="form-select border"
                            value={formData.customerId}
                            onChange={handleFormChange}
                            required
                          >
                            <option value="">Choose customer...</option>
                            {customersData.map((customer) => (
                              <option key={customer.id} value={customer.id}>
                                {customer.name} - {customer.vehicleNumber}
                              </option>
                            ))}
                          </select>
                        </FormGroup>
                      </Col>
                      <Col md={6}>
                        <FormGroup>
                          <Label for="jobType">Job Type *</Label>
                          <select
                            name="jobType"
                            id="jobType"
                            className="form-select border"
                            value={formData.jobType}
                            onChange={handleFormChange}
                            required
                          >
                            <option value="service">Service</option>
                            <option value="repair">Repair</option>
                            <option value="inspection">Inspection</option>
                            <option value="custom">Custom</option>
                          </select>
                        </FormGroup>
                      </Col>
                    </Row>
                    <Row>
                      <Col md={6}>
                        <FormGroup>
                          <Label for="vehicleNumber">Vehicle Number *</Label>
                          <Input
                            type="text"
                            name="vehicleNumber"
                            id="vehicleNumber"
                            value={formData.vehicleNumber}
                            onChange={handleFormChange}
                            required
                          />
                        </FormGroup>
                      </Col>
                      <Col md={6}>
                        <FormGroup>
                          <Label for="vehicleModel">Vehicle Model *</Label>
                          <Input
                            type="text"
                            name="vehicleModel"
                            id="vehicleModel"
                            value={formData.vehicleModel}
                            onChange={handleFormChange}
                            required
                          />
                        </FormGroup>
                      </Col>
                    </Row>
                  </div>

                  {/* Job Details Section */}
                  <div className="mb-4 text-muted">
                    <h5 className="mb-3">Job Details</h5>
                    <Row>
                      <Col md={6}>
                        <FormGroup>
                          <Label for="assignedTechnician">
                            Assign Technician *
                          </Label>
                          <select
                            name="assignedTechnician"
                            id="assignedTechnician"
                            className="form-select border"
                            value={formData.assignedTechnician}
                            onChange={handleFormChange}
                            required
                          >
                            <option value="">Select technician...</option>
                            {techniciansData.map((tech) => (
                              <option key={tech.id} value={tech.name}>
                                {tech.name} - {tech.specialization}
                              </option>
                            ))}
                          </select>
                        </FormGroup>
                      </Col>
                      <Col md={6}>
                        <FormGroup>
                          <Label for="estimatedCompletion">
                            Estimated Completion *
                          </Label>
                          <Input
                            type="date"
                            name="estimatedCompletion"
                            id="estimatedCompletion"
                            value={formData.estimatedCompletion}
                            onChange={handleFormChange}
                            required
                          />
                        </FormGroup>
                      </Col>
                    </Row>
                    <FormGroup>
                      <Label for="reportedIssue">Reported Issue *</Label>
                      <Input
                        type="textarea"
                        name="reportedIssue"
                        id="reportedIssue"
                        rows={3}
                        value={formData.reportedIssue}
                        onChange={handleFormChange}
                        placeholder="Describe the issue reported by the customer..."
                        required
                      />
                    </FormGroup>
                    <FormGroup>
                      <Label for="specialInstructions">
                        Special Instructions
                      </Label>
                      <Input
                        type="textarea"
                        name="specialInstructions"
                        id="specialInstructions"
                        rows={2}
                        value={formData.specialInstructions}
                        onChange={handleFormChange}
                        placeholder="Any special instructions or notes..."
                      />
                    </FormGroup>
                  </div>

                  {/* Job Items Section */}
                  <div className="mb-4 text-muted">
                    <h5 className="mb-3">Job Items / Labour Tasks</h5>
                
<Row className="mb-3">
  <Col md={6} className="mb-3 mb-md-0">
    <Input
      type="text"
      placeholder="Task description"
      value={newJobItem.description}
      onChange={(e) =>
        setNewJobItem({
          ...newJobItem,
          description: e.target.value,
        })
      }
    />
  </Col>

  <Col md={2} className="mb-3 mb-md-0">
    <Input
      type="number"
      placeholder="Hours"
      value={newJobItem.estimatedHours}
      onChange={(e) =>
        setNewJobItem({
          ...newJobItem,
          estimatedHours: parseFloat(e.target.value) || 0,
        })
      }
    />
  </Col>

  <Col md={2} className="mb-3 mb-md-0">
    <Input
      type="number"
      placeholder="Rate"
      value={newJobItem.rate}
      onChange={(e) =>
        setNewJobItem({
          ...newJobItem,
          rate: parseFloat(e.target.value) || 0,
        })
      }
    />
  </Col>

  <Col md={2} className="mb-3 mb-md-0">
    <Button
      color="primary"
      onClick={handleAddJobItem}
      className="w-100"
    >
      Add Task
    </Button>
  </Col>
</Row>

                    {jobItems.length > 0 && (
                      <Table size="sm" bordered>
                        <thead>
                          <tr>
                            <th>Description</th>
                            <th>Hours</th>
                            <th>Rate</th>
                            <th>Total</th>
                            <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          {jobItems.map((item) => (
                            <tr key={item.id}>
                              <td>{item.description}</td>
                              <td>{item.estimatedHours}</td>
                              <td>${item.rate}</td>
                              <td>${item.total.toFixed(2)}</td>
                              <td>
                                <Button
                                  color="danger"
                                  size="sm"
                                  onClick={() => handleRemoveJobItem(item.id)}
                                >
                                  <i className="icofont icofont-ui-delete"></i>
                                </Button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </Table>
                    )}
                  </div>

                  {/* Parts Used Section */}
                  <div className="mb-4 text-muted">
                    <h5 className="mb-3">Parts Used</h5>
                    <Row className="mb-3">
                      {/* <Col md={5}> */}
                        <Col md={5} className="mb-3 mb-md-0">
                        <select
                          className="form-select border"
                          value={selectedPart.partId}
                          onChange={(e) =>
                            setSelectedPart({
                              ...selectedPart,
                              partId: e.target.value,
                            })
                          }
                        >
                          <option value="">Select part...</option>
                          {partsInventory.map((part) => (
                            <option key={part.id} value={part.id}>
                              {part.name} (${part.price}) - Stock: {part.stock}
                            </option>
                          ))}
                        </select>
                      </Col>
                      <Col md={2} className="mb-3 mb-md-0">
                        <Input
                          type="number"
                          placeholder="Qty"
                          value={selectedPart.quantity}
                          onChange={(e) =>
                            setSelectedPart({
                              ...selectedPart,
                              quantity: parseInt(e.target.value) || 1,
                            })
                          }
                          min="1"
                        />
                      </Col>
                      <Col md={2} className="mb-3 mb-md-0">
                        <Button
                          color="primary"
                          onClick={handleAddPart}
                          className="w-100"
                        >
                          Add Part
                        </Button>
                      </Col>
                    </Row>

                    {partsUsed.length > 0 && (
                      <Table size="sm" bordered>
                        <thead>
                          <tr>
                            <th>Part Name</th>
                            <th>Qty</th>
                            <th>Unit Price</th>
                            <th>Total</th>
                            <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          {partsUsed.map((part) => (
                            <tr key={part.id}>
                              <td>{part.partName}</td>
                              <td>{part.quantity}</td>
                              <td>${part.unitPrice.toFixed(2)}</td>
                              <td>${part.total.toFixed(2)}</td>
                              <td>
                                <Button
                                  color="danger"
                                  size="sm"
                                  onClick={() => handleRemovePart(part.id)}
                                >
                                  <i className="icofont icofont-ui-delete"></i>
                                </Button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </Table>
                    )}
                  </div>

                  {/* Summary Section */}
                  <div className="mb-4 text-muted">
                    <h5 className="mb-3">Cost Summary</h5>
                    <Card>
                      <CardBody>
                        <Row>
                          <Col md={6}>
                            <div className="d-flex justify-content-between mb-2 text-muted">
                              <span>Labour Total:</span>
                              <strong>${labourTotal.toFixed(2)}</strong>
                            </div>
                            <div className="d-flex justify-content-between mb-2 text-muted">
                              <span>Parts Total:</span>
                              <strong>${partsTotal.toFixed(2)}</strong>
                            </div>
                            <hr />
                            <div className="d-flex justify-content-between text-muted">
                              <span>
                                <strong>Grand Total:</strong>
                              </span>
                              <strong className="text-primary">
                                ${grandTotal.toFixed(2)}
                              </strong>
                            </div>
                          </Col>
                        </Row>
                      </CardBody>
                    </Card>
                  </div>

                  {/* Submit Buttons */}
                  <div className="d-flex gap-2">
                    <Button type="submit" color="primary" size="lg">
                      Create Job Card
                    </Button>
                    <Button
                      type="button"
                      color="secondary"
                      size="lg"
                      onClick={() => router.push("/admin/jobcards")}
                    >
                      Cancel
                    </Button>
                    <Button
                      type="button"
                      color="info"
                      size="lg"
                      onClick={() => window.print()}
                    >
                      <i className="fa fa-print me-2"></i>
                      Print Estimate
                    </Button>
                  </div>
                </Form>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Container>
    </div>
  );
}

export default CreateJobCardPage;