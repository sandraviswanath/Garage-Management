
// "use client";
// import Breadcrumbs from "@/CommonElements/Breadcrumbs";
// import {
//   Container,
//   Row,
//   Col,
//   Card,
//   CardBody,
//   Badge,
//   Button,
//   TabContent,
//   TabPane,
//   Nav,
//   NavItem,
//   NavLink,
//   Table,
//   Progress,
//   Input, // Added missing import
// } from "reactstrap";
// import React, { useState } from "react";
// import { useRouter } from "next/navigation";

// // Mock data
// const jobCardData = {
//   id: 1,
//   jobNumber: "JC-2024-001",
//   customerName: "John Doe",
//   customerPhone: "+1 234 567 890",
//   customerEmail: "john@example.com",
//   vehicleNumber: "ABC123",
//   vehicleModel: "Toyota Camry 2022",
//   vehicleYear: "2022",
//   vin: "1HGCM82633A123456",
//   jobType: "service",
//   status: "in-progress",
//   reportedIssue:
//     "Regular maintenance service including oil change, filter replacement, and general inspection",
//   assignedTechnician: "Mike Smith",
//   estimatedCost: 250.0,
//   actualCost: 245.5,
//   createdAt: "2024-01-15",
//   estimatedCompletion: "2024-01-16",
//   specialInstructions: "Customer requested synthetic oil only",

//   jobItems: [
//     {
//       id: 1,
//       description: "Oil Change - Synthetic",
//       estimatedHours: 0.5,
//       rate: 75,
//       total: 37.5,
//       status: "completed",
//       notes: "Completed successfully",
//     },
//     {
//       id: 2,
//       description: "Oil Filter Replacement",
//       estimatedHours: 0.3,
//       rate: 75,
//       total: 22.5,
//       status: "completed",
//       notes: "Filter replaced",
//     },
//     {
//       id: 3,
//       description: "Air Filter Replacement",
//       estimatedHours: 0.2,
//       rate: 75,
//       total: 15.0,
//       status: "in-progress",
//       notes: "In progress",
//     },
//     {
//       id: 4,
//       description: "Brake Inspection",
//       estimatedHours: 0.5,
//       rate: 75,
//       total: 37.5,
//       status: "pending",
//       notes: "",
//     },
//   ],

//   partsUsed: [
//     {
//       id: 1,
//       partName: "Engine Oil Synthetic",
//       quantity: 1,
//       unitPrice: 45.99,
//       total: 45.99,
//     },
//     {
//       id: 2,
//       partName: "Oil Filter",
//       quantity: 1,
//       unitPrice: 12.5,
//       total: 12.5,
//     },
//     {
//       id: 3,
//       partName: "Air Filter",
//       quantity: 1,
//       unitPrice: 25.0,
//       total: 25.0,
//     },
//   ],

//   photos: [
//     {
//       id: 1,
//       type: "before",
//       url: "/before1.jpg",
//       description: "Engine bay before service",
//       date: "2024-01-15",
//     },
//     {
//       id: 2,
//       type: "after",
//       url: "/after1.jpg",
//       description: "Engine bay after service",
//       date: "2024-01-15",
//     },
//   ],

//   payments: [
//     {
//       id: 1,
//       type: "deposit",
//       amount: 100.0,
//       date: "2024-01-15",
//       status: "paid",
//       method: "Credit Card",
//     },
//     {
//       id: 2,
//       type: "balance",
//       amount: 145.5,
//       date: "2024-01-16",
//       status: "pending",
//       method: "",
//     },
//   ],
// };

// function JobCardDetailPage({ params }: { params: { id: string } }) {
//   const router = useRouter();
//   const [activeTab, setActiveTab] = useState("1");
//   const [jobCard, setJobCard] = useState(jobCardData);

//   const renderStatusBadge = (status: string) => {
//     const statusConfig = {
//       open: { class: "bg-primary", label: "Open" },
//       "in-progress": { class: "bg-warning", label: "In Progress" },
//       completed: { class: "bg-success", label: "Completed" },
//       cancelled: { class: "bg-danger", label: "Cancelled" },
//     };

//     const config = statusConfig[status as keyof typeof statusConfig];
//     return <Badge className={config.class}>{config.label}</Badge>;
//   };

//   const handleStatusChange = (newStatus: typeof jobCard.status) => {
//     setJobCard({ ...jobCard, status: newStatus });
//   };

//   const handleTaskStatusChange = (taskId: number, newStatus: string) => {
//     setJobCard({
//       ...jobCard,
//       jobItems: jobCard.jobItems.map((item) =>
//         item.id === taskId ? { ...item, status: newStatus } : item
//       ),
//     });
//   };

//   // Fixed: Added proper type for the event parameter
//   const handleTaskNotesChange = (
//     taskId: number,
//     e: React.ChangeEvent<HTMLInputElement>
//   ) => {
//     const updatedTasks = jobCard.jobItems.map((t) =>
//       t.id === taskId ? { ...t, notes: e.target.value } : t
//     );
//     setJobCard({ ...jobCard, jobItems: updatedTasks });
//   };

//   // Calculate progress
//   const completedTasks = jobCard.jobItems.filter(
//     (item) => item.status === "completed"
//   ).length;
//   const totalTasks = jobCard.jobItems.length;
//   const progressPercentage =
//     totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;

//   return (
//     <div className="page-body">
//       <Breadcrumbs
//         title={`Job Card - ${jobCard.jobNumber}`}
//         mainTitle="Job Card Details"
//         parent="Job Card Management"
//       />

//       <Container fluid>
//         <Row>
//           <Col lg={4}>
//             {/* Job Card Info Card */}
//             <Card className="mb-4">
//               <CardBody>
//                 <div className="text-center mb-4">
//                   <h4 className="text-primary">{jobCard.jobNumber}</h4>
//                   {renderStatusBadge(jobCard.status)}
//                 </div>

//                 <div className="mb-3 text-muted">
//                   <strong>Customer Information</strong>
//                   <div className="mt-2">
//                     <div className="d-flex justify-content-between py-2 border-bottom">
//                       <span>Name:</span>
//                       <span>{jobCard.customerName}</span>
//                     </div>
//                     <div className="d-flex justify-content-between py-2 border-bottom">
//                       <span>Phone:</span>
//                       <span>{jobCard.customerPhone}</span>
//                     </div>
//                     <div className="d-flex justify-content-between py-2 border-bottom">
//                       <span>Email:</span>
//                       <span>{jobCard.customerEmail}</span>
//                     </div>
//                   </div>
//                 </div>

//                 <div className="mb-3 text-muted">
//                   <strong>Vehicle Information</strong>
//                   <div className="mt-2">
//                     <div className="d-flex justify-content-between py-2 border-bottom">
//                       <span>Vehicle No:</span>
//                       <span>{jobCard.vehicleNumber}</span>
//                     </div>
//                     <div className="d-flex justify-content-between py-2 border-bottom">
//                       <span>Model:</span>
//                       <span>{jobCard.vehicleModel}</span>
//                     </div>
//                     <div className="d-flex justify-content-between py-2 border-bottom">
//                       <span>Year:</span>
//                       <span>{jobCard.vehicleYear}</span>
//                     </div>
//                     <div className="d-flex justify-content-between py-2">
//                       <span>VIN:</span>
//                       <span>{jobCard.vin}</span>
//                     </div>
//                   </div>
//                 </div>

//                 <div className="mb-3 text-muted">
//                   <strong>Job Information</strong>
//                   <div className="mt-2">
//                     <div className="d-flex justify-content-between py-2 border-bottom">
//                       <span>Job Type:</span>
//                       <Badge color="info">{jobCard.jobType}</Badge>
//                     </div>
//                     <div className="d-flex justify-content-between py-2 border-bottom">
//                       <span>Technician:</span>
//                       <span>{jobCard.assignedTechnician}</span>
//                     </div>
//                     <div className="d-flex justify-content-between py-2 border-bottom">
//                       <span>Created:</span>
//                       <span>
//                         {new Date(jobCard.createdAt).toLocaleDateString()}
//                       </span>
//                     </div>
//                     <div className="d-flex justify-content-between py-2">
//                       <span>Est. Completion:</span>
//                       <span>
//                         {new Date(
//                           jobCard.estimatedCompletion
//                         ).toLocaleDateString()}
//                       </span>
//                     </div>
//                   </div>
//                 </div>

//                 <div className="d-grid gap-2">
//                   <Button
//                     color="warning"
//                     onClick={() =>
//                       router.push(`/admin/jobcards/${jobCard.id}?edit=true`)
//                     }
//                   >
//                     Edit Job Card
//                   </Button>
//                   <Button color="info" onClick={() => window.print()}>
//                     <i className="fa fa-print me-2"></i>
//                     Print Job Card
//                   </Button>
//                   <Button
//                     color="outline-primary"
//                     onClick={() => router.push("/admin/jobcards")}
//                   >
//                     Back to List
//                   </Button>
//                 </div>
//               </CardBody>
//             </Card>

//             {/* Quick Actions Card */}
//             <Card>
//               <CardBody>
//                 <h6 className="mb-3 text-muted">Quick Actions</h6>
//                 <div className="d-grid gap-2">
//                   <Button
//                     color={
//                       jobCard.status === "open" ? "warning" : "outline-warning"
//                     }
//                     onClick={() => handleStatusChange("in-progress")}
//                     disabled={jobCard.status === "in-progress"}
//                   >
//                     Mark In Progress
//                   </Button>
//                   <Button
//                     color={
//                       jobCard.status === "in-progress"
//                         ? "success"
//                         : "outline-success"
//                     }
//                     onClick={() => handleStatusChange("completed")}
//                     disabled={jobCard.status === "completed"}
//                   >
//                     Mark Completed
//                   </Button>
//                   <Button
//                     color="primary"
//                     onClick={() => {
//                       /* Generate invoice logic */
//                     }}
//                   >
//                     Generate Invoice
//                   </Button>
//                 </div>
//               </CardBody>
//             </Card>
//           </Col>

//           <Col lg={8}>
//             {/* Progress Card */}
//             <Card className="mb-4 text-muted">
//               <CardBody>
//                 <div className="d-flex justify-content-between align-items-center mb-2 text-muted">
//                   <h6 className="mb-0">Job Progress</h6>
//                   <span>
//                     {completedTasks}/{totalTasks} tasks completed
//                   </span>
//                 </div>
//                 <Progress value={progressPercentage} className="mb-2" />
//                 <small className="text-muted">
//                   {progressPercentage.toFixed(0)}% complete
//                 </small>
//               </CardBody>
//             </Card>

//             {/* Tabs */}
//             <Card>
//               <CardBody>
//                 <Nav tabs>
//                   <NavItem>
//                     <NavLink
//                       className={activeTab === "1" ? "active" : ""}
//                       onClick={() => setActiveTab("1")}
//                     >
//                       Overview
//                     </NavLink>
//                   </NavItem>
//                   <NavItem>
//                     <NavLink
//                       className={activeTab === "2" ? "active" : ""}
//                       onClick={() => setActiveTab("2")}
//                     >
//                       Tasks
//                     </NavLink>
//                   </NavItem>
//                   <NavItem>
//                     <NavLink
//                       className={activeTab === "3" ? "active" : ""}
//                       onClick={() => setActiveTab("3")}
//                     >
//                       Parts Used
//                     </NavLink>
//                   </NavItem>
//                   <NavItem>
//                     <NavLink
//                       className={activeTab === "4" ? "active" : ""}
//                       onClick={() => setActiveTab("4")}
//                     >
//                       Photos
//                     </NavLink>
//                   </NavItem>
//                   <NavItem>
//                     <NavLink
//                       className={activeTab === "5" ? "active" : ""}
//                       onClick={() => setActiveTab("5")}
//                     >
//                       Payments
//                     </NavLink>
//                   </NavItem>
//                 </Nav>

//                 <TabContent activeTab={activeTab} className="pt-3">
//                   {/* Overview Tab */}
//                   <TabPane tabId="1">
//                     <div className="mb-4 text-muted">
//                       <h6>Reported Issue</h6>
//                       <Card>
//                         <CardBody>
//                           <p className="mb-0 text-muted">{jobCard.reportedIssue}</p>
//                         </CardBody>
//                       </Card>
//                     </div>

//                     {jobCard.specialInstructions && (
//                       <div className="mb-4 text-muted">
//                         <h6>Special Instructions</h6>
//                         <Card>
//                           <CardBody>
//                             <p className="mb-0 text-warning">
//                               {jobCard.specialInstructions}
//                             </p>
//                           </CardBody>
//                         </Card>
//                       </div>
//                     )}

//                     <div className="row text-center">
//                       <div className="col-md-4">
//                         <Card className="bg-light">
//                           <CardBody>
//                             <h4 className="text-primary">
//                               ${jobCard.estimatedCost}
//                             </h4> 
//                             <p className="mb-0 text-muted">Estimated Cost</p>
//                           </CardBody>
//                         </Card>
//                       </div>
//                       <div className="col-md-4">
//                         <Card className="bg-light">
//                           <CardBody>
//                             <h4 className="text-success">
//                               ${jobCard.actualCost || 0}
//                             </h4>
//                             <p className="mb-0 text-muted">Actual Cost</p>
//                           </CardBody>
//                         </Card>
//                       </div>
//                       <div className="col-md-4">
//                         <Card className="bg-light">
//                           <CardBody>
//                             <h4 className="text-info">
//                               {jobCard.jobItems.length}
//                             </h4>
//                             <p className="mb-0 text-muted">Total Tasks</p>
//                           </CardBody>
//                         </Card>
//                       </div>
//                     </div>
//                   </TabPane>

//                   {/* Tasks Tab */}
//                   <TabPane tabId="2">
//                     <Table bordered>
//                       <thead>
//                         <tr>
//                           <th>Task Description</th>
//                           <th>Hours</th>
//                           <th>Rate</th>
//                           <th>Total</th>
//                           <th>Status</th>
//                           <th>Notes</th>
//                           <th>Actions</th>
//                         </tr>
//                       </thead>
//                       <tbody>
//                         {jobCard.jobItems.map((task) => (
//                           <tr key={task.id}>
//                             <td>{task.description}</td>
//                             <td>{task.estimatedHours}</td>
//                             <td>${task.rate}</td>
//                             <td>${task.total}</td>
//                             <td>
//                               <select
//                                 className="form-select form-select-sm"
//                                 value={task.status}
//                                 onChange={(e) =>
//                                   handleTaskStatusChange(
//                                     task.id,
//                                     e.target.value
//                                   )
//                                 }
//                               >
//                                 <option value="pending">Pending</option>
//                                 <option value="in-progress">In Progress</option>
//                                 <option value="completed">Completed</option>
//                               </select>
//                             </td>
//                             <td>
//                               <Input
//                                 type="text"
//                                 // size="sm"
//                                 placeholder="Add notes..."
//                                 value={task.notes}
//                                 onChange={(e) =>
//                                   handleTaskNotesChange(task.id, e)
//                                 }
//                               />
//                             </td>
//                             <td>
//                               <Button color="primary" size="sm">
//                                 <i className="fa fa-edit"></i>
//                               </Button>
//                             </td>
//                           </tr>
//                         ))}
//                       </tbody>
//                     </Table>
//                   </TabPane>

//                   {/* Parts Used Tab */}
//                   <TabPane tabId="3">
//                     <Table bordered>
//                       <thead>
//                         <tr>
//                           <th>Part Name</th>
//                           <th>Quantity</th>
//                           <th>Unit Price</th>
//                           <th>Total</th>
//                         </tr>
//                       </thead>
//                       <tbody>
//                         {jobCard.partsUsed.map((part) => (
//                           <tr key={part.id}>
//                             <td>{part.partName}</td>
//                             <td>{part.quantity}</td>
//                             <td>${part.unitPrice}</td>
//                             <td>${part.total}</td>
//                           </tr>
//                         ))}
//                         <tr className="table-primary">
//                           <td colSpan={3} className="text-end">
//                             <strong>Parts Total:</strong>
//                           </td>
//                           <td>
//                             <strong>
//                               $
//                               {jobCard.partsUsed.reduce(
//                                 (sum, part) => sum + part.total,
//                                 0
//                               )}
//                             </strong>
//                           </td>
//                         </tr>
//                       </tbody>
//                     </Table>
//                   </TabPane>

//                   {/* Photos Tab */}
//                   <TabPane tabId="4">
//                     <div className="row">
//                       {jobCard.photos.map((photo) => (
//                         <div key={photo.id} className="col-md-6 mb-3">
//                           <Card>
//                             <CardBody className="text-center">
//                               <div className="bg-light rounded p-4 mb-2">
//                                 <i className="fa fa-image fa-3x text-muted"></i>
//                               </div>
//                               <Badge
//                                 color={
//                                   photo.type === "before"
//                                     ? "warning"
//                                     : "success"
//                                 }
//                                 className="mb-2"
//                               >
//                                 {photo.type.toUpperCase()}
//                               </Badge>
//                               <p className="mb-1 text-muted">{photo.description}</p>
//                               <small className="text-muted">{photo.date}</small>
//                             </CardBody>
//                           </Card>
//                         </div>
//                       ))}
//                       <div className="col-md-6 mb-3">
//                         <Card className="border-dashed">
//                           <CardBody className="text-center p-5">
//                             <i className="fa fa-cloud-upload fa-2x text-muted mb-3"></i>
//                             <p className="mb-2 text-muted">Upload New Photo</p>
//                             <Button color="outline-primary" size="sm">
//                               Choose File
//                             </Button>
//                           </CardBody>
//                         </Card>
//                       </div>
//                     </div>
//                   </TabPane>

//                   {/* Payments Tab */}
//                   <TabPane tabId="5">
//                     <Table bordered>
//                       <thead>
//                         <tr>
//                           <th>Type</th>
//                           <th>Amount</th>
//                           <th>Date</th>
//                           <th>Method</th>
//                           <th>Status</th>
//                         </tr>
//                       </thead>
//                       <tbody>
//                         {jobCard.payments.map((payment) => (
//                           <tr key={payment.id}>
//                             <td>
//                               <Badge color="info">{payment.type}</Badge>
//                             </td>
//                             <td>${payment.amount}</td>
//                             <td>{payment.date}</td>
//                             <td>{payment.method || "-"}</td>
//                             <td>
//                               <Badge
//                                 color={
//                                   payment.status === "paid"
//                                     ? "success"
//                                     : "warning"
//                                 }
//                               >
//                                 {payment.status}
//                               </Badge>
//                             </td>
//                           </tr>
//                         ))}
//                         <tr className="table-info">
//                           <td colSpan={1} className="text-end">
//                             <strong>Total:</strong>
//                           </td>
//                           <td>
//                             <strong>
//                               $
//                               {jobCard.payments.reduce(
//                                 (sum, payment) => sum + payment.amount,
//                                 0
//                               )}
//                             </strong>
//                           </td>
//                           <td colSpan={3}></td>
//                         </tr>
//                       </tbody>
//                     </Table>
//                   </TabPane>
//                 </TabContent>
//               </CardBody>
//             </Card>
//           </Col>
//         </Row>
//       </Container>
//     </div>
//   );
// }

// export default JobCardDetailPage;


"use client";
import Breadcrumbs from "@/CommonElements/Breadcrumbs";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  Badge,
  Button,
  TabContent,
  TabPane,
  Nav,
  NavItem,
  NavLink,
  Table,
  Progress,
  Input, // Added missing import
} from "reactstrap";
import React, { useState } from "react";
import { useRouter } from "next/navigation";

// Mock data
const jobCardData = {
  id: 1,
  jobNumber: "JC-2024-001",
  customerName: "John Doe",
  customerPhone: "+1 234 567 890",
  customerEmail: "john@example.com",
  vehicleNumber: "ABC123",
  vehicleModel: "Toyota Camry 2022",
  vehicleYear: "2022",
  vin: "1HGCM82633A123456",
  jobType: "service",
  status: "in-progress",
  reportedIssue:
    "Regular maintenance service including oil change, filter replacement, and general inspection",
  assignedTechnician: "Mike Smith",
  estimatedCost: 250.0,
  actualCost: 245.5,
  createdAt: "2024-01-15",
  estimatedCompletion: "2024-01-16",
  specialInstructions: "Customer requested synthetic oil only",

  jobItems: [
    {
      id: 1,
      description: "Oil Change - Synthetic",
      estimatedHours: 0.5,
      rate: 75,
      total: 37.5,
      status: "completed",
      notes: "Completed successfully",
    },
    {
      id: 2,
      description: "Oil Filter Replacement",
      estimatedHours: 0.3,
      rate: 75,
      total: 22.5,
      status: "completed",
      notes: "Filter replaced",
    },
    {
      id: 3,
      description: "Air Filter Replacement",
      estimatedHours: 0.2,
      rate: 75,
      total: 15.0,
      status: "in-progress",
      notes: "In progress",
    },
    {
      id: 4,
      description: "Brake Inspection",
      estimatedHours: 0.5,
      rate: 75,
      total: 37.5,
      status: "pending",
      notes: "",
    },
  ],

  partsUsed: [
    {
      id: 1,
      partName: "Engine Oil Synthetic",
      quantity: 1,
      unitPrice: 45.99,
      total: 45.99,
    },
    {
      id: 2,
      partName: "Oil Filter",
      quantity: 1,
      unitPrice: 12.5,
      total: 12.5,
    },
    {
      id: 3,
      partName: "Air Filter",
      quantity: 1,
      unitPrice: 25.0,
      total: 25.0,
    },
  ],

  // photos: [
  //   {
  //     id: 1,
  //     type: "before",
  //     url: "/before1.jpg",
  //     description: "Engine bay before service",
  //     date: "2024-01-15",
  //   },
  //   {
  //     id: 2,
  //     type: "after",
  //     url: "/after1.jpg",
  //     description: "Engine bay after service",
  //     date: "2024-01-15",
  //   },
  // ],
photos: [
    {
      id: 1,
      type: "before",
      url: "/before1.jpg",
      description: "Engine bay before service",
      date: "2024-01-15",
      uploadedBy: "Mike Smith",
    },
    {
      id: 2,
      type: "during",
      url: "/during1.jpg",
      description: "Oil filter replacement in progress",
      date: "2024-01-15",
      uploadedBy: "Mike Smith",
    },
    {
      id: 3,
      type: "after",
      url: "/after1.jpg",
      description: "Engine bay after service - clean and organized",
      date: "2024-01-15",
      uploadedBy: "Mike Smith",
    },
  ],
  payments: [
    {
      id: 1,
      type: "deposit",
      amount: 100.0,
      date: "2024-01-15",
      status: "paid",
      method: "Credit Card",
    },
    {
      id: 2,
      type: "balance",
      amount: 145.5,
      date: "2024-01-16",
      status: "pending",
      method: "",
    },
  ],
};

function JobCardDetailPage({ params }: { params: { id: string } }) {
  const router = useRouter();
  const [activeTab, setActiveTab] = useState("1");
  const [jobCard, setJobCard] = useState(jobCardData);

    const [photoFilter, setPhotoFilter] = useState('all');
  const [editingPhotoId, setEditingPhotoId] = useState<number | null>(null);

  const renderStatusBadge = (status: string) => {
    const statusConfig = {
      open: { class: "bg-primary", label: "Open" },
      "in-progress": { class: "bg-warning", label: "In Progress" },
      completed: { class: "bg-success", label: "Completed" },
      cancelled: { class: "bg-danger", label: "Cancelled" },
    };

    const config = statusConfig[status as keyof typeof statusConfig];
    return <Badge className={config.class}>{config.label}</Badge>;
  };

  const handleStatusChange = (newStatus: typeof jobCard.status) => {
    setJobCard({ ...jobCard, status: newStatus });
  };

  const handleTaskStatusChange = (taskId: number, newStatus: string) => {
    setJobCard({
      ...jobCard,
      jobItems: jobCard.jobItems.map((item) =>
        item.id === taskId ? { ...item, status: newStatus } : item
      ),
    });
  };

  // Fixed: Added proper type for the event parameter
  const handleTaskNotesChange = (
    taskId: number,
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const updatedTasks = jobCard.jobItems.map((t) =>
      t.id === taskId ? { ...t, notes: e.target.value } : t
    );
    setJobCard({ ...jobCard, jobItems: updatedTasks });
  };


  // Filter photos based on selected type
  const filteredPhotos = photoFilter === 'all' 
    ? jobCard.photos 
    : jobCard.photos.filter(photo => photo.type === photoFilter);

  // Handle photo upload
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    const newPhotos = Array.from(files).map((file, index) => ({
      id: Date.now() + index,
      type: 'before' as const,
      url: URL.createObjectURL(file),
      description: `Photo ${jobCard.photos.length + index + 1}`,
      date: new Date().toISOString().split('T')[0],
      uploadedBy: 'Current User', // You can replace with actual user name
      file: file // Store the actual file if needed
    }));

    setJobCard({
      ...jobCard,
      photos: [...jobCard.photos, ...newPhotos]
    });

    // Reset file input
    e.target.value = '';
  };

  // Handle photo deletion
  const handleDeletePhoto = (photoId: number) => {
    if (confirm('Are you sure you want to delete this photo?')) {
      setJobCard({
        ...jobCard,
        photos: jobCard.photos.filter(photo => photo.id !== photoId)
      });
    }
  };

  // Handle photo description change
  const handlePhotoDescriptionChange = (photoId: number, description: string) => {
    setJobCard({
      ...jobCard,
      photos: jobCard.photos.map(photo =>
        photo.id === photoId ? { ...photo, description } : photo
      )
    });
  };

  // Save photo description
  const handleSavePhotoDescription = (photoId: number) => {
    setEditingPhotoId(null);
    // Here you would typically save to your backend
    console.log('Saving photo description:', photoId);
  };

  // Quick photo action
  const handleQuickPhoto = (type: string) => {
    setPhotoFilter(type);
    // Trigger file input for quick upload
    const fileInput = document.getElementById('photoUpload') as HTMLInputElement;
    if (fileInput) {
      fileInput.click();
    }
  };

    const handlePhotoTypeChange = (photoId: number, newType: string) => {
    setJobCard({
      ...jobCard,
      photos: jobCard.photos.map(photo =>
        photo.id === photoId ? { ...photo, type: newType } : photo
      )
    });
  };
  // Calculate progress
  const completedTasks = jobCard.jobItems.filter(
    (item) => item.status === "completed"
  ).length;
  const totalTasks = jobCard.jobItems.length;
  const progressPercentage =
    totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;

  return (
    <div className="page-body">
      <Breadcrumbs
        title={`Job Card - ${jobCard.jobNumber}`}
        mainTitle="Job Card Details"
        parent="Job Card Management"
      />

      <Container fluid>
        <Row>
          <Col lg={4}>
            {/* Job Card Info Card */}
            <Card className="mb-4">
              <CardBody>
                <div className="text-center mb-4">
                  <h4 className="text-primary">{jobCard.jobNumber}</h4>
                  {renderStatusBadge(jobCard.status)}
                </div>

                <div className="mb-3 text-muted">
                  <strong>Customer Information</strong>
                  <div className="mt-2">
                    <div className="d-flex justify-content-between py-2 border-bottom">
                      <span>Name:</span>
                      <span>{jobCard.customerName}</span>
                    </div>
                    <div className="d-flex justify-content-between py-2 border-bottom">
                      <span>Phone:</span>
                      <span>{jobCard.customerPhone}</span>
                    </div>
                    <div className="d-flex justify-content-between py-2 border-bottom">
                      <span>Email:</span>
                      <span>{jobCard.customerEmail}</span>
                    </div>
                  </div>
                </div>

                <div className="mb-3 text-muted">
                  <strong>Vehicle Information</strong>
                  <div className="mt-2">
                    <div className="d-flex justify-content-between py-2 border-bottom">
                      <span>Vehicle No:</span>
                      <span>{jobCard.vehicleNumber}</span>
                    </div>
                    <div className="d-flex justify-content-between py-2 border-bottom">
                      <span>Model:</span>
                      <span>{jobCard.vehicleModel}</span>
                    </div>
                    <div className="d-flex justify-content-between py-2 border-bottom">
                      <span>Year:</span>
                      <span>{jobCard.vehicleYear}</span>
                    </div>
                    <div className="d-flex justify-content-between py-2">
                      <span>VIN:</span>
                      <span>{jobCard.vin}</span>
                    </div>
                  </div>
                </div>

                <div className="mb-3 text-muted">
                  <strong>Job Information</strong>
                  <div className="mt-2">
                    <div className="d-flex justify-content-between py-2 border-bottom">
                      <span>Job Type:</span>
                      <Badge color="info">{jobCard.jobType}</Badge>
                    </div>
                    <div className="d-flex justify-content-between py-2 border-bottom">
                      <span>Technician:</span>
                      <span>{jobCard.assignedTechnician}</span>
                    </div>
                    <div className="d-flex justify-content-between py-2 border-bottom">
                      <span>Created:</span>
                      <span>
                        {new Date(jobCard.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                    <div className="d-flex justify-content-between py-2">
                      <span>Est. Completion:</span>
                      <span>
                        {new Date(
                          jobCard.estimatedCompletion
                        ).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="d-grid gap-2">
                  <Button
                    color="warning"
                    onClick={() =>
                      router.push(`/admin/jobcards/${jobCard.id}?edit=true`)
                    }
                  >
                    Edit Job Card
                  </Button>
                  <Button color="info" onClick={() => window.print()}>
                    <i className="fa fa-print me-2"></i>
                    Print Job Card
                  </Button>
                  <Button
                    color="outline-primary"
                    onClick={() => router.push("/admin/jobcards")}
                  >
                    Back to List
                  </Button>
                </div>
              </CardBody>
            </Card>

            {/* Quick Actions Card */}
            <Card>
              <CardBody>
                <h6 className="mb-3 text-muted">Quick Actions</h6>
                <div className="d-grid gap-2">
                  <Button
                    color={
                      jobCard.status === "open" ? "warning" : "outline-warning"
                    }
                    onClick={() => handleStatusChange("in-progress")}
                    disabled={jobCard.status === "in-progress"}
                  >
                    Mark In Progress
                  </Button>
                  <Button
                    color={
                      jobCard.status === "in-progress"
                        ? "success"
                        : "outline-success"
                    }
                    onClick={() => handleStatusChange("completed")}
                    disabled={jobCard.status === "completed"}
                  >
                    Mark Completed
                  </Button>
                  <Button
                    color="primary"
                    onClick={() => {
                      /* Generate invoice logic */
                    }}
                  >
                    Generate Invoice
                  </Button>
                </div>
              </CardBody>
            </Card>
          </Col>

          <Col lg={8}>
            {/* Progress Card */}
            <Card className="mb-4 text-muted">
              <CardBody>
                <div className="d-flex justify-content-between align-items-center mb-2 text-muted">
                  <h6 className="mb-0">Job Progress</h6>
                  <span>
                    {completedTasks}/{totalTasks} tasks completed
                  </span>
                </div>
                <Progress value={progressPercentage} className="mb-2" />
                <small className="text-muted">
                  {progressPercentage.toFixed(0)}% complete
                </small>
              </CardBody>
            </Card>

            {/* Tabs */}
            <Card>
              <CardBody>
                <Nav tabs>
                  <NavItem>
                    <NavLink
                      className={activeTab === "1" ? "active" : ""}
                      onClick={() => setActiveTab("1")}
                    >
                      Overview
                    </NavLink>
                  </NavItem>
                  <NavItem>
                    <NavLink
                      className={activeTab === "2" ? "active" : ""}
                      onClick={() => setActiveTab("2")}
                    >
                      Tasks
                    </NavLink>
                  </NavItem>
                  <NavItem>
                    <NavLink
                      className={activeTab === "3" ? "active" : ""}
                      onClick={() => setActiveTab("3")}
                    >
                      Parts Used
                    </NavLink>
                  </NavItem>
                  <NavItem>
                    <NavLink
                      className={activeTab === "4" ? "active" : ""}
                      onClick={() => setActiveTab("4")}
                    >
                      Photos
                    </NavLink>
                  </NavItem>
                  <NavItem>
                    <NavLink
                      className={activeTab === "5" ? "active" : ""}
                      onClick={() => setActiveTab("5")}
                    >
                      Payments
                    </NavLink>
                  </NavItem>
                </Nav>

                <TabContent activeTab={activeTab} className="pt-3">
                  {/* Overview Tab */}
                  <TabPane tabId="1">
                    <div className="mb-4 text-muted">
                      <h6>Reported Issue</h6>
                      <Card>
                        <CardBody>
                          <p className="mb-0 text-muted">{jobCard.reportedIssue}</p>
                        </CardBody>
                      </Card>
                    </div>

                    {jobCard.specialInstructions && (
                      <div className="mb-4 text-muted">
                        <h6>Special Instructions</h6>
                        <Card>
                          <CardBody>
                            <p className="mb-0 text-warning">
                              {jobCard.specialInstructions}
                            </p>
                          </CardBody>
                        </Card>
                      </div>
                    )}

                    <div className="row text-center">
                      <div className="col-md-4">
                        <Card className="bg-light">
                          <CardBody>
                            <h4 className="text-primary">
                              ${jobCard.estimatedCost}
                            </h4> 
                            <p className="mb-0 text-muted">Estimated Cost</p>
                          </CardBody>
                        </Card>
                      </div>
                      <div className="col-md-4">
                        <Card className="bg-light">
                          <CardBody>
                            <h4 className="text-success">
                              ${jobCard.actualCost || 0}
                            </h4>
                            <p className="mb-0 text-muted">Actual Cost</p>
                          </CardBody>
                        </Card>
                      </div>
                      <div className="col-md-4">
                        <Card className="bg-light">
                          <CardBody>
                            <h4 className="text-info">
                              {jobCard.jobItems.length}
                            </h4>
                            <p className="mb-0 text-muted">Total Tasks</p>
                          </CardBody>
                        </Card>
                      </div>
                    </div>
                  </TabPane>

                  {/* Tasks Tab */}
                  <TabPane tabId="2">
                    <Table bordered>
                      <thead>
                        <tr>
                          <th>Task Description</th>
                          <th>Hours</th>
                          <th>Rate</th>
                          <th>Total</th>
                          <th>Status</th>
                          <th>Notes</th>
                          <th>Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {jobCard.jobItems.map((task) => (
                          <tr key={task.id}>
                            <td>{task.description}</td>
                            <td>{task.estimatedHours}</td>
                            <td>${task.rate}</td>
                            <td>${task.total}</td>
                            <td>
                              <select
                                className="form-select form-select-sm"
                                value={task.status}
                                onChange={(e) =>
                                  handleTaskStatusChange(
                                    task.id,
                                    e.target.value
                                  )
                                }
                              >
                                <option value="pending">Pending</option>
                                <option value="in-progress">In Progress</option>
                                <option value="completed">Completed</option>
                              </select>
                            </td>
                            <td>
                              <Input
                                type="text"
                                // size="sm"
                                placeholder="Add notes..."
                                value={task.notes}
                                onChange={(e) =>
                                  handleTaskNotesChange(task.id, e)
                                }
                              />
                            </td>
                            <td>
                              <Button color="primary" size="sm">
                                <i className="fa fa-edit"></i>
                              </Button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </Table>
                  </TabPane>

                  {/* Parts Used Tab */}
                  <TabPane tabId="3">
                    <Table bordered>
                      <thead>
                        <tr>
                          <th>Part Name</th>
                          <th>Quantity</th>
                          <th>Unit Price</th>
                          <th>Total</th>
                        </tr>
                      </thead>
                      <tbody>
                        {jobCard.partsUsed.map((part) => (
                          <tr key={part.id}>
                            <td>{part.partName}</td>
                            <td>{part.quantity}</td>
                            <td>${part.unitPrice}</td>
                            <td>${part.total}</td>
                          </tr>
                        ))}
                        <tr className="table-primary">
                          <td colSpan={3} className="text-end">
                            <strong>Parts Total:</strong>
                          </td>
                          <td>
                            <strong>
                              $
                              {jobCard.partsUsed.reduce(
                                (sum, part) => sum + part.total,
                                0
                              )}
                            </strong>
                          </td>
                        </tr>
                      </tbody>
                    </Table>
                  </TabPane>

                  {/* Photos Tab */}
                  {/* <TabPane tabId="4">
                    <div className="row">
                      {jobCard.photos.map((photo) => (
                        <div key={photo.id} className="col-md-6 mb-3">
                          <Card>
                            <CardBody className="text-center">
                              <div className="bg-light rounded p-4 mb-2">
                                <i className="fa fa-image fa-3x text-muted"></i>
                              </div>
                              <Badge
                                color={
                                  photo.type === "before"
                                    ? "warning"
                                    : "success"
                                }
                                className="mb-2"
                              >
                                {photo.type.toUpperCase()}
                              </Badge>
                              <p className="mb-1 text-muted">{photo.description}</p>
                              <small className="text-muted">{photo.date}</small>
                            </CardBody>
                          </Card>
                        </div>
                      ))}
                      <div className="col-md-6 mb-3">
                        <Card className="border-dashed">
                          <CardBody className="text-center p-5">
                            <i className="fa fa-cloud-upload fa-2x text-muted mb-3"></i>
                            <p className="mb-2 text-muted">Upload New Photo</p>
                            <Button color="outline-primary" size="sm">
                              Choose File
                            </Button>
                          </CardBody>
                        </Card>
                      </div>
                    </div>
                  </TabPane> */}
<TabPane tabId="4">
  <div className="mb-4">
    <div className="d-flex justify-content-between align-items-center mb-3">
      <h6 className="mb-0">Vehicle Photos</h6>
      <Button color="primary" size="sm" onClick={() => document.getElementById('photoUpload')?.click()}>
        <i className="fa fa-camera me-2"></i>
        Add Photos
      </Button>
      <Input
        type="file"
        id="photoUpload"
        multiple
        accept="image/*"
        style={{ display: 'none' }}
        onChange={(e) => handlePhotoUpload(e)}
      />
    </div>

    {/* Photo Type Tabs */}
    <Nav pills className="mb-3">
      <NavItem>
        <NavLink
          className={photoFilter === 'all' ? 'active' : ''}
          onClick={() => setPhotoFilter('all')}
        >
          All Photos
        </NavLink>
      </NavItem>
      <NavItem>
        <NavLink
          className={photoFilter === 'before' ? 'active' : ''}
          onClick={() => setPhotoFilter('before')}
        >
          Before Service
        </NavLink>
      </NavItem>
      <NavItem>
        <NavLink
          className={photoFilter === 'after' ? 'active' : ''}
          onClick={() => setPhotoFilter('after')}
        >
          After Service
        </NavLink>
      </NavItem>
      <NavItem>
        <NavLink
          className={photoFilter === 'during' ? 'active' : ''}
          onClick={() => setPhotoFilter('during')}
        >
          During Service
        </NavLink>
      </NavItem>
    </Nav>

    {/* Photo Gallery */}
    <Row>
      {filteredPhotos.length === 0 ? (
        <Col xs={12}>
          <div className="text-center py-5">
            <i className="fa fa-camera fa-3x text-muted mb-3"></i>
            <p className="text-muted">No photos uploaded yet</p>
            <Button color="primary" onClick={() => document.getElementById('photoUpload')?.click()}>
              Upload First Photo
            </Button>
          </div>
        </Col>
      ) : (
        filteredPhotos.map((photo) => (
          <Col key={photo.id} lg={4} md={6} className="mb-3">
            <Card className="photo-card">
              <div className="position-relative">
                <img
                  src={photo.url || '/placeholder-image.jpg'}
                  alt={photo.description}
                  className="card-img-top"
                  style={{ height: '200px', objectFit: 'cover' }}
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = '/placeholder-image.jpg';
                  }}
                />
                <div className="position-absolute top-0 end-0 m-2">
                  <Badge color={
                    photo.type === 'before' ? 'warning' :
                    photo.type === 'after' ? 'success' : 'info'
                  }>
                    {photo.type.charAt(0).toUpperCase() + photo.type.slice(1)}
                  </Badge>
                </div>
                <div className="position-absolute top-0 start-0 m-2">
                  <Button
                    color="danger"
                    size="sm"
                    onClick={() => handleDeletePhoto(photo.id)}
                  >
                    <i className="fa fa-trash"></i>
                  </Button>
                </div>
              </div>
              <CardBody>
                <Input
                  type="text"
                  placeholder="Add description..."
                  value={photo.description}
                  onChange={(e) => handlePhotoDescriptionChange(photo.id, e.target.value)}
                  onBlur={() => handleSavePhotoDescription(photo.id)}
                />
                <div className="mt-2">
                  <small className="text-muted">
                    {new Date(photo.date).toLocaleDateString()} • 
                    {photo.uploadedBy && ` by ${photo.uploadedBy}`}
                  </small>
                </div>
              </CardBody>
            </Card>
          </Col>
        ))
      )}
    </Row>
  </div>

  {/* Quick Photo Actions */}
  <Card>
    <CardBody>
      <h6 className="mb-3">Quick Photo Actions</h6>
      <div className="row g-2">
        <div className="col-md-4">
          <Button 
            color="outline-warning" 
            className="w-100"
            onClick={() => handleQuickPhoto('before')}
          >
            <i className="fa fa-camera me-2"></i>
            Before Photos
          </Button>
        </div>
        <div className="col-md-4">
          <Button 
            color="outline-info" 
            className="w-100"
            onClick={() => handleQuickPhoto('during')}
          >
            <i className="fa fa-wrench me-2"></i>
            During Service
          </Button>
        </div>
        <div className="col-md-4">
          <Button 
            color="outline-success" 
            className="w-100"
            onClick={() => handleQuickPhoto('after')}
          >
            <i className="fa fa-check me-2"></i>
            After Photos
          </Button>
        </div>
      </div>
    </CardBody>
  </Card>
</TabPane>
                  {/* Payments Tab */}
                  <TabPane tabId="5">
                    <Table bordered>
                      <thead>
                        <tr>
                          <th>Type</th>
                          <th>Amount</th>
                          <th>Date</th>
                          <th>Method</th>
                          <th>Status</th>
                        </tr>
                      </thead>
                      <tbody>
                        {jobCard.payments.map((payment) => (
                          <tr key={payment.id}>
                            <td>
                              <Badge color="info">{payment.type}</Badge>
                            </td>
                            <td>${payment.amount}</td>
                            <td>{payment.date}</td>
                            <td>{payment.method || "-"}</td>
                            <td>
                              <Badge
                                color={
                                  payment.status === "paid"
                                    ? "success"
                                    : "warning"
                                }
                              >
                                {payment.status}
                              </Badge>
                            </td>
                          </tr>
                        ))}
                        <tr className="table-info">
                          <td colSpan={1} className="text-end">
                            <strong>Total:</strong>
                          </td>
                          <td>
                            <strong>
                              $
                              {jobCard.payments.reduce(
                                (sum, payment) => sum + payment.amount,
                                0
                              )}
                            </strong>
                          </td>
                          <td colSpan={3}></td>
                        </tr>
                      </tbody>
                    </Table>
                  </TabPane>
                </TabContent>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Container>
    </div>
  );
}

export default JobCardDetailPage;


// "use client";
// import Breadcrumbs from "@/CommonElements/Breadcrumbs";
// import {
//   Container,
//   Row,
//   Col,
//   Card,
//   CardBody,
//   Badge,
//   Button,
//   TabContent,
//   TabPane,
//   Nav,
//   NavItem,
//   NavLink,
//   Table,
//   Progress,
//   Input, // Added missing import
// } from "reactstrap";
// import React, { useState } from "react";
// import { useRouter } from "next/navigation";

// // Mock data
// const jobCardData = {
//   id: 1,
//   jobNumber: "JC-2024-001",
//   customerName: "John Doe",
//   customerPhone: "+1 234 567 890",
//   customerEmail: "john@example.com",
//   vehicleNumber: "ABC123",
//   vehicleModel: "Toyota Camry 2022",
//   vehicleYear: "2022",
//   vin: "1HGCM82633A123456",
//   jobType: "service",
//   status: "in-progress",
//   reportedIssue:
//     "Regular maintenance service including oil change, filter replacement, and general inspection",
//   assignedTechnician: "Mike Smith",
//   estimatedCost: 250.0,
//   actualCost: 245.5,
//   createdAt: "2024-01-15",
//   estimatedCompletion: "2024-01-16",
//   specialInstructions: "Customer requested synthetic oil only",

//   jobItems: [
//     {
//       id: 1,
//       description: "Oil Change - Synthetic",
//       estimatedHours: 0.5,
//       rate: 75,
//       total: 37.5,
//       status: "completed",
//       notes: "Completed successfully",
//     },
//     {
//       id: 2,
//       description: "Oil Filter Replacement",
//       estimatedHours: 0.3,
//       rate: 75,
//       total: 22.5,
//       status: "completed",
//       notes: "Filter replaced",
//     },
//     {
//       id: 3,
//       description: "Air Filter Replacement",
//       estimatedHours: 0.2,
//       rate: 75,
//       total: 15.0,
//       status: "in-progress",
//       notes: "In progress",
//     },
//     {
//       id: 4,
//       description: "Brake Inspection",
//       estimatedHours: 0.5,
//       rate: 75,
//       total: 37.5,
//       status: "pending",
//       notes: "",
//     },
//   ],

//   partsUsed: [
//     {
//       id: 1,
//       partName: "Engine Oil Synthetic",
//       quantity: 1,
//       unitPrice: 45.99,
//       total: 45.99,
//     },
//     {
//       id: 2,
//       partName: "Oil Filter",
//       quantity: 1,
//       unitPrice: 12.5,
//       total: 12.5,
//     },
//     {
//       id: 3,
//       partName: "Air Filter",
//       quantity: 1,
//       unitPrice: 25.0,
//       total: 25.0,
//     },
//   ],

//   photos: [
//     {
//       id: 1,
//       type: "before",
//       url: "/before1.jpg",
//       description: "Engine bay before service",
//       date: "2024-01-15",
//     },
//     {
//       id: 2,
//       type: "after",
//       url: "/after1.jpg",
//       description: "Engine bay after service",
//       date: "2024-01-15",
//     },
//   ],

//   payments: [
//     {
//       id: 1,
//       type: "deposit",
//       amount: 100.0,
//       date: "2024-01-15",
//       status: "paid",
//       method: "Credit Card",
//     },
//     {
//       id: 2,
//       type: "balance",
//       amount: 145.5,
//       date: "2024-01-16",
//       status: "pending",
//       method: "",
//     },
//   ],
// };

// function JobCardDetailPage({ params }: { params: { id: string } }) {
//   const router = useRouter();
//   const [activeTab, setActiveTab] = useState("1");
//   const [jobCard, setJobCard] = useState(jobCardData);

//   const renderStatusBadge = (status: string) => {
//     const statusConfig = {
//       open: { class: "bg-primary", label: "Open" },
//       "in-progress": { class: "bg-warning", label: "In Progress" },
//       completed: { class: "bg-success", label: "Completed" },
//       cancelled: { class: "bg-danger", label: "Cancelled" },
//     };

//     const config = statusConfig[status as keyof typeof statusConfig];
//     return <Badge className={config.class}>{config.label}</Badge>;
//   };

//   const handleStatusChange = (newStatus: typeof jobCard.status) => {
//     setJobCard({ ...jobCard, status: newStatus });
//   };

//   const handleTaskStatusChange = (taskId: number, newStatus: string) => {
//     setJobCard({
//       ...jobCard,
//       jobItems: jobCard.jobItems.map((item) =>
//         item.id === taskId ? { ...item, status: newStatus } : item
//       ),
//     });
//   };

//   // Fixed: Added proper type for the event parameter
//   const handleTaskNotesChange = (
//     taskId: number,
//     e: React.ChangeEvent<HTMLInputElement>
//   ) => {
//     const updatedTasks = jobCard.jobItems.map((t) =>
//       t.id === taskId ? { ...t, notes: e.target.value } : t
//     );
//     setJobCard({ ...jobCard, jobItems: updatedTasks });
//   };

//   // Calculate progress
//   const completedTasks = jobCard.jobItems.filter(
//     (item) => item.status === "completed"
//   ).length;
//   const totalTasks = jobCard.jobItems.length;
//   const progressPercentage =
//     totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;

//   return (
//     <div className="page-body">
//       <Breadcrumbs
//         title={`Job Card - ${jobCard.jobNumber}`}
//         mainTitle="Job Card Details"
//         parent="Job Card Management"
//       />

//       <Container fluid>
//         <Row>
//           <Col lg={4}>
//             {/* Job Card Info Card */}
//             <Card className="mb-4">
//               <CardBody>
//                 <div className="text-center mb-4">
//                   <h4 className="text-primary">{jobCard.jobNumber}</h4>
//                   {renderStatusBadge(jobCard.status)}
//                 </div>

//                 <div className="mb-3">
//                   <strong>Customer Information</strong>
//                   <div className="mt-2">
//                     <div className="d-flex justify-content-between py-2 border-bottom">
//                       <span>Name:</span>
//                       <span>{jobCard.customerName}</span>
//                     </div>
//                     <div className="d-flex justify-content-between py-2 border-bottom">
//                       <span>Phone:</span>
//                       <span>{jobCard.customerPhone}</span>
//                     </div>
//                     <div className="d-flex justify-content-between py-2 border-bottom">
//                       <span>Email:</span>
//                       <span>{jobCard.customerEmail}</span>
//                     </div>
//                   </div>
//                 </div>

//                 <div className="mb-3">
//                   <strong>Vehicle Information</strong>
//                   <div className="mt-2">
//                     <div className="d-flex justify-content-between py-2 border-bottom">
//                       <span>Vehicle No:</span>
//                       <span>{jobCard.vehicleNumber}</span>
//                     </div>
//                     <div className="d-flex justify-content-between py-2 border-bottom">
//                       <span>Model:</span>
//                       <span>{jobCard.vehicleModel}</span>
//                     </div>
//                     <div className="d-flex justify-content-between py-2 border-bottom">
//                       <span>Year:</span>
//                       <span>{jobCard.vehicleYear}</span>
//                     </div>
//                     <div className="d-flex justify-content-between py-2">
//                       <span>VIN:</span>
//                       <span>{jobCard.vin}</span>
//                     </div>
//                   </div>
//                 </div>

//                 <div className="mb-3">
//                   <strong>Job Information</strong>
//                   <div className="mt-2">
//                     <div className="d-flex justify-content-between py-2 border-bottom">
//                       <span>Job Type:</span>
//                       <Badge color="info">{jobCard.jobType}</Badge>
//                     </div>
//                     <div className="d-flex justify-content-between py-2 border-bottom">
//                       <span>Technician:</span>
//                       <span>{jobCard.assignedTechnician}</span>
//                     </div>
//                     <div className="d-flex justify-content-between py-2 border-bottom">
//                       <span>Created:</span>
//                       <span>
//                         {new Date(jobCard.createdAt).toLocaleDateString()}
//                       </span>
//                     </div>
//                     <div className="d-flex justify-content-between py-2">
//                       <span>Est. Completion:</span>
//                       <span>
//                         {new Date(
//                           jobCard.estimatedCompletion
//                         ).toLocaleDateString()}
//                       </span>
//                     </div>
//                   </div>
//                 </div>

//                 <div className="d-grid gap-2">
//                   <Button
//                     color="warning"
//                     onClick={() =>
//                       router.push(`/admin/jobcards/${jobCard.id}?edit=true`)
//                     }
//                   >
//                     Edit Job Card
//                   </Button>
//                   <Button color="info" onClick={() => window.print()}>
//                     <i className="fa fa-print me-2"></i>
//                     Print Job Card
//                   </Button>
//                   <Button
//                     color="outline-primary"
//                     onClick={() => router.push("/admin/jobcards")}
//                   >
//                     Back to List
//                   </Button>
//                 </div>
//               </CardBody>
//             </Card>

//             {/* Quick Actions Card */}
//             <Card>
//               <CardBody>
//                 <h6 className="mb-3">Quick Actions</h6>
//                 <div className="d-grid gap-2">
//                   <Button
//                     color={
//                       jobCard.status === "open" ? "warning" : "outline-warning"
//                     }
//                     onClick={() => handleStatusChange("in-progress")}
//                     disabled={jobCard.status === "in-progress"}
//                   >
//                     Mark In Progress
//                   </Button>
//                   <Button
//                     color={
//                       jobCard.status === "in-progress"
//                         ? "success"
//                         : "outline-success"
//                     }
//                     onClick={() => handleStatusChange("completed")}
//                     disabled={jobCard.status === "completed"}
//                   >
//                     Mark Completed
//                   </Button>
//                   <Button
//                     color="primary"
//                     onClick={() => {
//                       /* Generate invoice logic */
//                     }}
//                   >
//                     Generate Invoice
//                   </Button>
//                 </div>
//               </CardBody>
//             </Card>
//           </Col>

//           <Col lg={8}>
//             {/* Progress Card */}
//             <Card className="mb-4">
//               <CardBody>
//                 <div className="d-flex justify-content-between align-items-center mb-2">
//                   <h6 className="mb-0">Job Progress</h6>
//                   <span>
//                     {completedTasks}/{totalTasks} tasks completed
//                   </span>
//                 </div>
//                 <Progress value={progressPercentage} className="mb-2" />
//                 <small className="text-muted">
//                   {progressPercentage.toFixed(0)}% complete
//                 </small>
//               </CardBody>
//             </Card>

//             {/* Tabs */}
//             <Card>
//               <CardBody>
//                 <Nav tabs>
//                   <NavItem>
//                     <NavLink
//                       className={activeTab === "1" ? "active" : ""}
//                       onClick={() => setActiveTab("1")}
//                     >
//                       Overview
//                     </NavLink>
//                   </NavItem>
//                   <NavItem>
//                     <NavLink
//                       className={activeTab === "2" ? "active" : ""}
//                       onClick={() => setActiveTab("2")}
//                     >
//                       Tasks
//                     </NavLink>
//                   </NavItem>
//                   <NavItem>
//                     <NavLink
//                       className={activeTab === "3" ? "active" : ""}
//                       onClick={() => setActiveTab("3")}
//                     >
//                       Parts Used
//                     </NavLink>
//                   </NavItem>
//                   <NavItem>
//                     <NavLink
//                       className={activeTab === "4" ? "active" : ""}
//                       onClick={() => setActiveTab("4")}
//                     >
//                       Photos
//                     </NavLink>
//                   </NavItem>
//                   <NavItem>
//                     <NavLink
//                       className={activeTab === "5" ? "active" : ""}
//                       onClick={() => setActiveTab("5")}
//                     >
//                       Payments
//                     </NavLink>
//                   </NavItem>
//                 </Nav>

//                 <TabContent activeTab={activeTab} className="pt-3">
//                   {/* Overview Tab */}
//                   <TabPane tabId="1">
//                     <div className="mb-4">
//                       <h6>Reported Issue</h6>
//                       <Card>
//                         <CardBody>
//                           <p className="mb-0">{jobCard.reportedIssue}</p>
//                         </CardBody>
//                       </Card>
//                     </div>

//                     {jobCard.specialInstructions && (
//                       <div className="mb-4">
//                         <h6>Special Instructions</h6>
//                         <Card>
//                           <CardBody>
//                             <p className="mb-0 text-warning">
//                               {jobCard.specialInstructions}
//                             </p>
//                           </CardBody>
//                         </Card>
//                       </div>
//                     )}

//                     <div className="row text-center">
//                       <div className="col-md-4">
//                         <Card className="bg-light">
//                           <CardBody>
//                             <h4 className="text-primary">
//                               ${jobCard.estimatedCost}
//                             </h4>
//                             <p className="mb-0">Estimated Cost</p>
//                           </CardBody>
//                         </Card>
//                       </div>
//                       <div className="col-md-4">
//                         <Card className="bg-light">
//                           <CardBody>
//                             <h4 className="text-success">
//                               ${jobCard.actualCost || 0}
//                             </h4>
//                             <p className="mb-0">Actual Cost</p>
//                           </CardBody>
//                         </Card>
//                       </div>
//                       <div className="col-md-4">
//                         <Card className="bg-light">
//                           <CardBody>
//                             <h4 className="text-info">
//                               {jobCard.jobItems.length}
//                             </h4>
//                             <p className="mb-0">Total Tasks</p>
//                           </CardBody>
//                         </Card>
//                       </div>
//                     </div>
//                   </TabPane>

//                   {/* Tasks Tab */}
//                   <TabPane tabId="2">
//                     <Table bordered>
//                       <thead>
//                         <tr>
//                           <th>Task Description</th>
//                           <th>Hours</th>
//                           <th>Rate</th>
//                           <th>Total</th>
//                           <th>Status</th>
//                           <th>Notes</th>
//                           <th>Actions</th>
//                         </tr>
//                       </thead>
//                       <tbody>
//                         {jobCard.jobItems.map((task) => (
//                           <tr key={task.id}>
//                             <td>{task.description}</td>
//                             <td>{task.estimatedHours}</td>
//                             <td>${task.rate}</td>
//                             <td>${task.total}</td>
//                             <td>
//                               <select
//                                 className="form-select form-select-sm"
//                                 value={task.status}
//                                 onChange={(e) =>
//                                   handleTaskStatusChange(
//                                     task.id,
//                                     e.target.value
//                                   )
//                                 }
//                               >
//                                 <option value="pending">Pending</option>
//                                 <option value="in-progress">In Progress</option>
//                                 <option value="completed">Completed</option>
//                               </select>
//                             </td>
//                             <td>
//                               <Input
//                                 type="text"
//                                 // size="sm"
//                                 placeholder="Add notes..."
//                                 value={task.notes}
//                                 onChange={(e) =>
//                                   handleTaskNotesChange(task.id, e)
//                                 }
//                               />
//                             </td>
//                             <td>
//                               <Button color="primary" size="sm">
//                                 <i className="fa fa-edit"></i>
//                               </Button>
//                             </td>
//                           </tr>
//                         ))}
//                       </tbody>
//                     </Table>
//                   </TabPane>

//                   {/* Parts Used Tab */}
//                   <TabPane tabId="3">
//                     <Table bordered>
//                       <thead>
//                         <tr>
//                           <th>Part Name</th>
//                           <th>Quantity</th>
//                           <th>Unit Price</th>
//                           <th>Total</th>
//                         </tr>
//                       </thead>
//                       <tbody>
//                         {jobCard.partsUsed.map((part) => (
//                           <tr key={part.id}>
//                             <td>{part.partName}</td>
//                             <td>{part.quantity}</td>
//                             <td>${part.unitPrice}</td>
//                             <td>${part.total}</td>
//                           </tr>
//                         ))}
//                         <tr className="table-primary">
//                           <td colSpan={3} className="text-end">
//                             <strong>Parts Total:</strong>
//                           </td>
//                           <td>
//                             <strong>
//                               $
//                               {jobCard.partsUsed.reduce(
//                                 (sum, part) => sum + part.total,
//                                 0
//                               )}
//                             </strong>
//                           </td>
//                         </tr>
//                       </tbody>
//                     </Table>
//                   </TabPane>

//                   {/* Photos Tab */}
//                   <TabPane tabId="4">
//                     <div className="row">
//                       {jobCard.photos.map((photo) => (
//                         <div key={photo.id} className="col-md-6 mb-3">
//                           <Card>
//                             <CardBody className="text-center">
//                               <div className="bg-light rounded p-4 mb-2">
//                                 <i className="fa fa-image fa-3x text-muted"></i>
//                               </div>
//                               <Badge
//                                 color={
//                                   photo.type === "before"
//                                     ? "warning"
//                                     : "success"
//                                 }
//                                 className="mb-2"
//                               >
//                                 {photo.type.toUpperCase()}
//                               </Badge>
//                               <p className="mb-1">{photo.description}</p>
//                               <small className="text-muted">{photo.date}</small>
//                             </CardBody>
//                           </Card>
//                         </div>
//                       ))}
//                       <div className="col-md-6 mb-3">
//                         <Card className="border-dashed">
//                           <CardBody className="text-center p-5">
//                             <i className="fa fa-cloud-upload fa-2x text-muted mb-3"></i>
//                             <p className="mb-2">Upload New Photo</p>
//                             <Button color="outline-primary" size="sm">
//                               Choose File
//                             </Button>
//                           </CardBody>
//                         </Card>
//                       </div>
//                     </div>
//                   </TabPane>

//                   {/* Payments Tab */}
//                   <TabPane tabId="5">
//                     <Table bordered>
//                       <thead>
//                         <tr>
//                           <th>Type</th>
//                           <th>Amount</th>
//                           <th>Date</th>
//                           <th>Method</th>
//                           <th>Status</th>
//                         </tr>
//                       </thead>
//                       <tbody>
//                         {jobCard.payments.map((payment) => (
//                           <tr key={payment.id}>
//                             <td>
//                               <Badge color="info">{payment.type}</Badge>
//                             </td>
//                             <td>${payment.amount}</td>
//                             <td>{payment.date}</td>
//                             <td>{payment.method || "-"}</td>
//                             <td>
//                               <Badge
//                                 color={
//                                   payment.status === "paid"
//                                     ? "success"
//                                     : "warning"
//                                 }
//                               >
//                                 {payment.status}
//                               </Badge>
//                             </td>
//                           </tr>
//                         ))}
//                         <tr className="table-info">
//                           <td colSpan={1} className="text-end">
//                             <strong>Total:</strong>
//                           </td>
//                           <td>
//                             <strong>
//                               $
//                               {jobCard.payments.reduce(
//                                 (sum, payment) => sum + payment.amount,
//                                 0
//                               )}
//                             </strong>
//                           </td>
//                           <td colSpan={3}></td>
//                         </tr>
//                       </tbody>
//                     </Table>
//                   </TabPane>
//                 </TabContent>
//               </CardBody>
//             </Card>
//           </Col>
//         </Row>
//       </Container>
//     </div>
//   );
// }

// export default JobCardDetailPage;
