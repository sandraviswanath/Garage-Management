"use client";
import Breadcrumbs from "@/CommonElements/Breadcrumbs";
import CustomPagination from "@/CommonElements/Pagination";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  Input,
  Button,
  Table,
} from "reactstrap";
import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { toast } from "react-toastify";
import { useAuth } from "@/helper/AuthContext";
import withAuth from "@/helper/WithAuth";

interface VehicleDetails {
  registration_number: string;
  model: string;
  year: string;
}

interface Customer {
  id: string;
  name: string;
  email: string;
  contact_phone: string;
  address: string | null;
  status: string;
  gst_number: string | null;
  meta: string;
  created_at: string;
  updated_at: string;
  vehicle_details: VehicleDetails | null;
}

type CustomerStatus = "active" | "inactive" | "pending" | "";

function Page() {
  const { state } = useAuth();
  const router = useRouter();
  const [currentPage, setCurrentPage] = useState(1);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<CustomerStatus | "all">(
    "all"
  );
  const itemsPerPage = 10;

  useEffect(() => {
    fetchCustomers();
  }, []);

  const fetchCustomers = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem("token");

      if (!token) {
        toast.error("Authentication required. Please login again.");
        router.push("/login");
        return;
      }

      const response = await fetch("/api/customers", {
        method: "GET",
        headers: {
          Authorization: `Bearer ${
            state?.accessToken || localStorage.getItem("token")
          }`,
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }

      const data = await response.json();

      if (data.data && Array.isArray(data.data)) {
        setCustomers(data.data);
      } else {
        toast.error("Invalid data format received from API");
        setCustomers([]);
      }
    } catch (error: any) {
      console.error("Error fetching customers:", error);
      toast.error(`Failed to load customers: ${error.message}`);
      setCustomers([]);
    } finally {
      setLoading(false);
    }
  };

  const filteredCustomers = customers.filter((customer) => {
    const matchesSearch =
      customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      customer.contact_phone.includes(searchTerm) ||
      customer.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      customer.vehicle_details?.registration_number
        .toLowerCase()
        .includes(searchTerm.toLowerCase()) ||
      false;

    const matchesStatus =
      statusFilter === "all" || customer.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  const handleDeleteCustomer = async (id: string) => {
    if (!confirm("Are you sure you want to delete this customer?")) {
      return;
    }

    try {
      const token = localStorage.getItem("token");

      const response = await fetch(`/api/customers/${id}`, {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      if (response.ok) {
        toast.success("Customer deleted successfully");
        // Refresh the customers list
        fetchCustomers();
      } else {
        const errorData = await response.json();
        toast.error(errorData.message || "Failed to delete customer");
      }
    } catch (error: any) {
      console.error("Error deleting customer:", error);
      toast.error(`Failed to delete customer: ${error.message}`);
    }
  };

  const totalPages = Math.max(
    1,
    Math.ceil(filteredCustomers.length / itemsPerPage)
  );
  const paginatedCustomers = filteredCustomers.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const renderStatusBadge = (status: string) => {
    const statusConfig: Record<string, { class: string; label: string }> = {
      active: { class: "bg-success", label: "Active" },
      inactive: { class: "bg-secondary", label: "Inactive" },
      pending: { class: "bg-warning", label: "Pending" },
      "": { class: "bg-info", label: "Unknown" },
    };

    const config = statusConfig[status] || {
      class: "bg-info",
      label: status.charAt(0).toUpperCase() + status.slice(1),
    };

    return (
      <span className={`badge ${config.class} text-white`}>{config.label}</span>
    );
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  };

  if (loading) {
    return (
      <div className="page-body">
        <Container fluid>
          <Row>
            <Col sm={12}>
              <Card>
                <CardBody className="text-center py-5">
                  <div className="spinner-border text-primary" role="status">
                    <span className="visually-hidden">Loading...</span>
                  </div>
                  <p className="mt-3">Loading customers...</p>
                </CardBody>
              </Card>
            </Col>
          </Row>
        </Container>
      </div>
    );
  }

  return (
    <div className="page-body">
      <Breadcrumbs
        title="Customer Management"
        mainTitle="Customer Management"
        parent="Dashboard"
      />

      <Container fluid>
        <Row>
          <Col sm={12}>
            <Card className="customer-card">
              <CardBody>
                {/* Header with Search, Filter, and Add Button */}
                <div className="row align-items-center mb-4 g-3">
                  {/* Search Bar */}
                  <div className="col-12 col-md-3">
                    <div className="position-relative">
                      <Input
                        type="search"
                        placeholder="Search customers..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="form-control"
                      />
                      {searchTerm.length === 0 && (
                        <i
                          className="fa fa-search position-absolute"
                          style={{
                            right: "10px",
                            top: "50%",
                            transform: "translateY(-50%)",
                            color: "#aaa",
                          }}
                        ></i>
                      )}
                    </div>
                  </div>

                  {/* Status Filter Dropdown */}
                  <div className="col-12 col-md-3">
                    <div className="position-relative">
                      <Input
                        type="select"
                        value={statusFilter}
                        onChange={(e) =>
                          setStatusFilter(
                            e.target.value as CustomerStatus | "all"
                          )
                        }
                        className="form-control"
                      >
                        <option value="all">All Status</option>
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                        <option value="pending">Pending</option>
                        <option value="">Unknown</option>
                      </Input>
                    </div>
                  </div>

                  {/* Spacer */}
                  <div className="d-none d-md-block col-md-3"></div>

                  {/* Add Customer Button */}
                  <div className="col-12 col-md-3 d-flex justify-content-md-end">
                    <Link
                      href="/admin/customer/add"
                      className="w-100 w-md-auto"
                    >
                      <Button color="primary" className="w-100 w-md-auto">
                        <i className="fa fa-plus me-2"></i>
                        Add Customer
                      </Button>
                    </Link>
                  </div>
                </div>

                {/* Customer Table - Updated to show vehicle details */}
                <div className="table-responsive">
                  <Table hover className="customer-table mb-0">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>Customer Name</th>
                        <th>Phone</th>
                        <th>Email</th>
                        <th>Address</th>
                        <th>Vehicle No.</th>
                        <th>Model</th>
                        {/* <th>GST Number</th> */}
                        <th>Status</th>
                        <th>Created</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {paginatedCustomers.length === 0 ? (
                        <tr>
                          <td colSpan={11} className="text-center py-4">
                            {searchTerm || statusFilter !== "all"
                              ? "No customers found matching your criteria"
                              : "No customers found"}
                          </td>
                        </tr>
                      ) : (
                        paginatedCustomers.map((customer, index) => (
                          <tr key={customer.id}>
                            <td>
                              <strong>
                                {(currentPage - 1) * itemsPerPage + index + 1}
                              </strong>
                            </td>
                            <td>
                              <div
                                className="fw-bold text-primary cursor-pointer"
                                onClick={() =>
                                  router.push(`/admin/customer/${customer.id}`)
                                }
                                style={{ cursor: "pointer" }}
                              >
                                {customer.name}
                              </div>
                            </td>
                            <td className="no-wrap">
                              {customer.contact_phone}
                            </td>
                            <td>
                              <small className="text-muted d-block">
                                {customer.email}
                              </small>
                            </td>
                            <td>
                              {customer.address || (
                                <span className="text-muted">No address</span>
                              )}
                            </td>
                            <td className="no-wrap">
                              {customer.vehicle_details
                                ?.registration_number || (
                                <span className="text-muted">N/A</span>
                              )}
                            </td>
                            <td>
                              {customer.vehicle_details?.model || (
                                <span className="text-muted">N/A</span>
                              )}
                            </td>
                            {/* <td>
                              {customer.gst_number || (
                                <span className="text-muted">N/A</span>
                              )}
                            </td> */}
                            <td>{renderStatusBadge(customer.status)}</td>
                            <td>
                              <small className="text-muted">
                                {formatDate(customer.created_at)}
                              </small>
                            </td>
                            <td>
                              <div className="d-flex gap-1">
                                {/* view button */}
                                <button
                                  className="action-btn text-white border btn-primary"
                                  onClick={() =>
                                    router.push(
                                      `/admin/customer/${customer.id}`
                                    )
                                  }
                                  title="View"
                                >
                                  <i className="fa fa-eye"></i>
                                </button>

                                {/* edit button */}
                                <button
                                  className="action-btn text-white border btn-warning"
                                  onClick={() =>
                                    router.push(
                                      `/admin/customer/add?id=${customer.id}`
                                    )
                                  }
                                  title="Edit"
                                >
                                  <i className="icofont icofont-pencil-alt-5"></i>
                                </button>

                                {/* delete button */}
                                <button
                                  className="action-btn text-white border btn-danger"
                                  onClick={() =>
                                    handleDeleteCustomer(customer.id)
                                  }
                                  title="Delete"
                                >
                                  <i className="icofont icofont-ui-delete"></i>
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </Table>
                </div>

                {/* Pagination and Info */}
                <div className="d-flex flex-column flex-md-row justify-content-between align-items-center gap-3 mt-4">
                  <div className="text-center text-md-start text-muted">
                    Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
                    {Math.min(
                      currentPage * itemsPerPage,
                      filteredCustomers.length
                    )}{" "}
                    of {filteredCustomers.length} entries
                  </div>
                  <CustomPagination
                    currentPage={currentPage}
                    totalPages={totalPages}
                    onPageChange={setCurrentPage}
                    showFirstLast={true}
                    maxVisiblePages={5}
                    paginationType="primary"
                    className="justify-content-center justify-content-md-end"
                  />
                </div>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Container>

      <style jsx>{`
        .customer-card {
          box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
          border: 1px solid rgba(0, 0, 0, 0.125);
        }

        .action-btn {
          padding: 0.25rem 0.5rem;
          border-radius: 5px;
          font-size: 0.75rem;
        }

        .action-btn:hover {
          opacity: 0.9;
        }

        .customer-table {
          font-size: 0.875rem;
          table-layout: auto;
        }

        .customer-table td {
          vertical-align: middle;
        }

        .no-wrap {
          white-space: nowrap;
        }

        .cursor-pointer {
          cursor: pointer;
        }

        @media (max-width: 768px) {
          .customer-card .card-body {
            padding: 1rem;
          }

          .table-responsive {
            border: 1px solid #dee2e6;
            border-radius: 0.375rem;
            overflow-x: auto;
          }

          .customer-table {
            min-width: 900px;
          }
        }
      `}</style>
    </div>
  );
}

export default withAuth(Page, ["admin"]);
