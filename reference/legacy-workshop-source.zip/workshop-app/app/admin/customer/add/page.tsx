"use client";
import Breadcrumbs from "@/CommonElements/Breadcrumbs";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  Form,
  FormGroup,
  Label,
  Input,
  Button,
  Alert,
  Spinner,
} from "reactstrap";

import React, { useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { toast } from "react-toastify";
import { useAuth } from "@/helper/AuthContext";
import { Loading } from "@/utils/Constant";

function AddCustomerPage() {
  const { state } = useAuth();
  const router = useRouter();

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    vehicle_number: "",
    vehicle_model: "",
    vehicle_year: "",
    // vin: "",
    status: "active",
    address: "",
  });

  //  state for editing
  const [isEditMode, setIsEditMode] = useState(false);
  const searchParams = useSearchParams();
  const customerId = searchParams.get("id");

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  // form submit
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    //console.log("Customer data:", formData);

    //validate all required fiels
    if (
      !formData.name ||
      !formData.phone ||
      !formData.vehicle_number ||
      !formData.vehicle_model
    ) {
      toast.warning("Please fill all the required fields *");
      return;
    }

    try {
      setSubmitting(true);
      setError(null);

      // const customerData = {
      //   name: formData.name ,
      //   email : formData.email ,
      //   phone : formData.phone ,
      //   vehicleNumber : formData.vehicleNumber,
      //   vehicleYear : formData.vehicleYear ,
      //   vin : formData.vin ,
      //   status : formData.status,
      // }

      console.log("Submitting Customer data", formData);

      let response;
      let method;
      let url;

      if (isEditMode && customerId) {
        (method = "PUT"), (url = `/api/customers/${customerId}`);
      } else {
        (method = "POST"), (url = "/api/customers");
      }

      response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${state?.accessToken ?? ""}`,
        },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(
          errorData.message ||
            `Failed to ${isEditMode ? "Update" : "Add"} customer: ${
              response.status
            }`
        );
      }

      // success
      console.log(response);
      const result = await response.json();
      console.log(
        `Customer ${isEditMode ? "Updated" : "Added"} Successfully`,
        result
      );

      toast.success(
        result.msg ||
          ` Customer ${isEditMode ? "Updated" : "Added"} Successfully`
      );

      router.push("/admin/customer");
    } catch (error) {
      console.error(
        `Error ${isEditMode ? "updating" : "adding"} customer:`,
        error
      );

      const errorMessage =
        error instanceof Error
          ? error.message
          : `Failed to ${
              isEditMode ? "update" : "add"
            } customer. Please try again.`;
      setError(errorMessage);
      toast.error(errorMessage);
    } finally {
      setSubmitting(false);
    }
  };

  // editing part
  useEffect(() => {
    if (customerId) {
      setIsEditMode(true);

      fetchCustomerData(customerId);
    }
  }, [customerId]);

  const fetchCustomerData = async (id: string) => {
    try {
      const response = await fetch(`/api/customers/${id}`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${state?.accessToken ?? ""}`,
        },
      });

      if (!response.ok) {
        throw new Error("Failed to fetch customer data");
      }

      console.log(response);
      const data = await response.json();
      console.log(data);

      // Map API response to form fields
      if (data.data) {
        setFormData({
          name: data.data.name || "",
          email: data.data.email || "",
          phone: data.data.contact_phone || "", // Map contact_phone to phone coz different in get api
          address: data.data.address || "",
          status: data.data.status || "active",
          // Vehicle fields might be separate in your API
          vehicle_number:
            data.data.vehicle_number || data.data.vehicleNumber || "",
          vehicle_model:
            data.data.vehicle_model || data.data.vehicleModel || "",
          vehicle_year: data.data.vehicle_year || data.data.vehicleYear || "",
          // vin: data.data.vin || "",
        });
      }
    } catch (error) {
      console.error("Error Fetching Data", error);
    }
  };

  return (
    <div className="page-body">
      <Breadcrumbs
        title={isEditMode ? "Edit Customer" : "Add New Customer"}
        mainTitle={isEditMode ? "Edit Customer" : "Add New Customer"}
        parent="Customer Management"
      />

      <Container fluid>
        <Row>
          {/* <Col sm={12} md={8} lg={6}> */}
          <Col sm={12}>
            <Card>
              <CardBody>
                {/* {showAlert && (
                  <Alert color="success" className="mb-3">
                    Customer added successfully! Redirecting...
                  </Alert>
                )} */}

                <Form onSubmit={handleSubmit}>
                  <Row className="text-muted">
                    <Col md={6}>
                      <FormGroup>
                        <Label for="name">Full Name *</Label>
                        <Input
                          type="text"
                          name="name"
                          id="name"
                          value={formData.name}
                          onChange={handleChange}
                          required
                        />
                      </FormGroup>
                    </Col>

                    <Col md={6}>
                      <FormGroup>
                        <Label for="email">Email Address</Label>
                        <Input
                          type="email"
                          name="email"
                          id="email"
                          value={formData.email}
                          onChange={handleChange}
                        />
                      </FormGroup>
                    </Col>
                  </Row>

                  <Row className="text-muted">
                    <Col md={6}>
                      <FormGroup>
                        <Label for="phone">Phone Number *</Label>
                        <Input
                          type="tel"
                          name="phone"
                          id="phone"
                          value={formData.phone}
                          onChange={handleChange}
                          required
                        />
                      </FormGroup>
                    </Col>

                    <Col md={6}>
                      <FormGroup>
                        <Label for="status">Status</Label>
                        <select
                          name="status"
                          id="status"
                          className="form-select border"
                          value={formData.status}
                          onChange={handleChange}
                        >
                          <option value="active">Active</option>
                          <option value="inactive">Inactive</option>
                          <option value="pending">Pending</option>
                        </select>
                      </FormGroup>
                    </Col>

                    <Col md={12}>
                      <FormGroup>
                        <Label for="address">Address</Label>
                        <Input
                          type="textarea"
                          name="address"
                          id="address"
                          rows={4}
                          placeholder="Enter full address..."
                          value={formData.address}
                          onChange={handleChange}
                        />
                      </FormGroup>
                    </Col>
                  </Row>
                  {!isEditMode ? (
                    <>
                      <hr className="my-4" />

                      <h6 className="mb-3 text-muted">Vehicle Information</h6>

                      <Row className="text-muted">
                        <Col md={6}>
                          <FormGroup>
                            <Label for="vehicleNumber">Vehicle Number *</Label>
                            <Input
                              type="text"
                              name="vehicle_number"
                              id="vehicle_number"
                              value={formData.vehicle_number}
                              onChange={handleChange}
                              required
                            />
                          </FormGroup>
                        </Col>

                        <Col md={6}>
                          <FormGroup>
                            <Label for="vehicleModel">Vehicle Model *</Label>
                            <Input
                              type="text"
                              name="vehicle_model"
                              id="vehicle_model"
                              value={formData.vehicle_model}
                              onChange={handleChange}
                              required
                            />
                          </FormGroup>
                        </Col>
                      </Row>

                      <Row className="text-muted">
                        <Col md={6}>
                          <FormGroup>
                            <Label for="vehicleYear">Vehicle Year</Label>
                            <Input
                              type="number"
                              name="vehicle_year"
                              id="vehicle_year"
                              value={formData.vehicle_year}
                              onChange={handleChange}
                              min="1990"
                              max="2024"
                            />
                          </FormGroup>
                        </Col>

                        {/* <Col md={6}>
                      <FormGroup>
                        <Label for="vin">VIN Number</Label>
                        <Input
                          type="text"
                          name="vin"
                          id="vin"
                          value={formData.vin}
                          onChange={handleChange}
                        />
                      </FormGroup>
                    </Col> */}
                      </Row>
                    </>
                  ) : (
                    <></>
                  )}
                  <div className="d-flex gap-2 mt-4">
                    <Button type="submit" color="primary" disabled={submitting}>
                      {submitting ? (
                        <>
                          <Spinner size="sm" className="me-2" />
                          {isEditMode ? "Updating..." : "Adding..."}
                        </>
                      ) : (
                        <>
                          <i className="fa fa-save me-2"></i>
                          {isEditMode ? "Update Customer" : "Add Customer"}
                        </>
                      )}
                    </Button>

                    <Button
                      type="button"
                      color="secondary"
                      onClick={() => router.push("/admin/customer")}
                      disabled={submitting}
                    >
                      Cancel
                    </Button>
                  </div>
                </Form>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Container>
    </div>
  );
}

export default AddCustomerPage;
