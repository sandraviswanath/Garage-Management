"use client";
import Breadcrumbs from "@/CommonElements/Breadcrumbs";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  Form,
  FormGroup,
  Label,
  Input,
  Button,
  Table,
  Badge,
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
} from "reactstrap";
import React, { useState, ChangeEvent } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";

// Types
interface EstimateItem {
  id: string;
  type: "labor" | "part";
  description: string;
  quantity: number;
  unitPrice: number;
  total: number;
}

interface JobCard {
  id: string;
  jobNumber: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  vehicle: string;
  reportedIssue: string;
}

// Mock data
const jobCardsData: JobCard[] = [
  {
    id: "1",
    jobNumber: "JC-2024-001",
    customerName: "John Doe",
    customerEmail: "john.doe@email.com",
    customerPhone: "+1-555-0101",
    vehicle: "Toyota Camry (ABC123)",
    reportedIssue: "Regular maintenance service",
  },
  {
    id: "2",
    jobNumber: "JC-2024-002",
    customerName: "Jane Smith",
    customerEmail: "jane.smith@email.com",
    customerPhone: "+1-555-0102",
    vehicle: "Honda Civic (XYZ789)",
    reportedIssue: "Brake noise and vibration",
  },
  {
    id: "3",
    jobNumber: "JC-2024-003",
    customerName: "Mike Johnson",
    customerEmail: "mike.j@email.com",
    customerPhone: "+1-555-0103",
    vehicle: "Ford F-150 (DEF456)",
    reportedIssue: "Pre-purchase inspection",
  },
];

const defaultParts = [
  {
    id: "1",
    name: "Oil Filter",
    description: "Premium oil filter",
    price: 25.0,
  },
  {
    id: "2",
    name: "Brake Pads",
    description: "Ceramic brake pads set",
    price: 85.0,
  },
  {
    id: "3",
    name: "Spark Plugs",
    description: "Iridium spark plug set",
    price: 45.0,
  },
  {
    id: "4",
    name: "Air Filter",
    description: "High-flow air filter",
    price: 32.0,
  },
  {
    id: "5",
    name: "Engine Oil",
    description: "Synthetic 5W-30 oil",
    price: 45.0,
  },
];

const laborRates = [
  { id: "1", name: "Basic Labor", rate: 75.0 },
  { id: "2", name: "Diagnostic Fee", rate: 50.0 },
  { id: "3", name: "Emergency Service", rate: 100.0 },
];

function CreateEstimatePage() {
  const router = useRouter();
  const [selectedJobCard, setSelectedJobCard] = useState<JobCard | null>(null);
  const [items, setItems] = useState<EstimateItem[]>([]);
  const [notes, setNotes] = useState("");
  const [validityDays, setValidityDays] = useState(7);
  const [addPartModal, setAddPartModal] = useState(false);
  const [addLaborModal, setAddLaborModal] = useState(false);

  // Calculate totals
  const subtotal = items.reduce((sum, item) => sum + item.total, 0);
  const taxRate = 0.08; // 8%
  const taxAmount = subtotal * taxRate;
  const totalAmount = subtotal + taxAmount;

  // Add part to estimate
  const handleAddPart = (
    part: (typeof defaultParts)[0],
    quantity: number = 1
  ) => {
    const newItem: EstimateItem = {
      id: `part-${Date.now()}`,
      type: "part",
      description: `${part.name} - ${part.description}`,
      quantity,
      unitPrice: part.price,
      total: part.price * quantity,
    };
    setItems([...items, newItem]);
    setAddPartModal(false);
  };

  // Add labor to estimate
  const handleAddLabor = (labor: (typeof laborRates)[0], hours: number = 1) => {
    const newItem: EstimateItem = {
      id: `labor-${Date.now()}`,
      type: "labor",
      description: `${labor.name} (${hours} hour${hours > 1 ? "s" : ""})`,
      quantity: hours,
      unitPrice: labor.rate,
      total: labor.rate * hours,
    };
    setItems([...items, newItem]);
    setAddLaborModal(false);
  };

  // Update item quantity
  const handleUpdateQuantity = (itemId: string, newQuantity: number) => {
    if (newQuantity < 1) return;

    setItems(
      items.map((item) =>
        item.id === itemId
          ? {
              ...item,
              quantity: newQuantity,
              total: newQuantity * item.unitPrice,
            }
          : item
      )
    );
  };

  // Update item price
  const handleUpdatePrice = (itemId: string, newPrice: number) => {
    if (newPrice < 0) return;

    setItems(
      items.map((item) =>
        item.id === itemId
          ? { ...item, unitPrice: newPrice, total: newPrice * item.quantity }
          : item
      )
    );
  };

  // Remove item
  const handleRemoveItem = (itemId: string) => {
    setItems(items.filter((item) => item.id !== itemId));
  };

  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedJobCard) {
      alert("Please select a job card first");
      return;
    }

    // In real app, this would save to database
    console.log("Creating estimate:", {
      jobCard: selectedJobCard,
      items,
      notes,
      validityDays,
      subtotal,
      taxAmount,
      totalAmount,
    });

    alert("Estimate created successfully!");
    router.push("/admin/estimates");
  };

  return (
    <div className="page-body">
      <Breadcrumbs
        title="Create Estimate"
        mainTitle="New Quotation"
        parent="Estimates"
      />

      <Container fluid>
        <Form onSubmit={handleSubmit}>
          <Row>
            {/* Left Column - Job Card Selection & Details */}
            <Col lg="4">
              <Card className="mb-4">
                <CardBody>
                  <h5 className="card-title mb-4 text-muted">Job Card Selection</h5>

                  {/* <FormGroup className="text-muted">
                    <Label>Select Job Card *</Label>
                    <Input
                      type="select"
                      value={selectedJobCard?.id || ""}
                      onChange={(e: ChangeEvent<HTMLInputElement>) => {
                        const jobCard = jobCardsData.find(
                          (jc) => jc.id === e.target.value
                        );
                        setSelectedJobCard(jobCard || null);
                      }}
                      required
                  
                    >
                      <option value="">Choose a job card...</option>
                      {jobCardsData.map((jobCard) => (
                        <option key={jobCard.id} value={jobCard.id}
                        >
                          {jobCard.jobNumber} - {jobCard.customerName} -{" "}
                          {jobCard.vehicle}
                        </option>
                      ))}
                    </Input>
                  </FormGroup> */}
<FormGroup className="text-muted">
                    <Label>Select Job Card *</Label>
                    <Input
                      type="select"
                      value={selectedJobCard?.id || ""}
                      onChange={(e: ChangeEvent<HTMLInputElement>) => {
                        const jobCard = jobCardsData.find(
                          (jc) => jc.id === e.target.value
                        );
                        setSelectedJobCard(jobCard || null);
                      }}
                      required
                  
                    >
                      <option value="">Choose a job card...</option>
                      {jobCardsData.map((jobCard) => (
                        <option key={jobCard.id} value={jobCard.id}
                        style={{fontSize :"14px"
                        }}
                        >
                          {jobCard.jobNumber} - {jobCard.customerName}
                          {/* {jobCard.vehicle} */}
                        </option>
                      ))}
                    </Input>
                  </FormGroup>

                  {selectedJobCard && (
                    <div className="mt-3 p-3 bg-light rounded">
                      <h6 className=" text-muted">Customer Details</h6>
                      <div className="small text-muted">
                        <div>
                          <strong>Name:</strong> {selectedJobCard.customerName}
                        </div>
                        <div>
                          <strong>Email:</strong>{" "}
                          {selectedJobCard.customerEmail}
                        </div>
                        <div>
                          <strong>Phone:</strong>{" "}
                          {selectedJobCard.customerPhone}
                        </div>
                        <div>
                          <strong>Vehicle:</strong> {selectedJobCard.vehicle}
                        </div>
                        <div>
                          <strong>Issue:</strong>{" "}
                          {selectedJobCard.reportedIssue}
                        </div>
                      </div>
                    </div>
                  )}

                  <FormGroup className="mt-3 text-muted">
                    <Label>Estimate Validity (Days)</Label>
                    <Input
                      type="number"
                      value={validityDays}
                      onChange={(e: ChangeEvent<HTMLInputElement>) =>
                        setValidityDays(parseInt(e.target.value))
                      }
                      min="1"
                      max="30"
                    />
                  </FormGroup>

                  <FormGroup className="text-muted">
                    <Label>Notes to Customer</Label>
                    <Input
                      type="textarea"
                      value={notes}
                      onChange={(e: ChangeEvent<HTMLInputElement>) =>
                        setNotes(e.target.value)
                      }
                      rows="3"
                      placeholder="Additional notes or terms..."
                    />
                  </FormGroup>
                </CardBody>
              </Card>

              {/* Quick Actions */}
              <Card>
                <CardBody>
                  <h5 className="card-title mb-4 text-muted">Quick Actions</h5>
                  <div className="d-grid gap-2">
                    <Button
                      color="primary"
                      onClick={() => setAddPartModal(true)}
                      disabled={!selectedJobCard}
                    >
                      <i className="fa fa-box me-2"></i>
                      Add Parts
                    </Button>
                    <Button
                      color="info"
                      onClick={() => setAddLaborModal(true)}
                      disabled={!selectedJobCard}
                      className="text-white"
                    >
                      <i className="fa fa-tools me-2"></i>
                      Add Labor
                    </Button>
                    <Button
                      color="success"
                      type="submit"
                      disabled={!selectedJobCard || items.length === 0}
                    >
                      <i className="fa fa-save me-2"></i>
                      Save Estimate
                    </Button>
                  </div>
                </CardBody>
              </Card>
            </Col>

            {/* Right Column - Estimate Items & Summary */}
            <Col lg="8">
              {/* <Card className="mb-4">
                <CardBody>
                  <div className="d-flex justify-content-between align-items-center mb-4">
                    <h5 className="card-title mb-0 text-muted">Estimate Items</h5>
                    <div className="text-muted">
                      {items.length} item{items.length !== 1 ? "s" : ""}
                    </div>
                  </div>

                  {items.length === 0 ? (
                    <div className="text-center py-5 text-muted">
                      <i className="fa fa-receipt fa-3x mb-3"></i>
                      <p>No items added yet. Start by adding parts or labor.</p>
                    </div>
                  ) : (
                    <div className="table-responsive">
                      <Table hover>
                        <thead>
                          <tr>
                            <th style={{ width: "auto" }}>Description</th>
                            <th style={{ width: "100" }}>Qty</th>
                            <th style={{ width: "120" }}>Unit Price</th>
                            <th style={{ width: "120" }}>Total</th>
                            <th style={{ width: "80" }}>Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {items.map((item) => (
                            <tr key={item.id}>
                              <td>
                                <div>
                                  <div className="fw-bold">
                                    <Badge
                                      color={
                                        item.type === "part"
                                          ? "info"
                                          : "warning"
                                      }
                                      className="me-2"
                                    >
                                      {item.type === "part" ? "Part" : "Labor"}
                                    </Badge>
                                    {item.description}
                                  </div>
                                </div>
                              </td>
                              <td>
                                <Input
                                  type="number"
                                  value={item.quantity}
                                  onChange={(
                                    e: ChangeEvent<HTMLInputElement>
                                  ) =>
                                    handleUpdateQuantity(
                                      item.id,
                                      parseInt(e.target.value)
                                    )
                                  }
                                  min="1"
                                  style={{ width: "70px" }}
                                />
                              </td>
  

                             <td>
                                <div className="input-group flex">
                                  <span className="input-group-text">$</span>
                                  <Input
                                    type="number"
                                    value={item.unitPrice}
                                    onChange={(
                                      e: ChangeEvent<HTMLInputElement>
                                    ) =>
                                      handleUpdatePrice(
                                        item.id,
                                        parseFloat(e.target.value)
                                      )
                                    }
                                    min="0"
                                    step="0.01"
                                    style={{ width: "100px" }}
                                  />
                                </div>
                              </td> 
                              <td>
                                <strong>${item.total.toFixed(2)}</strong>
                              </td>
                              <td>
                                <button
                                  type="button"
                                  className="btn btn-sm btn-danger"
                                  onClick={() => handleRemoveItem(item.id)}
                                >
                                  <i className="fa fa-trash"></i>
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </Table>
                    </div>
                  )}
                </CardBody>
              </Card> */}
<Card className="mb-4">
  <CardBody>
    <div className="d-flex justify-content-between align-items-center mb-4 flex-wrap">
      <h5 className="card-title mb-0 text-muted">Estimate Items</h5>
      <div className="text-muted mt-2 mt-sm-0">
        {items.length} item{items.length !== 1 ? "s" : ""}
      </div>
    </div>

    {items.length === 0 ? (
      <div className="text-center py-5 text-muted">
        <i className="fa fa-receipt fa-3x mb-3"></i>
        <p>No items added yet. Start by adding parts or labor.</p>
      </div>
    ) : (
      // ✅ Make table responsive
      <div className="table-responsive">
        <Table hover className="align-middle mb-0">
          <thead className="table-light">
            <tr>
              <th>Description</th>
              <th style={{ width: "90px" }}>Qty</th>
              <th style={{ width: "120px" }}>Unit Price</th>
              <th style={{ width: "120px" }}>Total</th>
              <th style={{ width: "80px" }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {items.map((item) => (
              <tr key={item.id}>
                <td>
                  <div>
                    <div className="fw-bold no-wrap">
                      <Badge
                        color={item.type === "part" ? "info" : "warning"}
                        className="me-2"
                      >
                        {item.type === "part" ? "Part" : "Labor"}
                      </Badge>
                      {item.description}
                    </div>
                  </div>
                </td>
                <td>
                  <Input
                    type="number"
                    value={item.quantity}
                    onChange={(e: ChangeEvent<HTMLInputElement>) =>
                      handleUpdateQuantity(item.id, parseInt(e.target.value))
                    }
                    min="1"
                    className="form-control form-control-sm"
                    style={{ width: "70px" }}
                  />
                </td>
                <td>
                  <div className="input-group input-group-sm" style={{ width: "100px" }}>
                    <span className="input-group-text p-2 border" style={{ borderRight: "none",  borderTopRightRadius: "0",
    borderBottomRightRadius: "0" }}>$</span>
                    <Input
                      type="number"
                      value={item.unitPrice}
                      onChange={(e: ChangeEvent<HTMLInputElement>) =>
                        handleUpdatePrice(item.id, parseFloat(e.target.value))
                      }
                      min="0"
                      step="0.01"
                      className="form-control p-1"
                      style={{ borderLeft: "none",  borderTopLeftRadius: "0",
    borderBottomLeftRadius: "0", }}
                    />
                  </div>
                </td>
                <td>
                  <strong>${item.total.toFixed(2)}</strong>
                </td>
                <td>
                  <button
                    type="button"
                    className="btn btn-sm btn-danger"
                    onClick={() => handleRemoveItem(item.id)}
                  >
                    <i className="fa fa-trash"></i>
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      </div>
    )}
  </CardBody>
</Card>

              {/* Summary Card */}
              <Card>
                <CardBody>
                  <h5 className="card-title mb-4 text-muted">Estimate Summary</h5>
                  <Row>
                    <Col md="8">
                      <div className="d-flex justify-content-between mb-2 text-muted">
                        <span>Subtotal:</span>
                        <span>${subtotal.toFixed(2)}</span>
                      </div>
                      <div className="d-flex justify-content-between mb-2 text-muted">
                        <span>Tax (8%):</span>
                        <span>${taxAmount.toFixed(2)}</span>
                      </div>
                      <hr />
                      <div className="d-flex justify-content-between mb-2 fs-5 text-muted">
                        <strong>Total Amount:</strong>
                        <strong className="text-success">
                          ${totalAmount.toFixed(2)}
                        </strong>
                      </div>
                      <div className="small text-muted">
                        Valid until:{" "}
                        {new Date(
                          Date.now() + validityDays * 24 * 60 * 60 * 1000
                        ).toLocaleDateString()}
                      </div>
                    </Col>
                    <Col md="4" className="text-end">
                      <div className="border rounded p-3 bg-light">
                        <div className="fw-bold text-muted">Quick Actions</div>
                        <div className="mt-2">
                          <Button
                            color="primary"
                            size="sm"
                            className="w-100 mb-2"
                          >
                            <i className="fa fa-print me-1"></i>
                            Print
                          </Button>
                          <Button color="success" size="sm" className="w-100">
                            <i className="fa fa-paper-plane me-1"></i>
                            Send to Customer
                          </Button>
                        </div>
                      </div>
                    </Col>
                  </Row>
                </CardBody>
              </Card>
            </Col>
          </Row>
        </Form>
      </Container>

      {/* Add Parts Modal */}
      <Modal
        isOpen={addPartModal}
        toggle={() => setAddPartModal(false)}
        size="lg"
       
      >
        <ModalHeader toggle={() => setAddPartModal(false)} className="text-secondary">
          Add Parts to Estimate
        </ModalHeader>
    <ModalBody className="text-body">
          <div className="table-responsive">
            <Table hover>
              <thead>
                <tr>
                  <th className="text-secondary">Part Name</th>
                  <th  className="text-secondary">Description</th>
                  <th  className="text-secondary">Price</th>
                  <th  className="text-secondary">Quantity</th>
                  <th  className="text-secondary">Action</th>
                </tr>
              </thead>
              <tbody>
                {defaultParts.map((part) => (
                  <tr key={part.id}>
                    <td  className="text-secondary">{part.name}</td>
                    <td  className="text-secondary">{part.description}</td>
                    <td  className="text-secondary">${part.price.toFixed(2)}</td>
                    <td  className="text-secondary">
                      <Input
                        type="number"
                        defaultValue="1"
                        min="1"
                        id={`qty-${part.id}`}
                        style={{ width: "80px" }}
                      />
                    </td>
                    <td>
                      <Button
                        color="primary"
                        size="sm"
                        onClick={() => {
                          const qtyInput = document.getElementById(
                            `qty-${part.id}`
                          ) as HTMLInputElement;
                          const quantity = parseInt(qtyInput?.value || "1");
                          handleAddPart(part, quantity);
                        }}
                      >
                        Add
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </div>
        </ModalBody>
      </Modal>

      {/* Add Labor Modal */}
      <Modal isOpen={addLaborModal} toggle={() => setAddLaborModal(false)}>
        <ModalHeader toggle={() => setAddLaborModal(false)}  className="text-secondary">
          Add Labor to Estimate
        </ModalHeader>
        <ModalBody>
          <div className="table-responsive">
            <Table hover>
              <thead>
                <tr>
                  <th  className="text-secondary">Service Type</th>
                  <th className="text-secondary">Rate/Hour</th>
                  <th className="text-secondary">Hours</th>
                  <th  className="text-secondary">Action</th>
                </tr>
              </thead>
              <tbody>
                {laborRates.map((labor) => (
                  <tr key={labor.id}>
                    <td>{labor.name}</td>
                    <td>${labor.rate.toFixed(2)}</td>
                    <td>
                      <Input
                        type="number"
                        defaultValue="1"
                        min="1"
                        step="0.5"
                        id={`hours-${labor.id}`}
                        style={{ width: "80px" }}
                      />
                    </td>
                    <td>
                      <Button
                        color="info"
                        size="sm"
                        onClick={() => {
                          const hoursInput = document.getElementById(
                            `hours-${labor.id}`
                          ) as HTMLInputElement;
                          const hours = parseFloat(hoursInput?.value || "1");
                          handleAddLabor(labor, hours);
                        }}
                      >
                        Add
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </div>
        </ModalBody>
      </Modal>

      <style jsx global>{`
        .action-btn {
          padding: 0.25rem 0.5rem;
          border-radius: 5px;
          font-size: 0.75rem;
          border: none;
          display: flex;
          align-items: center;
          justify-content: center;
          width: 32px;
          height: 32px;
        }
    
      `}</style>
    </div>
  );
}

export default CreateEstimatePage;
