"use client";
import Breadcrumbs from "@/CommonElements/Breadcrumbs";
import CustomPagination from "@/CommonElements/Pagination";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  Input,
  Button,
  Table,
  Badge,
  Dropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
} from "reactstrap";
import React, { useState, ChangeEvent } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import withAuth from "@/helper/WithAuth";

// Types
interface Estimate {
  id: string;
  estimateNumber: string;
  jobCardNumber: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  vehicle: string;
  totalAmount: number;
  status: "draft" | "sent" | "approved" | "rejected" | "expired";
  createdDate: string;
  expiryDate: string;
  sentDate?: string;
  approvedDate?: string;
}

// Mock data
const estimatesData: Estimate[] = [
  {
    id: "1",
    estimateNumber: "EST-2024-001",
    jobCardNumber: "JC-2024-001",
    customerName: "John Doe",
    customerEmail: "john.doe@email.com",
    customerPhone: "+1-555-0101",
    vehicle: "Toyota Camry (ABC123)",
    totalAmount: 325.5,
    status: "approved",
    createdDate: "2024-01-15",
    expiryDate: "2024-01-22",
    sentDate: "2024-01-15",
    approvedDate: "2024-01-16",
  },
  {
    id: "2",
    estimateNumber: "EST-2024-002",
    jobCardNumber: "JC-2024-002",
    customerName: "Jane Smith",
    customerEmail: "jane.smith@email.com",
    customerPhone: "+1-555-0102",
    vehicle: "Honda Civic (XYZ789)",
    totalAmount: 485.0,
    status: "sent",
    createdDate: "2024-01-16",
    expiryDate: "2024-01-23",
    sentDate: "2024-01-16",
  },
  {
    id: "3",
    estimateNumber: "EST-2024-003",
    jobCardNumber: "JC-2024-003",
    customerName: "Mike Johnson",
    customerEmail: "mike.j@email.com",
    customerPhone: "+1-555-0103",
    vehicle: "Ford F-150 (DEF456)",
    totalAmount: 120.0,
    status: "draft",
    createdDate: "2024-01-14",
    expiryDate: "2024-01-21",
  },
  {
    id: "4",
    estimateNumber: "EST-2024-004",
    jobCardNumber: "JC-2024-004",
    customerName: "Sarah Wilson",
    customerEmail: "sarah.w@email.com",
    customerPhone: "+1-555-0104",
    vehicle: "BMW X5 (GHI789)",
    totalAmount: 420.75,
    status: "rejected",
    createdDate: "2024-01-17",
    expiryDate: "2024-01-24",
    sentDate: "2024-01-17",
  },
  {
    id: "5",
    estimateNumber: "EST-2024-005",
    jobCardNumber: "JC-2024-005",
    customerName: "Robert Brown",
    customerEmail: "robert.b@email.com",
    customerPhone: "+1-555-0105",
    vehicle: "Mercedes C-Class (JKL012)",
    totalAmount: 895.25,
    status: "expired",
    createdDate: "2024-01-10",
    expiryDate: "2024-01-17",
    sentDate: "2024-01-10",
  },
];

function EstimatesPage() {
  const router = useRouter();
  const [currentPage, setCurrentPage] = useState(1);
  const [estimates, setEstimates] = useState<Estimate[]>(estimatesData);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const itemsPerPage = 8;

  // Filter estimates
  const filteredEstimates = estimates.filter((estimate) => {
    const matchesSearch =
      estimate.estimateNumber
        .toLowerCase()
        .includes(searchTerm.toLowerCase()) ||
      estimate.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      estimate.jobCardNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      estimate.vehicle.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus =
      statusFilter === "all" || estimate.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  // Calculate metrics
  const calculateMetrics = () => {
    const totalEstimates = estimates.length;
    const approvedEstimates = estimates.filter(
      (e) => e.status === "approved"
    ).length;
    const pendingApproval = estimates.filter((e) => e.status === "sent").length;
    const totalValue = estimates.reduce((sum, est) => sum + est.totalAmount, 0);
    const approvedValue = estimates
      .filter((e) => e.status === "approved")
      .reduce((sum, est) => sum + est.totalAmount, 0);

    return {
      totalEstimates,
      approvedEstimates,
      pendingApproval,
      totalValue,
      approvedValue,
      conversionRate:
        totalEstimates > 0 ? (approvedEstimates / totalEstimates) * 100 : 0,
    };
  };

  const metrics = calculateMetrics();

  // Pagination
  const totalPages = Math.ceil(filteredEstimates.length / itemsPerPage);
  const paginatedEstimates = filteredEstimates.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  // Status badge renderer
  const renderStatusBadge = (status: string) => {
    const statusConfig = {
      draft: { class: "bg-secondary", label: "Draft", icon: "fa-edit" },
      sent: { class: "bg-primary", label: "Sent", icon: "fa-paper-plane" },
      approved: { class: "bg-success", label: "Approved", icon: "fa-check" },
      rejected: { class: "bg-danger", label: "Rejected", icon: "fa-times" },
      expired: { class: "bg-warning", label: "Expired", icon: "fa-clock" },
    };

    const config = statusConfig[status as keyof typeof statusConfig] || {
      class: "bg-secondary",
      label: status,
      icon: "fa-question",
    };

    return (
      <Badge className={config.class}>
        <i className={`fa ${config.icon} me-1`}></i>
        {config.label}
      </Badge>
    );
  };

  // Handle actions
  const handleSendEstimate = (estimateId: string) => {
    // In real app, this would open a modal for sending options
    console.log("Sending estimate:", estimateId);
    alert("Send estimate functionality would open here");
  };

  const handleApproveEstimate = (estimateId: string) => {
    if (
      confirm(
        "Mark this estimate as approved? This will update the linked job card."
      )
    ) {
      setEstimates(
        estimates.map((est) =>
          est.id === estimateId
            ? {
                ...est,
                status: "approved",
                approvedDate: new Date().toISOString().split("T")[0],
              }
            : est
        )
      );
    }
  };

  const handleDeleteEstimate = (estimateId: string) => {
    if (confirm("Are you sure you want to delete this estimate?")) {
      setEstimates(estimates.filter((est) => est.id !== estimateId));
    }
  };

  const handleDuplicateEstimate = (estimateId: string) => {
    const original = estimates.find((est) => est.id === estimateId);
    if (original) {
      const newEstimate = {
        ...original,
        id: (estimates.length + 1).toString(),
        estimateNumber: `EST-2024-00${estimates.length + 1}`,
        status: "draft" as const,
        createdDate: new Date().toISOString().split("T")[0],
        expiryDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
          .toISOString()
          .split("T")[0],
      };
      setEstimates([...estimates, newEstimate]);
    }
  };

  const resetFilters = () => {
    setSearchTerm("");
    setStatusFilter("all");
    setCurrentPage(1);
  };

  return (
    <div className="page-body">
      <Breadcrumbs
        title="Estimation & Quotation"
        mainTitle="Manage Estimates"
        parent="Dashboard"
      />

      <Container fluid>
        {/* Metrics Overview */}
        {/* <Row className="mb-4">
          <Col xl="3" md="6">
            <Card className="card-stats">
              <CardBody>
                <div className="d-flex align-items-center">
                  <div className="flex-grow-1">
                    <h4 className="mb-0">{metrics.totalEstimates}</h4>
                    <span className="text-muted">Total Estimates</span>
                  </div>
                  <div className="flex-shrink-0">
                    <div className="bg-primary rounded-circle p-3">
                      <i className="fa fa-file-invoice text-white fs-4"></i>
                    </div>
                  </div>
                </div>
              </CardBody>
            </Card>
          </Col>

          <Col xl="3" md="6">
            <Card className="card-stats">
              <CardBody>
                <div className="d-flex align-items-center">
                  <div className="flex-grow-1">
                    <h4 className="mb-0">{metrics.approvedEstimates}</h4>
                    <span className="text-muted">Approved</span>
                  </div>
                  <div className="flex-shrink-0">
                    <div className="bg-success rounded-circle p-3">
                      <i className="fa fa-check-circle text-white fs-4"></i>
                    </div>
                  </div>
                </div>
              </CardBody>
            </Card>
          </Col>

          <Col xl="3" md="6">
            <Card className="card-stats">
              <CardBody>
                <div className="d-flex align-items-center">
                  <div className="flex-grow-1">
                    <h4 className="mb-0">{metrics.pendingApproval}</h4>
                    <span className="text-muted">Pending Approval</span>
                  </div>
                  <div className="flex-shrink-0">
                    <div className="bg-warning rounded-circle p-3">
                      <i className="fa fa-clock text-white fs-4"></i>
                    </div>
                  </div>
                </div>
              </CardBody>
            </Card>
          </Col>

          <Col xl="3" md="6">
            <Card className="card-stats">
              <CardBody>
                <div className="d-flex align-items-center">
                  <div className="flex-grow-1">
                    <h4 className="mb-0">
                      {metrics.conversionRate.toFixed(1)}%
                    </h4>
                    <span className="text-muted">Conversion Rate</span>
                  </div>
                  <div className="flex-shrink-0">
                    <div className="bg-info rounded-circle p-3">
                      <i className="fa fa-chart-line text-white fs-4"></i>
                    </div>
                  </div>
                </div>
              </CardBody>
            </Card>
          </Col>
        </Row> */}

        <Row>
          <Col sm="12">
            <Card>
              <CardBody>
                {/* Header with Search and Create Button */}
                <div className="row align-items-center mb-4 g-3">
                  <div className="col-12 col-md-3">
                    <Input
                      type="search"
                      placeholder="Search estimates..."
                      value={searchTerm}
                      onChange={(e: ChangeEvent<HTMLInputElement>) =>
                        setSearchTerm(e.target.value)
                      }
                    />
                  </div>

                  <div className="col-12 col-md-3">
                    <select
                      className="form-select border"
                      value={statusFilter}
                      onChange={(e: ChangeEvent<HTMLSelectElement>) =>
                        setStatusFilter(e.target.value)
                      }
                    >
                      <option value="all">All Status</option>
                      <option value="draft">Draft</option>
                      <option value="sent">Sent</option>
                      <option value="approved">Approved</option>
                      <option value="rejected">Rejected</option>
                      <option value="expired">Expired</option>
                    </select>
                  </div>
                  <Col md="2">
                    <div>
                      <Button color="outline-secondary" onClick={resetFilters}>
                        Clear Filter
                      </Button>
                    </div>
                  </Col>

                  <div className="d-none d-md-block col-md-1"></div>

                  <div className="col-12 col-md-3 d-flex justify-content-md-end">
                    <Link
                      href="/admin/estimates/create"
                      className="w-100 w-md-auto"
                    >
                      <Button
                        color="primary"
                        className="w-100 w-md-auto p-2"
                        style={{ fontSize: "13px" }}
                      >
                        <i className="fa fa-plus me-2"></i>
                        Create Estimate
                      </Button>
                    </Link>
                  </div>
                </div>

                {/* Estimates Table */}
                <div className="table-responsive">
                  <Table hover>
                    <thead>
                      <tr>
                        <th>Estimate No.</th>
                        <th>Job Card</th>
                        <th>Customer</th>
                        <th>Vehicle</th>
                        <th>Total Amount</th>
                        <th>Status</th>
                        <th>Created</th>
                        <th>Expires</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {paginatedEstimates.length === 0 ? (
                        <tr>
                          <td colSpan={9} className="text-center py-4">
                            No estimates found
                          </td>
                        </tr>
                      ) : (
                        paginatedEstimates.map((estimate) => (
                          <tr key={estimate.id}>
                            <td>
                              <strong className="text-primary no-wrap">
                                {estimate.estimateNumber}
                              </strong>
                            </td>
                            <td className="no-wrap">
                              <Link
                                href={`/admin/jobcards/${estimate.jobCardNumber}`}
                                className="text-info"
                              >
                                {estimate.jobCardNumber}
                              </Link>
                            </td>
                            <td>
                              <div>
                                <div className="fw-bold">
                                  {estimate.customerName}
                                </div>
                                <small className="text-muted">
                                  {estimate.customerEmail}
                                </small>
                              </div>
                            </td>
                            <td>{estimate.vehicle}</td>
                            <td>
                              <strong className="text-success">
                                ${estimate.totalAmount.toFixed(2)}
                              </strong>
                            </td>
                            <td>{renderStatusBadge(estimate.status)}</td>
                            <td>
                              {new Date(
                                estimate.createdDate
                              ).toLocaleDateString()}
                            </td>
                            <td>
                              <span
                                className={
                                  new Date(estimate.expiryDate) < new Date()
                                    ? "text-danger"
                                    : "text-muted"
                                }
                              >
                                {new Date(
                                  estimate.expiryDate
                                ).toLocaleDateString()}
                              </span>
                            </td>
                            <td>
                              <div className="d-flex gap-1 ">
                                <button
                                  className="action-btn text-white border btn-primary"
                                  onClick={() =>
                                    router.push(
                                      `/admin/estimates/${estimate.id}`
                                    )
                                  }
                                  title="View"
                                >
                                  <i className="fa fa-eye"></i>
                                </button>

                                {estimate.status === "draft" && (
                                  <button
                                    className="action-btn text-white border btn-success"
                                    onClick={() =>
                                      handleSendEstimate(estimate.id)
                                    }
                                    title="Send to Customer"
                                  >
                                    <i className="fa fa-paper-plane"></i>
                                  </button>
                                )}

                                {estimate.status === "sent" && (
                                  <button
                                    className="action-btn text-white border btn-success"
                                    onClick={() =>
                                      handleApproveEstimate(estimate.id)
                                    }
                                    title="Mark as Approved"
                                  >
                                    <i className="fa fa-check"></i>
                                  </button>
                                )}

                                <button
                                  className="action-btn text-white border btn-warning"
                                  onClick={() =>
                                    router.push(
                                      `/admin/estimates/${estimate.id}/edit`
                                    )
                                  }
                                  title="Edit"
                                >
                                  <i className="fa fa-edit"></i>
                                </button>

                                <button
                                  className="action-btn text-white border btn-info"
                                  onClick={() =>
                                    handleDuplicateEstimate(estimate.id)
                                  }
                                  title="Duplicate"
                                >
                                  <i className="fa fa-copy"></i>
                                </button>

                                <button
                                  className="action-btn text-white border btn-danger"
                                  onClick={() =>
                                    handleDeleteEstimate(estimate.id)
                                  }
                                  title="Delete"
                                >
                                  <i className="fa fa-trash"></i>
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </Table>
                </div>

                {/* Pagination */}
                <div className="d-flex flex-column flex-md-row justify-content-between align-items-center gap-3 mt-4">
                  <div className="text-center text-md-start text-muted">
                    Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
                    {Math.min(
                      currentPage * itemsPerPage,
                      filteredEstimates.length
                    )}{" "}
                    of {filteredEstimates.length} entries
                  </div>
                  <CustomPagination
                    currentPage={currentPage}
                    totalPages={totalPages}
                    onPageChange={setCurrentPage}
                    showFirstLast={true}
                    maxVisiblePages={5}
                    paginationType="primary"
                    className="justify-content-center justify-content-md-end"
                  />
                </div>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Container>

      <style jsx global>{`
        .action-btn {
          padding: 0.25rem 0.5rem;
          border-radius: 5px;
          font-size: 0.75rem;
          border: none;
          display: flex;
          align-items: center;
          justify-content: center;
          width: 32px;
          height: 32px;
        }

        .card-stats {
          border: 1px solid #e6edef;
          box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
        }

        .card-stats .bg-primary {
          background-color: #5c5ff6 !important;
        }
        .card-stats .bg-success {
          background-color: #28a745 !important;
        }
        .card-stats .bg-warning {
          background-color: #f8d62b !important;
        }
        .card-stats .bg-info {
          background-color: #17a2b8 !important;
        }
      `}</style>
    </div>
  );
}

// export default EstimatesPage;
export default withAuth(EstimatesPage, ["admin"]);
