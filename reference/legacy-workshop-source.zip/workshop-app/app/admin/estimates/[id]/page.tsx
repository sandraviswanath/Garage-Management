"use client";
import Breadcrumbs from "@/CommonElements/Breadcrumbs";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  Button,
  Badge,
  Table,
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
} from "reactstrap";
import React, { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";

// Types
interface EstimateItem {
  id: string;
  type: "labor" | "part";
  description: string;
  quantity: number;
  unitPrice: number;
  total: number;
}

interface Estimate {
  id: string;
  estimateNumber: string;
  jobCardNumber: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  vehicle: string;
  reportedIssue: string;
  items: EstimateItem[];
  notes: string;
  subtotal: number;
  taxAmount: number;
  totalAmount: number;
  status: "draft" | "sent" | "approved" | "rejected" | "expired";
  createdDate: string;
  expiryDate: string;
  sentDate?: string;
  approvedDate?: string;
}

// Mock data
const estimateData: Estimate = {
  id: "1",
  estimateNumber: "EST-2024-001",
  jobCardNumber: "JC-2024-001",
  customerName: "John Doe",
  customerEmail: "john.doe@email.com",
  customerPhone: "+1-555-0101",
  vehicle: "Toyota Camry (ABC123)",
  reportedIssue: "Regular maintenance service",
  items: [
    {
      id: "1",
      type: "part",
      description: "Oil Filter - Premium oil filter",
      quantity: 1,
      unitPrice: 25.0,
      total: 25.0,
    },
    {
      id: "2",
      type: "part",
      description: "Engine Oil - Synthetic 5W-30 oil",
      quantity: 5,
      unitPrice: 12.5,
      total: 62.5,
    },
    {
      id: "3",
      type: "labor",
      description: "Basic Labor (2 hours)",
      quantity: 2,
      unitPrice: 75.0,
      total: 150.0,
    },
    {
      id: "4",
      type: "labor",
      description: "Diagnostic Fee",
      quantity: 1,
      unitPrice: 50.0,
      total: 50.0,
    },
  ],
  notes:
    "Includes complimentary vehicle inspection. Estimate valid for 7 days.",
  subtotal: 287.5,
  taxAmount: 23.0,
  totalAmount: 310.5,
  status: "sent",
    // status: "draft",
  createdDate: "2024-01-15",
  expiryDate: "2024-01-22",
  sentDate: "2024-01-15",
};

function EstimateDetailPage({ params }: { params: { id: string } }) {
  const router = useRouter();
  const [estimate, setEstimate] = useState<Estimate>(estimateData);
  const [sendModal, setSendModal] = useState(false);
  const [approveModal, setApproveModal] = useState(false);

  const renderStatusBadge = (status: string) => {
    const statusConfig = {
      draft: { class: "bg-secondary", label: "Draft", icon: "fa-edit" },
      sent: { class: "bg-primary", label: "Sent", icon: "fa-paper-plane" },
      approved: { class: "bg-success", label: "Approved", icon: "fa-check" },
      rejected: { class: "bg-danger", label: "Rejected", icon: "fa-times" },
      expired: { class: "bg-warning", label: "Expired", icon: "fa-clock" },
    };

    const config = statusConfig[status as keyof typeof statusConfig] || {
      class: "bg-secondary",
      label: status,
      icon: "fa-question",
    };

    return (
      <Badge className={config.class}>
        <i className={`fa ${config.icon} me-1`}></i>
        {config.label}
      </Badge>
    );
  };

  const handleSendEstimate = (method: "email" | "whatsapp" | "print") => {
    console.log(`Sending estimate via ${method}`);
    setEstimate({
      ...estimate,
      status: "sent",
      sentDate: new Date().toISOString().split("T")[0],
    });
    setSendModal(false);
    alert(`Estimate sent to customer via ${method}`);
  };

  const handleApproveEstimate = () => {
    setEstimate({
      ...estimate,
      status: "approved",
      approvedDate: new Date().toISOString().split("T")[0],
    });
    setApproveModal(false);

    // In real app, this would update the linked job card
    alert("Estimate approved! Job card has been updated.");
  };

  const handleRejectEstimate = () => {
    if (confirm("Mark this estimate as rejected?")) {
      setEstimate({ ...estimate, status: "rejected" });
    }
  };

  return (
    <div className="page-body">
      <Breadcrumbs
        title="Estimate Details"
        mainTitle={`Estimate #${estimate.estimateNumber}`}
        parent="Estimates"
      />

      <Container fluid>
        <Row>
          <Col sm="12">
            {/* Header Actions */}
           
<Card className="mb-4">
  <CardBody>
    <div className="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3">
      {/* ===== Left side ===== */}
      {/* <div>
        <h4 className="mb-1 text-muted no-wrap">
          Estimate #{estimate.estimateNumber}
        </h4>
        <div className="d-flex flex-wrap align-items-center gap-2">
          {renderStatusBadge(estimate.status)}
          <span className="text-muted small">
            Created: {new Date(estimate.createdDate).toLocaleDateString()}
          </span>
          <span className="text-muted small">
            Expires: {new Date(estimate.expiryDate).toLocaleDateString()}
          </span>
        </div>
      </div> */}
<div>
  <h4 className="mb-1 text-muted text-nowrap">
    Estimate #{estimate.estimateNumber}
  </h4>
  <div
    className="d-flex align-items-center gap-3 flex-nowrap overflow-auto"
    style={{ whiteSpace: "nowrap" }}
  >
    {renderStatusBadge(estimate.status)}
    <span className="text-muted small">
      Created: {new Date(estimate.createdDate).toLocaleDateString()}
    </span>
    <span className="text-muted small">
      Expires: {new Date(estimate.expiryDate).toLocaleDateString()}
    </span>
  </div>
</div>

      {/* ===== Right side (buttons) ===== */}
      <div className="d-flex flex-wrap justify-content-md-end gap-2 w-100 w-md-auto">
        {estimate.status === "draft" && (
          <Button color="success" className="flex-fill flex-md-grow-0" onClick={() => setSendModal(true)}>
            <i className="fa fa-paper-plane me-2"></i>
            Send to Customer
          </Button>
        )}

        {estimate.status === "sent" && (
          <>
            <Button color="success" className="flex-fill flex-md-grow-0" onClick={() => setApproveModal(true)}>
              <i className="fa fa-check me-2"></i>
              Mark Approved
            </Button>
            <Button color="danger" outline className="flex-fill flex-md-grow-0" onClick={handleRejectEstimate}>
              <i className="fa fa-times me-2"></i>
              Mark Rejected
            </Button>
          </>
        )}

        <Button color="primary" outline className="flex-fill flex-md-grow-0">
          <i className="fa fa-print me-2"></i>
          Print
        </Button>

        <Button color="warning" outline className="flex-fill flex-md-grow-0">
          <i className="fa fa-edit me-2"></i>
          Edit
        </Button>
      </div>
    </div>
  </CardBody>
</Card>

            <Row>
              {/* Customer & Vehicle Info */}
              <Col lg="4">
                <Card className="mb-4">
                  <CardBody>
                    <h5 className="card-title mb-4 text-muted">Customer & Vehicle</h5>
                    <div className="mb-3 text-muted">
                      <strong>Customer</strong>
                      <div>{estimate.customerName}</div>
                      <div className="text-muted small">
                        {estimate.customerEmail}
                      </div>
                      <div className="text-muted small">
                        {estimate.customerPhone}
                      </div>
                    </div>

                    <div className="mb-3 text-muted">
                      <strong>Vehicle</strong>
                      <div>{estimate.vehicle}</div>
                    </div>

                    <div className="mb-3 text-muted">
                      <strong>Job Card</strong>
                      <div>
                        <Link
                          href={`/admin/jobcards/${estimate.jobCardNumber}`}
                          className="text-info"
                        >
                          {estimate.jobCardNumber}
                        </Link>
                      </div>
                    </div>

                    <div className="text-muted">
                      <strong>Reported Issue</strong>
                      <div className="text-muted">{estimate.reportedIssue}</div>
                    </div>
                  </CardBody>
                </Card>

                {/* Estimate Details */}
                <Card>
                  <CardBody>
                    <h5 className="card-title mb-4 text-muted">Estimate Details</h5>
                    <div className="mb-2 ">
                      <small className="text-muted">Estimate Number</small>
                      <div className="fw-bold text-muted">{estimate.estimateNumber}</div>
                    </div>
                    <div className="mb-2 text-muted">
                      <small className="text-muted">Created Date</small>
                      <div>
                        {new Date(estimate.createdDate).toLocaleDateString()}
                      </div>
                    </div>
                    <div className="mb-2 text-muted">
                      <small className="text-muted">Expiry Date</small>
                      <div
                        className={
                          new Date(estimate.expiryDate) < new Date()
                            ? "text-danger fw-bold"
                            : ""
                        }
                      >
                        {new Date(estimate.expiryDate).toLocaleDateString()}
                      </div>
                    </div>
                    {estimate.sentDate && (
                      <div className="mb-2 text-muted">
                        <small className="text-muted">Sent Date</small>
                        <div>
                          {new Date(estimate.sentDate).toLocaleDateString()}
                        </div>
                      </div>
                    )}
                    {estimate.approvedDate && (
                      <div className="mb-2">
                        <small className="text-muted">Approved Date</small>
                        <div>
                          {new Date(estimate.approvedDate).toLocaleDateString()}
                        </div>
                      </div>
                    )}
                  </CardBody>
                </Card>
              </Col>

              {/* Estimate Items & Summary */}
              <Col lg="8">
                <Card className="mb-4">
                  <CardBody>
                    <h5 className="card-title mb-4 text-muted">Estimate Items</h5>
                    <div className="table-responsive">
                      <Table hover>
                        <thead>
                          <tr>
                            <th style={{ width: "auto" }}>Description</th>
                            <th style={{ width: "80" }}>Qty</th>
                            <th style={{ width: "120" }}>Unit Price</th>
                            <th style={{ width: "120" }}>Total</th>
                          </tr>
                        </thead>
                        <tbody>
                          {estimate.items.map((item) => (
                            <tr key={item.id}>
                              <td>
                                <div>
                                  <Badge
                                    color={
                                      item.type === "part" ? "info" : "warning"
                                    }
                                    className="me-2"
                                  >
                                    {item.type === "part" ? "Part" : "Labor"}
                                  </Badge>
                                  {item.description}
                                </div>
                              </td>
                              <td>{item.quantity}</td>
                              <td>${item.unitPrice.toFixed(2)}</td>
                              <td>
                                <strong>${item.total.toFixed(2)}</strong>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </Table>
                    </div>

                    {/* Summary */}
                    <div className="row mt-4">
                      <div className="col-md-6">
                        {estimate.notes && (
                          <div className="bg-light p-3 rounded text-muted">
                            <strong>Notes:</strong>
                            <div className="mt-1">{estimate.notes}</div>
                          </div>
                        )}
                      </div>
                      <div className="col-md-6">
                        <div className="border rounded p-3">
                          <div className="d-flex justify-content-between mb-2 text-muted">
                            <span>Subtotal:</span>
                            <span>${estimate.subtotal.toFixed(2)}</span>
                          </div>
                          <div className="d-flex justify-content-between mb-2 text-muted">
                            <span>Tax (8%):</span>
                            <span>${estimate.taxAmount.toFixed(2)}</span>
                          </div>
                          <hr />
                          <div className="d-flex justify-content-between mb-2 fs-5 text-muted">
                            <strong>Total Amount:</strong>
                            <strong className="text-success">
                              ${estimate.totalAmount.toFixed(2)}
                            </strong>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardBody>
                </Card>

                {/* Action History */}
                <Card>
                  <CardBody>
                    <h5 className="card-title mb-4 text-muted">Action History</h5>
                    <div className="timeline">
                      <div className="timeline-item">
                        <div className="timeline-badge bg-primary">
                          <i className="fa fa-file-alt"></i>
                        </div>
                        <div className="timeline-content bg-light text-muted">
                          <strong>Estimate Created</strong>
                          <div className="text-muted small">
                            {new Date(estimate.createdDate).toLocaleString()}
                          </div>
                        </div>
                      </div>

                      {estimate.sentDate && (
                        <div className="timeline-item">
                          <div className="timeline-badge bg-success">
                            <i className="fa fa-paper-plane"></i>
                          </div>
                          <div className="timeline-content bg-light text-muted">
                            <strong>Sent to Customer</strong>
                            <div className="text-muted small">
                              {new Date(estimate.sentDate).toLocaleString()}
                            </div>
                          </div>
                        </div>
                      )}

                      {estimate.approvedDate && (
                        <div className="timeline-item">
                          <div className="timeline-badge bg-success">
                            <i className="fa fa-check"></i>
                          </div>
                          <div className="timeline-content">
                            <strong>Approved by Customer</strong>
                            <div className="text-muted small">
                              {new Date(estimate.approvedDate).toLocaleString()}
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </CardBody>
                </Card>
              </Col>
            </Row>
          </Col>
        </Row>
      </Container>

      {/* Send Estimate Modal */}
      <Modal isOpen={sendModal} toggle={() => setSendModal(false)}>
        <ModalHeader toggle={() => setSendModal(false)}>
          Send Estimate to Customer
        </ModalHeader>
        <ModalBody>
          <p>Choose how you want to send this estimate to the customer:</p>
          <div className="d-grid gap-2">
            <Button color="primary" onClick={() => handleSendEstimate("email")}>
              <i className="fa fa-envelope me-2"></i>
              Send via Email
            </Button>
            <Button
              color="success"
              onClick={() => handleSendEstimate("whatsapp")}
            >
              <i className="fa fa-whatsapp me-2"></i>
              Send via WhatsApp
            </Button>
            <Button
              color="secondary"
              onClick={() => handleSendEstimate("print")}
            >
              <i className="fa fa-print me-2"></i>
              Print for Customer
            </Button>
          </div>
        </ModalBody>
      </Modal>

      {/* Approve Estimate Modal */}
      <Modal isOpen={approveModal} toggle={() => setApproveModal(false)}>
        <ModalHeader toggle={() => setApproveModal(false)}>
          Approve Estimate
        </ModalHeader>
        <ModalBody>
          <p>Are you sure you want to mark this estimate as approved?</p>
          <div className="alert alert-info">
            <i className="fa fa-info-circle me-2"></i>
            This will update the linked job card status and allow work to begin.
          </div>
        </ModalBody>
        <ModalFooter>
          <Button color="secondary" onClick={() => setApproveModal(false)}>
            Cancel
          </Button>
          <Button color="success" onClick={handleApproveEstimate}>
            <i className="fa fa-check me-2"></i>
            Approve Estimate
          </Button>
        </ModalFooter>
      </Modal>

      <style jsx global>{`
        .timeline {
          position: relative;
          padding-left: 30px;
        }

        .timeline-item {
          position: relative;
          margin-bottom: 20px;
        }

        .timeline-badge {
          position: absolute;
          left: -40px;
          top: 0;
          width: 30px;
          height: 30px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          color: white;
        }

        .timeline-content {
          padding: 10px;
          background: #f8f9fa;
          border-radius: 5px;
        }
      `}</style>
    </div>
  );
}

export default EstimateDetailPage;
