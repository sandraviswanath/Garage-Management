// "use client";
// import { useState, ChangeEvent } from "react";
// import {
//   Card,
//   CardBody,
//   Form,
//   FormGroup,
//   Label,
//   Input,
//   Button,
//   Alert,
//   Row,
//   Col,
// } from "reactstrap";
// import { useAuth } from "@/helper/AuthContext";

// interface AddStockFormProps {
//   partId: string;
//   partName?: string;
//   currentStock?: number;
//   onSuccess?: () => void;
// }

// function AddStock({
//   partId,
//   partName,
//   currentStock,
//   onSuccess,
// }: AddStockFormProps) {
//   const { state } = useAuth();
//   const [loading, setLoading] = useState(false);
//   const [error, setError] = useState<string | null>(null);
//   const [success, setSuccess] = useState<string | null>(null);
//   const [quantity, setQuantity] = useState("");

//   const handleInputChange = (e: ChangeEvent<HTMLInputElement>) => {
//     setQuantity(e.target.value);
//     setError(null); // Clear error when user starts typing
//   };

//   const validateForm = (): boolean => {
//     const qty = parseInt(quantity);

//     if (isNaN(qty) || qty <= 0) {
//       setError("Quantity must be a positive number");
//       return false;
//     }

//     if (!partId) {
//       setError("Part ID is required");
//       return false;
//     }

//     return true;
//   };

//   const handleSubmit = async (e: React.FormEvent) => {
//     e.preventDefault();

//     setError(null);
//     setSuccess(null);

//     if (!validateForm()) {
//       return;
//     }

//     setLoading(true);

//     try {
//       const payload = {
//         qty: quantity,
//       };

//       console.log("Adding stock with payload:", payload);

//       const response = await fetch(`/api/inventory/${partId}/add_stock`, {
//         method: "POST",
//         headers: {
//           "Content-Type": "application/json",
//           Authorization: `Bearer ${
//             state?.accessToken || localStorage.getItem("token")
//           }`,
//         },
//         body: JSON.stringify(payload),
//       });

//       const result = await response.json();

//       if (!response.ok) {
//         throw new Error(result.message || "Failed to add stock");
//       }

//       setSuccess(`${quantity} units added to stock successfully!`);
//       setQuantity("");

//       // Call success callback if provided
//       if (onSuccess) {
//         setTimeout(() => {
//           onSuccess();
//         }, 1500);
//       }
//     } catch (err: any) {
//       console.error("Error adding stock:", err);
//       setError(err.message || "Failed to add stock. Please try again.");
//     } finally {
//       setLoading(false);
//     }
//   };

//   return (
//     <Card>
//       <CardBody>
//         <h5 className="mb-3">
//           Add Stock {partName && `- ${partName}`}
//           {currentStock !== undefined && (
//             <span className="text-muted ms-2">(Current: {currentStock})</span>
//           )}
//         </h5>

//         {success && (
//           <Alert color="success" className="mb-3">
//             <i className="fa fa-check-circle me-2"></i>
//             {success}
//           </Alert>
//         )}

//         {error && (
//           <Alert color="danger" className="mb-3">
//             <i className="fa fa-exclamation-circle me-2"></i>
//             {error}
//           </Alert>
//         )}

//         <Form onSubmit={handleSubmit}>
//           <Row>
//             <Col md="8">
//               <FormGroup>
//                 <Label>Quantity to Add *</Label>
//                 <Input
//                   type="number"
//                   value={quantity}
//                   onChange={handleInputChange}
//                   required
//                   min="1"
//                   placeholder="Enter quantity"
//                   disabled={loading}
//                 />
//                 <small className="text-muted">
//                   Enter the number of units to add to current stock
//                 </small>
//               </FormGroup>
//             </Col>
//             <Col md="4" className="d-flex align-items-end">
//               <Button
//                 color="primary"
//                 type="submit"
//                 disabled={loading}
//                 className="w-100"
//               >
//                 {loading ? (
//                   <>
//                     <span
//                       className="spinner-border spinner-border-sm me-2"
//                       role="status"
//                       aria-hidden="true"
//                     ></span>
//                     Adding...
//                   </>
//                 ) : (
//                   <>
//                     <i className="fa fa-plus me-2"></i>
//                     Add Stock
//                   </>
//                 )}
//               </Button>
//             </Col>
//           </Row>
//         </Form>
//       </CardBody>
//     </Card>
//   );
// }

// export default AddStock;

// components/AddStockModal.jsx
import { useState } from "react";
import {
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Button,
  Input,
  FormGroup,
  Label,
  Alert,
} from "reactstrap";
import { useAuth } from "@/helper/AuthContext";

function AddStockModal({
  isOpen,
  toggle,
  partId,
  partName,
  onSuccess,
}: {
  isOpen: boolean;
  toggle: () => void;
  partId: string;
  partName: string;
  onSuccess: () => void;
}) {
  const { state } = useAuth();
  const [quantity, setQuantity] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const handleSubmit = async () => {
    if (!quantity || parseInt(quantity) <= 0) {
      setError("Please enter a valid quantity");
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const response = await fetch(`/api/inventory/${partId}/add_stock`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${
            state?.accessToken || localStorage.getItem("token")
          }`,
        },
        body: JSON.stringify({ qty: quantity }),
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.message || "Failed to add stock");
      }

      setSuccess("Stock added successfully!");

      // Call success callback
      setTimeout(() => {
        onSuccess();
        setQuantity("");
        setSuccess(null);
        toggle();
      }, 1500);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    setQuantity("");
    setError(null);
    setSuccess(null);
    toggle();
  };

  return (
    <Modal isOpen={isOpen} toggle={handleClose}>
      <ModalHeader toggle={handleClose}>Add Stock - {partName}</ModalHeader>
      <ModalBody>
        {success && (
          <Alert color="success">
            <i className="fa fa-check-circle me-2"></i>
            {success}
          </Alert>
        )}

        {error && (
          <Alert color="danger">
            <i className="fa fa-exclamation-circle me-2"></i>
            {error}
          </Alert>
        )}

        <FormGroup>
          <Label for="quantity">Quantity to Add</Label>
          <Input
            type="number"
            id="quantity"
            value={quantity}
            onChange={(e) => setQuantity(e.target.value)}
            placeholder="Enter quantity"
            min="1"
            disabled={loading || success !== null}
          />
          <small className="text-muted">
            Enter the number of units to add to current stock
          </small>
        </FormGroup>
      </ModalBody>
      <ModalFooter>
        <Button color="secondary" onClick={handleClose} disabled={loading}>
          Cancel
        </Button>
        <Button
          color="primary"
          onClick={handleSubmit}
          disabled={loading || success !== null}
        >
          {loading ? (
            <>
              <span
                className="spinner-border spinner-border-sm me-2"
                role="status"
              ></span>
              Adding...
            </>
          ) : (
            "Add Stock"
          )}
        </Button>
      </ModalFooter>
    </Modal>
  );
}

export default AddStockModal;
