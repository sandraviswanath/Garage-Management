"use client";
import Breadcrumbs from "@/CommonElements/Breadcrumbs";
import CustomPagination from "@/CommonElements/Pagination";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  Input,
  Button,
  Table,
  Badge,
} from "reactstrap";
import React, { useState, ChangeEvent } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";

// Types
interface InventoryTransaction {
  id: number;
  partId: number;
  partNumber: string;
  partName: string;
  type: "stock-in" | "stock-out" | "adjustment";
  quantity: number;
  previousStock: number;
  newStock: number;
  reference: string;
  notes: string;
  createdBy: string;
  createdAt: string;
  cost?: number;
  jobCardNumber?: string;
}

// Mock data
const transactionsData: InventoryTransaction[] = [
  {
    id: 1,
    partId: 1,
    partNumber: "SP-001",
    partName: "Oil Filter",
    type: "stock-in",
    quantity: 50,
    previousStock: 0,
    newStock: 50,
    reference: "PO-2024-001",
    notes: "Initial stock purchase",
    createdBy: "John Doe",
    createdAt: "2024-01-15 09:30:00",
    cost: 625.0,
  },
  {
    id: 2,
    partId: 1,
    partNumber: "SP-001",
    partName: "Oil Filter",
    type: "stock-out",
    quantity: 5,
    previousStock: 50,
    newStock: 45,
    reference: "JC-2024-001",
    notes: "Used for Toyota Camry service",
    createdBy: "Mike Smith",
    createdAt: "2024-01-16 14:20:00",
    jobCardNumber: "JC-2024-001",
  },
  {
    id: 3,
    partId: 2,
    partNumber: "SP-002",
    partName: "Brake Pads",
    type: "stock-in",
    quantity: 30,
    previousStock: 0,
    newStock: 30,
    reference: "PO-2024-002",
    notes: "Brake pads purchase",
    createdBy: "John Doe",
    createdAt: "2024-01-10 11:15:00",
    cost: 1350.0,
  },
  {
    id: 4,
    partId: 2,
    partNumber: "SP-002",
    partName: "Brake Pads",
    type: "stock-out",
    quantity: 15,
    previousStock: 30,
    newStock: 15,
    reference: "JC-2024-002",
    notes: "Honda Civic brake replacement",
    createdBy: "Sarah Johnson",
    createdAt: "2024-01-16 16:45:00",
    jobCardNumber: "JC-2024-002",
  },
  {
    id: 5,
    partId: 3,
    partNumber: "SP-003",
    partName: "Spark Plug",
    type: "stock-out",
    quantity: 8,
    previousStock: 8,
    newStock: 0,
    reference: "JC-2024-003",
    notes: "Ford F-150 tune-up",
    createdBy: "David Wilson",
    createdAt: "2024-01-15 10:30:00",
    jobCardNumber: "JC-2024-003",
  },
  {
    id: 6,
    partId: 4,
    partNumber: "SP-004",
    partName: "Air Filter",
    type: "stock-in",
    quantity: 60,
    previousStock: 0,
    newStock: 60,
    reference: "PO-2024-003",
    notes: "Air filters restock",
    createdBy: "John Doe",
    createdAt: "2024-01-18 08:45:00",
    cost: 915.0,
  },
];

function InventoryTransactionsPage() {
  const router = useRouter();
  const [currentPage, setCurrentPage] = useState(1);
  const [transactions, setTransactions] =
    useState<InventoryTransaction[]>(transactionsData);
  const [searchTerm, setSearchTerm] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [dateFilter, setDateFilter] = useState("all");
  const itemsPerPage = 10;

  // Filter transactions
  const filteredTransactions = transactions.filter((transaction) => {
    const matchesSearch =
      transaction.partNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      transaction.partName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      transaction.reference.toLowerCase().includes(searchTerm.toLowerCase()) ||
      transaction.jobCardNumber
        ?.toLowerCase()
        .includes(searchTerm.toLowerCase());

    const matchesType = typeFilter === "all" || transaction.type === typeFilter;

    return matchesSearch && matchesType;
  });

  // Pagination
  const totalPages = Math.ceil(filteredTransactions.length / itemsPerPage);
  const paginatedTransactions = filteredTransactions.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  // Transaction type badge
  const renderTypeBadge = (type: string) => {
    const typeConfig = {
      "stock-in": {
        class: "bg-success",
        label: "Stock In",
        icon: "fa-arrow-down",
      },
      "stock-out": {
        class: "bg-danger",
        label: "Stock Out",
        icon: "fa-arrow-up",
      },
      adjustment: {
        class: "bg-warning",
        label: "Adjustment",
        icon: "fa-adjust",
      },
    };

    const config = typeConfig[type as keyof typeof typeConfig] || {
      class: "bg-secondary",
      label: type,
      icon: "fa-question",
    };

    return (
      <Badge className={config.class}>
        <i className={`fa ${config.icon} me-1`}></i>
        {config.label}
      </Badge>
    );
  };

  // Calculate summary
  const calculateSummary = () => {
    const stockIn = transactions
      .filter((t) => t.type === "stock-in")
      .reduce((sum, t) => sum + (t.cost || 0), 0);

    const stockOut = transactions.filter((t) => t.type === "stock-out").length;

    return {
      totalTransactions: transactions.length,
      totalStockInValue: stockIn,
      totalStockOutItems: stockOut,
    };
  };

  const summary = calculateSummary();

  return (
    <div className="page-body">
      <Breadcrumbs
        title="Inventory Transactions"
        mainTitle="Movement History"
        parent="Inventory"
      />

      <Container fluid>
        {/* Summary Cards */}
        <Row className="mb-4">
          <Col xl="4" md="6">
            <Card className="card-stats">
              <CardBody>
                <div className="d-flex align-items-center">
                  <div className="flex-grow-1">
                    <h4 className="mb-0 text-muted">{summary.totalTransactions}</h4>
                    <span className="text-muted">Total Transactions</span>
                  </div>
                  <div className="flex-shrink-0">
                    <div className="bg-primary rounded-circle p-3">
                      {/* <i className="fa fa-exchange-alt text-white fs-4"></i> */}
                   <i className="fa fa-exchange text-white fs-4"></i>
                    </div>
                  </div>
                </div>
              </CardBody>
            </Card>
          </Col>

          <Col xl="4" md="6">
            <Card className="card-stats">
              <CardBody>
                <div className="d-flex align-items-center">
                  <div className="flex-grow-1">
                    <h4 className="mb-0 text-muted">
                      ${summary.totalStockInValue.toFixed(2)}
                    </h4>
                    <span className="text-muted">Total Stock In Value</span>
                  </div>
                  <div className="flex-shrink-0">
                    <div className="bg-success rounded-circle p-3">
                      <i className="fa fa-arrow-down text-white fs-4"></i>
                    </div>
                  </div>
                </div>
              </CardBody>
            </Card>
          </Col>

          <Col xl="4" md="6">
            <Card className="card-stats">
              <CardBody>
                <div className="d-flex align-items-center">
                  <div className="flex-grow-1">
                    <h4 className="mb-0 text-muted">{summary.totalStockOutItems}</h4>
                    <span className="text-muted">Stock Out Items</span>
                  </div>
                  <div className="flex-shrink-0">
                    <div className="bg-danger rounded-circle p-3">
                      <i className="fa fa-arrow-up text-white fs-4"></i>
                    </div>
                  </div>
                </div>
              </CardBody>
            </Card>
          </Col>
        </Row>

        <Row>
          <Col sm="12">
            <Card>
              <CardBody>
                {/* Header with Filters */}
                <div className="row align-items-center mb-4 g-3">
                  <div className="col-12 col-md-3">
                    <Input
                      type="search"
                      placeholder="Search transactions..."
                      value={searchTerm}
                      onChange={(e: ChangeEvent<HTMLInputElement>) =>
                        setSearchTerm(e.target.value)
                      }
                    />
                  </div>

                  <div className="col-12 col-md-3">
                    <select
                      className="form-select border p-2"
                      value={typeFilter}
                              style={{fontSize:'0.9rem'}}
                      onChange={(e: ChangeEvent<HTMLSelectElement>) =>
                        setTypeFilter(e.target.value)
                      }
                    >
                      <option value="all">All Types</option>
                      <option value="stock-in">Stock In</option>
                      <option value="stock-out">Stock Out</option>
                      <option value="adjustment">Adjustment</option>
                    </select>
                  </div>

                  <div className="col-12 col-md-3">
                    <Input
                      type="date"
                      value={dateFilter === "all" ? "" : dateFilter}
                      onChange={(e: ChangeEvent<HTMLInputElement>) =>
                        setDateFilter(e.target.value || "all")
                      }
                    />
                  </div>

                  <div className="d-none d-md-block col-md-1"></div>

                  <div className="col-12 col-md-2 d-flex justify-content-md-end">
                    <Button color="primary">
                      <i className="fa fa-download me-2"></i>
                      Export
                    </Button>
                  </div>
                </div>

                {/* Transactions Table */}
                <div className="table-responsive">
                  <Table hover>
                    <thead>
                      <tr>
                        <th>Date & Time</th>
                        <th>Part</th>
                        <th>Type</th>
                        <th>Quantity</th>
                        <th>Stock Change</th>
                        <th>Reference</th>
                        <th>Job Card</th>
                        <th>Cost</th>
                        <th>User</th>
                        <th>Notes</th>
                      </tr>
                    </thead>
                    <tbody>
                      {paginatedTransactions.length === 0 ? (
                        <tr>
                          <td colSpan={10} className="text-center py-4">
                            No transactions found
                          </td>
                        </tr>
                      ) : (
                        paginatedTransactions.map((transaction) => (
                          <tr key={transaction.id}>
                            <td>
                              <div>
                                <div>
                                  {new Date(
                                    transaction.createdAt
                                  ).toLocaleDateString()}
                                </div>
                                <small className="text-muted">
                                  {new Date(
                                    transaction.createdAt
                                  ).toLocaleTimeString()}
                                </small>
                              </div>
                            </td>
                            <td>
                              <div className="no-wrap">
                                <div className="fw-bold">
                                  {transaction.partNumber}
                                </div>
                                <small className="text-muted">
                                  {transaction.partName}
                                </small>
                              </div>
                            </td>
                            <td>{renderTypeBadge(transaction.type)}</td>
                            <td>
                              <span
                                className={
                                  transaction.type === "stock-in"
                                    ? "text-success"
                                    : "text-danger"
                                }
                              >
                                {transaction.type === "stock-in" ? "+" : "-"}
                                {transaction.quantity}
                              </span>
                            </td>
                            <td>
                              <small className="text-muted">
                                {transaction.previousStock} →{" "}
                                {transaction.newStock}
                              </small>
                            </td>
                            <td>
                              <Badge color="light" className="text-muted">
                                {transaction.reference}
                              </Badge>
                            </td>
                            <td>
                              {transaction.jobCardNumber ? (
                                <Link
                                  href={`/admin/jobcards/${transaction.jobCardNumber}`}
                                >
                                  <Badge
                                    color="info"
                                    className="cursor-pointer"
                                  >
                                    {transaction.jobCardNumber}
                                  </Badge>
                                </Link>
                              ) : (
                                <span className="text-muted">-</span>
                              )}
                            </td>
                            <td>
                              {transaction.cost ? (
                                <span className="fw-bold">
                                  ${transaction.cost.toFixed(2)}
                                </span>
                              ) : (
                                <span className="text-muted">-</span>
                              )}
                            </td>
                            <td className="no-wrap">{transaction.createdBy}</td>
                            <td>
                              <div
                                className="text-truncate"
                                style={{ maxWidth: "200px" }}
                                title={transaction.notes}
                              >
                                {transaction.notes}
                              </div>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </Table>
                </div>

                {/* Pagination */}
                <div className="d-flex flex-column flex-md-row justify-content-between align-items-center gap-3 mt-4">
                  <div className="text-center text-md-start text-muted">
                    Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
                    {Math.min(
                      currentPage * itemsPerPage,
                      filteredTransactions.length
                    )}{" "}
                    of {filteredTransactions.length} entries
                  </div>
                  <CustomPagination
                    currentPage={currentPage}
                    totalPages={totalPages}
                    onPageChange={setCurrentPage}
                    showFirstLast={true}
                    maxVisiblePages={5}
                    paginationType="primary"
                    className="justify-content-center justify-content-md-end"
                  />
                </div>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Container>
    </div>
  );
}

export default InventoryTransactionsPage;
