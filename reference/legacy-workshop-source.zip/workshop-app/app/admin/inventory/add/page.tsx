// "use client";
// import Breadcrumbs from "@/CommonElements/Breadcrumbs";
// import {
//   Container,
//   Row,
//   Col,
//   Card,
//   CardBody,
//   Form,
//   FormGroup,
//   Label,
//   Input,
//   Button,
// } from "reactstrap";
// import React, { useState, ChangeEvent } from "react";
// import Link from "next/link";
// import { useRouter } from "next/navigation";

// // Mock suppliers data
// const suppliers = [
//   { id: 1, name: "AutoParts Direct" },
//   { id: 2, name: "Brake Masters" },
//   { id: 3, name: "Ignition Pro" },
//   { id: 4, name: "PowerCell Inc" },
//   { id: 5, name: "Filter Experts" },
// ];

// const categories = [
//   "Filters",
//   "Brakes",
//   "Ignition",
//   "Electrical",
//   "Engine",
//   "Transmission",
//   "Suspension",
//   "Exhaust",
//   "Cooling",
//   "Accessories",
// ];

// function AddPartPage() {
//   const router = useRouter();
//   const [formData, setFormData] = useState({
//     partNumber: "",
//     name: "",
//     description: "",
//     category: "",
//     quantity: "",
//     minStockLevel: "",
//     maxStockLevel: "",
//     unitCost: "",
//     sellingPrice: "",
//     supplierId: "",
//     location: "",
//   });

//   const handleInputChange = (
//     e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
//   ) => {
//     const { name, value } = e.target;
//     setFormData((prev) => ({
//       ...prev,
//       [name]: value,
//     }));
//   };

//   const handleSubmit = (e: React.FormEvent) => {
//     e.preventDefault();
//     // Handle form submission logic here
//     console.log("Part added:", formData);
//     // Redirect back to inventory page
//     router.push("/admin/inventory");
//   };

//   return (
//     <div className="page-body">
//       <Breadcrumbs
//         title="Add Spare Part"
//         mainTitle="Add New Part"
//         parent="Inventory"
//       />

//       <Container fluid>
//         <Row>
//           <Col sm="12">
//             <Card>
//               <CardBody>
//                 <Form onSubmit={handleSubmit}>
//                   <Row className="text-muted">
//                     <Col md="6">
//                       <FormGroup>
//                         <Label>Part Number *</Label>
//                         <Input
//                           type="text"
//                           name="partNumber"
//                           value={formData.partNumber}
//                           onChange={handleInputChange}
//                           required
//                           placeholder="Enter part number"
//                         />
//                       </FormGroup>
//                     </Col>

//                     <Col md="6">
//                       <FormGroup>
//                         <Label>Part Name *</Label>
//                         <Input
//                           type="text"
//                           name="name"
//                           value={formData.name}
//                           onChange={handleInputChange}
//                           required
//                           placeholder="Enter part name"
//                         />
//                       </FormGroup>
//                     </Col>

//                     <Col md="12">
//                       <FormGroup>
//                         <Label>Description</Label>
//                         <Input
//                           type="textarea"
//                           name="description"
//                           value={formData.description}
//                           onChange={handleInputChange}
//                           rows={3}
//                           placeholder="Enter part description"
//                         />
//                       </FormGroup>
//                     </Col>

//                     <Col md="6">
//                       <FormGroup>
//                         <Label>Category *</Label>
//                         <Input
//                           type="select"
//                           name="category"
//                           value={formData.category}
//                           onChange={handleInputChange}
//                             style={{fontSize:'0.9rem'}}
//                           className="border p-2"
//                           required
//                         >
//                           <option value="">Select Category</option>
//                           {categories.map((category) => (
//                             <option key={category} value={category}>
//                               {category}
//                             </option>
//                           ))}
//                         </Input>
//                       </FormGroup>
//                     </Col>

//                     <Col md="6">
//                       <FormGroup>
//                         <Label>Supplier *</Label>
//                         <Input
//                           type="select"
//                           name="supplierId"
//                           value={formData.supplierId}
//                           onChange={handleInputChange}
//                                   style={{fontSize:'0.9rem'}}
//                           className="border p-2"
//                           required
//                         >
//                           <option value="">Select Supplier</option>
//                           {suppliers.map((supplier) => (
//                             <option key={supplier.id} value={supplier.id}>
//                               {supplier.name}
//                             </option>
//                           ))}
//                         </Input>
//                       </FormGroup>
//                     </Col>

//                     <Col md="4">
//                       <FormGroup>
//                         <Label>Quantity *</Label>
//                         <Input
//                           type="number"
//                           name="quantity"
//                           value={formData.quantity}
//                           onChange={handleInputChange}
//                           required
//                           min="0"
//                           placeholder="0"
//                         />
//                       </FormGroup>
//                     </Col>

//                     <Col md="4">
//                       <FormGroup>
//                         <Label>Min Stock Level *</Label>
//                         <Input
//                           type="number"
//                           name="minStockLevel"
//                           value={formData.minStockLevel}
//                           onChange={handleInputChange}
//                           required
//                           min="0"
//                           placeholder="0"
//                         />
//                       </FormGroup>
//                     </Col>

//                     <Col md="4">
//                       <FormGroup>
//                         <Label>Max Stock Level *</Label>
//                         <Input
//                           type="number"
//                           name="maxStockLevel"
//                           value={formData.maxStockLevel}
//                           onChange={handleInputChange}
//                           required
//                           min="0"
//                           placeholder="0"
//                         />
//                       </FormGroup>
//                     </Col>

//                     <Col md="6">
//                       <FormGroup>
//                         <Label>Unit Cost ($) *</Label>
//                         <Input
//                           type="number"
//                           name="unitCost"
//                           value={formData.unitCost}
//                           onChange={handleInputChange}
//                           required
//                           min="0"
//                           step="0.01"
//                           placeholder="0.00"
//                         />
//                       </FormGroup>
//                     </Col>

//                     <Col md="6">
//                       <FormGroup>
//                         <Label>Selling Price ($) *</Label>
//                         <Input
//                           type="number"
//                           name="sellingPrice"
//                           value={formData.sellingPrice}
//                           onChange={handleInputChange}
//                           required
//                           min="0"
//                           step="0.01"
//                           placeholder="0.00"
//                         />
//                       </FormGroup>
//                     </Col>

//                     <Col md="6">
//                       <FormGroup>
//                         <Label>Location *</Label>
//                         <Input
//                           type="text"
//                           name="location"
//                           value={formData.location}
//                           onChange={handleInputChange}
//                           required
//                           placeholder="e.g., A1-02"
//                         />
//                       </FormGroup>
//                     </Col>
//                   </Row>

//                   <div className="d-flex gap-2 mt-3">
//                     <Button color="primary" type="submit">
//                       <i className="fa fa-save me-2"></i>
//                       Add Part
//                     </Button>
//                     <Link href="/admin/inventory">
//                       <Button color="secondary" type="button">
//                         Cancel
//                       </Button>
//                     </Link>
//                   </div>
//                 </Form>
//               </CardBody>
//             </Card>
//           </Col>
//         </Row>
//       </Container>
//     </div>
//   );
// }

// export default AddPartPage;

"use client";
import Breadcrumbs from "@/CommonElements/Breadcrumbs";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  Form,
  FormGroup,
  Label,
  Input,
  Button,
  Alert,
} from "reactstrap";
import React, { useState, ChangeEvent, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useAuth } from "@/helper/AuthContext";

interface Supplier {
  id: string;
  name: string;
  email?: string;
  phone?: string;
}

const categories = [
  "Filters",
  "Brakes",
  "Ignition",
  "Electrical",
  "Engine",
  "Transmission",
  "Suspension",
  "Exhaust",
  "Cooling",
  "Accessories",
];

interface FormData {
  sku: string;
  name: string;
  description: string;
  category: string;
  quantity: string;
  min_stock_level: string;
  max_stock_level: string;
  unit_cost: string;
  retail_price: string;
  // supplier_id: string;
  // location: string;
  // meta?: {
  //   supplierName?: string;
  //   lastRestocked?: string;
  // };
}

function AddPartPage() {
  const { state } = useAuth();
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);

  const [formData, setFormData] = useState<FormData>({
    sku: "",
    name: "",
    description: "",
    category: "",
    quantity: "0",
    min_stock_level: "0",
    max_stock_level: "0",
    unit_cost: "0.00",
    retail_price: "0.00",
    // supplier_id: "",
    // location: "",
  });

  // Fetch suppliers on component mount
  // useEffect(() => {
  //   fetchSuppliers();
  // }, []);

  // const fetchSuppliers = async () => {
  //   try {
  //     // Replace with your actual suppliers API endpoint
  //     const response = await fetch("/api/suppliers", {
  //       headers: {
  //         Accept: "application/json",
  //         "Content-Type": "application/json",
  //       },
  //     });

  //     if (response.ok) {
  //       const data = await response.json();
  //       setSuppliers(data.data || []);
  //     } else {
  //       console.warn("Failed to fetch suppliers, using empty list");
  //     }
  //   } catch (err) {
  //     console.error("Error fetching suppliers:", err);
  //   }
  // };

  const handleInputChange = (
    e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const validateForm = (): boolean => {
    // Required field validation
    if (!formData.sku.trim()) {
      setError("SKU is required");
      return false;
    }

    if (!formData.name.trim()) {
      setError("Part name is required");
      return false;
    }

    // if (!formData.category) {
    //   setError("Category is required");
    //   return false;
    // }

    // Numeric validation
    const quantity = parseInt(formData.quantity);
    const minStock = parseInt(formData.min_stock_level);
    const maxStock = parseInt(formData.max_stock_level);
    const unitCost = parseFloat(formData.unit_cost);
    const retailPrice = parseFloat(formData.retail_price);

    if (isNaN(quantity) || quantity < 0) {
      setError("Quantity must be a positive number");
      return false;
    }

    if (isNaN(minStock) || minStock < 0) {
      setError("Min stock level must be a positive number");
      return false;
    }

    if (isNaN(maxStock) || maxStock < 0) {
      setError("Max stock level must be a positive number");
      return false;
    }

    if (minStock > maxStock) {
      setError("Min stock level cannot be greater than max stock level");
      return false;
    }

    if (isNaN(unitCost) || unitCost < 0) {
      setError("Unit cost must be a positive number");
      return false;
    }

    if (isNaN(retailPrice) || retailPrice < 0) {
      setError("Retail price must be a positive number");
      return false;
    }

    // if (!formData.location.trim()) {
    //   setError("Location is required");
    //   return false;
    // }

    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Clear previous messages
    setError(null);
    setSuccess(null);

    // Validate form
    if (!validateForm()) {
      return;
    }

    setLoading(true);

    try {
      // Prepare data for API
      const payload = {
        sku: formData.sku,
        name: formData.name,
        description: formData.description,
        quantity: formData.quantity,
        min_stock_level: formData.min_stock_level,
        max_stock_level: formData.max_stock_level,
        unit_cost: formData.unit_cost,
        retail_price: formData.retail_price,
        // supplier_id: formData.supplier_id || null,
        meta: JSON.stringify({
          category: formData.category,
          // location: formData.location,
          // supplierName:
          //   suppliers.find((s) => s.id === formData.supplier_id)?.name || "",
          // lastRestocked: new Date().toISOString().split("T")[0],
        }),
      };

      console.log("Submitting payload:", payload);

      const response = await fetch("/api/inventory", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",

          Authorization: `Bearer ${
            state?.accessToken || localStorage.getItem("token")
          }`,
        },
        body: JSON.stringify(payload),
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.message || "Failed to add part");
      }

      setSuccess("Part added successfully!");

      // Reset form
      setFormData({
        sku: "",
        name: "",
        description: "",
        category: "",
        quantity: "0",
        min_stock_level: "0",
        max_stock_level: "0",
        unit_cost: "0.00",
        retail_price: "0.00",
        // supplier_id: "",
        // location: "",
      });

      // Redirect after 2 seconds
      setTimeout(() => {
        router.push("/admin/inventory");
      }, 2000);
    } catch (err: any) {
      console.error("Error adding part:", err);
      setError(err.message || "Failed to add part. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page-body">
      <Breadcrumbs
        title="Add Spare Part"
        mainTitle="Add New Part"
        parent="Inventory"
      />

      <Container fluid>
        <Row>
          <Col sm="12">
            <Card>
              <CardBody>
                {/* Success and Error Messages */}
                {success && (
                  <Alert color="success" className="mb-4">
                    <i className="fa fa-check-circle me-2"></i>
                    {success}
                  </Alert>
                )}

                {error && (
                  <Alert color="danger" className="mb-4">
                    <i className="fa fa-exclamation-circle me-2"></i>
                    {error}
                  </Alert>
                )}

                <Form onSubmit={handleSubmit}>
                  <Row className="text-muted">
                    <Col md="6">
                      <FormGroup>
                        <Label>SKU *</Label>
                        <Input
                          type="text"
                          name="sku"
                          value={formData.sku}
                          onChange={handleInputChange}
                          required
                          placeholder="Enter SKU"
                          disabled={loading}
                        />
                        <small className="text-muted">
                          Unique stock keeping unit
                        </small>
                      </FormGroup>
                    </Col>

                    <Col md="6">
                      <FormGroup>
                        <Label>Part Name *</Label>
                        <Input
                          type="text"
                          name="name"
                          value={formData.name}
                          onChange={handleInputChange}
                          required
                          placeholder="Enter part name"
                          disabled={loading}
                        />
                      </FormGroup>
                    </Col>

                    <Col md="12">
                      <FormGroup>
                        <Label>Description</Label>
                        <Input
                          type="textarea"
                          name="description"
                          value={formData.description}
                          onChange={handleInputChange}
                          rows={3}
                          placeholder="Enter part description"
                          disabled={loading}
                        />
                      </FormGroup>
                    </Col>

                    {/* <Col md="6">
                      <FormGroup>
                        <Label>Category *</Label>
                        <Input
                          type="select"
                          name="category"
                          value={formData.category}
                          onChange={handleInputChange}
                          style={{ fontSize: "0.9rem" }}
                          className="border p-2"
                          required
                          disabled={loading}
                        >
                          <option value="">Select Category</option>
                          {categories.map((category) => (
                            <option key={category} value={category}>
                              {category}
                            </option>
                          ))}
                        </Input>
                      </FormGroup>
                    </Col> */}

                    {/* <Col md="6">
                      <FormGroup>
                        <Label>Supplier</Label>
                        <Input
                          type="select"
                          name="supplier_id"
                          value={formData.supplier_id}
                          onChange={handleInputChange}
                          style={{ fontSize: "0.9rem" }}
                          className="border p-2"
                          disabled={loading}
                        >
                          <option value="">Select Supplier (Optional)</option>
                          {suppliers.map((supplier) => (
                            <option key={supplier.id} value={supplier.id}>
                              {supplier.name}
                            </option>
                          ))}
                        </Input>
                      </FormGroup>
                    </Col> */}

                    <Col md="4">
                      <FormGroup>
                        <Label>Quantity *</Label>
                        <Input
                          type="number"
                          name="quantity"
                          value={formData.quantity}
                          onChange={handleInputChange}
                          required
                          min="0"
                          placeholder="0"
                          disabled={loading}
                        />
                      </FormGroup>
                    </Col>

                    <Col md="4">
                      <FormGroup>
                        <Label>Min Stock Level *</Label>
                        <Input
                          type="number"
                          name="min_stock_level"
                          value={formData.min_stock_level}
                          onChange={handleInputChange}
                          required
                          min="0"
                          placeholder="0"
                          disabled={loading}
                        />
                      </FormGroup>
                    </Col>

                    <Col md="4">
                      <FormGroup>
                        <Label>Max Stock Level *</Label>
                        <Input
                          type="number"
                          name="max_stock_level"
                          value={formData.max_stock_level}
                          onChange={handleInputChange}
                          required
                          min="0"
                          placeholder="0"
                          disabled={loading}
                        />
                      </FormGroup>
                    </Col>

                    <Col md="6">
                      <FormGroup>
                        <Label>Unit Cost ($) *</Label>
                        <Input
                          type="number"
                          name="unit_cost"
                          value={formData.unit_cost}
                          onChange={handleInputChange}
                          required
                          min="0"
                          step="0.01"
                          placeholder="0.00"
                          disabled={loading}
                        />
                      </FormGroup>
                    </Col>

                    <Col md="6">
                      <FormGroup>
                        <Label>Retail Price ($) *</Label>
                        <Input
                          type="number"
                          name="retail_price"
                          value={formData.retail_price}
                          onChange={handleInputChange}
                          required
                          min="0"
                          step="0.01"
                          placeholder="0.00"
                          disabled={loading}
                        />
                      </FormGroup>
                    </Col>

                    {/* <Col md="6">
                      <FormGroup>
                        <Label>Location *</Label>
                        <Input
                          type="text"
                          name="location"
                          value={formData.location}
                          onChange={handleInputChange}
                          required
                          placeholder="e.g., A1-02"
                          disabled={loading}
                        />
                      </FormGroup>
                    </Col> */}
                  </Row>

                  <div className="d-flex gap-2 mt-3">
                    <Button color="primary" type="submit" disabled={loading}>
                      {loading ? (
                        <>
                          <span
                            className="spinner-border spinner-border-sm me-2"
                            role="status"
                            aria-hidden="true"
                          ></span>
                          Adding...
                        </>
                      ) : (
                        <>
                          <i className="fa fa-save me-2"></i>
                          Add Part
                        </>
                      )}
                    </Button>
                    <Link href="/admin/inventory">
                      <Button
                        color="secondary"
                        type="button"
                        disabled={loading}
                      >
                        Cancel
                      </Button>
                    </Link>
                  </div>
                </Form>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Container>
    </div>
  );
}

export default AddPartPage;
