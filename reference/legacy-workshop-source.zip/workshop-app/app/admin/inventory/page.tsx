"use client";
import Breadcrumbs from "@/CommonElements/Breadcrumbs";
import CustomPagination from "@/CommonElements/Pagination";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  Input,
  Button,
  Table,
  Badge,
  Alert,
} from "reactstrap";
import React, { useState, ChangeEvent, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useAuth } from "@/helper/AuthContext";
import AddStockModal from "./AddStock";
import withAuth from "@/helper/WithAuth";

// Types matching your API response
interface SparePart {
  id: string;
  sku: string;
  name: string;
  description: string;
  supplier_id: string | null;
  unit_cost: string;
  retail_price: string;
  stock_level: string;
  reorder_point: string;
  quantity: string;
  min_stock_level: string;
  max_stock_level: string;
  meta: any;
  created_at: string;
  updated_at: string;
}

// Extended interface for UI display
interface DisplaySparePart
  extends Omit<
    SparePart,
    | "unit_cost"
    | "retail_price"
    | "stock_level"
    | "quantity"
    | "min_stock_level"
    | "max_stock_level"
  > {
  unit_cost: number;
  retail_price: number;
  stock_level: number;
  quantity: number;
  min_stock_level: number;
  max_stock_level: number;
  category?: string;
  // supplierName?: string;
  // location?: string;
  // lastRestocked?: string;
}

interface InventoryMetrics {
  totalParts: number;
  lowStockItems: number;
  outOfStockItems: number;
  totalInventoryValue: number;
}

function InventoryPage() {
  const { state } = useAuth();
  const router = useRouter();
  const [currentPage, setCurrentPage] = useState(1);
  const [parts, setParts] = useState<DisplaySparePart[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");

  const [modalOpen, setModalOpen] = useState(false);
  const [selectedPart, setSelectedPart] = useState<{
    id: string;
    name: string;
  } | null>(null);
  const itemsPerPage = 10;

  // Fetch parts from API
  useEffect(() => {
    fetchParts();
  }, []);

  const fetchParts = async () => {
    try {
      setLoading(true);
      setError(null);

      const response = await fetch("/api/inventory", {
        headers: {
          // Authorization: `Bearer ${token}`,
          // authorizations: state?.accessToken ?? "",
          Authorization: `Bearer ${
            state?.accessToken || localStorage.getItem("token")
          }`,
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch: ${response.status}`);
      }

      const result = await response.json();

      // Transform API data to match component structure
      const transformedParts: DisplaySparePart[] = result.data.map(
        (item: SparePart) => {
          // Parse meta field if it's a string
          let metaData = item.meta;
          if (typeof metaData === "string") {
            try {
              metaData = JSON.parse(metaData);
            } catch {
              metaData = {};
            }
          }

          return {
            ...item,
            unit_cost: parseFloat(item.unit_cost) || 0,
            retail_price: parseFloat(item.retail_price) || 0,
            stock_level: parseInt(item.stock_level) || 0,
            quantity: parseInt(item.quantity) || 0,
            min_stock_level: parseInt(item.min_stock_level) || 0,
            max_stock_level: parseInt(item.max_stock_level) || 0,
            category: metaData?.category || "Uncategorized",
            // supplierName: metaData?.supplierName || "Unknown Supplier",
            // location: metaData?.location || "N/A",
            // lastRestocked: metaData?.lastRestocked || item.updated_at,
            // meta: metaData || {},
          };
        }
      );

      setParts(transformedParts);
    } catch (err: any) {
      console.error("Error fetching parts:", err);
      setError(err.message || "Failed to load inventory data");
    } finally {
      setLoading(false);
    }
  };

  // Get unique categories from parts
  const categories = [
    ...new Set(parts.map((part) => part.category).filter(Boolean) as string[]),
  ];

  // Filter parts
  const filteredParts = parts.filter((part) => {
    const matchesSearch =
      part.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
      part.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      part.description.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesCategory =
      categoryFilter === "all" || part.category === categoryFilter;

    const matchesStatus =
      statusFilter === "all" || getStockStatus(part) === statusFilter;

    return matchesSearch && matchesCategory && matchesStatus;
  });

  // Calculate stock status based on quantities
  const getStockStatus = (
    part: DisplaySparePart
  ): "in-stock" | "low-stock" | "out-of-stock" => {
    const quantity = part.quantity;
    const minStock = part.min_stock_level;

    if (quantity === 0) return "out-of-stock";
    if (quantity <= minStock) return "low-stock";
    return "in-stock";
  };

  // Calculate metrics
  const calculateMetrics = (): InventoryMetrics => {
    const totalParts = parts.length;
    const lowStockItems = parts.filter(
      (part) => getStockStatus(part) === "low-stock"
    ).length;
    const outOfStockItems = parts.filter(
      (part) => getStockStatus(part) === "out-of-stock"
    ).length;
    const totalInventoryValue = parts.reduce(
      (sum, part) => sum + part.quantity * part.unit_cost,
      0
    );

    return {
      totalParts,
      lowStockItems,
      outOfStockItems,
      totalInventoryValue,
    };
  };

  const metrics = calculateMetrics();

  // Pagination
  const totalPages = Math.ceil(filteredParts.length / itemsPerPage);
  const paginatedParts = filteredParts.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  // Status badge render function
  const renderStatusBadge = (part: DisplaySparePart) => {
    const status = getStockStatus(part);
    const statusConfig = {
      "in-stock": { class: "bg-success", label: "In Stock" },
      "low-stock": { class: "bg-warning", label: "Low Stock" },
      "out-of-stock": { class: "bg-danger", label: "Out of Stock" },
    };

    const config = statusConfig[status] || {
      class: "bg-secondary",
      label: status,
    };

    return <Badge className={config.class}>{config.label}</Badge>;
  };

  // Stock level indicator
  const renderStockLevel = (part: DisplaySparePart) => {
    const maxStock = part.max_stock_level || 100;
    const percentage = maxStock > 0 ? (part.quantity / maxStock) * 100 : 0;
    const status = getStockStatus(part);
    let color = "success";

    if (status === "low-stock") color = "warning";
    if (status === "out-of-stock") color = "danger";

    return (
      <div className="d-flex align-items-center gap-2">
        <div className="flex-grow-1">
          <div className="progress" style={{ height: "8px" }}>
            <div
              className={`progress-bar bg-${color}`}
              style={{ width: `${percentage}%` }}
            ></div>
          </div>
        </div>
        <small className="text-muted">
          {part.quantity} / {maxStock}
        </small>
      </div>
    );
  };

  const handleDeletePart = async (id: string) => {
    if (!confirm("Are you sure you want to delete this part?")) {
      return;
    }

    try {
      const response = await fetch(`/api/inventory/${id}`, {
        method: "DELETE",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to delete part");
      }

      // Remove from local state
      setParts(parts.filter((part) => part.id !== id));

      // Show success message
      alert("Part deleted successfully!");
    } catch (err: any) {
      console.error("Error deleting part:", err);
      alert("Failed to delete part: " + err.message);
    }
  };

  const resetFilters = () => {
    setSearchTerm("");
    setStatusFilter("all");
    setCategoryFilter("all");
    setCurrentPage(1);
  };

  // Refresh data function
  const refreshData = () => {
    fetchParts();
  };

  // Loading state
  if (loading && parts.length === 0) {
    return (
      <div className="page-body">
        <Breadcrumbs
          title="Spare Parts & Inventory"
          mainTitle="Inventory Management"
          parent="Dashboard"
        />
        <Container fluid>
          <Row>
            <Col sm="12">
              <Card>
                <CardBody className="text-center py-5">
                  <div className="spinner-border text-primary" role="status">
                    <span className="visually-hidden">Loading...</span>
                  </div>
                  <p className="mt-3 mb-0">Loading inventory data...</p>
                </CardBody>
              </Card>
            </Col>
          </Row>
        </Container>
      </div>
    );
  }

  // Error state
  if (error && parts.length === 0) {
    return (
      <div className="page-body">
        <Breadcrumbs
          title="Spare Parts & Inventory"
          mainTitle="Inventory Management"
          parent="Dashboard"
        />
        <Container fluid>
          <Row>
            <Col sm="12">
              <Card>
                <CardBody className="text-center py-5">
                  <Alert color="danger">
                    <h4 className="alert-heading">Error Loading Data</h4>
                    <p>{error}</p>
                    <hr />
                    <Button color="danger" onClick={refreshData}>
                      Retry
                    </Button>
                  </Alert>
                </CardBody>
              </Card>
            </Col>
          </Row>
        </Container>
      </div>
    );
  }
  const handleStockAdded = () => {
    fetchParts(); // Refresh all data
  };
  return (
    <div className="page-body">
      <Breadcrumbs
        title="Spare Parts & Inventory"
        mainTitle="Inventory Management"
        parent="Dashboard"
      />

      <Container fluid>
        {/* Refresh button and error alert */}
        <div className="d-flex justify-content-between align-items-center mb-3">
          {error && (
            <Alert color="danger" className="mb-0 flex-grow-1 me-3">
              <i className="fa fa-exclamation-circle me-2"></i>
              {error}
            </Alert>
          )}
        </div>

        {/* Low Stock Alert */}
        {metrics.lowStockItems > 0 && (
          <Alert color="warning" className="mb-4">
            <i className="fa fa-exclamation-triangle me-2"></i>
            You have {metrics.lowStockItems} items with low stock levels that
            need attention.
          </Alert>
        )}

        {/* Out of Stock Alert */}
        {metrics.outOfStockItems > 0 && (
          <Alert color="danger" className="mb-4">
            <i className="fa fa-times-circle me-2"></i>
            You have {metrics.outOfStockItems} items that are out of stock.
          </Alert>
        )}

        <Row>
          <Col sm="12">
            <Card>
              <CardBody>
                {/* Header with Search and Add Button */}
                <div className="row align-items-center mb-4 g-3">
                  <div className="col-12 col-md-3">
                    <Input
                      type="search"
                      placeholder="Search by SKU, name, or description..."
                      value={searchTerm}
                      onChange={(e: ChangeEvent<HTMLInputElement>) =>
                        setSearchTerm(e.target.value)
                      }
                      disabled={loading}
                    />
                  </div>

                  {/* <div className="col-12 col-md-2">
                    <select
                      className="form-select p-2 border"
                      style={{ fontSize: "0.9rem" }}
                      value={categoryFilter}
                      onChange={(e: ChangeEvent<HTMLSelectElement>) =>
                        setCategoryFilter(e.target.value)
                      }
                      disabled={loading}
                    >
                      <option value="all">All Categories</option>
                      {categories.map((category) => (
                        <option key={category} value={category}>
                          {category}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="col-12 col-md-2">
                    <select
                      className="form-select p-2 border"
                      style={{ fontSize: "0.9rem" }}
                      value={statusFilter}
                      onChange={(e: ChangeEvent<HTMLSelectElement>) =>
                        setStatusFilter(e.target.value)
                      }
                      disabled={loading}
                    >
                      <option value="all">All Status</option>
                      <option value="in-stock">In Stock</option>
                      <option value="low-stock">Low Stock</option>
                      <option value="out-of-stock">Out of Stock</option>
                    </select>
                  </div> */}

                  {/* <div className="col-12 col-md-2">
                    <Button
                      color="outline-secondary"
                      onClick={resetFilters}
                      disabled={loading}
                      className="w-100"
                    >
                      Clear Filter
                    </Button>
                  </div> */}

                  <div className="col-12 col-md-3 d-flex justify-content-md-end">
                    <Link
                      href="/admin/inventory/add"
                      className="w-100 w-md-auto"
                    >
                      <Button
                        color="primary"
                        className="w-100 w-md-auto"
                        disabled={loading}
                      >
                        <i className="fa fa-plus me-2"></i>
                        Add Part
                      </Button>
                    </Link>
                  </div>
                </div>

                {/* Loading indicator for table */}
                {loading && (
                  <div className="text-center mb-3">
                    <div
                      className="spinner-border spinner-border-sm text-primary me-2"
                      role="status"
                    >
                      <span className="visually-hidden">Loading...</span>
                    </div>
                    <span className="text-muted">Updating data...</span>
                  </div>
                )}

                {/* Parts Table */}
                <div className="table-responsive">
                  <Table hover>
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>SKU</th>
                        <th>Part Name</th>
                        {/* <th>Category</th> */}
                        <th>Stock Level</th>
                        <th>Unit Cost</th>
                        <th>Retail Price</th>
                        {/* <th>Supplier</th> */}
                        {/* <th>Location</th>*/}
                        {/* <th>Status</th> */}
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {paginatedParts.length === 0 ? (
                        <tr>
                          <td colSpan={10} className="text-center py-4">
                            {searchTerm ||
                            categoryFilter !== "all" ||
                            statusFilter !== "all"
                              ? "No parts match your filters"
                              : "No parts found in inventory"}
                          </td>
                        </tr>
                      ) : (
                        paginatedParts.map((part, index) => (
                          <tr key={part.id}>
                            <td>
                              {(currentPage - 1) * itemsPerPage + index + 1}
                            </td>
                            <td>
                              <strong className="text-primary">
                                {part.sku}
                              </strong>
                            </td>
                            <td>
                              <div>
                                <div className="fw-bold">{part.name}</div>
                                <small className="text-muted no-wrap">
                                  {part.description || "No description"}
                                </small>
                              </div>
                            </td>
                            {/* <td>
                              <Badge color="light" className="text-muted">
                                {part.category || "Uncategorized"}
                              </Badge>
                            </td> */}
                            <td style={{ minWidth: "150px" }}>
                              {renderStockLevel(part)}
                            </td>
                            <td>${part.unit_cost.toFixed(2)}</td>
                            <td>${part.retail_price.toFixed(2)}</td>
                            {/* <td>{part.supplierName || "Unknown"}</td> */}
                            {/* <td>
                              <Badge color="light" className="text-muted">
                                {part.location || "N/A"}
                              </Badge>
                            </td> */}
                            {/* <td>{renderStatusBadge(part)}</td> */}
                            <td>
                              <div className="d-flex gap-1">
                                {/* <button
                                  className="action-btn text-white border btn-primary"
                                  onClick={() =>
                                    router.push(`/admin/inventory/${part.id}`)
                                  }
                                  title="View"
                                  disabled={loading}
                                >
                                  <i className="fa fa-eye"></i>
                                </button> */}
                                {/* <button
                                  className="action-btn text-white border btn-warning"
                                  onClick={() =>
                                    router.push(
                                      `/admin/inventory/${part.id}/edit`
                                    )
                                  }
                                  title="Edit"
                                  disabled={loading}
                                >
                                  <i className="fa fa-edit"></i>
                                </button> */}
                                <button
                                  className="action-btn text-white border btn-success"
                                  onClick={() => {
                                    setSelectedPart({
                                      id: part.id,
                                      name: part.name,
                                    });
                                    setModalOpen(true);
                                  }}
                                  title="Add Stock"
                                  disabled={loading}
                                >
                                  <i className="fa fa-plus"></i>
                                </button>
                                <button
                                  className="action-btn text-white border btn-info"
                                  onClick={() =>
                                    router.push(
                                      `/admin/inventory/transactions?part=${part.id}`
                                    )
                                  }
                                  title="History"
                                  disabled={loading}
                                >
                                  <i className="fa fa-history"></i>
                                </button>
                                <button
                                  className="action-btn text-white border btn-danger"
                                  onClick={() => handleDeletePart(part.id)}
                                  title="Delete"
                                  disabled={loading}
                                >
                                  <i className="fa fa-trash"></i>
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </Table>
                </div>

                {/* Pagination */}
                {filteredParts.length > 0 && (
                  <div className="d-flex flex-column flex-md-row justify-content-between align-items-center gap-3 mt-4">
                    <div className="text-center text-md-start text-muted">
                      Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
                      {Math.min(
                        currentPage * itemsPerPage,
                        filteredParts.length
                      )}{" "}
                      of {filteredParts.length} entries
                    </div>
                    {totalPages > 1 && (
                      <CustomPagination
                        currentPage={currentPage}
                        totalPages={totalPages}
                        onPageChange={setCurrentPage}
                        showFirstLast={true}
                        maxVisiblePages={5}
                        paginationType="primary"
                        className="justify-content-center justify-content-md-end"
                      />
                    )}
                  </div>
                )}
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Container>
      <AddStockModal
        isOpen={modalOpen}
        toggle={() => setModalOpen(!modalOpen)}
        partId={selectedPart?.id || ""}
        partName={selectedPart?.name || ""}
        onSuccess={handleStockAdded}
      />
    </div>
  );
}

export default withAuth(InventoryPage, ["admin"]);
