// "use client";
// import Breadcrumbs from "@/CommonElements/Breadcrumbs";
// import {
//   Container,
//   Row,
//   Col,
//   Card,
//   CardBody,
//   Table,
//   Badge,
//   Button,
//   Dropdown,
//   DropdownToggle,
//   DropdownMenu,
//   DropdownItem,
// } from "reactstrap";
// import React, { useState } from "react";
// import Link from "next/link";
// import { Invoice } from "@/Types/invoice";
// import CustomPagination from "@/CommonElements/Pagination";

// // Mock data
// const mockInvoices: Invoice[] = [
//   {
//     id: 1,
//     invoiceNumber: "INV-2024-001",
//     jobCardId: 101,
//     customerId: 1,
//     customerName: "John Doe",
//     customerEmail: "john@example.com",
//     customerPhone: "+1 234 567 8900",
//     customerAddress: "123 Main St, City, State 12345",
//     issueDate: "2024-01-15",
//     dueDate: "2024-01-30",
//     items: [
//       {
//         id: 1,
//         description: "Brake Pad Replacement",
//         type: "labor",
//         quantity: 2,
//         unitPrice: 150.0,
//         total: 300.0,
//       },
//       {
//         id: 2,
//         description: "Brake Pads Set",
//         type: "part",
//         quantity: 1,
//         unitPrice: 120.0,
//         total: 120.0,
//       },
//     ],
//     subtotal: 420.0,
//     taxRate: 8.5,
//     taxAmount: 35.7,
//     discount: 0,
//     total: 455.7,
//     amountPaid: 455.7,
//     balanceDue: 0,
//     status: "paid",
//     payments: [
//       {
//         id: 1,
//         date: "2024-01-15",
//         amount: 455.7,
//         method: "credit_card",
//         reference: "CHG-12345",
//         status: "completed",
//       },
//     ],
//     notes: "Brakes were worn out and needed replacement",
//     terms: "Due upon receipt",
//     createdAt: "2024-01-15T10:00:00Z",
//     updatedAt: "2024-01-15T10:00:00Z",
//   },
//   {
//     id: 2,
//     invoiceNumber: "INV-2024-002",
//     jobCardId: 102,
//     customerId: 2,
//     customerName: "Jane Smith",
//     customerEmail: "jane@example.com",
//     customerPhone: "+1 234 567 8901",
//     customerAddress: "456 Oak Ave, City, State 12345",
//     issueDate: "2024-01-16",
//     dueDate: "2024-01-31",
//     items: [
//       {
//         id: 1,
//         description: "Oil Change Service",
//         type: "labor",
//         quantity: 1,
//         unitPrice: 50.0,
//         total: 50.0,
//       },
//       {
//         id: 2,
//         description: "Synthetic Oil 5W-30",
//         type: "part",
//         quantity: 5,
//         unitPrice: 12.0,
//         total: 60.0,
//       },
//       {
//         id: 3,
//         description: "Oil Filter",
//         type: "part",
//         quantity: 1,
//         unitPrice: 15.0,
//         total: 15.0,
//       },
//     ],
//     subtotal: 125.0,
//     taxRate: 8.5,
//     taxAmount: 10.63,
//     discount: 10.0,
//     total: 125.63,
//     amountPaid: 0,
//     balanceDue: 125.63,
//     status: "sent",
//     payments: [],
//     notes: "Regular maintenance service",
//     terms: "Net 15 days",
//     createdAt: "2024-01-16T09:00:00Z",
//     updatedAt: "2024-01-16T09:00:00Z",
//   },
// ];

// function InvoicesPage() {
//   const [invoices, setInvoices] = useState<Invoice[]>(mockInvoices);
//   const [statusFilter, setStatusFilter] = useState<string>("all");
//   const [dropdownOpen, setDropdownOpen] = useState(false);
//   const [currentPage, setCurrentPage] = useState(1);
//   const itemsPerPage = 10;

//   const toggleDropdown = () => setDropdownOpen(!dropdownOpen);

//   const filteredInvoices = invoices.filter(
//     (invoice) => statusFilter === "all" || invoice.status === statusFilter
//   );

//   const getStatusBadge = (status: string) => {
//     const statusConfig = {
//       draft: { color: "secondary", label: "Draft" },
//       sent: { color: "info", label: "Sent" },
//       paid: { color: "success", label: "Paid" },
//       overdue: { color: "danger", label: "Overdue" },
//       partial: { color: "warning", label: "Partial" },
//       cancelled: { color: "dark", label: "Cancelled" },
//     };

//     const config = statusConfig[status as keyof typeof statusConfig] || {
//       color: "secondary",
//       label: status,
//     };

//     return <Badge color={config.color}>{config.label}</Badge>;
//   };

//   const handleDeleteInvoice = (invoiceId: number) => {
//     if (window.confirm("Are you sure you want to delete this invoice?")) {
//       setInvoices(invoices.filter((inv) => inv.id !== invoiceId));
//     }
//   };

//   const handleSendInvoice = (invoiceId: number) => {
//     setInvoices(
//       invoices.map((inv) =>
//         inv.id === invoiceId ? { ...inv, status: "sent" } : inv
//       )
//     );
//     alert("Invoice sent to customer!");
//   };

//   const handleExportPDF = (invoice: Invoice) => {
//     console.log("Exporting PDF for invoice:", invoice.invoiceNumber);
//     alert(`PDF generated for ${invoice.invoiceNumber}`);
//   };

//   const totalPages = Math.ceil(filteredInvoices.length / itemsPerPage);
//   const paginatedInvoices = filteredInvoices.slice(
//     (currentPage - 1) * itemsPerPage,
//     currentPage * itemsPerPage
//   );

//   const resetFilters = () => {
//     // setSearchTerm("");
//     setStatusFilter("all");

//     // setCurrentPage(1);
//   };

//   return (
//     <div className="page-body">
//       <Breadcrumbs
//         title="Invoices"
//         mainTitle="Billing & Invoicing"
//         parent="Finance"
//       />

//       <Container fluid>
//         <Row>
//           <Col sm="12">
//             <Card>
//               <CardBody>
//                 {/* Header with Actions */}
//                 <div className="d-flex justify-content-between align-items-center mb-4 ">
//                   <h5 className="card-title mb-0 text-muted">
//                     Invoice Management
//                   </h5>
//                   <div className="d-flex gap-2">
//                     <Dropdown isOpen={dropdownOpen} toggle={toggleDropdown}>
//                       {/* <DropdownToggle caret color="outline-primary"> */}
//                       <DropdownToggle
//                         caret
//                         className="text-muted"
//                         style={{ padding: "7px" }}
//                         color="outline-primary"
//                       >
//                         {/* Filter:{" "} */}
//                         {statusFilter === "all" ? "All Status" : statusFilter}
//                       </DropdownToggle>
//                       <DropdownMenu>
//                         <DropdownItem onClick={() => setStatusFilter("all")}>
//                           All Status
//                         </DropdownItem>
//                         <DropdownItem onClick={() => setStatusFilter("draft")}>
//                           Draft
//                         </DropdownItem>
//                         <DropdownItem onClick={() => setStatusFilter("sent")}>
//                           Sent
//                         </DropdownItem>
//                         <DropdownItem onClick={() => setStatusFilter("paid")}>
//                           Paid
//                         </DropdownItem>
//                         <DropdownItem
//                           onClick={() => setStatusFilter("partial")}
//                         >
//                           Partial
//                         </DropdownItem>
//                         <DropdownItem
//                           onClick={() => setStatusFilter("overdue")}
//                         >
//                           Overdue
//                         </DropdownItem>
//                       </DropdownMenu>
//                     </Dropdown>

//                     {/* <div>
//                       <Button color="outline-secondary" onClick={resetFilters}>
//                         Clear Filters
//                       </Button>
//                     </div> */}

//                     <Link href="/admin/invoices/create">
//                       <Button color="primary">
//                         <i className="fa fa-plus me-2"></i>
//                         Create Invoice
//                       </Button>
//                     </Link>
//                   </div>
//                 </div>

//                 {/* Invoices Table */}
//                 <div className="table-responsive">
//                   <Table hover>
//                     <thead>
//                       <tr>
//                         <th>Invoice #</th>
//                         <th>Customer</th>
//                         <th>Issue Date</th>
//                         <th>Due Date</th>
//                         <th>Total Amount</th>
//                         <th>Balance Due</th>
//                         <th>Status</th>
//                         <th>Actions</th>
//                       </tr>
//                     </thead>
//                     <tbody>
//                       {paginatedInvoices.map((invoice) => (
//                         <tr key={invoice.id}>
//                           <td>
//                             <Link href={`/admin/invoices/${invoice.id}`}>
//                               <strong className="text-primary no-wrap">
//                                 {invoice.invoiceNumber}
//                               </strong>
//                             </Link>
//                             <br />
//                             <small className="text-muted">
//                               Job: JC-{invoice.jobCardId}
//                             </small>
//                           </td>
//                           <td>
//                             <div>{invoice.customerName}</div>
//                             <small className="text-muted">
//                               {invoice.customerEmail}
//                             </small>
//                           </td>
//                           <td>
//                             {new Date(invoice.issueDate).toLocaleDateString()}
//                           </td>
//                           <td>
//                             {new Date(invoice.dueDate).toLocaleDateString()}
//                           </td>
//                           <td>
//                             <strong>${invoice.total.toFixed(2)}</strong>
//                           </td>
//                           <td>
//                             <strong
//                               className={
//                                 invoice.balanceDue > 0
//                                   ? "text-danger"
//                                   : "text-success"
//                               }
//                             >
//                               ${invoice.balanceDue.toFixed(2)}
//                             </strong>
//                           </td>
//                           <td>{getStatusBadge(invoice.status)}</td>
//                           <td>
//                             <div className="d-flex gap-1">
//                               <Link href={`/admin/invoices/${invoice.id}`}>
//                                 <Button color="primary" size="sm">
//                                   <i className="fa fa-eye"></i>
//                                 </Button>
//                               </Link>
//                               <Button
//                                 color="outline-success"
//                                 size="sm"
//                                 onClick={() => handleExportPDF(invoice)}
//                               >
//                                 {/* <i className="fa fa-file-pdf"></i> */}
//                                 <i className="icofont icofont-download-alt"></i>
//                               </Button>
//                               {invoice.status === "draft" && (
//                                 <>
//                                   <Button
//                                     color="outline-info"
//                                     size="sm"
//                                     onClick={() =>
//                                       handleSendInvoice(invoice.id)
//                                     }
//                                   >
//                                     <i className="fa fa-paper-plane"></i>
//                                   </Button>
//                                   <Button
//                                     color="outline-danger"
//                                     size="sm"
//                                     onClick={() =>
//                                       handleDeleteInvoice(invoice.id)
//                                     }
//                                   >
//                                     <i className="fa fa-trash"></i>
//                                   </Button>
//                                 </>
//                               )}
//                             </div>
//                           </td>
//                         </tr>
//                       ))}
//                       {paginatedInvoices.length === 0 && (
//                         <tr>
//                           <td colSpan={8} className="text-center py-4">
//                             <div className="text-muted">
//                               No invoices found matching your criteria.
//                             </div>
//                           </td>
//                         </tr>
//                       )}
//                     </tbody>
//                   </Table>
//                 </div>

//                 {/* Pagination and Info */}
//                 <div className="d-flex flex-column flex-md-row justify-content-between align-items-center gap-3 mt-4">
//                   <div className="text-center text-md-start text-muted">
//                     Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
//                     {Math.min(
//                       currentPage * itemsPerPage,
//                       filteredInvoices.length
//                     )}{" "}
//                     of {filteredInvoices.length} entries
//                   </div>
//                   <CustomPagination
//                     currentPage={currentPage}
//                     totalPages={totalPages}
//                     onPageChange={setCurrentPage}
//                     showFirstLast={true}
//                     maxVisiblePages={5}
//                     paginationType="primary"
//                     className="justify-content-center justify-content-md-end"
//                   />
//                 </div>

//                 {/* Summary Cards */}
//                 <Row className="mt-4">
//                   <Col md="3">
//                     <Card className="card-stats">
//                       <CardBody>
//                         <div className="text-center">
//                           <h4 className="mb-0 text-primary">
//                             {invoices.length}
//                           </h4>
//                           <span className="text-muted">Total Invoices</span>
//                         </div>
//                       </CardBody>
//                     </Card>
//                   </Col>
//                   <Col md="3">
//                     <Card className="card-stats">
//                       <CardBody>
//                         <div className="text-center">
//                           <h4 className="mb-0 text-success">
//                             $
//                             {invoices
//                               .filter((inv) => inv.status === "paid")
//                               .reduce((sum, inv) => sum + inv.total, 0)
//                               .toFixed(2)}
//                           </h4>
//                           <span className="text-muted">Total Paid</span>
//                         </div>
//                       </CardBody>
//                     </Card>
//                   </Col>
//                   <Col md="3">
//                     <Card className="card-stats">
//                       <CardBody>
//                         <div className="text-center">
//                           <h4 className="mb-0 text-warning">
//                             $
//                             {invoices
//                               .filter((inv) => inv.status === "partial")
//                               .reduce((sum, inv) => sum + inv.balanceDue, 0)
//                               .toFixed(2)}
//                           </h4>
//                           <span className="text-muted">Partial Payments</span>
//                         </div>
//                       </CardBody>
//                     </Card>
//                   </Col>
//                   <Col md="3">
//                     <Card className="card-stats">
//                       <CardBody>
//                         <div className="text-center">
//                           <h4 className="mb-0 text-danger">
//                             $
//                             {invoices
//                               .filter(
//                                 (inv) =>
//                                   inv.status === "sent" ||
//                                   inv.status === "overdue"
//                               )
//                               .reduce((sum, inv) => sum + inv.balanceDue, 0)
//                               .toFixed(2)}
//                           </h4>
//                           <span className="text-muted">Outstanding</span>
//                         </div>
//                       </CardBody>
//                     </Card>
//                   </Col>
//                 </Row>
//               </CardBody>
//             </Card>
//           </Col>
//         </Row>
//       </Container>

//       <style jsx global>{`
//         .card-stats {
//           border: 1px solid #e6edef;
//           box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
//         }
//       `}</style>
//     </div>
//   );
// }

// export default InvoicesPage;

// api integration
// "use client";
// import Breadcrumbs from "@/CommonElements/Breadcrumbs";
// import {
//   Container,
//   Row,
//   Col,
//   Card,
//   CardBody,
//   Table,
//   Badge,
//   Button,
//   Dropdown,
//   DropdownToggle,
//   DropdownMenu,
//   DropdownItem,
// } from "reactstrap";
// import React, { useState, useEffect } from "react";
// import Link from "next/link";
// import { Invoice } from "@/Types/invoice";
// import CustomPagination from "@/CommonElements/Pagination";
// import { useAuth } from "@/helper/AuthContext";
// import withAuth from "@/helper/WithAuth";

// interface ApiInvoice {
//   id: string;
//   invoice_number: string;
//   job_card_id: string;
//   customer_id: string;
//   customer_name: string;
//   issue_date: string;
//   due_date: string;
//   subtotal: string;
//   tax_amount: string;
//   discount_amount: string;
//   total_amount: string;
//   status: string;
//   created_at: string;
//   updated_at: string;
//   job_number: string;
// }
// function InvoicesPage() {
//   const { state } = useAuth();
//   const [invoices, setInvoices] = useState<Invoice[]>([]);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState<string | null>(null);
//   const [statusFilter, setStatusFilter] = useState<string>("all");
//   const [dropdownOpen, setDropdownOpen] = useState(false);
//   const [currentPage, setCurrentPage] = useState(1);
//   const itemsPerPage = 10;

//   // Fetch invoices from API
//   useEffect(() => {
//     fetchInvoices();
//   }, []);

//   const fetchInvoices = async () => {
//     try {
//       setLoading(true);
//       setError(null);

//       // const response = await fetch("/api/invoices");
//       const response = await fetch("/api/invoices", {
//         method: "GET",
//         headers: {
//           // Authorization: `Bearer ${token}`,
//           // authorizations: state?.accessToken ?? "",
//           Authorization: `Bearer ${
//             state?.accessToken || localStorage.getItem("token")
//           }`,
//           "Content-Type": "application/json",
//         },
//       });

//       if (!response.ok) {
//         throw new Error(`HTTP error! status: ${response.status}`);
//       }

//       const data = await response.json();

//       // Transform API data to match your Invoice type
//       const transformedInvoices: Invoice[] = data.data.map(
//         (apiInvoice: ApiInvoice) => {
//           const total = parseFloat(apiInvoice.total_amount) || 0;
//           const balanceDue = apiInvoice.status === "paid" ? 0 : total;

//           return {
//             id: parseInt(apiInvoice.id),
//             invoiceNumber: apiInvoice.invoice_number,
//             jobCardId: parseInt(apiInvoice.job_card_id),
//             customerId: parseInt(apiInvoice.customer_id),
//             customerName: apiInvoice.customer_name,

//             issueDate:
//               apiInvoice.issue_date === "0000-00-00 00:00:00"
//                 ? new Date().toISOString().split("T")[0]
//                 : apiInvoice.issue_date.split(" ")[0],
//             dueDate:
//               apiInvoice.due_date === "0000-00-00 00:00:00"
//                 ? new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
//                     .toISOString()
//                     .split("T")[0]
//                 : apiInvoice.due_date.split(" ")[0],

//             subtotal: parseFloat(apiInvoice.subtotal) || 0,

//             taxAmount: parseFloat(apiInvoice.tax_amount) || 0,
//             discount: parseFloat(apiInvoice.discount_amount) || 0,
//             total: total,
//             amountPaid: apiInvoice.status === "paid" ? total : 0,
//             balanceDue: balanceDue,
//             status: apiInvoice.status,

//             createdAt: apiInvoice.created_at,
//             updatedAt: apiInvoice.updated_at,
//           };
//         }
//       );

//       setInvoices(transformedInvoices);
//     } catch (err) {
//       console.error("Error fetching invoices:", err);
//       setError(err instanceof Error ? err.message : "Failed to fetch invoices");
//     } finally {
//       setLoading(false);
//     }
//   };

//   const toggleDropdown = () => setDropdownOpen(!dropdownOpen);

//   const filteredInvoices = invoices.filter(
//     (invoice) => statusFilter === "all" || invoice.status === statusFilter
//   );

//   const getStatusBadge = (status: string) => {
//     const statusConfig = {
//       draft: { color: "secondary", label: "Draft" },
//       sent: { color: "info", label: "Sent" },
//       paid: { color: "success", label: "Paid" },
//       unpaid: { color: "warning", label: "Unpaid" },
//       overdue: { color: "danger", label: "Overdue" },
//       partial: { color: "warning", label: "Partial" },
//       cancelled: { color: "dark", label: "Cancelled" },
//     };

//     const config = statusConfig[status as keyof typeof statusConfig] || {
//       color: "secondary",
//       label: status.charAt(0).toUpperCase() + status.slice(1),
//     };

//     return <Badge color={config.color}>{config.label}</Badge>;
//   };

//   const handleDeleteInvoice = async (invoiceId: number) => {
//     if (window.confirm("Are you sure you want to delete this invoice?")) {
//       try {
//         const response = await fetch(`/api/invoices/${invoiceId}`, {
//           method: "DELETE",
//         });

//         if (response.ok) {
//           setInvoices(invoices.filter((inv) => inv.id !== invoiceId));
//           alert("Invoice deleted successfully!");
//         } else {
//           throw new Error("Failed to delete invoice");
//         }
//       } catch (err) {
//         console.error("Error deleting invoice:", err);
//         alert("Failed to delete invoice. Please try again.");
//       }
//     }
//   };

//   const handleSendInvoice = async (invoiceId: number) => {
//     try {
//       const response = await fetch(`/api/invoices/${invoiceId}`, {
//         method: "PUT",
//         headers: {
//           "Content-Type": "application/json",
//         },
//         body: JSON.stringify({ status: "sent" }),
//       });

//       if (response.ok) {
//         setInvoices(
//           invoices.map((inv) =>
//             inv.id === invoiceId ? { ...inv, status: "sent" } : inv
//           )
//         );
//         alert("Invoice sent to customer!");
//       } else {
//         throw new Error("Failed to update invoice");
//       }
//     } catch (err) {
//       console.error("Error sending invoice:", err);
//       alert("Failed to send invoice. Please try again.");
//     }
//   };

//   const handleExportPDF = (invoice: Invoice) => {
//     console.log("Exporting PDF for invoice:", invoice.invoiceNumber);
//     alert(`PDF generated for ${invoice.invoiceNumber}`);
//   };

//   const handleMarkAsPaid = async (invoiceId: number) => {
//     try {
//       const response = await fetch(`/api/invoices/${invoiceId}/status`, {
//         method: "PUT",
//         headers: {
//           "Content-Type": "application/json",
//         },
//         body: JSON.stringify({ status: "paid" }),
//       });

//       if (response.ok) {
//         setInvoices(
//           invoices.map((inv) =>
//             inv.id === invoiceId
//               ? {
//                   ...inv,
//                   status: "paid",
//                   amountPaid: inv.total,
//                   balanceDue: 0,
//                 }
//               : inv
//           )
//         );
//         alert("Invoice marked as paid!");
//       } else {
//         throw new Error("Failed to update invoice");
//       }
//     } catch (err) {
//       console.error("Error marking invoice as paid:", err);
//       alert("Failed to update invoice. Please try again.");
//     }
//   };

//   const totalPages = Math.ceil(filteredInvoices.length / itemsPerPage);
//   const paginatedInvoices = filteredInvoices.slice(
//     (currentPage - 1) * itemsPerPage,
//     currentPage * itemsPerPage
//   );

//   const resetFilters = () => {
//     setStatusFilter("all");
//     setCurrentPage(1);
//   };

//   // Calculate summary statistics
//   const totalPaid = invoices
//     .filter((inv) => inv.status === "paid")
//     .reduce((sum, inv) => sum + inv.total, 0);

//   const totalOutstanding = invoices
//     .filter((inv) => inv.status === "unpaid" || inv.status === "partial")
//     .reduce((sum, inv) => sum + inv.balanceDue, 0);

//   const totalPartial = invoices
//     .filter((inv) => inv.status === "partial")
//     .reduce((sum, inv) => sum + inv.balanceDue, 0);

//   if (loading) {
//     return (
//       <div className="page-body">
//         <Breadcrumbs
//           title="Invoices"
//           mainTitle="Billing & Invoicing"
//           parent="Finance"
//         />
//         <Container fluid>
//           <Row>
//             <Col sm="12">
//               <Card>
//                 <CardBody className="text-center py-5">
//                   <div className="spinner-border text-primary" role="status">
//                     <span className="visually-hidden">Loading...</span>
//                   </div>
//                   <p className="mt-3 mb-0">Loading invoices...</p>
//                 </CardBody>
//               </Card>
//             </Col>
//           </Row>
//         </Container>
//       </div>
//     );
//   }

//   if (error) {
//     return (
//       <div className="page-body">
//         <Breadcrumbs
//           title="Invoices"
//           mainTitle="Billing & Invoicing"
//           parent="Finance"
//         />
//         <Container fluid>
//           <Row>
//             <Col sm="12">
//               <Card>
//                 <CardBody className="text-center py-5">
//                   <div className="text-danger mb-3">
//                     <i className="fa fa-exclamation-triangle fa-3x"></i>
//                   </div>
//                   <h5 className="text-danger">Error Loading Invoices</h5>
//                   <p className="text-muted">{error}</p>
//                   <Button color="primary" onClick={fetchInvoices}>
//                     <i className="fa fa-refresh me-2"></i>
//                     Try Again
//                   </Button>
//                 </CardBody>
//               </Card>
//             </Col>
//           </Row>
//         </Container>
//       </div>
//     );
//   }

//   return (
//     <div className="page-body">
//       <Breadcrumbs
//         title="Invoices"
//         mainTitle="Billing & Invoicing"
//         parent="Finance"
//       />

//       <Container fluid>
//         <Row>
//           <Col sm="12">
//             <Card>
//               <CardBody>
//                 {/* Header with Actions */}
//                 <div className="d-flex justify-content-between align-items-center mb-4">
//                   <h5 className="card-title mb-0 text-muted">
//                     Invoice Management
//                   </h5>
//                   <div className="d-flex gap-2">
//                     <Dropdown isOpen={dropdownOpen} toggle={toggleDropdown}>
//                       <DropdownToggle
//                         caret
//                         className="text-muted"
//                         style={{ padding: "7px" }}
//                         color="outline-primary"
//                       >
//                         {statusFilter === "all" ? "All Status" : statusFilter}
//                       </DropdownToggle>
//                       <DropdownMenu>
//                         <DropdownItem onClick={() => setStatusFilter("all")}>
//                           All Status
//                         </DropdownItem>
//                         <DropdownItem onClick={() => setStatusFilter("draft")}>
//                           Draft
//                         </DropdownItem>
//                         <DropdownItem onClick={() => setStatusFilter("unpaid")}>
//                           Unpaid
//                         </DropdownItem>
//                         <DropdownItem onClick={() => setStatusFilter("paid")}>
//                           Paid
//                         </DropdownItem>
//                         <DropdownItem
//                           onClick={() => setStatusFilter("partial")}
//                         >
//                           Partial
//                         </DropdownItem>
//                         <DropdownItem
//                           onClick={() => setStatusFilter("overdue")}
//                         >
//                           Overdue
//                         </DropdownItem>
//                       </DropdownMenu>
//                     </Dropdown>

//                     <div>
//                       <Button color="outline-secondary" onClick={resetFilters}>
//                         Clear Filters
//                       </Button>
//                     </div>

//                     <Button color="outline-primary" onClick={fetchInvoices}>
//                       <i className="fa fa-refresh me-2"></i>
//                       Refresh
//                     </Button>

//                     <Link href="/admin/invoices/create">
//                       <Button color="primary">
//                         <i className="fa fa-plus me-2"></i>
//                         Create Invoice
//                       </Button>
//                     </Link>
//                   </div>
//                 </div>

//                 {/* Invoices Table */}
//                 <div className="table-responsive">
//                   <Table hover>
//                     <thead>
//                       <tr>
//                         <th>Invoice #</th>
//                         <th>Customer</th>
//                         <th>Issue Date</th>
//                         <th>Due Date</th>
//                         <th>Total Amount</th>
//                         <th>Balance Due</th>
//                         <th>Status</th>
//                         <th>Actions</th>
//                       </tr>
//                     </thead>
//                     <tbody>
//                       {paginatedInvoices.map((invoice) => (
//                         <tr key={invoice.id}>
//                           <td>
//                             <Link href={`/admin/invoices/${invoice.id}`}>
//                               <strong className="text-primary no-wrap">
//                                 {invoice.invoiceNumber}
//                               </strong>
//                             </Link>
//                             <br />
//                             <small className="text-muted">
//                               Job: {invoice.jobCardId}
//                             </small>
//                           </td>
//                           <td>
//                             <div>{invoice.customerName}</div>
//                             <small className="text-muted">
//                               {invoice.customerEmail || "No email"}
//                             </small>
//                           </td>
//                           <td>
//                             {new Date(invoice.issueDate).toLocaleDateString()}
//                           </td>
//                           <td>
//                             {new Date(invoice.dueDate).toLocaleDateString()}
//                           </td>
//                           <td>
//                             <strong>${invoice.total.toFixed(2)}</strong>
//                           </td>
//                           <td>
//                             <strong
//                               className={
//                                 invoice.balanceDue > 0
//                                   ? "text-danger"
//                                   : "text-success"
//                               }
//                             >
//                               ${invoice.balanceDue.toFixed(2)}
//                             </strong>
//                           </td>
//                           <td>{getStatusBadge(invoice.status)}</td>
//                           <td>
//                             <div className="d-flex gap-1">
//                               <Link href={`/admin/invoices/${invoice.id}`}>
//                                 <Button color="primary" size="sm">
//                                   <i className="fa fa-eye"></i>
//                                 </Button>
//                               </Link>
//                               <Button
//                                 color="outline-success"
//                                 size="sm"
//                                 onClick={() => handleExportPDF(invoice)}
//                               >
//                                 <i className="icofont icofont-download-alt"></i>
//                               </Button>

//                               {invoice.status === "unpaid" && (
//                                 <Button
//                                   color="outline-success"
//                                   size="sm"
//                                   onClick={() => handleMarkAsPaid(invoice.id)}
//                                 >
//                                   <i className="fa fa-check"></i>
//                                 </Button>
//                               )}

//                               {invoice.status === "draft" && (
//                                 <>
//                                   <Button
//                                     color="outline-info"
//                                     size="sm"
//                                     onClick={() =>
//                                       handleSendInvoice(invoice.id)
//                                     }
//                                   >
//                                     <i className="fa fa-paper-plane"></i>
//                                   </Button>
//                                   <Button
//                                     color="outline-danger"
//                                     size="sm"
//                                     onClick={() =>
//                                       handleDeleteInvoice(invoice.id)
//                                     }
//                                   >
//                                     <i className="fa fa-trash"></i>
//                                   </Button>
//                                 </>
//                               )}
//                             </div>
//                           </td>
//                         </tr>
//                       ))}
//                       {paginatedInvoices.length === 0 && (
//                         <tr>
//                           <td colSpan={8} className="text-center py-4">
//                             <div className="text-muted">
//                               No invoices found matching your criteria.
//                             </div>
//                           </td>
//                         </tr>
//                       )}
//                     </tbody>
//                   </Table>
//                 </div>

//                 {/* Pagination and Info */}
//                 <div className="d-flex flex-column flex-md-row justify-content-between align-items-center gap-3 mt-4">
//                   <div className="text-center text-md-start text-muted">
//                     Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
//                     {Math.min(
//                       currentPage * itemsPerPage,
//                       filteredInvoices.length
//                     )}{" "}
//                     of {filteredInvoices.length} entries
//                   </div>
//                   <CustomPagination
//                     currentPage={currentPage}
//                     totalPages={totalPages}
//                     onPageChange={setCurrentPage}
//                     showFirstLast={true}
//                     maxVisiblePages={5}
//                     paginationType="primary"
//                     className="justify-content-center justify-content-md-end"
//                   />
//                 </div>

//                 {/* Summary Cards */}
//                 <Row className="mt-4">
//                   <Col md="3">
//                     <Card className="card-stats">
//                       <CardBody>
//                         <div className="text-center">
//                           <h4 className="mb-0 text-primary">
//                             {invoices.length}
//                           </h4>
//                           <span className="text-muted">Total Invoices</span>
//                         </div>
//                       </CardBody>
//                     </Card>
//                   </Col>
//                   <Col md="3">
//                     <Card className="card-stats">
//                       <CardBody>
//                         <div className="text-center">
//                           <h4 className="mb-0 text-success">
//                             ${totalPaid.toFixed(2)}
//                           </h4>
//                           <span className="text-muted">Total Paid</span>
//                         </div>
//                       </CardBody>
//                     </Card>
//                   </Col>
//                   <Col md="3">
//                     <Card className="card-stats">
//                       <CardBody>
//                         <div className="text-center">
//                           <h4 className="mb-0 text-warning">
//                             ${totalPartial.toFixed(2)}
//                           </h4>
//                           <span className="text-muted">Partial Payments</span>
//                         </div>
//                       </CardBody>
//                     </Card>
//                   </Col>
//                   <Col md="3">
//                     <Card className="card-stats">
//                       <CardBody>
//                         <div className="text-center">
//                           <h4 className="mb-0 text-danger">
//                             ${totalOutstanding.toFixed(2)}
//                           </h4>
//                           <span className="text-muted">Outstanding</span>
//                         </div>
//                       </CardBody>
//                     </Card>
//                   </Col>
//                 </Row>
//               </CardBody>
//             </Card>
//           </Col>
//         </Row>
//       </Container>

//       <style jsx global>{`
//         .card-stats {
//           border: 1px solid #e6edef;
//           box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
//         }
//         .no-wrap {
//           white-space: nowrap;
//         }
//       `}</style>
//     </div>
//   );
// }
// export default withAuth(InvoicesPage, ["admin"]);

"use client";
import Breadcrumbs from "@/CommonElements/Breadcrumbs";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  Table,
  Badge,
  Button,
  Dropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
} from "reactstrap";
import React, { useState, useEffect } from "react";
import Link from "next/link";
import { Invoice } from "@/Types/invoice";
import CustomPagination from "@/CommonElements/Pagination";
import { useAuth } from "@/helper/AuthContext";
import withAuth from "@/helper/WithAuth";
import { toast } from "react-toastify";

// API response type
interface ApiInvoice {
  id: string;
  invoice_number: string;
  job_card_id: string;
  customer_id: string;
  customer_name: string;
  issue_date: string;
  due_date: string;
  subtotal: string;
  tax_amount: string;
  discount_amount: string;
  total_amount: string;
  status: string;
  created_at: string;
  updated_at: string;
  job_number: string;
}

function InvoicesPage() {
  const { state } = useAuth();
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  // Fetch invoices from API
  useEffect(() => {
    fetchInvoices();
  }, []);

  // const fetchInvoices = async () => {
  //   try {
  //     setLoading(true);
  //     setError(null);

  //     const token = state?.accessToken || localStorage.getItem("token");
  //     const response = await fetch("/api/invoices", {
  //       method: "GET",
  //       headers: {
  //         Authorization: `Bearer ${token}`,
  //         "Content-Type": "application/json",
  //       },
  //     });

  //     if (!response.ok) {
  //       throw new Error(`HTTP error! status: ${response.status}`);
  //     }

  //     const data = await response.json();

  //     // Remove duplicates by creating a Map with invoice ID as key
  //     const uniqueInvoicesMap = new Map();

  //     data.data.forEach((apiInvoice: ApiInvoice) => {
  //       if (!uniqueInvoicesMap.has(apiInvoice.id)) {
  //         const total = parseFloat(apiInvoice.total_amount) || 0;
  //         const balanceDue = apiInvoice.status === "paid" ? 0 : total;

  //         uniqueInvoicesMap.set(apiInvoice.id, {
  //           id: parseInt(apiInvoice.id),
  //           invoiceNumber: apiInvoice.invoice_number,
  //           jobCardId: parseInt(apiInvoice.job_card_id),
  //           customerId: parseInt(apiInvoice.customer_id),
  //           customerName: apiInvoice.customer_name,
  //           customerEmail: "", // Add if your API provides it
  //           customerPhone: "",
  //           customerAddress: "",

  //           issueDate:
  //             apiInvoice.issue_date === "0000-00-00 00:00:00"
  //               ? new Date().toISOString().split("T")[0]
  //               : apiInvoice.issue_date.split(" ")[0],
  //           dueDate:
  //             apiInvoice.due_date === "0000-00-00 00:00:00"
  //               ? new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
  //                   .toISOString()
  //                   .split("T")[0]
  //               : apiInvoice.due_date.split(" ")[0],

  //           subtotal: parseFloat(apiInvoice.subtotal) || 0,
  //           taxAmount: parseFloat(apiInvoice.tax_amount) || 0,
  //           discount: parseFloat(apiInvoice.discount_amount) || 0,
  //           total: total,
  //           amountPaid: apiInvoice.status === "paid" ? total : 0,
  //           balanceDue: balanceDue,
  //           status: apiInvoice.status.toLowerCase(), // Ensure lowercase

  //           createdAt: apiInvoice.created_at,
  //           updatedAt: apiInvoice.updated_at,
  //         });
  //       }
  //     });

  //     // Convert Map values back to array
  //     const transformedInvoices = Array.from(uniqueInvoicesMap.values());

  //     setInvoices(transformedInvoices);
  //   } catch (err) {
  //     console.error("Error fetching invoices:", err);
  //     setError(err instanceof Error ? err.message : "Failed to fetch invoices");
  //     toast.error("Failed to load invoices");
  //   } finally {
  //     setLoading(false);
  //   }
  // };
  const fetchInvoices = async () => {
    try {
      setLoading(true);
      setError(null);

      // const response = await fetch("/api/invoices");
      const response = await fetch("/api/invoices", {
        method: "GET",
        headers: {
          // Authorization: `Bearer ${token}`,
          // authorizations: state?.accessToken ?? "",
          Authorization: `Bearer ${
            state?.accessToken || localStorage.getItem("token")
          }`,
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      // Transform API data to match your Invoice type
      const transformedInvoices: Invoice[] = data.data.map(
        (apiInvoice: ApiInvoice) => {
          const total = parseFloat(apiInvoice.total_amount) || 0;
          const balanceDue = apiInvoice.status === "paid" ? 0 : total;

          return {
            id: parseInt(apiInvoice.id),
            invoiceNumber: apiInvoice.invoice_number,
            jobCardId: parseInt(apiInvoice.job_card_id),
            customerId: parseInt(apiInvoice.customer_id),
            customerName: apiInvoice.customer_name,

            issueDate:
              apiInvoice.issue_date === "0000-00-00 00:00:00"
                ? new Date().toISOString().split("T")[0]
                : apiInvoice.issue_date.split(" ")[0],
            dueDate:
              apiInvoice.due_date === "0000-00-00 00:00:00"
                ? new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
                    .toISOString()
                    .split("T")[0]
                : apiInvoice.due_date.split(" ")[0],

            subtotal: parseFloat(apiInvoice.subtotal) || 0,

            taxAmount: parseFloat(apiInvoice.tax_amount) || 0,
            discount: parseFloat(apiInvoice.discount_amount) || 0,
            total: total,
            amountPaid: apiInvoice.status === "paid" ? total : 0,
            balanceDue: balanceDue,
            status: apiInvoice.status,

            createdAt: apiInvoice.created_at,
            updatedAt: apiInvoice.updated_at,
          };
        }
      );

      setInvoices(transformedInvoices);
    } catch (err) {
      console.error("Error fetching invoices:", err);
      setError(err instanceof Error ? err.message : "Failed to fetch invoices");
    } finally {
      setLoading(false);
    }
  };
  const toggleDropdown = () => setDropdownOpen(!dropdownOpen);

  const filteredInvoices = invoices.filter((invoice) => {
    if (statusFilter === "all") return true;
    if (!invoice.status) return false;
    return invoice.status.toLowerCase() === statusFilter.toLowerCase();
  });

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      draft: { color: "secondary", label: "Draft" },
      sent: { color: "info", label: "Sent" },
      paid: { color: "success", label: "Paid" },
      unpaid: { color: "danger", label: "Unpaid" },
      overdue: { color: "danger", label: "Overdue" },
      partial: { color: "warning", label: "Partial" },
      cancelled: { color: "dark", label: "Cancelled" },
    };

    const config = statusConfig[status as keyof typeof statusConfig] || {
      color: "secondary",
      label: status.charAt(0).toUpperCase() + status.slice(1),
    };

    return <Badge color={config.color}>{config.label}</Badge>;
  };

  const handleDeleteInvoice = async (invoiceId: number) => {
    if (window.confirm("Are you sure you want to delete this invoice?")) {
      try {
        const token = state?.accessToken || localStorage.getItem("token");
        const response = await fetch(`/api/invoices/${invoiceId}`, {
          method: "DELETE",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        });

        if (response.ok) {
          setInvoices(invoices.filter((inv) => inv.id !== invoiceId));
          toast.success("Invoice deleted successfully!");
        } else {
          const errorData = await response.json();
          throw new Error(errorData.message || "Failed to delete invoice");
        }
      } catch (err: any) {
        console.error("Error deleting invoice:", err);
        toast.error(err.message || "Failed to delete invoice");
      }
    }
  };

  const handleSendInvoice = async (invoiceId: number) => {
    try {
      const token = state?.accessToken || localStorage.getItem("token");
      const response = await fetch(`/api/invoices/${invoiceId}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ status: "sent" }),
      });

      if (response.ok) {
        setInvoices(
          invoices.map((inv) =>
            inv.id === invoiceId ? { ...inv, status: "sent" } : inv
          )
        );
        toast.success("Invoice sent to customer!");
      } else {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to update invoice");
      }
    } catch (err: any) {
      console.error("Error sending invoice:", err);
      toast.error(err.message || "Failed to send invoice");
    }
  };

  const handleExportPDF = (invoice: Invoice) => {
    console.log("Exporting PDF for invoice:", invoice.invoiceNumber);
    // For now, open a print dialog
    window.open(`/admin/invoices/${invoice.id}/print`, "_blank");
    toast.info(`Preparing PDF for ${invoice.invoiceNumber}`);
  };

  // const handleMarkAsPaid = async (invoiceId: number) => {
  //   try {
  //     const token = state?.accessToken || localStorage.getItem("token");

  //     // Use the correct endpoint - just /api/invoices/{id} with PUT method
  //     const response = await fetch(`/api/invoices/${invoiceId}/status`, {
  //       method: "PATCH",
  //       headers: {
  //         "Content-Type": "application/json",
  //         Authorization: `Bearer ${token}`,
  //       },
  //       body: JSON.stringify({
  //         status: "paid",
  //         amount_paid: invoices.find((inv) => inv.id === invoiceId)?.total || 0,
  //       }),
  //     });

  //     if (response.ok) {
  //       const invoice = invoices.find((inv) => inv.id === invoiceId);
  //       const total = invoice?.total || 0;

  //       setInvoices(
  //         invoices.map((inv) =>
  //           inv.id === invoiceId
  //             ? {
  //                 ...inv,
  //                 status: "paid",
  //                 amountPaid: total,
  //                 balanceDue: 0,
  //               }
  //             : inv
  //         )
  //       );
  //       toast.success("Invoice marked as paid!");
  //     } else {
  //       const errorData = await response.json();
  //       throw new Error(errorData.message || "Failed to update invoice");
  //     }
  //   } catch (err: any) {
  //     console.error("Error marking invoice as paid:", err);
  //     toast.error(err.message || "Failed to update invoice");
  //   }
  // };

  const totalPages = Math.ceil(filteredInvoices.length / itemsPerPage);
  const paginatedInvoices = filteredInvoices.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const resetFilters = () => {
    setStatusFilter("all");
    setCurrentPage(1);
  };

  // Calculate summary statistics
  const totalPaid = invoices
    .filter((inv) => inv.status === "paid")
    .reduce((sum, inv) => sum + inv.total, 0);

  const totalOutstanding = invoices
    .filter((inv) => inv.status === "unpaid" || inv.status === "partial")
    .reduce((sum, inv) => sum + inv.balanceDue, 0);

  const totalPartial = invoices
    .filter((inv) => inv.status === "partial")
    .reduce((sum, inv) => sum + inv.balanceDue, 0);

  if (loading) {
    return (
      <div className="page-body">
        <Breadcrumbs
          title="Invoices"
          mainTitle="Billing & Invoicing"
          parent="Finance"
        />
        <Container fluid>
          <Row>
            <Col sm="12">
              <Card>
                <CardBody className="text-center py-5">
                  <div className="spinner-border text-primary" role="status">
                    <span className="visually-hidden">Loading...</span>
                  </div>
                  <p className="mt-3 mb-0">Loading invoices...</p>
                </CardBody>
              </Card>
            </Col>
          </Row>
        </Container>
      </div>
    );
  }

  if (error) {
    return (
      <div className="page-body">
        <Breadcrumbs
          title="Invoices"
          mainTitle="Billing & Invoicing"
          parent="Finance"
        />
        <Container fluid>
          <Row>
            <Col sm="12">
              <Card>
                <CardBody className="text-center py-5">
                  <div className="text-danger mb-3">
                    <i className="fa fa-exclamation-triangle fa-3x"></i>
                  </div>
                  <h5 className="text-danger">Error Loading Invoices</h5>
                  <p className="text-muted">{error}</p>
                  <Button color="primary" onClick={fetchInvoices}>
                    <i className="fa fa-refresh me-2"></i>
                    Try Again
                  </Button>
                </CardBody>
              </Card>
            </Col>
          </Row>
        </Container>
      </div>
    );
  }

  return (
    <div className="page-body">
      <Breadcrumbs
        title="Invoices"
        mainTitle="Billing & Invoicing"
        parent="Finance"
      />

      <Container fluid>
        <Row>
          <Col sm="12">
            <Card>
              <CardBody>
                {/* Header with Actions */}
                <div className="d-flex justify-content-between align-items-center mb-4">
                  <h5 className="card-title mb-0 text-muted">
                    Invoice Management
                  </h5>
                  <div className="d-flex gap-2">
                    <Dropdown isOpen={dropdownOpen} toggle={toggleDropdown}>
                      <DropdownToggle
                        caret
                        className="text-muted"
                        style={{ padding: "7px" }}
                        color="outline-primary"
                      >
                        {statusFilter === "all" ? "All Status" : statusFilter}
                      </DropdownToggle>
                      <DropdownMenu>
                        <DropdownItem onClick={() => setStatusFilter("all")}>
                          All Status
                        </DropdownItem>
                        {/* <DropdownItem onClick={() => setStatusFilter("draft")}>
                          Draft
                        </DropdownItem> */}
                        <DropdownItem onClick={() => setStatusFilter("unpaid")}>
                          Unpaid
                        </DropdownItem>
                        <DropdownItem onClick={() => setStatusFilter("paid")}>
                          Paid
                        </DropdownItem>
                        <DropdownItem
                          onClick={() => setStatusFilter("partial")}
                        >
                          Partial
                        </DropdownItem>
                        {/* <DropdownItem
                          onClick={() => setStatusFilter("overdue")}
                        >
                          Overdue
                        </DropdownItem> */}
                      </DropdownMenu>
                    </Dropdown>

                    <div>
                      <Button color="outline-secondary" onClick={resetFilters}>
                        Clear Filters
                      </Button>
                    </div>

                    {/* <Button color="outline-primary" onClick={fetchInvoices}>
                      <i className="fa fa-refresh me-2"></i>
                      Refresh
                    </Button> */}

                    <Link href="/admin/invoices/create">
                      <Button color="primary">
                        <i className="fa fa-plus me-2"></i>
                        Create Invoice
                      </Button>
                    </Link>
                  </div>
                </div>

                {/* Debug info - can be removed in production */}
                {/* <div className="mb-3 p-2 bg-light rounded">
                  <small className="text-muted">
                    Found {invoices.length} unique invoices. Showing{" "}
                    {filteredInvoices.length} after filter.
                  </small>
                </div> */}

                {/* Invoices Table */}
                <div className="table-responsive">
                  <Table hover>
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>Invoice</th>
                        <th>Customer</th>
                        <th>Issue Date</th>
                        <th>Due Date</th>
                        <th>Total Amount</th>
                        <th>Balance Due</th>
                        <th>Status</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {paginatedInvoices.map((invoice, index) => (
                        <tr key={invoice.id}>
                          <td>
                            {(currentPage - 1) * itemsPerPage + index + 1}
                          </td>
                          <td>
                            <Link href={`/admin/invoices/${invoice.id}`}>
                              <strong className="text-primary no-wrap">
                                {invoice.invoiceNumber}
                              </strong>
                            </Link>
                            <br />
                            <small className="text-muted">
                              Job: {invoice.jobCardId}
                            </small>
                          </td>
                          <td>
                            <div>{invoice.customerName}</div>
                            <small className="text-muted">
                              {invoice.customerEmail || "No email"}
                            </small>
                          </td>
                          <td>
                            {new Date(invoice.issueDate).toLocaleDateString()}
                          </td>
                          <td>
                            {new Date(invoice.dueDate).toLocaleDateString()}
                          </td>
                          <td>
                            <strong>${invoice.total.toFixed(2)}</strong>
                          </td>
                          <td>
                            <strong
                              className={
                                invoice.balanceDue > 0
                                  ? "text-danger"
                                  : "text-success"
                              }
                            >
                              ${invoice.balanceDue.toFixed(2)}
                            </strong>
                          </td>
                          <td>{getStatusBadge(invoice.status)}</td>
                          <td>
                            <div className="d-flex gap-1">
                              <Link href={`/admin/invoices/${invoice.id}`}>
                                <Button color="primary" size="sm">
                                  <i className="fa fa-eye"></i>
                                </Button>
                              </Link>
                              <Link href={`/admin/payments/${invoice.id}`}>
                                <Button
                                  color="outline-info"
                                  size="sm"
                                  title="view payment"
                                >
                                  {/* <i className="icofont icofont-download-alt"></i> */}
                                  <i className="icofont icofont-credit-card"></i>
                                </Button>
                              </Link>

                              {/* {invoice.status === "unpaid" && (
                                <Button
                                  color="outline-success"
                                  size="sm"
                                  onClick={() => handleMarkAsPaid(invoice.id)}
                                  title="Mark as Paid"
                                >
                                  <i className="fa fa-check"></i>
                                </Button>
                              )} */}

                              {/* {invoice.status === "draft" && (
                                <>
                                  <Button
                                    color="outline-info"
                                    size="sm"
                                    onClick={() =>
                                      handleSendInvoice(invoice.id)
                                    }
                                    title="Send to Customer"
                                  >
                                    <i className="fa fa-paper-plane"></i>
                                  </Button>
                                  <Button
                                    color="outline-danger"
                                    size="sm"
                                    onClick={() =>
                                      handleDeleteInvoice(invoice.id)
                                    }
                                    title="Delete Invoice"
                                  >
                                    <i className="fa fa-trash"></i>
                                  </Button>
                                </>
                              )} */}
                            </div>
                          </td>
                        </tr>
                      ))}
                      {paginatedInvoices.length === 0 && (
                        <tr>
                          <td colSpan={8} className="text-center py-4">
                            <div className="text-muted">
                              No invoices found matching your criteria.
                            </div>
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </Table>
                </div>

                {/* Pagination and Info */}
                <div className="d-flex flex-column flex-md-row justify-content-between align-items-center gap-3 mt-4">
                  <div className="text-center text-md-start text-muted">
                    Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
                    {Math.min(
                      currentPage * itemsPerPage,
                      filteredInvoices.length
                    )}{" "}
                    of {filteredInvoices.length} entries
                  </div>
                  <CustomPagination
                    currentPage={currentPage}
                    totalPages={totalPages}
                    onPageChange={setCurrentPage}
                    showFirstLast={true}
                    maxVisiblePages={5}
                    paginationType="primary"
                    className="justify-content-center justify-content-md-end"
                  />
                </div>

                {/* Summary Cards */}
                {/* <Row className="mt-4">
                  <Col md="3">
                    <Card className="card-stats">
                      <CardBody>
                        <div className="text-center">
                          <h4 className="mb-0 text-primary">
                            {invoices.length}
                          </h4>
                          <span className="text-muted">Total Invoices</span>
                        </div>
                      </CardBody>
                    </Card>
                  </Col>
                  <Col md="3">
                    <Card className="card-stats">
                      <CardBody>
                        <div className="text-center">
                          <h4 className="mb-0 text-success">
                            ${totalPaid.toFixed(2)}
                          </h4>
                          <span className="text-muted">Total Paid</span>
                        </div>
                      </CardBody>
                    </Card>
                  </Col>
                  <Col md="3">
                    <Card className="card-stats">
                      <CardBody>
                        <div className="text-center">
                          <h4 className="mb-0 text-warning">
                            ${totalPartial.toFixed(2)}
                          </h4>
                          <span className="text-muted">Partial Payments</span>
                        </div>
                      </CardBody>
                    </Card>
                  </Col>
                  <Col md="3">
                    <Card className="card-stats">
                      <CardBody>
                        <div className="text-center">
                          <h4 className="mb-0 text-danger">
                            ${totalOutstanding.toFixed(2)}
                          </h4>
                          <span className="text-muted">Outstanding</span>
                        </div>
                      </CardBody>
                    </Card>
                  </Col>
                </Row> */}
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Container>

      <style jsx global>{`
        .card-stats {
          border: 1px solid #e6edef;
          box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
        }
        .no-wrap {
          white-space: nowrap;
        }
      `}</style>
    </div>
  );
}

export default withAuth(InvoicesPage, ["admin"]);
