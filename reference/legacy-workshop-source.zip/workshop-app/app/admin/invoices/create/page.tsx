// "use client";
// import Breadcrumbs from "@/CommonElements/Breadcrumbs";
// import {
//   Container,
//   Row,
//   Col,
//   Card,
//   CardBody,
//   Form,
//   FormGroup,
//   Label,
//   Input,
//   Button,
//   Table,
//   Badge,
// } from "reactstrap";
// import React, { useState, ChangeEvent } from "react";
// import { useRouter } from "next/navigation";
// import { Invoice, InvoiceItem, JobCard } from "@/Types/invoice";

// const mockJobCards: JobCard[] = [
//   {
//     id: 101,
//     jobNumber: "JC-2024-001",
//     customerId: 1,
//     customerName: "John Doe",
//     vehicle: "Toyota Camry 2020",
//     licensePlate: "ABC-123",
//     serviceType: "Brake Repair",
//     laborCost: 300.0,
//     partsCost: 120.0,
//     totalCost: 420.0,
//     status: "completed",
//     completedDate: "2024-01-15",
//   },
//   {
//     id: 102,
//     jobNumber: "JC-2024-002",
//     customerId: 2,
//     customerName: "Jane Smith",
//     vehicle: "Honda Civic 2019",
//     licensePlate: "XYZ-789",
//     serviceType: "Oil Change",
//     laborCost: 50.0,
//     partsCost: 75.0,
//     totalCost: 125.0,
//     status: "completed",
//     completedDate: "2024-01-16",
//   },
// ];

// function CreateInvoicePage() {
//   const router = useRouter();
//   const [selectedJobCard, setSelectedJobCard] = useState<JobCard | null>(null);
//   const [invoice, setInvoice] = useState<Partial<Invoice>>({
//     issueDate: new Date().toISOString().split("T")[0],
//     dueDate: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000)
//       .toISOString()
//       .split("T")[0],
//     taxRate: 8.5,
//     discount: 0,
//     notes: "",
//     terms: "Due upon receipt",
//     status: "draft",
//   });

//   const handleJobCardSelect = (jobCard: JobCard) => {
//     setSelectedJobCard(jobCard);
//     const invoiceItems: InvoiceItem[] = [
//       {
//         id: 1,
//         description: `${jobCard.serviceType} - Labor`,
//         type: "labor",
//         quantity: 1,
//         unitPrice: jobCard.laborCost,
//         total: jobCard.laborCost,
//       },
//       {
//         id: 2,
//         description: `${jobCard.serviceType} - Parts`,
//         type: "part",
//         quantity: 1,
//         unitPrice: jobCard.partsCost,
//         total: jobCard.partsCost,
//       },
//     ];

//     const subtotal = invoiceItems.reduce((sum, item) => sum + item.total, 0);
//     const taxAmount = (subtotal * 8.5) / 100;

//     setInvoice({
//       ...invoice,
//       jobCardId: jobCard.id,
//       customerId: jobCard.customerId,
//       customerName: jobCard.customerName,
//       items: invoiceItems,
//       subtotal,
//       taxAmount,
//       total: subtotal + taxAmount,
//       balanceDue: subtotal + taxAmount,
//     });
//   };

//   const handleInputChange = (field: string, value: string | number) => {
//     setInvoice((prev) => {
//       const updated = { ...prev, [field]: value };

//       // Recalculate totals if relevant fields change
//       if (field === "taxRate" || field === "discount") {
//         const subtotal =
//           updated.items?.reduce((sum, item) => sum + item.total, 0) || 0;
//         const taxAmount = (subtotal * (Number(updated.taxRate) || 0)) / 100;
//         const discountAmount = Number(updated.discount) || 0;
//         const total = subtotal + taxAmount - discountAmount;

//         return {
//           ...updated,
//           subtotal,
//           taxAmount,
//           total,
//           balanceDue: total - (updated.amountPaid || 0),
//         };
//       }

//       return updated;
//     });
//   };

//   const handleItemChange = (
//     index: number,
//     field: string,
//     value: string | number
//   ) => {
//     setInvoice((prev) => {
//       const updatedItems = prev.items?.map((item, i) => {
//         if (i === index) {
//           const updatedItem = { ...item, [field]: value };
//           if (field === "quantity" || field === "unitPrice") {
//             updatedItem.total = updatedItem.quantity * updatedItem.unitPrice;
//           }
//           return updatedItem;
//         }
//         return item;
//       });

//       const subtotal =
//         updatedItems?.reduce((sum, item) => sum + item.total, 0) || 0;
//       const taxAmount = (subtotal * (prev.taxRate || 0)) / 100;
//       const discountAmount = prev.discount || 0;
//       const total = subtotal + taxAmount - discountAmount;

//       return {
//         ...prev,
//         items: updatedItems,
//         subtotal,
//         taxAmount,
//         total,
//         balanceDue: total - (prev.amountPaid || 0),
//       };
//     });
//   };

//   const addNewItem = () => {
//     const newItem: InvoiceItem = {
//       id: Date.now(),
//       description: "",
//       type: "service",
//       quantity: 1,
//       unitPrice: 0,
//       total: 0,
//     };

//     setInvoice((prev) => ({
//       ...prev,
//       items: [...(prev.items || []), newItem],
//     }));
//   };

//   const removeItem = (index: number) => {
//     setInvoice((prev) => ({
//       ...prev,
//       items: prev.items?.filter((_, i) => i !== index),
//     }));
//   };

//   const handleSaveInvoice = (status: "draft" | "sent") => {
//     // Generate invoice number
//     const invoiceNumber = `INV-2024-${String(
//       invoice.id || Math.floor(Math.random() * 1000)
//     ).padStart(3, "0")}`;

//     const newInvoice: Invoice = {
//       id: Math.floor(Math.random() * 1000),
//       invoiceNumber,
//       jobCardId: invoice.jobCardId!,
//       customerId: invoice.customerId!,
//       customerName: invoice.customerName!,
//       customerEmail: "customer@example.com", // Would come from customer data
//       customerPhone: "+1 234 567 8900",
//       customerAddress: "123 Main St, City, State",
//       issueDate: invoice.issueDate!,
//       dueDate: invoice.dueDate!,
//       items: invoice.items || [],
//       subtotal: invoice.subtotal || 0,
//       taxRate: invoice.taxRate || 0,
//       taxAmount: invoice.taxAmount || 0,
//       discount: invoice.discount || 0,
//       total: invoice.total || 0,
//       amountPaid: 0,
//       balanceDue: invoice.total || 0,
//       status,
//       payments: [],
//       notes: invoice.notes || "",
//       terms: invoice.terms || "",
//       createdAt: new Date().toISOString(),
//       updatedAt: new Date().toISOString(),
//     };

//     console.log("Saving invoice:", newInvoice);
//     alert(
//       `Invoice ${status === "draft" ? "saved as draft" : "sent to customer"}!`
//     );
//     router.push("/invoices");
//   };

//   return (
//     <div className="page-body">
//       <Breadcrumbs
//         title="Create Invoice"
//         mainTitle="Billing & Invoicing"
//         parent="Invoices"
//       />

//       <Container fluid>
//         <Row>
//           <Col lg="8">
//             <Card>
//               <CardBody>
//                 <h5 className="card-title mb-4 text-muted">
//                   Create New Invoice
//                 </h5>

//                 {/* Job Card Selection */}
//                 <Card className="bg-light mb-4 text-muted">
//                   <CardBody>
//                     <h6 className="mb-3 text-muted">Select Job Card</h6>
//                     <div className="row g-2">
//                       {mockJobCards.map((jobCard) => (
//                         <div key={jobCard.id} className="col-md-6">
//                           <Card
//                             className={`cursor-pointer ${
//                               selectedJobCard?.id === jobCard.id
//                                 ? "border-primary"
//                                 : ""
//                             }`}
//                             onClick={() => handleJobCardSelect(jobCard)}
//                           >
//                             <CardBody>
//                               <div className="d-flex justify-content-between text-muted">
//                                 <div>
//                                   <h6 className="mb-1">{jobCard.jobNumber}</h6>
//                                   <p className="mb-1 text-muted">
//                                     {jobCard.customerName}
//                                   </p>
//                                   <small className="text-muted">
//                                     {jobCard.vehicle} • {jobCard.licensePlate}
//                                   </small>
//                                 </div>
//                                 <Badge color="success">
//                                   ${jobCard.totalCost.toFixed(2)}
//                                 </Badge>
//                               </div>
//                             </CardBody>
//                           </Card>
//                         </div>
//                       ))}
//                     </div>
//                   </CardBody>
//                 </Card>

//                 {selectedJobCard && (
//                   <>
//                     {/* Invoice Items */}
//                     <Card className="mb-4">
//                       <CardBody>
//                         <div className="d-flex justify-content-between align-items-center mb-3 text-muted">
//                           <h6 className="mb-0">Invoice Items</h6>
//                           <Button
//                             color="primary"
//                             size="sm"
//                             onClick={addNewItem}
//                           >
//                             <i className="fa fa-plus me-1"></i> Add Item
//                           </Button>
//                         </div>

//                         {/* Responsive wrapper */}
//                         <div className="table-responsive">
//                           <Table bordered hover>
//                             <thead>
//                               <tr>
//                                 <th>Description</th>
//                                 <th>Type</th>
//                                 <th>Qty</th>
//                                 <th>Unit Price</th>
//                                 <th>Total</th>
//                                 <th>Action</th>
//                               </tr>
//                             </thead>

//                             <tbody>
//                               {invoice.items?.map((item, index) => (
//                                 <tr key={item.id}>
//                                   <td
//                                     className="p-2"
//                                     style={{ minWidth: "200px" }}
//                                   >
//                                     <Input
//                                       type="text"
//                                       className="w-100"
//                                       value={item.description}
//                                       onChange={(e) =>
//                                         handleItemChange(
//                                           index,
//                                           "description",
//                                           e.target.value
//                                         )
//                                       }
//                                     />
//                                   </td>

//                                   <td
//                                     className="p-2"
//                                     style={{ minWidth: "130px" }}
//                                   >
//                                     <Input
//                                       type="select"
//                                       className="w-100"
//                                       value={item.type}
//                                       onChange={(e) =>
//                                         handleItemChange(
//                                           index,
//                                           "type",
//                                           e.target.value
//                                         )
//                                       }
//                                     >
//                                       <option value="labor">Labor</option>
//                                       <option value="part">Part</option>
//                                       <option value="service">Service</option>
//                                       <option value="other">Other</option>
//                                     </Input>
//                                   </td>

//                                   <td
//                                     className="p-2"
//                                     style={{ minWidth: "120px" }}
//                                   >
//                                     <Input
//                                       type="number"
//                                       className="w-100"
//                                       value={item.quantity}
//                                       min="1"
//                                       onChange={(e) =>
//                                         handleItemChange(
//                                           index,
//                                           "quantity",
//                                           Number(e.target.value)
//                                         )
//                                       }
//                                     />
//                                   </td>

//                                   <td
//                                     className="p-2"
//                                     style={{ minWidth: "150px" }}
//                                   >
//                                     <Input
//                                       type="number"
//                                       step="0.01"
//                                       className="w-100"
//                                       value={item.unitPrice}
//                                       onChange={(e) =>
//                                         handleItemChange(
//                                           index,
//                                           "unitPrice",
//                                           Number(e.target.value)
//                                         )
//                                       }
//                                     />
//                                   </td>

//                                   <td
//                                     className="p-2"
//                                     style={{ minWidth: "120px" }}
//                                   >
//                                     ${item.total.toFixed(2)}
//                                   </td>

//                                   <td
//                                     className="p-2"
//                                     style={{ minWidth: "100px" }}
//                                   >
//                                     <Button
//                                       color="outline-danger"
//                                       size="sm"
//                                       onClick={() => removeItem(index)}
//                                     >
//                                       <i className="fa fa-trash"></i>
//                                     </Button>
//                                   </td>
//                                 </tr>
//                               ))}
//                             </tbody>
//                           </Table>
//                         </div>
//                       </CardBody>
//                     </Card>

//                     {/* Invoice Details */}
//                     <Card>
//                       <CardBody>
//                         <h6 className="mb-3 text-muted">Invoice Details</h6>
//                         <Row className="text-muted">
//                           <Col md="6">
//                             <FormGroup>
//                               <Label>Issue Date</Label>
//                               <Input
//                                 type="date"
//                                 value={invoice.issueDate}
//                                 onChange={(e) =>
//                                   handleInputChange("issueDate", e.target.value)
//                                 }
//                               />
//                             </FormGroup>
//                           </Col>
//                           <Col md="6">
//                             <FormGroup>
//                               <Label>Due Date</Label>
//                               <Input
//                                 type="date"
//                                 value={invoice.dueDate}
//                                 onChange={(e) =>
//                                   handleInputChange("dueDate", e.target.value)
//                                 }
//                               />
//                             </FormGroup>
//                           </Col>
//                         </Row>
//                         <Row className="text-muted">
//                           <Col md="6">
//                             <FormGroup>
//                               <Label>Tax Rate (%)</Label>
//                               <Input
//                                 type="number"
//                                 step="0.1"
//                                 value={invoice.taxRate}
//                                 onChange={(e) =>
//                                   handleInputChange(
//                                     "taxRate",
//                                     Number(e.target.value)
//                                   )
//                                 }
//                               />
//                             </FormGroup>
//                           </Col>
//                           <Col md="6">
//                             <FormGroup>
//                               <Label>Discount ($)</Label>
//                               <Input
//                                 type="number"
//                                 step="0.01"
//                                 value={invoice.discount}
//                                 onChange={(e) =>
//                                   handleInputChange(
//                                     "discount",
//                                     Number(e.target.value)
//                                   )
//                                 }
//                               />
//                             </FormGroup>
//                           </Col>
//                         </Row>
//                         <FormGroup className="text-muted">
//                           <Label>Notes</Label>
//                           <Input
//                             type="textarea"
//                             rows="3"
//                             value={invoice.notes}
//                             onChange={(e) =>
//                               handleInputChange("notes", e.target.value)
//                             }
//                           />
//                         </FormGroup>
//                         <FormGroup className="text-muted">
//                           <Label>Terms & Conditions</Label>
//                           <Input
//                             type="textarea"
//                             rows="2"
//                             value={invoice.terms}
//                             onChange={(e) =>
//                               handleInputChange("terms", e.target.value)
//                             }
//                           />
//                         </FormGroup>
//                       </CardBody>
//                     </Card>
//                   </>
//                 )}
//               </CardBody>
//             </Card>
//           </Col>

//           {/* Invoice Summary */}
//           <Col lg="4">
//             <Card>
//               <CardBody className="text-muted">
//                 <h6 className="card-title mb-3 text-muted">Invoice Summary</h6>

//                 {selectedJobCard ? (
//                   <>
//                     <div className="mb-3">
//                       <strong>Customer:</strong> {invoice.customerName}
//                       <br />
//                       <strong>Job Card:</strong> JC-{invoice.jobCardId}
//                       <br />
//                       <strong>Vehicle:</strong> {selectedJobCard.vehicle}
//                     </div>

//                     <div className="border-top pt-3">
//                       <div className="d-flex justify-content-between mb-2">
//                         <span>Subtotal:</span>
//                         <span>${invoice.subtotal?.toFixed(2)}</span>
//                       </div>
//                       <div className="d-flex justify-content-between mb-2">
//                         <span>Tax ({invoice.taxRate}%):</span>
//                         <span>${invoice.taxAmount?.toFixed(2)}</span>
//                       </div>
//                       <div className="d-flex justify-content-between mb-2">
//                         <span>Discount:</span>
//                         <span>-${invoice.discount?.toFixed(2)}</span>
//                       </div>
//                       <div className="d-flex justify-content-between mb-2 border-top pt-2">
//                         <strong>Total:</strong>
//                         <strong>${invoice.total?.toFixed(2)}</strong>
//                       </div>
//                     </div>

//                     <div className="mt-4">
//                       <Button
//                         color="primary"
//                         className="w-100 mb-2"
//                         onClick={() => handleSaveInvoice("sent")}
//                       >
//                         <i className="fa fa-paper-plane me-2"></i>
//                         Send Invoice
//                       </Button>
//                       <Button
//                         color="outline-secondary"
//                         className="w-100"
//                         onClick={() => handleSaveInvoice("draft")}
//                       >
//                         <i className="fa fa-save me-2"></i>
//                         Save as Draft
//                       </Button>
//                     </div>
//                   </>
//                 ) : (
//                   <div className="text-center text-muted py-4">
//                     <i className="fa fa-file-invoice fa-3x mb-3"></i>
//                     <p>Select a job card to create an invoice</p>
//                   </div>
//                 )}
//               </CardBody>
//             </Card>
//           </Col>
//         </Row>
//       </Container>
//     </div>
//   );
// }

// export default CreateInvoicePage;

// card design for job cards
// "use client";
// import Breadcrumbs from "@/CommonElements/Breadcrumbs";
// import {
//   Container,
//   Row,
//   Col,
//   Card,
//   CardBody,
//   Form,
//   FormGroup,
//   Label,
//   Input,
//   Button,
//   Table,
//   Badge,
//   Alert,
//   Spinner,
// } from "reactstrap";
// import React, { useState, useEffect } from "react";
// import { useRouter } from "next/navigation";
// import { Invoice, InvoiceItem, JobCard } from "@/Types/invoice";
// // import { useAuth } from "@/AuthContext";
// import { toast } from "react-toastify";
// import { useAuth } from "@/helper/AuthContext";

// // API response types
// interface ApiJobCard {
//   id: string;
//   job_number: string;
//   customer_id: string;
//   customer_name: string;
//   vehicle_id?: string;
//   registration_number?: string;
//   model?: string;
//   total_cost?: string;
//   status: string;
//   completed_date?: string;
//   // Add other fields from your job card API
// }

// interface Customer {
//   id: string;
//   name: string;
//   email?: string;
//   phone?: string;
//   address?: string;
// }

// function CreateInvoicePage() {
//   const router = useRouter();
//   const { state } = useAuth();
//   const [loading, setLoading] = useState(true);
//   const [saving, setSaving] = useState(false);
//   const [jobCards, setJobCards] = useState<JobCard[]>([]);
//   const [customers, setCustomers] = useState<Customer[]>([]);
//   const [selectedJobCard, setSelectedJobCard] = useState<JobCard | null>(null);
//   const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(
//     null
//   );
//   const [error, setError] = useState<string | null>(null);

//   const [invoice, setInvoice] = useState<Partial<Invoice>>({
//     issueDate: new Date().toISOString().split("T")[0],
//     dueDate: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000)
//       .toISOString()
//       .split("T")[0],
//     taxRate: 8.5,
//     discount: 0,
//     notes: "",
//     terms: "Due upon receipt",
//     status: "draft",
//   });

//   // Fetch job cards and customers from API
//   useEffect(() => {
//     fetchJobCards();
//     fetchCustomers();
//   }, []);

//   const fetchJobCards = async () => {
//     try {
//       setLoading(true);
//       const token = state?.accessToken || localStorage.getItem("token");

//       // Fetch completed job cards
//       const response = await fetch("/api/jobcards?status=completed", {
//         headers: {
//           Authorization: `Bearer ${token}`,
//           "Content-Type": "application/json",
//         },
//       });

//       if (!response.ok) {
//         throw new Error("Failed to fetch job cards");
//       }

//       const data = await response.json();

//       // Transform API data to match JobCard type
//       const transformedJobCards: JobCard[] = data.data.map(
//         (apiJobCard: ApiJobCard) => ({
//           id: parseInt(apiJobCard.id),
//           jobNumber: apiJobCard.job_number,
//           customerId: parseInt(apiJobCard.customer_id),
//           customerName: apiJobCard.customer_name,
//           vehicle: apiJobCard.model || "Unknown Vehicle",
//           licensePlate: apiJobCard.registration_number || "N/A",
//           serviceType: "Service", // You might need to fetch this from job card details
//           laborCost: 0, // These would come from job card items/parts
//           partsCost: 0,
//           totalCost: parseFloat(apiJobCard.total_cost || "0"),
//           status: apiJobCard.status,
//           completedDate:
//             apiJobCard.completed_date || new Date().toISOString().split("T")[0],
//         })
//       );

//       setJobCards(transformedJobCards);
//     } catch (err: any) {
//       console.error("Error fetching job cards:", err);
//       setError(err.message);
//       toast.error("Failed to load job cards");
//     } finally {
//       setLoading(false);
//     }
//   };

//   const fetchCustomers = async () => {
//     try {
//       const token = state?.accessToken || localStorage.getItem("token");

//       const response = await fetch("/api/customers", {
//         headers: {
//           Authorization: `Bearer ${token}`,
//           "Content-Type": "application/json",
//         },
//       });

//       if (response.ok) {
//         const data = await response.json();
//         setCustomers(data.data || []);
//       }
//     } catch (err) {
//       console.error("Error fetching customers:", err);
//     }
//   };

//   const handleJobCardSelect = async (jobCard: JobCard) => {
//     try {
//       setLoading(true);
//       const token = state?.accessToken || localStorage.getItem("token");

//       // Fetch job card details to get items and parts
//       const response = await fetch(`/api/jobcards/${jobCard.id}`, {
//         headers: {
//           Authorization: `Bearer ${token}`,
//         },
//       });

//       if (response.ok) {
//         const jobCardDetails = await response.json();

//         // Create invoice items from job card items and parts
//         const invoiceItems: InvoiceItem[] = [];

//         // Add labor items
//         if (jobCardDetails.items && jobCardDetails.items.length > 0) {
//           jobCardDetails.items.forEach((item: any, index: number) => {
//             invoiceItems.push({
//               id: index + 1,
//               description: item.description || "Labor",
//               type: "labor",
//               quantity: item.labor_hours || 1,
//               unitPrice: item.labor_rate || 0,
//               total: (item.labor_hours || 1) * (item.labor_rate || 0),
//             });
//           });
//         }

//         // Add parts items
//         if (jobCardDetails.parts && jobCardDetails.parts.length > 0) {
//           jobCardDetails.parts.forEach((part: any, index: number) => {
//             invoiceItems.push({
//               id: invoiceItems.length + index + 1,
//               description: part.name || "Part",
//               type: "part",
//               quantity: part.quantity || 1,
//               unitPrice: part.unit_price || 0,
//               total: (part.quantity || 1) * (part.unit_price || 0),
//             });
//           });
//         }

//         // Calculate totals
//         const subtotal = invoiceItems.reduce(
//           (sum, item) => sum + item.total,
//           0
//         );
//         const taxAmount = (subtotal * 8.5) / 100;

//         // Find customer details
//         const customer = customers.find(
//           (c) => c.id === jobCard.customerId.toString()
//         );

//         setSelectedJobCard(jobCard);
//         setSelectedCustomer(customer || null);

//         setInvoice({
//           ...invoice,
//           jobCardId: jobCard.id,
//           customerId: jobCard.customerId,
//           customerName: jobCard.customerName,
//           customerEmail: customer?.email || "",
//           customerPhone: customer?.phone || "",
//           customerAddress: customer?.address || "",
//           items: invoiceItems,
//           subtotal,
//           taxAmount,
//           total: subtotal + taxAmount,
//           balanceDue: subtotal + taxAmount,
//         });
//       } else {
//         toast.error("Failed to load job card details");
//       }
//     } catch (err: any) {
//       console.error("Error fetching job card details:", err);
//       toast.error("Error loading job card details");
//     } finally {
//       setLoading(false);
//     }
//   };

//   const handleInputChange = (field: string, value: string | number) => {
//     setInvoice((prev) => {
//       const updated = { ...prev, [field]: value };

//       // Recalculate totals if relevant fields change
//       if (field === "taxRate" || field === "discount") {
//         const subtotal =
//           updated.items?.reduce((sum, item) => sum + item.total, 0) || 0;
//         const taxAmount = (subtotal * (Number(updated.taxRate) || 0)) / 100;
//         const discountAmount = Number(updated.discount) || 0;
//         const total = subtotal + taxAmount - discountAmount;

//         return {
//           ...updated,
//           subtotal,
//           taxAmount,
//           total,
//           balanceDue: total - (updated.amountPaid || 0),
//         };
//       }

//       return updated;
//     });
//   };

//   const handleItemChange = (
//     index: number,
//     field: string,
//     value: string | number
//   ) => {
//     setInvoice((prev) => {
//       const updatedItems = prev.items?.map((item, i) => {
//         if (i === index) {
//           const updatedItem = { ...item, [field]: value };
//           if (field === "quantity" || field === "unitPrice") {
//             updatedItem.total = updatedItem.quantity * updatedItem.unitPrice;
//           }
//           return updatedItem;
//         }
//         return item;
//       });

//       const subtotal =
//         updatedItems?.reduce((sum, item) => sum + item.total, 0) || 0;
//       const taxAmount = (subtotal * (prev.taxRate || 0)) / 100;
//       const discountAmount = prev.discount || 0;
//       const total = subtotal + taxAmount - discountAmount;

//       return {
//         ...prev,
//         items: updatedItems,
//         subtotal,
//         taxAmount,
//         total,
//         balanceDue: total - (prev.amountPaid || 0),
//       };
//     });
//   };

//   const addNewItem = () => {
//     const newItem: InvoiceItem = {
//       id: Date.now(),
//       description: "",
//       type: "service",
//       quantity: 1,
//       unitPrice: 0,
//       total: 0,
//     };

//     setInvoice((prev) => ({
//       ...prev,
//       items: [...(prev.items || []), newItem],
//     }));
//   };

//   const removeItem = (index: number) => {
//     setInvoice((prev) => ({
//       ...prev,
//       items: prev.items?.filter((_, i) => i !== index),
//     }));
//   };

//   const handleSaveInvoice = async (status: "draft" | "unpaid") => {
//     if (!selectedJobCard) {
//       toast.error("Please select a job card");
//       return;
//     }

//     if (!invoice.items || invoice.items.length === 0) {
//       toast.error("Please add at least one invoice item");
//       return;
//     }

//     try {
//       setSaving(true);
//       const token = state?.accessToken || localStorage.getItem("token");

//       // Prepare items for API (remove id and total as they'll be calculated on backend)
//       const apiItems = invoice.items.map(({ id, total, ...rest }) => rest);

//       // Prepare the payload based on your API structure
//       const payload = {
//         issue_date: invoice.issueDate,
//         due_date: invoice.dueDate,
//         tax_amount: invoice.taxAmount,
//         discount_amount: invoice.discount,
//         invoice_number: `INV-${Date.now().toString().slice(-6)}`, // Generate a unique number
//         job_card_id: selectedJobCard.id.toString(),
//         customer_id:
//           selectedCustomer?.id || selectedJobCard.customerId.toString(),
//         subtotal: invoice.subtotal,
//         total_amount: invoice.total,
//         status: status,
//         notes: invoice.notes,
//         terms: invoice.terms,
//         items: apiItems,
//         // Add customer details if needed
//         customer_name: selectedCustomer?.name || invoice.customerName,
//         customer_email: selectedCustomer?.email || invoice.customerEmail,
//         customer_phone: selectedCustomer?.phone || invoice.customerPhone,
//         customer_address: selectedCustomer?.address || invoice.customerAddress,
//       };

//       console.log("Sending invoice payload:", payload);

//       const response = await fetch("/api/invoices", {
//         method: "POST",
//         headers: {
//           "Content-Type": "application/json",
//           Authorization: `Bearer ${token}`,
//         },
//         body: JSON.stringify(payload),
//       });

//       if (response.ok) {
//         const result = await response.json();
//         toast.success(
//           `Invoice ${
//             status === "draft" ? "saved as draft" : "created successfully"
//           }!`
//         );

//         // Redirect to invoices page
//         setTimeout(() => {
//           router.push("/admin/invoices");
//         }, 1500);
//       } else {
//         const errorData = await response.json();
//         toast.error(errorData.message || "Failed to create invoice");
//       }
//     } catch (err: any) {
//       console.error("Error creating invoice:", err);
//       toast.error("Failed to create invoice");
//     } finally {
//       setSaving(false);
//     }
//   };

//   if (loading && !selectedJobCard) {
//     return (
//       <div className="page-body">
//         <Breadcrumbs
//           title="Create Invoice"
//           mainTitle="Billing & Invoicing"
//           parent="Invoices"
//         />
//         <Container fluid>
//           <Row>
//             <Col lg="12">
//               <Card>
//                 <CardBody className="text-center py-5">
//                   <Spinner color="primary" />
//                   <p className="mt-3">Loading job cards...</p>
//                 </CardBody>
//               </Card>
//             </Col>
//           </Row>
//         </Container>
//       </div>
//     );
//   }

//   return (
//     <div className="page-body">
//       <Breadcrumbs
//         title="Create Invoice"
//         mainTitle="Billing & Invoicing"
//         parent="Invoices"
//       />

//       <Container fluid>
//         <Row>
//           <Col lg="8">
//             <Card>
//               <CardBody>
//                 <h5 className="card-title mb-4 text-muted">
//                   Create New Invoice
//                 </h5>

//                 {error && (
//                   <Alert color="danger" className="mb-4">
//                     {error}
//                   </Alert>
//                 )}

//                 {/* Job Card Selection */}
//                 <Card className="bg-light mb-4">
//                   <CardBody>
//                     <h6 className="mb-3 text-muted">Select Job Card</h6>

//                     {jobCards.length === 0 ? (
//                       <div className="text-center py-3">
//                         <p className="text-muted mb-3">
//                           No completed job cards found
//                         </p>
//                         <Button color="primary" onClick={fetchJobCards}>
//                           <i className="fa fa-refresh me-2"></i>
//                           Refresh
//                         </Button>
//                       </div>
//                     ) : (
//                       <div className="row g-2">
//                         {jobCards.map((jobCard) => (
//                           <div key={jobCard.id} className="col-md-6">
//                             <Card
//                               className={`cursor-pointer ${
//                                 selectedJobCard?.id === jobCard.id
//                                   ? "border-primary"
//                                   : ""
//                               }`}
//                               onClick={() => handleJobCardSelect(jobCard)}
//                               style={{ cursor: "pointer" }}
//                             >
//                               <CardBody>
//                                 <div className="d-flex justify-content-between">
//                                   <div>
//                                     <h6 className="mb-1">
//                                       {jobCard.jobNumber}
//                                     </h6>
//                                     <p className="mb-1 text-muted">
//                                       {jobCard.customerName}
//                                     </p>
//                                     <small className="text-muted">
//                                       {jobCard.vehicle} • {jobCard.licensePlate}
//                                     </small>
//                                     <br />
//                                     <small className="text-muted">
//                                       Completed: {jobCard.completedDate}
//                                     </small>
//                                   </div>
//                                   <Badge color="success">
//                                     ${jobCard.totalCost.toFixed(2)}
//                                   </Badge>
//                                 </div>
//                               </CardBody>
//                             </Card>
//                           </div>
//                         ))}
//                       </div>
//                     )}
//                   </CardBody>
//                 </Card>

//                 {selectedJobCard && (
//                   <>
//                     {/* Customer Information */}
//                     <Card className="mb-4">
//                       <CardBody>
//                         <h6 className="mb-3 text-muted">
//                           Customer Information
//                         </h6>
//                         <Row>
//                           <Col md="6">
//                             <FormGroup>
//                               <Label>Customer Name</Label>
//                               <Input
//                                 type="text"
//                                 value={invoice.customerName || ""}
//                                 disabled
//                               />
//                             </FormGroup>
//                           </Col>
//                           <Col md="6">
//                             <FormGroup>
//                               <Label>Customer Email</Label>
//                               <Input
//                                 type="email"
//                                 value={invoice.customerEmail || ""}
//                                 onChange={(e) =>
//                                   handleInputChange(
//                                     "customerEmail",
//                                     e.target.value
//                                   )
//                                 }
//                               />
//                             </FormGroup>
//                           </Col>
//                           <Col md="6">
//                             <FormGroup>
//                               <Label>Customer Phone</Label>
//                               <Input
//                                 type="text"
//                                 value={invoice.customerPhone || ""}
//                                 onChange={(e) =>
//                                   handleInputChange(
//                                     "customerPhone",
//                                     e.target.value
//                                   )
//                                 }
//                               />
//                             </FormGroup>
//                           </Col>
//                           <Col md="6">
//                             <FormGroup>
//                               <Label>Customer Address</Label>
//                               <Input
//                                 type="text"
//                                 value={invoice.customerAddress || ""}
//                                 onChange={(e) =>
//                                   handleInputChange(
//                                     "customerAddress",
//                                     e.target.value
//                                   )
//                                 }
//                               />
//                             </FormGroup>
//                           </Col>
//                         </Row>
//                       </CardBody>
//                     </Card>

//                     {/* Invoice Items */}
//                     <Card className="mb-4">
//                       <CardBody>
//                         <div className="d-flex justify-content-between align-items-center mb-3 text-muted">
//                           <h6 className="mb-0">Invoice Items</h6>
//                           <Button
//                             color="primary"
//                             size="sm"
//                             onClick={addNewItem}
//                           >
//                             <i className="fa fa-plus me-1"></i> Add Item
//                           </Button>
//                         </div>

//                         <div className="table-responsive">
//                           <Table bordered hover>
//                             <thead>
//                               <tr>
//                                 <th>Description</th>
//                                 <th>Type</th>
//                                 <th>Qty</th>
//                                 <th>Unit Price</th>
//                                 <th>Total</th>
//                                 <th>Action</th>
//                               </tr>
//                             </thead>

//                             <tbody>
//                               {invoice.items?.map((item, index) => (
//                                 <tr key={item.id}>
//                                   <td
//                                     className="p-2"
//                                     style={{ minWidth: "200px" }}
//                                   >
//                                     <Input
//                                       type="text"
//                                       className="w-100"
//                                       value={item.description}
//                                       onChange={(e) =>
//                                         handleItemChange(
//                                           index,
//                                           "description",
//                                           e.target.value
//                                         )
//                                       }
//                                     />
//                                   </td>

//                                   <td
//                                     className="p-2"
//                                     style={{ minWidth: "130px" }}
//                                   >
//                                     <Input
//                                       type="select"
//                                       className="w-100"
//                                       value={item.type}
//                                       onChange={(e) =>
//                                         handleItemChange(
//                                           index,
//                                           "type",
//                                           e.target.value
//                                         )
//                                       }
//                                     >
//                                       <option value="labor">Labor</option>
//                                       <option value="part">Part</option>
//                                       <option value="service">Service</option>
//                                       <option value="other">Other</option>
//                                     </Input>
//                                   </td>

//                                   <td
//                                     className="p-2"
//                                     style={{ minWidth: "120px" }}
//                                   >
//                                     <Input
//                                       type="number"
//                                       className="w-100"
//                                       value={item.quantity}
//                                       min="1"
//                                       onChange={(e) =>
//                                         handleItemChange(
//                                           index,
//                                           "quantity",
//                                           Number(e.target.value)
//                                         )
//                                       }
//                                     />
//                                   </td>

//                                   <td
//                                     className="p-2"
//                                     style={{ minWidth: "150px" }}
//                                   >
//                                     <Input
//                                       type="number"
//                                       step="0.01"
//                                       className="w-100"
//                                       value={item.unitPrice}
//                                       onChange={(e) =>
//                                         handleItemChange(
//                                           index,
//                                           "unitPrice",
//                                           Number(e.target.value)
//                                         )
//                                       }
//                                     />
//                                   </td>

//                                   <td
//                                     className="p-2"
//                                     style={{ minWidth: "120px" }}
//                                   >
//                                     ${item.total.toFixed(2)}
//                                   </td>

//                                   <td
//                                     className="p-2"
//                                     style={{ minWidth: "100px" }}
//                                   >
//                                     <Button
//                                       color="outline-danger"
//                                       size="sm"
//                                       onClick={() => removeItem(index)}
//                                     >
//                                       <i className="fa fa-trash"></i>
//                                     </Button>
//                                   </td>
//                                 </tr>
//                               ))}
//                             </tbody>
//                           </Table>
//                         </div>
//                       </CardBody>
//                     </Card>

//                     {/* Invoice Details */}
//                     <Card>
//                       <CardBody>
//                         <h6 className="mb-3 text-muted">Invoice Details</h6>
//                         <Row className="text-muted">
//                           <Col md="6">
//                             <FormGroup>
//                               <Label>Issue Date</Label>
//                               <Input
//                                 type="date"
//                                 value={invoice.issueDate}
//                                 onChange={(e) =>
//                                   handleInputChange("issueDate", e.target.value)
//                                 }
//                               />
//                             </FormGroup>
//                           </Col>
//                           <Col md="6">
//                             <FormGroup>
//                               <Label>Due Date</Label>
//                               <Input
//                                 type="date"
//                                 value={invoice.dueDate}
//                                 onChange={(e) =>
//                                   handleInputChange("dueDate", e.target.value)
//                                 }
//                               />
//                             </FormGroup>
//                           </Col>
//                         </Row>
//                         <Row className="text-muted">
//                           <Col md="6">
//                             <FormGroup>
//                               <Label>Tax Rate (%)</Label>
//                               <Input
//                                 type="number"
//                                 step="0.1"
//                                 value={invoice.taxRate}
//                                 onChange={(e) =>
//                                   handleInputChange(
//                                     "taxRate",
//                                     Number(e.target.value)
//                                   )
//                                 }
//                               />
//                             </FormGroup>
//                           </Col>
//                           <Col md="6">
//                             <FormGroup>
//                               <Label>Discount ($)</Label>
//                               <Input
//                                 type="number"
//                                 step="0.01"
//                                 value={invoice.discount}
//                                 onChange={(e) =>
//                                   handleInputChange(
//                                     "discount",
//                                     Number(e.target.value)
//                                   )
//                                 }
//                               />
//                             </FormGroup>
//                           </Col>
//                         </Row>
//                         <FormGroup className="text-muted">
//                           <Label>Notes</Label>
//                           <Input
//                             type="textarea"
//                             rows="3"
//                             value={invoice.notes}
//                             onChange={(e) =>
//                               handleInputChange("notes", e.target.value)
//                             }
//                           />
//                         </FormGroup>
//                         <FormGroup className="text-muted">
//                           <Label>Terms & Conditions</Label>
//                           <Input
//                             type="textarea"
//                             rows="2"
//                             value={invoice.terms}
//                             onChange={(e) =>
//                               handleInputChange("terms", e.target.value)
//                             }
//                           />
//                         </FormGroup>
//                       </CardBody>
//                     </Card>
//                   </>
//                 )}
//               </CardBody>
//             </Card>
//           </Col>

//           {/* Invoice Summary */}
//           <Col lg="4">
//             <Card>
//               <CardBody className="text-muted">
//                 <h6 className="card-title mb-3 text-muted">Invoice Summary</h6>

//                 {selectedJobCard ? (
//                   <>
//                     <div className="mb-3">
//                       <strong>Customer:</strong> {invoice.customerName}
//                       <br />
//                       <strong>Job Card:</strong> {selectedJobCard.jobNumber}
//                       <br />
//                       <strong>Vehicle:</strong> {selectedJobCard.vehicle}
//                       <br />
//                       <strong>License:</strong> {selectedJobCard.licensePlate}
//                     </div>

//                     <div className="border-top pt-3">
//                       <div className="d-flex justify-content-between mb-2">
//                         <span>Subtotal:</span>
//                         <span>${invoice.subtotal?.toFixed(2) || "0.00"}</span>
//                       </div>
//                       <div className="d-flex justify-content-between mb-2">
//                         <span>Tax ({invoice.taxRate}%):</span>
//                         <span>${invoice.taxAmount?.toFixed(2) || "0.00"}</span>
//                       </div>
//                       <div className="d-flex justify-content-between mb-2">
//                         <span>Discount:</span>
//                         <span>-${invoice.discount?.toFixed(2) || "0.00"}</span>
//                       </div>
//                       <div className="d-flex justify-content-between mb-2 border-top pt-2">
//                         <strong>Total:</strong>
//                         <strong>${invoice.total?.toFixed(2) || "0.00"}</strong>
//                       </div>
//                     </div>

//                     <div className="mt-4">
//                       <Button
//                         color="primary"
//                         className="w-100 mb-2"
//                         onClick={() => handleSaveInvoice("unpaid")}
//                         disabled={saving}
//                       >
//                         {saving ? (
//                           <>
//                             <Spinner size="sm" className="me-2" />
//                             Creating...
//                           </>
//                         ) : (
//                           <>
//                             <i className="fa fa-paper-plane me-2"></i>
//                             Create Invoice
//                           </>
//                         )}
//                       </Button>
//                       <Button
//                         color="outline-secondary"
//                         className="w-100"
//                         onClick={() => handleSaveInvoice("draft")}
//                         disabled={saving}
//                       >
//                         {saving ? (
//                           <>
//                             <Spinner size="sm" className="me-2" />
//                             Saving...
//                           </>
//                         ) : (
//                           <>
//                             <i className="fa fa-save me-2"></i>
//                             Save as Draft
//                           </>
//                         )}
//                       </Button>
//                       <Button
//                         color="outline-danger"
//                         className="w-100 mt-2"
//                         onClick={() => router.push("/admin/invoices")}
//                         disabled={saving}
//                       >
//                         Cancel
//                       </Button>
//                     </div>
//                   </>
//                 ) : (
//                   <div className="text-center text-muted py-4">
//                     <i className="fa fa-file-invoice fa-3x mb-3"></i>
//                     <p>Select a job card to create an invoice</p>
//                   </div>
//                 )}
//               </CardBody>
//             </Card>
//           </Col>
//         </Row>
//       </Container>

//       <style jsx>{`
//         .cursor-pointer {
//           cursor: pointer;
//         }
//       `}</style>
//     </div>
//   );
// }

// export default CreateInvoicePage;

// searchable dropdown for job cards
// "use client";
// import Breadcrumbs from "@/CommonElements/Breadcrumbs";
// import {
//   Container,
//   Row,
//   Col,
//   Card,
//   CardBody,
//   Form,
//   FormGroup,
//   Label,
//   Input,
//   Button,
//   Table,
//   Badge,
//   Alert,
//   Spinner,
//   Dropdown,
//   DropdownToggle,
//   DropdownMenu,
//   DropdownItem,
// } from "reactstrap";
// import React, { useState, useEffect, useRef } from "react";
// import { useRouter } from "next/navigation";
// import { Invoice, InvoiceItem, JobCard } from "@/Types/invoice";

// import { toast } from "react-toastify";
// import { useAuth } from "@/helper/AuthContext";

// // API response types
// interface ApiJobCard {
//   id: string;
//   job_number: string;
//   customer_id: string;
//   customer_name: string;
//   vehicle_id?: string;
//   registration_number?: string;
//   model?: string;
//   total_cost?: string;
//   status: string;
//   completed_date?: string;
// }

// interface Customer {
//   id: string;
//   name: string;
//   email?: string;
//   phone?: string;
//   address?: string;
// }

// function CreateInvoicePage() {
//   const router = useRouter();
//   const { state } = useAuth();
//   const [loading, setLoading] = useState(true);
//   const [saving, setSaving] = useState(false);
//   const [jobCards, setJobCards] = useState<JobCard[]>([]);
//   const [customers, setCustomers] = useState<Customer[]>([]);
//   const [selectedJobCard, setSelectedJobCard] = useState<JobCard | null>(null);
//   const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(
//     null
//   );
//   const [error, setError] = useState<string | null>(null);

//   // Dropdown state
//   const [dropdownOpen, setDropdownOpen] = useState(false);
//   const [searchTerm, setSearchTerm] = useState("");
//   const dropdownRef = useRef<HTMLDivElement>(null);

//   const [invoice, setInvoice] = useState<Partial<Invoice>>({
//     issueDate: new Date().toISOString().split("T")[0],
//     dueDate: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000)
//       .toISOString()
//       .split("T")[0],
//     taxRate: 8.5,
//     discount: 0,
//     notes: "",
//     terms: "Due upon receipt",
//     status: "draft",
//   });

//   // Fetch job cards and customers from API
//   useEffect(() => {
//     fetchJobCards();
//     fetchCustomers();
//   }, []);

//   // Close dropdown when clicking outside
//   useEffect(() => {
//     const handleClickOutside = (event: MouseEvent) => {
//       if (
//         dropdownRef.current &&
//         !dropdownRef.current.contains(event.target as Node)
//       ) {
//         setDropdownOpen(false);
//       }
//     };

//     document.addEventListener("mousedown", handleClickOutside);
//     return () => {
//       document.removeEventListener("mousedown", handleClickOutside);
//     };
//   }, []);

//   const fetchJobCards = async () => {
//     try {
//       setLoading(true);
//       const token = state?.accessToken || localStorage.getItem("token");

//       // Fetch completed job cards
//       const response = await fetch("/api/jobcards", {
//         headers: {
//           Authorization: `Bearer ${token}`,
//           "Content-Type": "application/json",
//         },
//       });

//       if (!response.ok) {
//         throw new Error("Failed to fetch job cards");
//       }

//       const data = await response.json();

//       // Transform API data to match JobCard type
//       const transformedJobCards: JobCard[] = data.data.map(
//         (apiJobCard: ApiJobCard) => ({
//           id: parseInt(apiJobCard.id),
//           jobNumber: apiJobCard.job_number,
//           customerId: parseInt(apiJobCard.customer_id),
//           customerName: apiJobCard.customer_name,
//           vehicle: apiJobCard.model || "Unknown Vehicle",
//           licensePlate: apiJobCard.registration_number || "N/A",
//           serviceType: "Service",
//           laborCost: 0,
//           partsCost: 0,
//           totalCost: parseFloat(apiJobCard.total_cost || "0"),
//           status: apiJobCard.status,
//           completedDate:
//             apiJobCard.completed_date || new Date().toISOString().split("T")[0],
//         })
//       );
//       setJobCards(transformedJobCards);

//       if (data.data && Array.isArray(data.data)) {
//         const jobsWithcompletedStatus = data.data.filter(
//           (status: any) => status.status == "completed"
//         );
//         // setJobCards(data.data);
//         setJobCards(jobsWithcompletedStatus);
//         // setFilteredJobs(jobsWithTechnicians);
//       } else {
//         toast.error("Invalid data format received from API");
//         setJobCards([]);
//         // setFilteredJobs([]);
//       }
//     } catch (err: any) {
//       console.error("Error fetching job cards:", err);
//       setError(err.message);
//       toast.error("Failed to load job cards");
//     } finally {
//       setLoading(false);
//     }
//   };

//   const fetchCustomers = async () => {
//     try {
//       const token = state?.accessToken || localStorage.getItem("token");

//       const response = await fetch("/api/customers", {
//         headers: {
//           Authorization: `Bearer ${token}`,
//           "Content-Type": "application/json",
//         },
//       });

//       if (response.ok) {
//         const data = await response.json();
//         setCustomers(data.data || []);
//       }
//     } catch (err) {
//       console.error("Error fetching customers:", err);
//     }
//   };

//   // Filter job cards based on search term
//   const filteredJobCards = jobCards.filter(
//     (jobCard) =>
//       jobCard.jobNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
//       jobCard.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
//       jobCard.vehicle.toLowerCase().includes(searchTerm.toLowerCase())
//   );

//   const toggleDropdown = () => setDropdownOpen(!dropdownOpen);

//   const handleJobCardSelect = async (jobCard: JobCard) => {
//     try {
//       setLoading(true);
//       const token = state?.accessToken || localStorage.getItem("token");

//       // Fetch job card details to get items and parts
//       const response = await fetch(`/api/jobcards/${jobCard.id}`, {
//         headers: {
//           Authorization: `Bearer ${token}`,
//         },
//       });

//       if (response.ok) {
//         const jobCardDetails = await response.json();

//         // Create invoice items from job card items and parts
//         const invoiceItems: InvoiceItem[] = [];

//         // Add labor items
//         if (jobCardDetails.items && jobCardDetails.items.length > 0) {
//           jobCardDetails.items.forEach((item: any, index: number) => {
//             invoiceItems.push({
//               id: index + 1,
//               description: item.description || "Labor",
//               type: "labor",
//               quantity: item.labor_hours || 1,
//               unitPrice: item.labor_rate || 0,
//               total: (item.labor_hours || 1) * (item.labor_rate || 0),
//             });
//           });
//         }

//         // Add parts items
//         if (jobCardDetails.parts && jobCardDetails.parts.length > 0) {
//           jobCardDetails.parts.forEach((part: any, index: number) => {
//             invoiceItems.push({
//               id: invoiceItems.length + index + 1,
//               description: part.name || "Part",
//               type: "part",
//               quantity: part.quantity || 1,
//               unitPrice: part.unit_price || 0,
//               total: (part.quantity || 1) * (part.unit_price || 0),
//             });
//           });
//         }

//         // Calculate totals
//         const subtotal = invoiceItems.reduce(
//           (sum, item) => sum + item.total,
//           0
//         );
//         const taxAmount = (subtotal * 8.5) / 100;

//         // Find customer details
//         const customer = customers.find(
//           (c) => c.id === jobCard.customerId.toString()
//         );

//         setSelectedJobCard(jobCard);
//         setSelectedCustomer(customer || null);
//         setSearchTerm(jobCard.jobNumber); // Update search term with selected job card
//         setDropdownOpen(false); // Close dropdown after selection

//         setInvoice({
//           ...invoice,
//           jobCardId: jobCard.id,
//           customerId: jobCard.customerId,
//           customerName: jobCard.customerName,
//           customerEmail: customer?.email || "",
//           customerPhone: customer?.phone || "",
//           customerAddress: customer?.address || "",
//           items: invoiceItems,
//           subtotal,
//           taxAmount,
//           total: subtotal + taxAmount,
//           balanceDue: subtotal + taxAmount,
//         });
//       } else {
//         toast.error("Failed to load job card details");
//       }
//     } catch (err: any) {
//       console.error("Error fetching job card details:", err);
//       toast.error("Error loading job card details");
//     } finally {
//       setLoading(false);
//     }
//   };

//   const clearSelection = () => {
//     setSelectedJobCard(null);
//     setSelectedCustomer(null);
//     setSearchTerm("");
//     setInvoice({
//       issueDate: new Date().toISOString().split("T")[0],
//       dueDate: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000)
//         .toISOString()
//         .split("T")[0],
//       taxRate: 8.5,
//       discount: 0,
//       notes: "",
//       terms: "Due upon receipt",
//       status: "draft",
//     });
//   };

//   const handleInputChange = (field: string, value: string | number) => {
//     setInvoice((prev) => {
//       const updated = { ...prev, [field]: value };

//       if (field === "taxRate" || field === "discount") {
//         const subtotal =
//           updated.items?.reduce((sum, item) => sum + item.total, 0) || 0;
//         const taxAmount = (subtotal * (Number(updated.taxRate) || 0)) / 100;
//         const discountAmount = Number(updated.discount) || 0;
//         const total = subtotal + taxAmount - discountAmount;

//         return {
//           ...updated,
//           subtotal,
//           taxAmount,
//           total,
//           balanceDue: total - (updated.amountPaid || 0),
//         };
//       }

//       return updated;
//     });
//   };

//   const handleItemChange = (
//     index: number,
//     field: string,
//     value: string | number
//   ) => {
//     setInvoice((prev) => {
//       const updatedItems = prev.items?.map((item, i) => {
//         if (i === index) {
//           const updatedItem = { ...item, [field]: value };
//           if (field === "quantity" || field === "unitPrice") {
//             updatedItem.total = updatedItem.quantity * updatedItem.unitPrice;
//           }
//           return updatedItem;
//         }
//         return item;
//       });

//       const subtotal =
//         updatedItems?.reduce((sum, item) => sum + item.total, 0) || 0;
//       const taxAmount = (subtotal * (prev.taxRate || 0)) / 100;
//       const discountAmount = prev.discount || 0;
//       const total = subtotal + taxAmount - discountAmount;

//       return {
//         ...prev,
//         items: updatedItems,
//         subtotal,
//         taxAmount,
//         total,
//         balanceDue: total - (prev.amountPaid || 0),
//       };
//     });
//   };

//   const addNewItem = () => {
//     const newItem: InvoiceItem = {
//       id: Date.now(),
//       description: "",
//       type: "service",
//       quantity: 1,
//       unitPrice: 0,
//       total: 0,
//     };

//     setInvoice((prev) => ({
//       ...prev,
//       items: [...(prev.items || []), newItem],
//     }));
//   };

//   const removeItem = (index: number) => {
//     setInvoice((prev) => ({
//       ...prev,
//       items: prev.items?.filter((_, i) => i !== index),
//     }));
//   };

//   const handleSaveInvoice = async (status: "draft" | "unpaid") => {
//     if (!selectedJobCard) {
//       toast.error("Please select a job card");
//       return;
//     }

//     if (!invoice.items || invoice.items.length === 0) {
//       toast.error("Please add at least one invoice item");
//       return;
//     }

//     try {
//       setSaving(true);
//       const token = state?.accessToken || localStorage.getItem("token");

//       // Prepare items for API
//       const apiItems = invoice.items.map(({ id, total, ...rest }) => rest);

//       // Prepare the payload
//       const payload = {
//         issue_date: invoice.issueDate,
//         due_date: invoice.dueDate,
//         tax_amount: invoice.taxAmount,
//         discount_amount: invoice.discount,
//         invoice_number: `INV-${Date.now().toString().slice(-6)}`,
//         job_card_id: selectedJobCard.id.toString(),
//         customer_id:
//           selectedCustomer?.id || selectedJobCard.customerId.toString(),
//         subtotal: invoice.subtotal,
//         total_amount: invoice.total,
//         status: status,
//         notes: invoice.notes,
//         terms: invoice.terms,
//         items: apiItems,
//         customer_name: selectedCustomer?.name || invoice.customerName,
//         customer_email: selectedCustomer?.email || invoice.customerEmail,
//         customer_phone: selectedCustomer?.phone || invoice.customerPhone,
//         customer_address: selectedCustomer?.address || invoice.customerAddress,
//       };

//       const response = await fetch("/api/invoices", {
//         method: "POST",
//         headers: {
//           "Content-Type": "application/json",
//           Authorization: `Bearer ${token}`,
//         },
//         body: JSON.stringify(payload),
//       });

//       if (response.ok) {
//         const result = await response.json();
//         toast.success(
//           `Invoice ${
//             status === "draft" ? "saved as draft" : "created successfully"
//           }!`
//         );

//         setTimeout(() => {
//           router.push("/admin/invoices");
//         }, 1500);
//       } else {
//         const errorData = await response.json();
//         toast.error(errorData.message || "Failed to create invoice");
//       }
//     } catch (err: any) {
//       console.error("Error creating invoice:", err);
//       toast.error("Failed to create invoice");
//     } finally {
//       setSaving(false);
//     }
//   };

//   if (loading && !selectedJobCard) {
//     return (
//       <div className="page-body">
//         <Breadcrumbs
//           title="Create Invoice"
//           mainTitle="Billing & Invoicing"
//           parent="Invoices"
//         />
//         <Container fluid>
//           <Row>
//             <Col lg="12">
//               <Card>
//                 <CardBody className="text-center py-5">
//                   <Spinner color="primary" />
//                   <p className="mt-3">Loading job cards...</p>
//                 </CardBody>
//               </Card>
//             </Col>
//           </Row>
//         </Container>
//       </div>
//     );
//   }

//   return (
//     <div className="page-body">
//       <Breadcrumbs
//         title="Create Invoice"
//         mainTitle="Billing & Invoicing"
//         parent="Invoices"
//       />

//       <Container fluid>
//         <Row>
//           <Col lg="8">
//             <Card>
//               <CardBody>
//                 <h5 className="card-title mb-4 text-muted">
//                   Create New Invoice
//                 </h5>

//                 {error && (
//                   <Alert color="danger" className="mb-4">
//                     {error}
//                   </Alert>
//                 )}

//                 {/* Job Card Selection - Searchable Dropdown */}
//                 <Card className="mb-4">
//                   <CardBody>
//                     <h6 className="mb-3 text-muted">Select Job Card</h6>

//                     <div className="position-relative" ref={dropdownRef}>
//                       <div className="d-flex gap-2 mb-3">
//                         <div className="flex-grow-1">
//                           <Input
//                             type="text"
//                             placeholder="Search job cards by job number, customer, or vehicle..."
//                             value={searchTerm}
//                             onChange={(e) => {
//                               setSearchTerm(e.target.value);
//                               if (!dropdownOpen) setDropdownOpen(true);
//                             }}
//                             onClick={() => setDropdownOpen(true)}
//                             className="w-100"
//                           />
//                         </div>
//                         {selectedJobCard && (
//                           <Button
//                             color="outline-danger"
//                             onClick={clearSelection}
//                             className="flex-shrink-0"
//                           >
//                             <i className="fa fa-times"></i>
//                           </Button>
//                         )}
//                       </div>

//                       {/* Dropdown Menu */}
//                       {dropdownOpen && filteredJobCards.length > 0 && (
//                         <div
//                           className="position-absolute w-100 bg-white border rounded shadow-lg"
//                           style={{
//                             zIndex: 1000,
//                             maxHeight: "400px",
//                             overflowY: "auto",
//                             marginTop: "2px",
//                           }}
//                         >
//                           {filteredJobCards.map((jobCard) => (
//                             <div
//                               key={jobCard.id}
//                               className={`p-3 border-bottom cursor-pointer hover-bg ${
//                                 selectedJobCard?.id === jobCard.id
//                                   ? "bg-primary text-white"
//                                   : ""
//                               }`}
//                               onClick={() => handleJobCardSelect(jobCard)}
//                             >
//                               <div className="d-flex justify-content-between align-items-start">
//                                 <div>
//                                   <div className="d-flex align-items-center">
//                                     <strong className="me-2">
//                                       {jobCard.jobNumber}
//                                     </strong>
//                                     <Badge
//                                       color={
//                                         jobCard.status === "completed"
//                                           ? "success"
//                                           : "warning"
//                                       }
//                                       className="ms-2"
//                                     >
//                                       {jobCard.status}
//                                     </Badge>
//                                   </div>
//                                   <div className="mt-1">
//                                     <small>
//                                       <i className="fa fa-user me-1"></i>
//                                       {jobCard.customerName}
//                                     </small>
//                                     <br />
//                                     <small>
//                                       <i className="fa fa-car me-1"></i>
//                                       {jobCard.vehicle} ({jobCard.licensePlate})
//                                     </small>
//                                   </div>
//                                 </div>
//                                 <div className="text-end">
//                                   <div className="fw-bold">
//                                     ${jobCard.totalCost.toFixed(2)}
//                                   </div>
//                                   <small className="text-muted">
//                                     {jobCard.completedDate}
//                                   </small>
//                                 </div>
//                               </div>
//                             </div>
//                           ))}
//                         </div>
//                       )}

//                       {dropdownOpen && filteredJobCards.length === 0 && (
//                         <div
//                           className="position-absolute w-100 bg-white border rounded shadow-lg p-3"
//                           style={{ zIndex: 1000, marginTop: "2px" }}
//                         >
//                           <div className="text-center text-muted">
//                             <i className="fa fa-search fa-lg mb-2"></i>
//                             <p>No job cards found</p>
//                           </div>
//                         </div>
//                       )}

//                       {/* Selected Job Card Display */}
//                       {selectedJobCard && !dropdownOpen && (
//                         <Card className="mt-3 border-primary">
//                           <CardBody>
//                             <div className="d-flex justify-content-between align-items-start">
//                               <div>
//                                 <h6 className="mb-1">
//                                   <i className="fa fa-file-alt me-2 text-primary"></i>
//                                   {selectedJobCard.jobNumber}
//                                 </h6>
//                                 <p className="mb-1">
//                                   <strong>Customer:</strong>{" "}
//                                   {selectedJobCard.customerName}
//                                 </p>
//                                 <p className="mb-1">
//                                   <strong>Vehicle:</strong>{" "}
//                                   {selectedJobCard.vehicle} (
//                                   {selectedJobCard.licensePlate})
//                                 </p>
//                                 <p className="mb-1">
//                                   <strong>Service:</strong>{" "}
//                                   {selectedJobCard.serviceType}
//                                 </p>
//                                 <p className="mb-0">
//                                   <strong>Completed:</strong>{" "}
//                                   {selectedJobCard.completedDate}
//                                 </p>
//                               </div>
//                               <div className="text-end">
//                                 <Badge color="success" className="mb-2">
//                                   ${selectedJobCard.totalCost.toFixed(2)}
//                                 </Badge>
//                                 <div>
//                                   <small className="text-muted">
//                                     Click search to change
//                                   </small>
//                                 </div>
//                               </div>
//                             </div>
//                           </CardBody>
//                         </Card>
//                       )}

//                       {!selectedJobCard && jobCards.length === 0 && (
//                         <Alert color="info" className="mt-3">
//                           <i className="fa fa-info-circle me-2"></i>
//                           No completed job cards found. Please complete a job
//                           card first.
//                         </Alert>
//                       )}
//                     </div>
//                   </CardBody>
//                 </Card>

//                 {selectedJobCard && (
//                   <>
//                     {/* Customer Information */}
//                     <Card className="mb-4">
//                       <CardBody>
//                         <h6 className="mb-3 text-muted">
//                           Customer Information
//                         </h6>
//                         <Row>
//                           <Col md="6">
//                             <FormGroup>
//                               <Label>Customer Name</Label>
//                               <Input
//                                 type="text"
//                                 value={invoice.customerName || ""}
//                                 disabled
//                               />
//                             </FormGroup>
//                           </Col>
//                           <Col md="6">
//                             <FormGroup>
//                               <Label>Customer Email</Label>
//                               <Input
//                                 type="email"
//                                 value={invoice.customerEmail || ""}
//                                 onChange={(e) =>
//                                   handleInputChange(
//                                     "customerEmail",
//                                     e.target.value
//                                   )
//                                 }
//                               />
//                             </FormGroup>
//                           </Col>
//                           <Col md="6">
//                             <FormGroup>
//                               <Label>Customer Phone</Label>
//                               <Input
//                                 type="text"
//                                 value={invoice.customerPhone || ""}
//                                 onChange={(e) =>
//                                   handleInputChange(
//                                     "customerPhone",
//                                     e.target.value
//                                   )
//                                 }
//                               />
//                             </FormGroup>
//                           </Col>
//                           <Col md="6">
//                             <FormGroup>
//                               <Label>Customer Address</Label>
//                               <Input
//                                 type="text"
//                                 value={invoice.customerAddress || ""}
//                                 onChange={(e) =>
//                                   handleInputChange(
//                                     "customerAddress",
//                                     e.target.value
//                                   )
//                                 }
//                               />
//                             </FormGroup>
//                           </Col>
//                         </Row>
//                       </CardBody>
//                     </Card>

//                     {/* Invoice Items */}
//                     <Card className="mb-4">
//                       <CardBody>
//                         <div className="d-flex justify-content-between align-items-center mb-3 text-muted">
//                           <h6 className="mb-0">Invoice Items</h6>
//                           <Button
//                             color="primary"
//                             size="sm"
//                             onClick={addNewItem}
//                             disabled={saving}
//                           >
//                             <i className="fa fa-plus me-1"></i> Add Item
//                           </Button>
//                         </div>

//                         <div className="table-responsive">
//                           <Table bordered hover>
//                             <thead>
//                               <tr>
//                                 <th>Description</th>
//                                 <th>Type</th>
//                                 <th>Qty</th>
//                                 <th>Unit Price</th>
//                                 <th>Total</th>
//                                 <th>Action</th>
//                               </tr>
//                             </thead>

//                             <tbody>
//                               {invoice.items?.map((item, index) => (
//                                 <tr key={item.id}>
//                                   <td
//                                     className="p-2"
//                                     style={{ minWidth: "200px" }}
//                                   >
//                                     <Input
//                                       type="text"
//                                       className="w-100"
//                                       value={item.description}
//                                       onChange={(e) =>
//                                         handleItemChange(
//                                           index,
//                                           "description",
//                                           e.target.value
//                                         )
//                                       }
//                                       disabled={saving}
//                                     />
//                                   </td>

//                                   <td
//                                     className="p-2"
//                                     style={{ minWidth: "130px" }}
//                                   >
//                                     <Input
//                                       type="select"
//                                       className="w-100"
//                                       value={item.type}
//                                       onChange={(e) =>
//                                         handleItemChange(
//                                           index,
//                                           "type",
//                                           e.target.value
//                                         )
//                                       }
//                                       disabled={saving}
//                                     >
//                                       <option value="labor">Labor</option>
//                                       <option value="part">Part</option>
//                                       <option value="service">Service</option>
//                                       <option value="other">Other</option>
//                                     </Input>
//                                   </td>

//                                   <td
//                                     className="p-2"
//                                     style={{ minWidth: "120px" }}
//                                   >
//                                     <Input
//                                       type="number"
//                                       className="w-100"
//                                       value={item.quantity}
//                                       min="1"
//                                       onChange={(e) =>
//                                         handleItemChange(
//                                           index,
//                                           "quantity",
//                                           Number(e.target.value)
//                                         )
//                                       }
//                                       disabled={saving}
//                                     />
//                                   </td>

//                                   <td
//                                     className="p-2"
//                                     style={{ minWidth: "150px" }}
//                                   >
//                                     <Input
//                                       type="number"
//                                       step="0.01"
//                                       className="w-100"
//                                       value={item.unitPrice}
//                                       onChange={(e) =>
//                                         handleItemChange(
//                                           index,
//                                           "unitPrice",
//                                           Number(e.target.value)
//                                         )
//                                       }
//                                       disabled={saving}
//                                     />
//                                   </td>

//                                   <td
//                                     className="p-2"
//                                     style={{ minWidth: "120px" }}
//                                   >
//                                     ${item.total.toFixed(2)}
//                                   </td>

//                                   <td
//                                     className="p-2"
//                                     style={{ minWidth: "100px" }}
//                                   >
//                                     <Button
//                                       color="outline-danger"
//                                       size="sm"
//                                       onClick={() => removeItem(index)}
//                                       disabled={saving}
//                                     >
//                                       <i className="fa fa-trash"></i>
//                                     </Button>
//                                   </td>
//                                 </tr>
//                               ))}
//                             </tbody>
//                           </Table>
//                         </div>
//                       </CardBody>
//                     </Card>

//                     {/* Invoice Details */}
//                     <Card>
//                       <CardBody>
//                         <h6 className="mb-3 text-muted">Invoice Details</h6>
//                         <Row className="text-muted">
//                           <Col md="6">
//                             <FormGroup>
//                               <Label>Issue Date</Label>
//                               <Input
//                                 type="date"
//                                 value={invoice.issueDate}
//                                 onChange={(e) =>
//                                   handleInputChange("issueDate", e.target.value)
//                                 }
//                                 disabled={saving}
//                               />
//                             </FormGroup>
//                           </Col>
//                           <Col md="6">
//                             <FormGroup>
//                               <Label>Due Date</Label>
//                               <Input
//                                 type="date"
//                                 value={invoice.dueDate}
//                                 onChange={(e) =>
//                                   handleInputChange("dueDate", e.target.value)
//                                 }
//                                 disabled={saving}
//                               />
//                             </FormGroup>
//                           </Col>
//                         </Row>
//                         <Row className="text-muted">
//                           <Col md="6">
//                             <FormGroup>
//                               <Label>Tax Rate (%)</Label>
//                               <Input
//                                 type="number"
//                                 step="0.1"
//                                 value={invoice.taxRate}
//                                 onChange={(e) =>
//                                   handleInputChange(
//                                     "taxRate",
//                                     Number(e.target.value)
//                                   )
//                                 }
//                                 disabled={saving}
//                               />
//                             </FormGroup>
//                           </Col>
//                           <Col md="6">
//                             <FormGroup>
//                               <Label>Discount ($)</Label>
//                               <Input
//                                 type="number"
//                                 step="0.01"
//                                 value={invoice.discount}
//                                 onChange={(e) =>
//                                   handleInputChange(
//                                     "discount",
//                                     Number(e.target.value)
//                                   )
//                                 }
//                                 disabled={saving}
//                               />
//                             </FormGroup>
//                           </Col>
//                         </Row>
//                         <FormGroup className="text-muted">
//                           <Label>Notes</Label>
//                           <Input
//                             type="textarea"
//                             rows="3"
//                             value={invoice.notes}
//                             onChange={(e) =>
//                               handleInputChange("notes", e.target.value)
//                             }
//                             disabled={saving}
//                           />
//                         </FormGroup>
//                         <FormGroup className="text-muted">
//                           <Label>Terms & Conditions</Label>
//                           <Input
//                             type="textarea"
//                             rows="2"
//                             value={invoice.terms}
//                             onChange={(e) =>
//                               handleInputChange("terms", e.target.value)
//                             }
//                             disabled={saving}
//                           />
//                         </FormGroup>
//                       </CardBody>
//                     </Card>
//                   </>
//                 )}
//               </CardBody>
//             </Card>
//           </Col>

//           {/* Invoice Summary */}
//           <Col lg="4">
//             <Card>
//               <CardBody className="text-muted">
//                 <h6 className="card-title mb-3 text-muted">Invoice Summary</h6>

//                 {selectedJobCard ? (
//                   <>
//                     <div className="mb-3">
//                       <strong>Customer:</strong> {invoice.customerName}
//                       <br />
//                       <strong>Job Card:</strong> {selectedJobCard.jobNumber}
//                       <br />
//                       <strong>Vehicle:</strong> {selectedJobCard.vehicle}
//                       <br />
//                       <strong>License:</strong> {selectedJobCard.licensePlate}
//                     </div>

//                     <div className="border-top pt-3">
//                       <div className="d-flex justify-content-between mb-2">
//                         <span>Subtotal:</span>
//                         <span>${invoice.subtotal?.toFixed(2) || "0.00"}</span>
//                       </div>
//                       <div className="d-flex justify-content-between mb-2">
//                         <span>Tax ({invoice.taxRate}%):</span>
//                         <span>${invoice.taxAmount?.toFixed(2) || "0.00"}</span>
//                       </div>
//                       <div className="d-flex justify-content-between mb-2">
//                         <span>Discount:</span>
//                         <span>-${invoice.discount?.toFixed(2) || "0.00"}</span>
//                       </div>
//                       <div className="d-flex justify-content-between mb-2 border-top pt-2">
//                         <strong>Total:</strong>
//                         <strong>${invoice.total?.toFixed(2) || "0.00"}</strong>
//                       </div>
//                     </div>

//                     <div className="mt-4">
//                       <Button
//                         color="primary"
//                         className="w-100 mb-2"
//                         onClick={() => handleSaveInvoice("unpaid")}
//                         disabled={saving}
//                       >
//                         {saving ? (
//                           <>
//                             <Spinner size="sm" className="me-2" />
//                             Creating...
//                           </>
//                         ) : (
//                           <>
//                             <i className="fa fa-paper-plane me-2"></i>
//                             Create Invoice
//                           </>
//                         )}
//                       </Button>
//                       {/* <Button
//                         color="outline-secondary"
//                         className="w-100 mb-2"
//                         onClick={() => handleSaveInvoice("draft")}
//                         disabled={saving}
//                       >
//                         {saving ? (
//                           <>
//                             <Spinner size="sm" className="me-2" />
//                             Saving...
//                           </>
//                         ) : (
//                           <>
//                             <i className="fa fa-save me-2"></i>
//                             Save as Draft
//                           </>
//                         )}
//                       </Button> */}
//                       <Button
//                         color="outline-danger"
//                         className="w-100"
//                         onClick={() => router.push("/admin/invoices")}
//                         disabled={saving}
//                       >
//                         Cancel
//                       </Button>
//                     </div>
//                   </>
//                 ) : (
//                   <div className="text-center text-muted py-4">
//                     <i className="fa fa-file-invoice fa-3x mb-3"></i>
//                     <p className="mb-2">
//                       Select a job card to create an invoice
//                     </p>
//                     <small className="text-muted">
//                       Search and select from completed job cards
//                     </small>
//                   </div>
//                 )}
//               </CardBody>
//             </Card>
//           </Col>
//         </Row>
//       </Container>

//       <style jsx>{`
//         .cursor-pointer {
//           cursor: pointer;
//         }

//         .hover-bg:hover {
//           background-color: #f8f9fa;
//         }

//         .hover-bg.bg-primary:hover {
//           background-color: #0d6efd !important;
//         }
//       `}</style>
//     </div>
//   );
// }

// export default CreateInvoicePage;

// "use client";
// import Breadcrumbs from "@/CommonElements/Breadcrumbs";
// import {
//   Container,
//   Row,
//   Col,
//   Card,
//   CardBody,
//   Form,
//   FormGroup,
//   Label,
//   Input,
//   Button,
//   Table,
//   Badge,
//   Alert,
//   Spinner,
//   Dropdown,
//   DropdownToggle,
//   DropdownMenu,
//   DropdownItem,
// } from "reactstrap";
// import React, { useState, useEffect, useRef } from "react";
// import { useRouter } from "next/navigation";
// // import { Invoice, InvoiceItem, JobCard } from "@/Types/invoice";
// import { Invoice, InvoiceItem } from "@/Types/invoice";

// import { toast } from "react-toastify";
// import { useAuth } from "@/helper/AuthContext";
// import { Currency } from "@/utils/Utils";

// // API response types
// interface ApiJobCard {
//   id: string;
//   job_number: string;
//   customer_id: string;
//   customer_name: string;
//   vehicle_id?: string;
//   registration_number?: string;
//   model?: string;
//   total_cost?: string;
//   total_estimate: string;
//   status: string;
//   completed_date?: string;
// }
// // In @/Types/invoice.ts or wherever your JobCard interface is defined
// export interface JobCard {
//   id: number;
//   jobNumber: string;
//   customerId: number;
//   customerName: string;
//   vehicle: string;
//   licensePlate: string;
//   serviceType: string;
//   laborCost: number;
//   partsCost: number;
//   total_estimate: number; // Change from totalCost to total_estimate
//   status: string;
//   completedDate: string;
// }
// interface Customer {
//   id: string;
//   name: string;
//   email?: string;
//   phone?: string;
//   address?: string;
// }

// function CreateInvoicePage() {
//   const router = useRouter();
//   const { state } = useAuth();
//   const [loading, setLoading] = useState(true);
//   const [saving, setSaving] = useState(false);
//   const [jobCards, setJobCards] = useState<JobCard[]>([]);
//   const [customers, setCustomers] = useState<Customer[]>([]);
//   const [selectedJobCard, setSelectedJobCard] = useState<JobCard | null>(null);
//   const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(
//     null
//   );
//   const [error, setError] = useState<string | null>(null);

//   // Dropdown state
//   const [dropdownOpen, setDropdownOpen] = useState(false);
//   const [searchTerm, setSearchTerm] = useState("");
//   const dropdownRef = useRef<HTMLDivElement>(null);

//   const [invoice, setInvoice] = useState<Partial<Invoice>>({
//     issueDate: new Date().toISOString().split("T")[0],
//     dueDate: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000)
//       .toISOString()
//       .split("T")[0],
//     taxRate: 8.5,
//     discount: 0,
//     notes: "",
//     terms: "Due upon receipt",
//     status: "draft",
//   });

//   // Fetch job cards and customers from API
//   useEffect(() => {
//     fetchJobCards();
//     fetchCustomers();
//   }, []);

//   // Close dropdown when clicking outside
//   useEffect(() => {
//     const handleClickOutside = (event: MouseEvent) => {
//       if (
//         dropdownRef.current &&
//         !dropdownRef.current.contains(event.target as Node)
//       ) {
//         setDropdownOpen(false);
//       }
//     };

//     document.addEventListener("mousedown", handleClickOutside);
//     return () => {
//       document.removeEventListener("mousedown", handleClickOutside);
//     };
//   }, []);

//   const fetchJobCards = async () => {
//     try {
//       setLoading(true);
//       const token = state?.accessToken || localStorage.getItem("token");

//       // Fetch ALL job cards (or you can filter by status in the API if supported)
//       const response = await fetch("/api/jobcards", {
//         headers: {
//           Authorization: `Bearer ${token}`,
//           "Content-Type": "application/json",
//         },
//       });

//       if (!response.ok) {
//         throw new Error("Failed to fetch job cards");
//       }

//       const data = await response.json();

//       if (data.data && Array.isArray(data.data)) {
//         // Filter for completed job cards only
//         const completedJobs = data.data.filter(
//           (job: any) => job.status === "completed" || job.status === "Completed"
//         );

//         if (completedJobs.length === 0) {
//           toast.info("No completed job cards found");
//         }

//         // Transform API data to match JobCard type for COMPLETED jobs only
//         const transformedJobCards: JobCard[] = completedJobs.map(
//           (apiJobCard: ApiJobCard) => ({
//             id: parseInt(apiJobCard.id),
//             jobNumber: apiJobCard.job_number,
//             customerId: parseInt(apiJobCard.customer_id),
//             customerName: apiJobCard.customer_name,
//             // vehicle: apiJobCard.model || "Unknown Vehicle",
//             vehicle: apiJobCard.registration_number || "N/A",
//             serviceType: "Service",
//             laborCost: 0,
//             partsCost: 0,
//             // totalCost: parseFloat(apiJobCard.total_cost || "0"),
//             total_estimate: parseFloat(apiJobCard.total_estimate || "0"),
//             status: apiJobCard.status,
//             completedDate:
//               apiJobCard.completed_date ||
//               new Date().toISOString().split("T")[0],
//           })
//         );

//         setJobCards(transformedJobCards);
//       } else {
//         toast.error("Invalid data format received from API");
//         setJobCards([]);
//       }
//     } catch (err: any) {
//       console.error("Error fetching job cards:", err);
//       setError(err.message);
//       toast.error("Failed to load job cards");
//     } finally {
//       setLoading(false);
//     }
//   };

//   const fetchCustomers = async () => {
//     try {
//       const token = state?.accessToken || localStorage.getItem("token");

//       const response = await fetch("/api/customers", {
//         headers: {
//           Authorization: `Bearer ${token}`,
//           "Content-Type": "application/json",
//         },
//       });

//       if (response.ok) {
//         const data = await response.json();
//         setCustomers(data.data || []);
//       }
//     } catch (err) {
//       console.error("Error fetching customers:", err);
//     }
//   };

//   // Filter job cards based on search term
//   const filteredJobCards = jobCards.filter(
//     (jobCard) =>
//       jobCard.jobNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
//       jobCard.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
//       jobCard.vehicle.toLowerCase().includes(searchTerm.toLowerCase())
//   );

//   const toggleDropdown = () => setDropdownOpen(!dropdownOpen);

//   const handleJobCardSelect = async (jobCard: JobCard) => {
//     try {
//       setLoading(true);
//       const token = state?.accessToken || localStorage.getItem("token");

//       // Fetch job card details to get items and parts
//       const response = await fetch(`/api/jobcards/${jobCard.id}`, {
//         headers: {
//           Authorization: `Bearer ${token}`,
//         },
//       });

//       if (response.ok) {
//         const jobCardDetails = await response.json();

//         // Create invoice items from job card items and parts
//         const invoiceItems: InvoiceItem[] = [];

//         // Add labor items
//         if (jobCardDetails.items && jobCardDetails.items.length > 0) {
//           jobCardDetails.items.forEach((item: any, index: number) => {
//             invoiceItems.push({
//               id: index + 1,
//               description: item.description || "Labor",
//               type: "labor",
//               quantity: item.labor_hours || 1,
//               unitPrice: item.labor_rate || 0,
//               total: (item.labor_hours || 1) * (item.labor_rate || 0),
//             });
//           });
//         }

//         // Add parts items
//         if (jobCardDetails.parts && jobCardDetails.parts.length > 0) {
//           jobCardDetails.parts.forEach((part: any, index: number) => {
//             invoiceItems.push({
//               id: invoiceItems.length + index + 1,
//               description: part.name || "Part",
//               type: "part",
//               quantity: part.quantity || 1,
//               unitPrice: part.unit_price || 0,
//               total: (part.quantity || 1) * (part.unit_price || 0),
//             });
//           });
//         }

//         // Calculate totals
//         // const subtotal = invoiceItems.reduce(
//         //   (sum, item) => sum + item.total,
//         //   0
//         // );
//         // const taxAmount = (subtotal * 8.5) / 100;

//         // Find customer details
//         const customer = customers.find(
//           (c) => c.id === jobCard.customerId.toString()
//         );

//         setSelectedJobCard(jobCard);
//         setSelectedCustomer(customer || null);
//         setSearchTerm(jobCard.jobNumber); // Update search term with selected job card
//         setDropdownOpen(false); // Close dropdown after selection

//         setInvoice({
//           ...invoice,
//           jobCardId: jobCard.id,
//           customerId: jobCard.customerId,
//           customerName: jobCard.customerName,
//           customerEmail: customer?.email || "",
//           customerPhone: customer?.phone || "",
//           customerAddress: customer?.address || "",
//           items: invoiceItems,
//           subtotal: jobCard.total_estimate,
//         });
//       } else {
//         toast.error("Failed to load job card details");
//       }
//     } catch (err: any) {
//       console.error("Error fetching job card details:", err);
//       toast.error("Error loading job card details");
//     } finally {
//       setLoading(false);
//     }
//   };

//   const clearSelection = () => {
//     setSelectedJobCard(null);
//     setSelectedCustomer(null);
//     setSearchTerm("");
//     setInvoice({
//       issueDate: new Date().toISOString().split("T")[0],
//       dueDate: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000)
//         .toISOString()
//         .split("T")[0],
//       taxRate: 8.5,
//       discount: 0,
//       notes: "",
//       terms: "Due upon receipt",
//       status: "draft",
//     });
//   };

//   const handleInputChange = (field: string, value: string | number) => {
//     setInvoice((prev) => {
//       const updated = { ...prev, [field]: value };

//       if (field === "taxRate" || field === "discount") {
//         const subtotal =
//           updated.items?.reduce((sum, item) => sum + item.total, 0) || 0;
//         const taxAmount = (subtotal * (Number(updated.taxRate) || 0)) / 100;
//         const discountAmount = Number(updated.discount) || 0;
//         const total = subtotal + taxAmount - discountAmount;

//         return {
//           ...updated,
//           subtotal,
//           taxAmount,
//           total,
//           balanceDue: total - (updated.amountPaid || 0),
//         };
//       }

//       return updated;
//     });
//   };

//   const handleItemChange = (
//     index: number,
//     field: string,
//     value: string | number
//   ) => {
//     setInvoice((prev) => {
//       const updatedItems = prev.items?.map((item, i) => {
//         if (i === index) {
//           const updatedItem = { ...item, [field]: value };
//           if (field === "quantity" || field === "unitPrice") {
//             updatedItem.total = updatedItem.quantity * updatedItem.unitPrice;
//           }
//           return updatedItem;
//         }
//         return item;
//       });

//       const subtotal =
//         updatedItems?.reduce((sum, item) => sum + item.total, 0) || 0;
//       const taxAmount = (subtotal * (prev.taxRate || 0)) / 100;
//       const discountAmount = prev.discount || 0;
//       const total = subtotal + taxAmount - discountAmount;

//       return {
//         ...prev,
//         items: updatedItems,
//         subtotal,
//         taxAmount,
//         total,
//         balanceDue: total - (prev.amountPaid || 0),
//       };
//     });
//   };

//   const addNewItem = () => {
//     const newItem: InvoiceItem = {
//       id: Date.now(),
//       description: "",
//       type: "service",
//       quantity: 1,
//       unitPrice: 0,
//       total: 0,
//     };

//     setInvoice((prev) => ({
//       ...prev,
//       items: [...(prev.items || []), newItem],
//     }));
//   };

//   const removeItem = (index: number) => {
//     setInvoice((prev) => ({
//       ...prev,
//       items: prev.items?.filter((_, i) => i !== index),
//     }));
//   };

//   // const handleSaveInvoice = async (status: "draft" | "unpaid") => {
//   //   if (!selectedJobCard) {
//   //     toast.error("Please select a job card");
//   //     return;
//   //   }

//   //   if (!invoice.items || invoice.items.length === 0) {
//   //     toast.error("Please add at least one invoice item");
//   //     return;
//   //   }

//   //   try {
//   //     setSaving(true);
//   //     const token = state?.accessToken || localStorage.getItem("token");

//   //     // Prepare items for API
//   //     const apiItems = invoice.items.map(({ id, total, ...rest }) => rest);

//   //     // Prepare the payload
//   //     const payload = {
//   //       issue_date: invoice.issueDate,
//   //       due_date: invoice.dueDate,
//   //       tax_amount: invoice.taxAmount,
//   //       discount_amount: invoice.discount,
//   //       invoice_number: `INV-${Date.now().toString().slice(-6)}`,
//   //       job_card_id: selectedJobCard.id.toString(),
//   //       customer_id:
//   //         selectedCustomer?.id || selectedJobCard.customerId.toString(),
//   //       subtotal: invoice.subtotal,
//   //       total_amount: invoice.total,
//   //       status: status,
//   //       notes: invoice.notes,
//   //       terms: invoice.terms,
//   //       items: apiItems,
//   //       customer_name: selectedCustomer?.name || invoice.customerName,
//   //       customer_email: selectedCustomer?.email || invoice.customerEmail,
//   //       customer_phone: selectedCustomer?.phone || invoice.customerPhone,
//   //       customer_address: selectedCustomer?.address || invoice.customerAddress,
//   //     };

//   //     const response = await fetch("/api/invoices", {
//   //       method: "POST",
//   //       headers: {
//   //         "Content-Type": "application/json",
//   //         Authorization: `Bearer ${token}`,
//   //       },
//   //       body: JSON.stringify(payload),
//   //     });

//   //     if (response.ok) {
//   //       const result = await response.json();
//   //       toast.success(
//   //         `Invoice ${
//   //           status === "draft" ? "saved as draft" : "created successfully"
//   //         }!`
//   //       );

//   //       setTimeout(() => {
//   //         router.push("/admin/invoices");
//   //       }, 1500);
//   //     } else {
//   //       const errorData = await response.json();
//   //       toast.error(errorData.message || "Failed to create invoice");
//   //     }
//   //   } catch (err: any) {
//   //     console.error("Error creating invoice:", err);
//   //     toast.error("Failed to create invoice");
//   //   } finally {
//   //     setSaving(false);
//   //   }
//   // };
//   const handleSaveInvoice = async (status: "draft" | "unpaid") => {
//     if (!selectedJobCard) {
//       toast.error("Please select a job card");
//       return;
//     }

//     try {
//       setSaving(true);
//       const token = state?.accessToken || localStorage.getItem("token");

//       // Prepare the payload according to API expectations
//       const payload = {
//         issue_date: invoice.issueDate,
//         due_date: invoice.dueDate,
//         // tax_amount: invoice.taxAmount || 0,
//         tax_amount: "",
//         // discount_amount: invoice.discount || 0,
//         discount_amount: "",
//         job_card_id: selectedJobCard.id.toString(),
//         customer_id:
//           selectedCustomer?.id || selectedJobCard.customerId.toString(),
//       };

//       // Log the payload for debugging
//       console.log("Sending invoice payload:", JSON.stringify(payload, null, 2));

//       const response = await fetch("/api/invoices", {
//         method: "POST",
//         headers: {
//           "Content-Type": "application/json",
//           Authorization: `Bearer ${token}`,
//         },
//         body: JSON.stringify(payload),
//       });

//       const responseData = await response.json();

//       if (response.ok) {
//         toast.success(`Invoice created successfully!`);

//         setTimeout(() => {
//           router.push("/admin/invoices");
//         }, 1500);
//       } else {
//         console.error("API Error Response:", responseData);
//         toast.error(responseData.message || "Failed to create invoice");
//       }
//     } catch (err: any) {
//       console.error("Error creating invoice:", err);
//       toast.error("Failed to create invoice");
//     } finally {
//       setSaving(false);
//     }
//   };

//   // Optional: If you need to create invoice items separately
//   // const createInvoiceItems = async (invoiceId: string) => {
//   //   try {
//   //     const token = state?.accessToken || localStorage.getItem("token");

//   //     // Prepare items for API
//   //     const itemsPayload =
//   //       invoice.items?.map((item) => ({
//   //         invoice_id: invoiceId,
//   //         description: item.description,
//   //         quantity: item.quantity,
//   //         unit_price: item.unitPrice,
//   //         amount: item.total,
//   //         type: item.type,
//   //       })) || [];

//   //     // Create items if your API has an endpoint for invoice items
//   //     // This is optional and depends on your backend API structure
//   //     const response = await fetch(`/api/invoices/${invoiceId}/items`, {
//   //       method: "POST",
//   //       headers: {
//   //         "Content-Type": "application/json",
//   //         Authorization: `Bearer ${token}`,
//   //       },
//   //       body: JSON.stringify({ items: itemsPayload }),
//   //     });

//   //     if (response.ok) {
//   //       console.log("Invoice items created successfully");
//   //     }
//   //   } catch (error) {
//   //     console.error("Error creating invoice items:", error);
//   //     // Don't show error to user as invoice was already created
//   //   }
//   // };

//   if (loading && !selectedJobCard) {
//     return (
//       <div className="page-body">
//         <Breadcrumbs
//           title="Create Invoice"
//           mainTitle="Billing & Invoicing"
//           parent="Invoices"
//         />
//         <Container fluid>
//           <Row>
//             <Col lg="12">
//               <Card>
//                 <CardBody className="text-center py-5">
//                   <Spinner color="primary" />
//                   <p className="mt-3">Loading job cards...</p>
//                 </CardBody>
//               </Card>
//             </Col>
//           </Row>
//         </Container>
//       </div>
//     );
//   }

//   return (
//     <div className="page-body">
//       <Breadcrumbs
//         title="Create Invoice"
//         mainTitle="Billing & Invoicing"
//         parent="Invoices"
//       />

//       <Container fluid>
//         <Row>
//           <Col lg="8">
//             <Card>
//               <CardBody>
//                 <h5 className="card-title mb-4 text-muted">
//                   Create New Invoice
//                 </h5>

//                 {error && (
//                   <Alert color="danger" className="mb-4">
//                     {error}
//                   </Alert>
//                 )}

//                 {/* Job Card Selection - Searchable Dropdown */}
//                 <Card className="mb-4">
//                   <CardBody>
//                     <h6 className="mb-3 text-muted">Select Job Card</h6>

//                     <div className="position-relative" ref={dropdownRef}>
//                       <div className="d-flex gap-2 mb-3">
//                         <div className="flex-grow-1">
//                           <Input
//                             type="text"
//                             placeholder="Search job cards by job number, customer, or vehicle..."
//                             value={searchTerm}
//                             onChange={(e) => {
//                               setSearchTerm(e.target.value);
//                               if (!dropdownOpen) setDropdownOpen(true);
//                             }}
//                             onClick={() => setDropdownOpen(true)}
//                             className="w-100"
//                           />
//                         </div>
//                         {selectedJobCard && (
//                           <Button
//                             color="outline-danger"
//                             onClick={clearSelection}
//                             className="flex-shrink-0"
//                           >
//                             <i className="fa fa-times"></i>
//                           </Button>
//                         )}
//                       </div>

//                       {/* Dropdown Menu */}
//                       {dropdownOpen && filteredJobCards.length > 0 && (
//                         <div
//                           className="position-absolute w-100 bg-white border rounded shadow-lg"
//                           style={{
//                             zIndex: 1000,
//                             maxHeight: "400px",
//                             overflowY: "auto",
//                             marginTop: "2px",
//                           }}
//                         >
//                           {filteredJobCards.map((jobCard) => (
//                             <div
//                               key={jobCard.id}
//                               className={`p-3 border-bottom cursor-pointer hover-bg ${
//                                 selectedJobCard?.id === jobCard.id
//                                   ? "bg-primary text-white"
//                                   : ""
//                               }`}
//                               onClick={() => handleJobCardSelect(jobCard)}
//                             >
//                               <div className="d-flex justify-content-between align-items-start">
//                                 <div>
//                                   <div className="d-flex align-items-center">
//                                     <strong className="me-2">
//                                       {jobCard.jobNumber}
//                                     </strong>
//                                     <Badge
//                                       color={
//                                         jobCard.status === "completed"
//                                           ? "success"
//                                           : "warning"
//                                       }
//                                       className="ms-2"
//                                     >
//                                       {jobCard.status}
//                                     </Badge>
//                                   </div>
//                                   <div className="mt-1">
//                                     <small>
//                                       <i className="fa fa-user me-1"></i>
//                                       {jobCard.customerName}
//                                     </small>
//                                     <br />
//                                     <small>
//                                       <i className="fa fa-car me-1"></i>
//                                       {jobCard.vehicle}
//                                     </small>
//                                   </div>
//                                 </div>
//                                 <div className="text-end">
//                                   <div className="fw-bold">
//                                     ${jobCard.total_estimate.toFixed(2)}
//                                   </div>
//                                   <small className="text-muted">
//                                     {jobCard.completedDate}
//                                   </small>
//                                 </div>
//                               </div>
//                             </div>
//                           ))}
//                         </div>
//                       )}

//                       {dropdownOpen && filteredJobCards.length === 0 && (
//                         <div
//                           className="position-absolute w-100 bg-white border rounded shadow-lg p-3"
//                           style={{ zIndex: 1000, marginTop: "2px" }}
//                         >
//                           {/* <div className="text-center text-muted">
//                             <i className="fa fa-search fa-lg mb-2"></i>
//                             <p>No job cards found</p>
//                           </div> */}
//                           <div className="text-center text-muted">
//                             <i className="fa fa-check-circle fa-lg mb-2 text-success"></i>
//                             <p>No completed job cards found</p>
//                             <small className="text-muted">
//                               Only job cards with "completed" status are shown
//                             </small>
//                           </div>
//                         </div>
//                       )}

//                       {/* Selected Job Card Display */}
//                       {selectedJobCard && !dropdownOpen && (
//                         <Card className="mt-3 border-primary">
//                           <CardBody>
//                             <div className="d-flex justify-content-between align-items-start">
//                               <div>
//                                 <h6 className="mb-1">
//                                   <i className="fa fa-file-alt me-2 text-primary"></i>
//                                   {selectedJobCard.jobNumber}
//                                 </h6>
//                                 <p className="mb-1">
//                                   <strong>Customer:</strong>{" "}
//                                   {selectedJobCard.customerName}
//                                 </p>
//                                 <p className="mb-1">
//                                   <strong>Vehicle:</strong>{" "}
//                                   {selectedJobCard.vehicle}
//                                 </p>
//                                 <p className="mb-1">
//                                   <strong>Service:</strong>{" "}
//                                   {selectedJobCard.serviceType}
//                                 </p>
//                                 <p className="mb-0">
//                                   <strong>Completed:</strong>{" "}
//                                   {selectedJobCard.completedDate}
//                                 </p>
//                               </div>
//                               <div className="text-end">
//                                 <Badge color="success" className="mb-2">
//                                   ${selectedJobCard.total_estimate.toFixed(2)}
//                                 </Badge>
//                                 <div>
//                                   <small className="text-muted">
//                                     Click search to change
//                                   </small>
//                                 </div>
//                               </div>
//                             </div>
//                           </CardBody>
//                         </Card>
//                       )}

//                       {!selectedJobCard && jobCards.length === 0 && (
//                         <Alert color="info" className="mt-3">
//                           <i className="fa fa-info-circle me-2"></i>
//                           No completed job cards found. Please complete a job
//                           card first.
//                         </Alert>
//                       )}
//                     </div>
//                   </CardBody>
//                 </Card>

//                 {selectedJobCard && (
//                   <>
//                     {/* Customer Information */}
//                     {/* <Card className="mb-4">
//                       <CardBody>
//                         <h6 className="mb-3 text-muted">
//                           Customer Information
//                         </h6>
//                         <Row>
//                           <Col md="6">
//                             <FormGroup>
//                               <Label>Customer Name</Label>
//                               <Input
//                                 type="text"
//                                 value={invoice.customerName || ""}
//                                 disabled
//                               />
//                             </FormGroup>
//                           </Col>
//                           <Col md="6">
//                             <FormGroup>
//                               <Label>Customer Email</Label>
//                               <Input
//                                 type="email"
//                                 value={invoice.customerEmail || ""}
//                                 onChange={(e) =>
//                                   handleInputChange(
//                                     "customerEmail",
//                                     e.target.value
//                                   )
//                                 }
//                               />
//                             </FormGroup>
//                           </Col>
//                           <Col md="6">
//                             <FormGroup>
//                               <Label>Customer Phone</Label>
//                               <Input
//                                 type="text"
//                                 value={invoice.customerPhone || ""}
//                                 onChange={(e) =>
//                                   handleInputChange(
//                                     "customerPhone",
//                                     e.target.value
//                                   )
//                                 }
//                               />
//                             </FormGroup>
//                           </Col>
//                           <Col md="6">
//                             <FormGroup>
//                               <Label>Customer Address</Label>
//                               <Input
//                                 type="text"
//                                 value={invoice.customerAddress || ""}
//                                 onChange={(e) =>
//                                   handleInputChange(
//                                     "customerAddress",
//                                     e.target.value
//                                   )
//                                 }
//                               />
//                             </FormGroup>
//                           </Col>
//                         </Row>
//                       </CardBody>
//                     </Card> */}

//                     {/* Invoice Items */}
//                     {/* <Card className="mb-4">
//                       <CardBody>
//                         <div className="d-flex justify-content-between align-items-center mb-3 text-muted">
//                           <h6 className="mb-0">Invoice Items</h6>
//                           <Button
//                             color="primary"
//                             size="sm"
//                             onClick={addNewItem}
//                             disabled={saving}
//                           >
//                             <i className="fa fa-plus me-1"></i> Add Item
//                           </Button>
//                         </div>

//                         <div className="table-responsive">
//                           <Table bordered hover>
//                             <thead>
//                               <tr>
//                                 <th>Description</th>
//                                 <th>Type</th>
//                                 <th>Qty</th>
//                                 <th>Unit Price</th>
//                                 <th>Total</th>
//                                 <th>Action</th>
//                               </tr>
//                             </thead>

//                             <tbody>
//                               {invoice.items?.map((item, index) => (
//                                 <tr key={item.id}>
//                                   <td
//                                     className="p-2"
//                                     style={{ minWidth: "200px" }}
//                                   >
//                                     <Input
//                                       type="text"
//                                       className="w-100"
//                                       value={item.description}
//                                       onChange={(e) =>
//                                         handleItemChange(
//                                           index,
//                                           "description",
//                                           e.target.value
//                                         )
//                                       }
//                                       disabled={saving}
//                                     />
//                                   </td>

//                                   <td
//                                     className="p-2"
//                                     style={{ minWidth: "130px" }}
//                                   >
//                                     <Input
//                                       type="select"
//                                       className="w-100"
//                                       value={item.type}
//                                       onChange={(e) =>
//                                         handleItemChange(
//                                           index,
//                                           "type",
//                                           e.target.value
//                                         )
//                                       }
//                                       disabled={saving}
//                                     >
//                                       <option value="labor">Labor</option>
//                                       <option value="part">Part</option>
//                                       <option value="service">Service</option>
//                                       <option value="other">Other</option>
//                                     </Input>
//                                   </td>

//                                   <td
//                                     className="p-2"
//                                     style={{ minWidth: "120px" }}
//                                   >
//                                     <Input
//                                       type="number"
//                                       className="w-100"
//                                       value={item.quantity}
//                                       min="1"
//                                       onChange={(e) =>
//                                         handleItemChange(
//                                           index,
//                                           "quantity",
//                                           Number(e.target.value)
//                                         )
//                                       }
//                                       disabled={saving}
//                                     />
//                                   </td>

//                                   <td
//                                     className="p-2"
//                                     style={{ minWidth: "150px" }}
//                                   >
//                                     <Input
//                                       type="number"
//                                       step="0.01"
//                                       className="w-100"
//                                       value={item.unitPrice}
//                                       onChange={(e) =>
//                                         handleItemChange(
//                                           index,
//                                           "unitPrice",
//                                           Number(e.target.value)
//                                         )
//                                       }
//                                       disabled={saving}
//                                     />
//                                   </td>

//                                   <td
//                                     className="p-2"
//                                     style={{ minWidth: "120px" }}
//                                   >
//                                     ${item.total.toFixed(2)}
//                                   </td>

//                                   <td
//                                     className="p-2"
//                                     style={{ minWidth: "100px" }}
//                                   >
//                                     <Button
//                                       color="outline-danger"
//                                       size="sm"
//                                       onClick={() => removeItem(index)}
//                                       disabled={saving}
//                                     >
//                                       <i className="fa fa-trash"></i>
//                                     </Button>
//                                   </td>
//                                 </tr>
//                               ))}
//                             </tbody>
//                           </Table>
//                         </div>
//                       </CardBody>
//                     </Card> */}

//                     {/* Invoice Details */}
//                     <Card>
//                       <CardBody>
//                         <h6 className="mb-3 text-muted">Invoice Details</h6>
//                         <Row className="text-muted">
//                           <Col md="6">
//                             <FormGroup>
//                               <Label>Issue Date</Label>
//                               <Input
//                                 type="date"
//                                 value={invoice.issueDate}
//                                 onChange={(e) =>
//                                   handleInputChange("issueDate", e.target.value)
//                                 }
//                                 disabled={saving}
//                               />
//                             </FormGroup>
//                           </Col>
//                           <Col md="6">
//                             <FormGroup>
//                               <Label>Due Date</Label>
//                               <Input
//                                 type="date"
//                                 value={invoice.dueDate}
//                                 onChange={(e) =>
//                                   handleInputChange("dueDate", e.target.value)
//                                 }
//                                 disabled={saving}
//                               />
//                             </FormGroup>
//                           </Col>
//                         </Row>
//                         <Row className="text-muted">
//                           <Col md="6">
//                             <FormGroup>
//                               <Label>Tax Rate (%)</Label>
//                               <Input
//                                 type="number"
//                                 step="0.1"
//                                 value={invoice.taxRate}
//                                 onChange={(e) =>
//                                   handleInputChange(
//                                     "taxRate",
//                                     Number(e.target.value)
//                                   )
//                                 }
//                                 disabled={saving}
//                               />
//                             </FormGroup>
//                           </Col>
//                           <Col md="6">
//                             <FormGroup>
//                               <Label>Discount ($)</Label>
//                               <Input
//                                 type="number"
//                                 step="0.01"
//                                 value={invoice.discount}
//                                 onChange={(e) =>
//                                   handleInputChange(
//                                     "discount",
//                                     Number(e.target.value)
//                                   )
//                                 }
//                                 disabled={saving}
//                               />
//                             </FormGroup>
//                           </Col>
//                         </Row>
//                         {/* <FormGroup className="text-muted">
//                           <Label>Notes</Label>
//                           <Input
//                             type="textarea"
//                             rows="3"
//                             value={invoice.notes}
//                             onChange={(e) =>
//                               handleInputChange("notes", e.target.value)
//                             }
//                             disabled={saving}
//                           />
//                         </FormGroup>
//                         <FormGroup className="text-muted">
//                           <Label>Terms & Conditions</Label>
//                           <Input
//                             type="textarea"
//                             rows="2"
//                             value={invoice.terms}
//                             onChange={(e) =>
//                               handleInputChange("terms", e.target.value)
//                             }
//                             disabled={saving}
//                           />
//                         </FormGroup> */}
//                       </CardBody>
//                     </Card>
//                   </>
//                 )}
//               </CardBody>
//             </Card>
//           </Col>

//           {/* Invoice Summary */}
//           <Col lg="4">
//             <Card>
//               <CardBody className="text-muted">
//                 <h6 className="card-title mb-3 text-muted">Invoice Summary</h6>

//                 {selectedJobCard ? (
//                   <>
//                     <div className="mb-3">
//                       <strong>Customer:</strong> {invoice.customerName}
//                       <br />
//                       <strong>Job Card:</strong> {selectedJobCard.jobNumber}
//                       <br />
//                       <strong>Vehicle:</strong> {selectedJobCard.vehicle}
//                       <br />
//                       {/* <strong>License:</strong> {selectedJobCard.licensePlate} */}
//                     </div>

//                     <div className="border-top pt-3">
//                       <div className="d-flex justify-content-between mb-2">
//                         <span>Subtotal:</span>
//                         <span>
//                           ${invoice.subtotal?.toFixed(2) || "0.00"}
//                           {Currency}{" "}
//                           {selectedJobCard?.total_estimate.toFixed(2) || "0.00"}
//                         </span>
//                       </div>
//                       <div className="d-flex justify-content-between mb-2">
//                         <span>Tax ({invoice.taxRate}%):</span>
//                         <span>
//                           {/* ${invoice.taxAmount?.toFixed(2) || "0.00"} */}

//                           {(
//                             ((selectedJobCard?.total_estimate || 0) *
//                               (invoice.taxRate || 0)) /
//                             100
//                           ).toFixed(2)}
//                         </span>
//                       </div>
//                       <div className="d-flex justify-content-between mb-2">
//                         <span>Discount:</span>
//                         <span>
//                           {/* -${invoice.discount?.toFixed(2) || "0.00"} */}
//                           -${invoice.discount?.toFixed(2) || "0.00"}
//                         </span>
//                       </div>
//                       <div className="d-flex justify-content-between mb-2 border-top pt-2">
//                         <strong>Total:</strong>
//                         <strong>${total || "0.00"}</strong>
//                       </div>
//                     </div>

//                     <div className="mt-4">
//                       <Button
//                         color="primary"
//                         className="w-100 mb-2"
//                         onClick={() => handleSaveInvoice("unpaid")}
//                         disabled={saving}
//                       >
//                         {saving ? (
//                           <>
//                             <Spinner size="sm" className="me-2" />
//                             Creating...
//                           </>
//                         ) : (
//                           <>
//                             <i className="fa fa-paper-plane me-2"></i>
//                             Create Invoice
//                           </>
//                         )}
//                       </Button>
//                       {/* <Button
//                         color="outline-secondary"
//                         className="w-100 mb-2"
//                         onClick={() => handleSaveInvoice("draft")}
//                         disabled={saving}
//                       >
//                         {saving ? (
//                           <>
//                             <Spinner size="sm" className="me-2" />
//                             Saving...
//                           </>
//                         ) : (
//                           <>
//                             <i className="fa fa-save me-2"></i>
//                             Save as Draft
//                           </>
//                         )}
//                       </Button> */}
//                       <Button
//                         color="outline-danger"
//                         className="w-100"
//                         onClick={() => router.push("/admin/invoices")}
//                         disabled={saving}
//                       >
//                         Cancel
//                       </Button>
//                     </div>
//                   </>
//                 ) : (
//                   // <div className="text-center text-muted py-4">
//                   //   <i className="fa fa-file-invoice fa-3x mb-3"></i>
//                   //   <p className="mb-2">
//                   //     Select a job card to create an invoice
//                   //   </p>
//                   //   <small className="text-muted">
//                   //     Search and select from completed job cards
//                   //   </small>
//                   // </div>
//                   <div className="text-center text-muted py-4">
//                     <i className="fa fa-file-invoice fa-3x mb-3"></i>
//                     <p className="mb-2">
//                       Select a completed job card to create an invoice
//                     </p>
//                     <small className="text-muted">
//                       Only job cards with "completed" status are shown
//                     </small>
//                     {jobCards.length === 0 && (
//                       <div className="mt-3">
//                         <Alert color="warning" className="mb-0">
//                           <i className="fa fa-exclamation-triangle me-2"></i>
//                           No completed job cards available
//                         </Alert>
//                       </div>
//                     )}
//                   </div>
//                 )}
//               </CardBody>
//             </Card>
//           </Col>
//         </Row>
//       </Container>

//       <style jsx>{`
//         .cursor-pointer {
//           cursor: pointer;
//         }

//         .hover-bg:hover {
//           background-color: #f8f9fa;
//         }

//         .hover-bg.bg-primary:hover {
//           background-color: #0d6efd !important;
//         }
//       `}</style>
//     </div>
//   );
// }

// export default CreateInvoicePage;

"use client";
import Breadcrumbs from "@/CommonElements/Breadcrumbs";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  Form,
  FormGroup,
  Label,
  Input,
  Button,
  Table,
  Badge,
  Alert,
  Spinner,
  Dropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
} from "reactstrap";
import React, { useState, useEffect, useRef } from "react";
import { useRouter } from "next/navigation";
import { InvoiceItem } from "@/Types/invoice";
import { toast } from "react-toastify";
import { useAuth } from "@/helper/AuthContext";

// API response types
interface ApiJobCard {
  id: string;
  job_number: string;
  customer_id: string;
  customer_name: string;
  vehicle_id?: string;
  registration_number?: string;
  model?: string;
  total_cost?: string;
  total_estimate: string;
  status: string;
  completed_date?: string;
}

// JobCard interface
export interface JobCard {
  id: number;
  jobNumber: string;
  customerId: number;
  customerName: string;
  vehicle: string;
  licensePlate: string;
  serviceType: string;
  laborCost: number;
  partsCost: number;
  total_estimate: number;
  status: string;
  completedDate: string;
}

interface Customer {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  address?: string;
}

interface Invoice {
  issueDate: string;
  dueDate: string;
  tax_amount: number;
  discount_amount: number;
  job_card_id: string;
  customer_id: string;
}

function CreateInvoicePage() {
  const router = useRouter();
  const { state } = useAuth();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [jobCards, setJobCards] = useState<JobCard[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [selectedJobCard, setSelectedJobCard] = useState<JobCard | null>(null);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(
    null
  );
  const [error, setError] = useState<string | null>(null);

  // Dropdown state
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const dropdownRef = useRef<HTMLDivElement>(null);

  const [invoice, setInvoice] = useState<Partial<Invoice>>({
    issueDate: new Date().toISOString().split("T")[0],
    dueDate: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000)
      .toISOString()
      .split("T")[0],
    tax_amount: 0,
    discount_amount: 0,
  });

  // Fetch job cards and customers from API
  useEffect(() => {
    fetchJobCards();
    fetchCustomers();
  }, []);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node)
      ) {
        setDropdownOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const fetchJobCards = async () => {
    try {
      setLoading(true);
      const token = state?.accessToken || localStorage.getItem("token");

      // Fetch ALL job cards (or you can filter by status in the API if supported)
      const response = await fetch("/api/jobcards", {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error("Failed to fetch job cards");
      }

      const data = await response.json();

      if (data.data && Array.isArray(data.data)) {
        // Filter for completed job cards only
        const completedJobs = data.data.filter(
          (job: any) =>
            job.status === "completed" && job.invoice_status === "no"
          // ||job.status === "Completed"
        );

        // if (completedJobs.length === 0) {
        //   toast.info("No completed job cards found");
        // }

        // Transform API data to match JobCard type for COMPLETED jobs only
        const transformedJobCards: JobCard[] = completedJobs.map(
          (apiJobCard: ApiJobCard) => ({
            id: parseInt(apiJobCard.id),
            jobNumber: apiJobCard.job_number,
            customerId: parseInt(apiJobCard.customer_id),
            customerName: apiJobCard.customer_name,
            vehicle: apiJobCard.registration_number || "N/A",
            licensePlate: apiJobCard.registration_number || "N/A",
            serviceType: "Service",
            laborCost: 0,
            partsCost: 0,
            total_estimate: parseFloat(apiJobCard.total_estimate || "0"),
            status: apiJobCard.status,
            completedDate:
              apiJobCard.completed_date ||
              new Date().toISOString().split("T")[0],
          })
        );

        setJobCards(transformedJobCards);
      } else {
        toast.error("Invalid data format received from API");
        setJobCards([]);
      }
    } catch (err: any) {
      console.error("Error fetching job cards:", err);
      setError(err.message);
      toast.error("Failed to load job cards");
    } finally {
      setLoading(false);
    }
  };

  const fetchCustomers = async () => {
    try {
      const token = state?.accessToken || localStorage.getItem("token");

      const response = await fetch("/api/customers", {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      if (response.ok) {
        const data = await response.json();
        setCustomers(data.data || []);
      }
    } catch (err) {
      console.error("Error fetching customers:", err);
    }
  };

  // Filter job cards based on search term
  const filteredJobCards = jobCards.filter(
    (jobCard) =>
      jobCard.jobNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      jobCard.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      jobCard.vehicle.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleJobCardSelect = async (jobCard: JobCard) => {
    try {
      setLoading(true);
      const token = state?.accessToken || localStorage.getItem("token");

      // Fetch job card details to get items and parts
      const response = await fetch(`/api/jobcards/${jobCard.id}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (response.ok) {
        const jobCardDetails = await response.json();

        // Create invoice items from job card items and parts
        const invoiceItems: InvoiceItem[] = [];

        // Add labor items
        if (jobCardDetails.items && jobCardDetails.items.length > 0) {
          jobCardDetails.items.forEach((item: any, index: number) => {
            invoiceItems.push({
              id: index + 1,
              description: item.description || "Labor",
              type: "labor",
              quantity: item.labor_hours || 1,
              unitPrice: item.labor_rate || 0,
              total: (item.labor_hours || 1) * (item.labor_rate || 0),
            });
          });
        }

        // Add parts items
        if (jobCardDetails.parts && jobCardDetails.parts.length > 0) {
          jobCardDetails.parts.forEach((part: any, index: number) => {
            invoiceItems.push({
              id: invoiceItems.length + index + 1,
              description: part.name || "Part",
              type: "part",
              quantity: part.quantity || 1,
              unitPrice: part.unit_price || 0,
              total: (part.quantity || 1) * (part.unit_price || 0),
            });
          });
        }

        // Find customer details
        const customer = customers.find(
          (c) => c.id === jobCard.customerId.toString()
        );

        setSelectedJobCard(jobCard);
        setSelectedCustomer(customer || null);
        setSearchTerm(jobCard.jobNumber);
        setDropdownOpen(false);

        setInvoice({
          issueDate: new Date().toISOString().split("T")[0],
          dueDate: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000)
            .toISOString()
            .split("T")[0],
          tax_amount: 0,
          discount_amount: 0,
        });
      } else {
        toast.error("Failed to load job card details");
      }
    } catch (err: any) {
      console.error("Error fetching job card details:", err);
      toast.error("Error loading job card details");
    } finally {
      setLoading(false);
    }
  };

  const clearSelection = () => {
    setSelectedJobCard(null);
    setSelectedCustomer(null);
    setSearchTerm("");
    setInvoice({
      issueDate: new Date().toISOString().split("T")[0],
      dueDate: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000)
        .toISOString()
        .split("T")[0],
      tax_amount: 0,
      discount_amount: 0,
    });
  };

  const handleInputChange = (field: string, value: string | number) => {
    setInvoice((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleSaveInvoice = async () => {
    if (!selectedJobCard) {
      toast.error("Please select a job card");
      return;
    }

    try {
      setSaving(true);
      const token = state?.accessToken || localStorage.getItem("token");

      // Get values from form
      const taxAmount = Number(invoice.tax_amount) || 0;
      const discountAmount = Number(invoice.discount_amount) || 0;

      // Format dates to match API expected format (DD-MM-YYYY)
      const formatDate = (dateString: string) => {
        const date = new Date(dateString);
        const day = String(date.getDate()).padStart(2, "0");
        const month = String(date.getMonth() + 1).padStart(2, "0");
        const year = date.getFullYear();
        return `${day}-${month}-${year}`;
      };

      // Prepare the payload according to API expectations
      const payload = {
        issue_date: formatDate(
          invoice.issueDate || new Date().toISOString().split("T")[0]
        ),
        due_date: formatDate(
          invoice.dueDate ||
            new Date(Date.now() + 15 * 24 * 60 * 60 * 1000)
              .toISOString()
              .split("T")[0]
        ),
        tax_amount: String(taxAmount),
        discount_amount: String(discountAmount),
        job_card_id: selectedJobCard.id.toString(),
        customer_id:
          selectedCustomer?.id || selectedJobCard.customerId.toString(),
      };

      console.log("Sending invoice payload:", JSON.stringify(payload, null, 2));

      const response = await fetch("/api/invoices", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      });

      const responseData = await response.json();

      if (response.ok) {
        toast.success(`Invoice created successfully!`);

        setTimeout(() => {
          router.push("/admin/invoices");
        }, 1500);
      } else {
        console.error("API Error Response:", responseData);
        toast.error(responseData.message || "Failed to create invoice");
      }
    } catch (err: any) {
      console.error("Error creating invoice:", err);
      toast.error("Failed to create invoice");
    } finally {
      setSaving(false);
    }
  };

  // Calculate total amount
  const calculateTotal = () => {
    if (!selectedJobCard) return 0;

    const subtotal = selectedJobCard.total_estimate;
    const taxAmount = Number(invoice.tax_amount) || 0;
    const discountAmount = Number(invoice.discount_amount) || 0;

    return subtotal + taxAmount - discountAmount;
  };

  if (loading && !selectedJobCard) {
    return (
      <div className="page-body">
        <Breadcrumbs
          title="Create Invoice"
          mainTitle="Billing & Invoicing"
          parent="Invoices"
        />
        <Container fluid>
          <Row>
            <Col lg="12">
              <Card>
                <CardBody className="text-center py-5">
                  <Spinner color="primary" />
                  <p className="mt-3">Loading job cards...</p>
                </CardBody>
              </Card>
            </Col>
          </Row>
        </Container>
      </div>
    );
  }

  return (
    <div className="page-body">
      <Breadcrumbs
        title="Create Invoice"
        mainTitle="Billing & Invoicing"
        parent="Invoices"
      />

      <Container fluid>
        <Row>
          <Col lg="8">
            <Card>
              <CardBody>
                <h5 className="card-title mb-4 text-muted">
                  Create New Invoice
                </h5>

                {error && (
                  <Alert color="danger" className="mb-4">
                    {error}
                  </Alert>
                )}

                {/* Job Card Selection - Searchable Dropdown */}
                <Card className="mb-4">
                  <CardBody>
                    <h6 className="mb-3 text-muted">Select Job Card</h6>

                    <div className="position-relative" ref={dropdownRef}>
                      <div className="d-flex gap-2 mb-3">
                        <div className="flex-grow-1">
                          <Input
                            type="text"
                            placeholder="Search job cards by job number, customer, or vehicle..."
                            value={searchTerm}
                            onChange={(e) => {
                              setSearchTerm(e.target.value);
                              if (!dropdownOpen) setDropdownOpen(true);
                            }}
                            onClick={() => setDropdownOpen(true)}
                            className="w-100"
                          />
                        </div>
                        {selectedJobCard && (
                          <Button
                            color="outline-danger"
                            onClick={clearSelection}
                            className="flex-shrink-0"
                          >
                            <i className="fa fa-times"></i>
                          </Button>
                        )}
                      </div>

                      {/* Dropdown Menu */}
                      {dropdownOpen && filteredJobCards.length > 0 && (
                        <div
                          className="position-absolute w-100 bg-white border rounded shadow-lg"
                          style={{
                            zIndex: 1000,
                            maxHeight: "400px",
                            overflowY: "auto",
                            marginTop: "2px",
                          }}
                        >
                          {filteredJobCards.map((jobCard) => (
                            <div
                              key={jobCard.id}
                              className={`p-3 border-bottom cursor-pointer hover-bg ${
                                selectedJobCard?.id === jobCard.id
                                  ? "bg-primary text-white"
                                  : ""
                              }`}
                              onClick={() => handleJobCardSelect(jobCard)}
                            >
                              <div className="d-flex justify-content-between align-items-start">
                                <div>
                                  <div className="d-flex align-items-center">
                                    <strong className="me-2">
                                      {jobCard.jobNumber}
                                    </strong>
                                    <Badge
                                      color={
                                        jobCard.status === "completed"
                                          ? "success"
                                          : "warning"
                                      }
                                      className="ms-2"
                                    >
                                      {jobCard.status}
                                    </Badge>
                                  </div>
                                  <div className="mt-1">
                                    <small>
                                      <i className="fa fa-user me-1"></i>
                                      {jobCard.customerName}
                                    </small>
                                    <br />
                                    <small>
                                      <i className="fa fa-car me-1"></i>
                                      {jobCard.vehicle}
                                    </small>
                                  </div>
                                </div>
                                <div className="text-end">
                                  <div className="fw-bold">
                                    ${jobCard.total_estimate.toFixed(2)}
                                  </div>
                                  <small className="text-muted">
                                    {jobCard.completedDate}
                                  </small>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}

                      {dropdownOpen && filteredJobCards.length === 0 && (
                        <div
                          className="position-absolute w-100 bg-white border rounded shadow-lg p-3"
                          style={{ zIndex: 1000, marginTop: "2px" }}
                        >
                          <div className="text-center text-muted">
                            <i className="fa fa-check-circle fa-lg mb-2 text-success"></i>
                            <p>No completed job cards found</p>
                            <small className="text-muted">
                              Only job cards with "completed" status are shown
                            </small>
                          </div>
                        </div>
                      )}

                      {/* Selected Job Card Display */}
                      {selectedJobCard && !dropdownOpen && (
                        <Card className="mt-3 border-primary">
                          <CardBody>
                            <div className="d-flex justify-content-between align-items-start">
                              <div>
                                <h6 className="mb-1">
                                  <i className="fa fa-file-alt me-2 text-primary"></i>
                                  {selectedJobCard.jobNumber}
                                </h6>
                                <p className="mb-1">
                                  <strong>Customer:</strong>{" "}
                                  {selectedJobCard.customerName}
                                </p>
                                <p className="mb-1">
                                  <strong>Vehicle:</strong>{" "}
                                  {selectedJobCard.vehicle}
                                </p>
                                <p className="mb-1">
                                  <strong>Service:</strong>{" "}
                                  {selectedJobCard.serviceType}
                                </p>
                                <p className="mb-0">
                                  <strong>Completed:</strong>{" "}
                                  {selectedJobCard.completedDate}
                                </p>
                              </div>
                              <div className="text-end">
                                <Badge color="success" className="mb-2">
                                  ${selectedJobCard.total_estimate.toFixed(2)}
                                </Badge>
                                <div>
                                  <small className="text-muted">
                                    Click search to change
                                  </small>
                                </div>
                              </div>
                            </div>
                          </CardBody>
                        </Card>
                      )}

                      {!selectedJobCard && jobCards.length === 0 && (
                        <Alert color="info" className="mt-3">
                          <i className="fa fa-info-circle me-2"></i>
                          No completed job cards found. Please complete a job
                          card first.
                        </Alert>
                      )}
                    </div>
                  </CardBody>
                </Card>

                {selectedJobCard && (
                  <>
                    {/* Invoice Details */}
                    <Card>
                      <CardBody>
                        <h6 className="mb-3 text-muted">Invoice Details</h6>
                        <Row className="text-muted">
                          <Col md="6">
                            <FormGroup>
                              <Label>Issue Date</Label>
                              <Input
                                type="date"
                                value={invoice.issueDate}
                                onChange={(e) =>
                                  handleInputChange("issueDate", e.target.value)
                                }
                                disabled={saving}
                              />
                            </FormGroup>
                          </Col>
                          <Col md="6">
                            <FormGroup>
                              <Label>Due Date</Label>
                              <Input
                                type="date"
                                value={invoice.dueDate}
                                onChange={(e) =>
                                  handleInputChange("dueDate", e.target.value)
                                }
                                disabled={saving}
                              />
                            </FormGroup>
                          </Col>
                        </Row>
                        <Row className="text-muted">
                          <Col md="6">
                            <FormGroup>
                              <Label>Tax Amount ($)</Label>
                              <Input
                                type="number"
                                step="0.01"
                                min="0"
                                value={invoice.tax_amount || 0}
                                onChange={(e) =>
                                  handleInputChange(
                                    "tax_amount",
                                    Number(e.target.value)
                                  )
                                }
                                disabled={saving}
                              />
                            </FormGroup>
                          </Col>
                          <Col md="6">
                            <FormGroup>
                              <Label>Discount ($)</Label>
                              <Input
                                type="number"
                                step="0.01"
                                min="0"
                                value={invoice.discount_amount || 0}
                                onChange={(e) =>
                                  handleInputChange(
                                    "discount_amount",
                                    Number(e.target.value)
                                  )
                                }
                                disabled={saving}
                              />
                            </FormGroup>
                          </Col>
                        </Row>
                      </CardBody>
                    </Card>
                  </>
                )}
              </CardBody>
            </Card>
          </Col>

          {/* Invoice Summary */}
          <Col lg="4">
            <Card>
              <CardBody className="text-muted">
                <h6 className="card-title mb-3 text-muted">Invoice Summary</h6>

                {selectedJobCard ? (
                  <>
                    <div className="mb-3">
                      <strong>Customer:</strong> {selectedJobCard.customerName}
                      <br />
                      <strong>Job Card:</strong> {selectedJobCard.jobNumber}
                      <br />
                      <strong>Vehicle:</strong> {selectedJobCard.vehicle}
                    </div>

                    <div className="border-top pt-3">
                      <div className="d-flex justify-content-between mb-2">
                        <span>Subtotal:</span>
                        <span>
                          ${selectedJobCard.total_estimate.toFixed(2)}
                        </span>
                      </div>
                      <div className="d-flex justify-content-between mb-2">
                        <span>Tax Amount:</span>
                        <span>
                          ${Number(invoice.tax_amount || 0).toFixed(2)}
                        </span>
                      </div>
                      <div className="d-flex justify-content-between mb-2">
                        <span>Discount:</span>
                        <span>
                          -${Number(invoice.discount_amount || 0).toFixed(2)}
                        </span>
                      </div>
                      <div className="d-flex justify-content-between mb-2 border-top pt-2">
                        <strong>Total:</strong>
                        <strong>${calculateTotal().toFixed(2)}</strong>
                      </div>
                    </div>

                    <div className="mt-4">
                      <Button
                        color="primary"
                        className="w-100 mb-2"
                        onClick={handleSaveInvoice}
                        disabled={saving}
                      >
                        {saving ? (
                          <>
                            <Spinner size="sm" className="me-2" />
                            Creating...
                          </>
                        ) : (
                          <>
                            <i className="fa fa-paper-plane me-2"></i>
                            Create Invoice
                          </>
                        )}
                      </Button>
                      <Button
                        color="outline-danger"
                        className="w-100"
                        onClick={() => router.push("/admin/invoices")}
                        disabled={saving}
                      >
                        Cancel
                      </Button>
                    </div>
                  </>
                ) : (
                  <div className="text-center text-muted py-4">
                    <i className="fa fa-file-invoice fa-3x mb-3"></i>
                    <p className="mb-2">
                      Select a completed job card to create an invoice
                    </p>
                    <small className="text-muted">
                      Only job cards with "completed" status are shown
                    </small>
                    {jobCards.length === 0 && (
                      <div className="mt-3">
                        <Alert color="warning" className="mb-0">
                          <i className="fa fa-exclamation-triangle me-2"></i>
                          No completed job cards available
                        </Alert>
                      </div>
                    )}
                  </div>
                )}
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Container>

      <style jsx>{`
        .cursor-pointer {
          cursor: pointer;
        }

        .hover-bg:hover {
          background-color: #f8f9fa;
        }

        .hover-bg.bg-primary:hover {
          background-color: #0d6efd !important;
        }
      `}</style>
    </div>
  );
}

export default CreateInvoicePage;
