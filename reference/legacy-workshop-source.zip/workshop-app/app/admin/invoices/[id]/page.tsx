// "use client";
// import Breadcrumbs from "@/CommonElements/Breadcrumbs";
// import {
//   Container,
//   Row,
//   Col,
//   Card,
//   CardBody,
//   Table,
//   Badge,
//   Button,
//   Form,
//   FormGroup,
//   Label,
//   Input,
// } from "reactstrap";
// import React, { useState } from "react";
// import { useParams, useRouter } from "next/navigation";
// import { Invoice, Payment } from "@/Types/invoice";
// // import { Invoice, Payment } from "@/types/invoice";

// // Mock data - in real app, you'd fetch this based on ID
// const mockInvoice: Invoice = {
//   id: 1,
//   invoiceNumber: "INV-2024-001",
//   jobCardId: 101,
//   customerId: 1,
//   customerName: "John Doe",
//   customerEmail: "john@example.com",
//   customerPhone: "+1 234 567 8900",
//   customerAddress: "123 Main St, City, State 12345",
//   issueDate: "2024-01-15",
//   dueDate: "2024-01-30",
//   items: [
//     {
//       id: 1,
//       description: "Brake Pad Replacement",
//       type: "labor",
//       quantity: 2,
//       unitPrice: 150.0,
//       total: 300.0,
//     },
//     {
//       id: 2,
//       description: "Brake Pads Set",
//       type: "part",
//       quantity: 1,
//       unitPrice: 120.0,
//       total: 120.0,
//     },
//   ],
//   subtotal: 420.0,
//   taxRate: 8.5,
//   taxAmount: 35.7,
//   discount: 0,
//   total: 455.7,
//   amountPaid: 455.7,
//   balanceDue: 0,
//   status: "paid",
//   payments: [
//     {
//       id: 1,
//       date: "2024-01-15",
//       amount: 455.7,
//       method: "credit_card",
//       reference: "CHG-12345",
//       status: "completed",
//     },
//   ],
//   notes: "Brakes were worn out and needed replacement",
//   terms: "Due upon receipt",
//   createdAt: "2024-01-15T10:00:00Z",
//   updatedAt: "2024-01-15T10:00:00Z",
// };

// function InvoiceDetailPage() {
//   const params = useParams();
//   const router = useRouter();
//   const [invoice, setInvoice] = useState<Invoice>(mockInvoice);
//   const [showPaymentForm, setShowPaymentForm] = useState(false);
//   const [newPayment, setNewPayment] = useState<Partial<Payment>>({
//     date: new Date().toISOString().split("T")[0],
//     amount: 0,
//     method: "cash",
//     reference: "",
//   });

//   const getStatusBadge = (status: string) => {
//     const statusConfig = {
//       draft: { color: "secondary", label: "Draft" },
//       sent: { color: "info", label: "Sent" },
//       paid: { color: "success", label: "Paid" },
//       overdue: { color: "danger", label: "Overdue" },
//       partial: { color: "warning", label: "Partial" },
//       cancelled: { color: "dark", label: "Cancelled" },
//     };

//     const config = statusConfig[status as keyof typeof statusConfig];
//     return <Badge color={config.color}>{config.label}</Badge>;
//   };

//   const handleAddPayment = () => {
//     const payment: Payment = {
//       id: Math.floor(Math.random() * 1000),
//       date: newPayment.date!,
//       amount: newPayment.amount!,
//       method: newPayment.method!,
//       reference: newPayment.reference!,
//       status: "completed",
//     };

//     const updatedPayments = [...invoice.payments, payment];
//     const amountPaid = updatedPayments.reduce((sum, p) => sum + p.amount, 0);
//     const balanceDue = invoice.total - amountPaid;
//     const status =
//       balanceDue === 0
//         ? "paid"
//         : balanceDue < invoice.total
//         ? "partial"
//         : invoice.status;

//     setInvoice({
//       ...invoice,
//       payments: updatedPayments,
//       amountPaid,
//       balanceDue,
//       status,
//     });

//     setShowPaymentForm(false);
//     setNewPayment({
//       date: new Date().toISOString().split("T")[0],
//       amount: 0,
//       method: "cash",
//       reference: "",
//     });

//     // If fully paid, mark job as closed
//     if (balanceDue === 0) {
//       console.log("Job marked as closed for invoice:", invoice.invoiceNumber);
//     }
//   };

//   const handleExportPDF = () => {
//     console.log("Exporting PDF for invoice:", invoice.invoiceNumber);
//     alert(`PDF generated for ${invoice.invoiceNumber}`);
//   };

//   const handleSendReminder = () => {
//     alert(`Payment reminder sent to ${invoice.customerEmail}`);
//   };

//   return (
//     <div className="page-body">
//       <Breadcrumbs
//         title={`Invoice ${invoice.invoiceNumber}`}
//         mainTitle="Billing & Invoicing"
//         parent="Invoices"
//       />

//       <Container fluid>
//         <Row>
//           <Col lg="8">
//             <Card>
//               <CardBody>
//                 {/* Invoice Header */}
//                 <div className="d-flex justify-content-between align-items-center mb-4 text-muted">
//                   <div>
//                     <h4 className="mb-1">{invoice.invoiceNumber}</h4>
//                     <p className="text-muted mb-0">
//                       Job Card: JC-{invoice.jobCardId}
//                     </p>
//                   </div>
//                   <div className="text-end">
//                     {getStatusBadge(invoice.status)}
//                     <div className="mt-2">
//                       <Button
//                         color="outline-primary"
//                         size="sm"
//                         onClick={handleExportPDF}
//                       >
//                         <i className="fa fa-file-pdf me-1"></i>PDF
//                       </Button>
//                       {invoice.status === "sent" && (
//                         <Button
//                           color="outline-warning"
//                           size="sm"
//                           className="ms-1"
//                           onClick={handleSendReminder}
//                         >
//                           <i className="fa fa-bell me-1"></i>Reminder
//                         </Button>
//                       )}
//                     </div>
//                   </div>
//                 </div>

//                 {/* Customer and Dates */}
//                 <Row className="mb-4">
//                   <Col md="6">
//                     <Card className="bg-light">
//                       <CardBody className="text-muted">
//                         <h6>Bill To:</h6>
//                         <strong>{invoice.customerName}</strong>
//                         <br />
//                         {invoice.customerAddress}
//                         <br />
//                         {invoice.customerPhone}
//                         <br />
//                         {invoice.customerEmail}
//                       </CardBody>
//                     </Card>
//                   </Col>
//                   <Col md="6">
//                     <Card className="bg-light">
//                       <CardBody className="text-muted">
//                         <div className="d-flex justify-content-between">
//                           <span>Issue Date:</span>
//                           <strong>
//                             {new Date(invoice.issueDate).toLocaleDateString()}
//                           </strong>
//                         </div>
//                         <div className="d-flex justify-content-between">
//                           <span>Due Date:</span>
//                           <strong>
//                             {new Date(invoice.dueDate).toLocaleDateString()}
//                           </strong>
//                         </div>
//                         <div className="d-flex justify-content-between">
//                           <span>Status:</span>
//                           <strong>{getStatusBadge(invoice.status)}</strong>
//                         </div>
//                       </CardBody>
//                     </Card>
//                   </Col>
//                 </Row>

//                 {/* Invoice Items */}
//                 <Card className="mb-4">
//                   <CardBody className="text-muted">
//                     <h6 className="mb-3">Invoice Items</h6>
//                     <div className="table-responsive">
//                       <Table bordered hover>
//                         <thead>
//                           <tr>
//                             <th>Description</th>
//                             <th>Type</th>
//                             <th>Qty</th>
//                             <th>Unit Price</th>
//                             <th>Total</th>
//                           </tr>
//                         </thead>
//                         <tbody>
//                           {invoice.items.map((item) => (
//                             <tr key={item.id}>
//                               <td>{item.description}</td>
//                               <td>
//                                 <Badge
//                                   color="light"
//                                   className="text-capitalize text-muted"
//                                 >
//                                   {item.type}
//                                 </Badge>
//                               </td>
//                               <td>{item.quantity}</td>
//                               <td>${item.unitPrice.toFixed(2)}</td>
//                               <td>${item.total.toFixed(2)}</td>
//                             </tr>
//                           ))}
//                         </tbody>
//                       </Table>
//                     </div>
//                   </CardBody>
//                 </Card>

//                 {/* Payment History */}
//                 <Card>
//                   <CardBody>
//                     <div className="d-flex justify-content-between align-items-center mb-3 ">
//                       <h6 className="mb-0 text-muted">Payment History</h6>
//                       {invoice.balanceDue > 0 && (
//                         <Button
//                           color="primary"
//                           size="sm"
//                           onClick={() => setShowPaymentForm(!showPaymentForm)}
//                         >
//                           <i className="fa fa-plus me-1"></i>
//                           Add Payment
//                         </Button>
//                       )}
//                     </div>

//                     {/* Add Payment Form */}
//                     {showPaymentForm && (
//                       <Card className="bg-light mb-3">
//                         <CardBody>
//                           <h6>Record New Payment</h6>
//                           <Row>
//                             <Col md="3">
//                               <FormGroup>
//                                 <Label>Date</Label>
//                                 <Input
//                                   type="date"
//                                   value={newPayment.date}
//                                   onChange={(e) =>
//                                     setNewPayment({
//                                       ...newPayment,
//                                       date: e.target.value,
//                                     })
//                                   }
//                                 />
//                               </FormGroup>
//                             </Col>
//                             <Col md="3">
//                               <FormGroup>
//                                 <Label>Amount</Label>
//                                 <Input
//                                   type="number"
//                                   step="0.01"
//                                   value={newPayment.amount}
//                                   onChange={(e) =>
//                                     setNewPayment({
//                                       ...newPayment,
//                                       amount: Number(e.target.value),
//                                     })
//                                   }
//                                   max={invoice.balanceDue}
//                                 />
//                               </FormGroup>
//                             </Col>
//                             <Col md="3">
//                               <FormGroup>
//                                 <Label>Method</Label>
//                                 <Input
//                                   type="select"
//                                   value={newPayment.method}
//                                   onChange={(e) =>
//                                     setNewPayment({
//                                       ...newPayment,
//                                       method: e.target.value as any,
//                                     })
//                                   }
//                                 >
//                                   <option value="cash">Cash</option>
//                                   <option value="credit_card">
//                                     Credit Card
//                                   </option>
//                                   <option value="bank_transfer">
//                                     Bank Transfer
//                                   </option>
//                                   <option value="check">Check</option>
//                                 </Input>
//                               </FormGroup>
//                             </Col>
//                             <Col md="3">
//                               <FormGroup>
//                                 <Label>Reference</Label>
//                                 <Input
//                                   type="text"
//                                   value={newPayment.reference}
//                                   onChange={(e) =>
//                                     setNewPayment({
//                                       ...newPayment,
//                                       reference: e.target.value,
//                                     })
//                                   }
//                                   placeholder="Ref #"
//                                 />
//                               </FormGroup>
//                             </Col>
//                           </Row>
//                           <div className="d-flex gap-2">
//                             <Button color="success" onClick={handleAddPayment}>
//                               Record Payment
//                             </Button>
//                             <Button
//                               color="outline-secondary"
//                               onClick={() => setShowPaymentForm(false)}
//                             >
//                               Cancel
//                             </Button>
//                           </div>
//                         </CardBody>
//                       </Card>
//                     )}

//                     {/* Payments List */}
//                     {/* Payments List */}
//                     {invoice.payments.length > 0 ? (
//                       <div className="table-responsive">
//                         <Table bordered hover>
//                           <thead>
//                             <tr>
//                               <th>Date</th>
//                               <th>Amount</th>
//                               <th>Method</th>
//                               <th>Reference</th>
//                               <th>Status</th>
//                             </tr>
//                           </thead>
//                           <tbody>
//                             {invoice.payments.map((payment) => (
//                               <tr key={payment.id}>
//                                 <td>
//                                   {new Date(payment.date).toLocaleDateString()}
//                                 </td>
//                                 <td>${payment.amount.toFixed(2)}</td>
//                                 <td>
//                                   <Badge
//                                     color="info"
//                                     className="text-capitalize"
//                                   >
//                                     {payment.method.replace("_", " ")}
//                                   </Badge>
//                                 </td>
//                                 <td>{payment.reference}</td>
//                                 <td>
//                                   <Badge color="success">Completed</Badge>
//                                 </td>
//                               </tr>
//                             ))}
//                           </tbody>
//                         </Table>
//                       </div>
//                     ) : (
//                       <div className="text-center text-muted py-3">
//                         No payments recorded yet.
//                       </div>
//                     )}
//                   </CardBody>
//                 </Card>
//               </CardBody>
//             </Card>
//           </Col>

//           {/* Invoice Summary */}
//           <Col lg="4">
//             <Card>
//               <CardBody className="text-muted">
//                 <h6 className="card-title mb-3 text-muted">Invoice Summary</h6>

//                 <div className="border-bottom pb-3 mb-3">
//                   <div className="d-flex justify-content-between mb-2">
//                     <span>Subtotal:</span>
//                     <span>${invoice.subtotal.toFixed(2)}</span>
//                   </div>
//                   <div className="d-flex justify-content-between mb-2">
//                     <span>Tax ({invoice.taxRate}%):</span>
//                     <span>${invoice.taxAmount.toFixed(2)}</span>
//                   </div>
//                   <div className="d-flex justify-content-between mb-2">
//                     <span>Discount:</span>
//                     <span>-${invoice.discount.toFixed(2)}</span>
//                   </div>
//                   <div className="d-flex justify-content-between mb-2 pt-2 border-top">
//                     <strong>Total Amount:</strong>
//                     <strong>${invoice.total.toFixed(2)}</strong>
//                   </div>
//                 </div>

//                 <div className="border-bottom pb-3 mb-3">
//                   <div className="d-flex justify-content-between mb-2">
//                     <span>Amount Paid:</span>
//                     <span className="text-success">
//                       ${invoice.amountPaid.toFixed(2)}
//                     </span>
//                   </div>
//                   <div className="d-flex justify-content-between mb-2">
//                     <span>Balance Due:</span>
//                     <span
//                       className={
//                         invoice.balanceDue > 0 ? "text-danger" : "text-success"
//                       }
//                     >
//                       ${invoice.balanceDue.toFixed(2)}
//                     </span>
//                   </div>
//                 </div>

//                 {invoice.notes && (
//                   <div className="mb-3">
//                     <strong>Notes:</strong>
//                     <p className="text-muted mb-0">{invoice.notes}</p>
//                   </div>
//                 )}

//                 {invoice.terms && (
//                   <div>
//                     <strong>Terms:</strong>
//                     <p className="text-muted mb-0">{invoice.terms}</p>
//                   </div>
//                 )}
//               </CardBody>
//             </Card>

//             {/* Quick Actions */}
//             <Card className="mt-4">
//               <CardBody>
//                 <h6 className="card-title mb-3 text-muted">Quick Actions</h6>
//                 <div className="d-grid gap-2">
//                   <Button color="outline-primary" onClick={handleExportPDF}>
//                     <i className="fa fa-file-pdf me-2"></i>
//                     Download PDF
//                   </Button>
//                   <Button color="outline-success">
//                     <i className="fa fa-envelope me-2"></i>
//                     Email Invoice
//                   </Button>
//                   {invoice.balanceDue > 0 && (
//                     <Button
//                       color="primary"
//                       onClick={() => setShowPaymentForm(true)}
//                     >
//                       <i className="fa fa-credit-card me-2"></i>
//                       Record Payment
//                     </Button>
//                   )}
//                 </div>
//               </CardBody>
//             </Card>
//           </Col>
//         </Row>
//       </Container>
//     </div>
//   );
// }

// export default InvoiceDetailPage;

"use client";
import Breadcrumbs from "@/CommonElements/Breadcrumbs";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  Table,
  Badge,
  Button,
  Form,
  FormGroup,
  Label,
  Input,
  Spinner,
  Alert,
} from "reactstrap";
import React, { useState, useEffect } from "react";
import { useParams, useRouter } from "next/navigation";
import { toast } from "react-toastify";
import { useAuth } from "@/helper/AuthContext";
import { Invoice, Payment } from "@/Types/invoice";

// API response types
interface ApiInvoice {
  id: string;
  invoice_number: string;
  job_card_id: string;
  customer_id: string;
  created_by: string;
  issue_date: string;
  due_date: string;
  subtotal: string;
  tax_amount: string;
  discount_amount: string;
  total_amount: string;
  status: string;
  meta: string;
  created_at: string;
  updated_at: string;
}

interface Customer {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  address?: string;
}

function InvoiceDetailPage() {
  const params = useParams();
  const router = useRouter();
  const { state } = useAuth();
  const [invoice, setInvoice] = useState<Invoice | null>(null);
  const [customer, setCustomer] = useState<Customer | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showPaymentForm, setShowPaymentForm] = useState(false);
  const [addingPayment, setAddingPayment] = useState(false);
  const [newPayment, setNewPayment] = useState<Partial<Payment>>({
    date: new Date().toISOString().split("T")[0],
    amount: 0,
    method: "cash",
    reference: "",
  });

  const invoiceId = params.id as string;

  // Fetch invoice data
  useEffect(() => {
    if (invoiceId) {
      fetchInvoice();
    }
  }, [invoiceId]);

  const fetchInvoice = async () => {
    try {
      setLoading(true);
      setError(null);
      const token = state?.accessToken || localStorage.getItem("token");

      // Fetch invoice
      const response = await fetch(`/api/invoices/${invoiceId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        throw new Error("Failed to fetch invoice");
      }

      const data = await response.json();
      const apiInvoice = data.data;

      // Transform API data to Invoice type
      const transformedInvoice: Invoice = {
        id: parseInt(apiInvoice.id),
        invoiceNumber: apiInvoice.invoice_number,
        jobCardId: parseInt(apiInvoice.job_card_id),
        customerId: parseInt(apiInvoice.customer_id),
        customerName: "", // Will be fetched separately
        customerEmail: "",
        customerPhone: "",
        customerAddress: "",
        issueDate: apiInvoice.issue_date.split(" ")[0], // Get date part only
        dueDate: apiInvoice.due_date.split(" ")[0], // Get date part only
        items: [], // Items might come from separate API
        subtotal: parseFloat(apiInvoice.subtotal) || 0,
        taxRate: 0, // Calculate from tax_amount/subtotal
        taxAmount: parseFloat(apiInvoice.tax_amount) || 0,
        discount: parseFloat(apiInvoice.discount_amount) || 0,
        total: parseFloat(apiInvoice.total_amount) || 0,
        amountPaid: 0,
        // amountPaid: Math.max(
        //   parseFloat(apiInvoice.data.total_amount) -
        //     parseFloat(apiInvoice.data.due_amount),
        //   0
        // ),
        // balanceDue: parseFloat(apiInvoice.total_amount) || 0,
        balanceDue: parseFloat(apiInvoice.due_amount) || 0,
        status: apiInvoice.status,
        payments: [], // Will fetch separately
        notes: "",
        terms: "",
        createdAt: apiInvoice.created_at,
        updatedAt: apiInvoice.updated_at,
      };

      // Calculate tax rate
      if (transformedInvoice.subtotal > 0) {
        transformedInvoice.taxRate =
          (transformedInvoice.taxAmount / transformedInvoice.subtotal) * 100;
      }

      setInvoice(transformedInvoice);

      // Fetch customer details
      await fetchCustomer(apiInvoice.customer_id);

      // Fetch invoice items if available
      // await fetchInvoiceItems(apiInvoice.id);

      // Fetch payments if available
      await fetchPayments(apiInvoice.id);
    } catch (err: any) {
      console.error("Error fetching invoice:", err);
      setError(err.message);
      toast.error("Failed to load invoice");
    } finally {
      setLoading(false);
    }
  };

  const fetchCustomer = async (customerId: string) => {
    try {
      const token = state?.accessToken || localStorage.getItem("token");

      const response = await fetch(`/api/customers/${customerId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (response.ok) {
        const data = await response.json();
        if (data.data) {
          setCustomer(data.data);

          // Update invoice with customer details
          setInvoice((prev) =>
            prev
              ? {
                  ...prev,
                  customerName: data.data.name || "",
                  customerEmail: data.data.email || "",
                  customerPhone: data.data.phone || "",
                  customerAddress: data.data.address || "",
                }
              : prev
          );
        }
      }
    } catch (err) {
      console.error("Error fetching customer:", err);
    }
  };

  // const fetchInvoiceItems = async (invoiceId: string) => {
  //   try {
  //     const token = state?.accessToken || localStorage.getItem("token");

  //     // Try to fetch invoice items if the endpoint exists
  //     const response = await fetch(`/api/invoices/${invoiceId}/items`, {
  //       headers: {
  //         Authorization: `Bearer ${token}`,
  //       },
  //     });

  //     if (response.ok) {
  //       const data = await response.json();
  //       if (data.data && Array.isArray(data.data)) {
  //         const items = data.data.map((item: any, index: number) => ({
  //           id: index + 1,
  //           description: item.description || item.name || "Item",
  //           type: item.type || "service",
  //           quantity: parseFloat(item.quantity) || 1,
  //           unitPrice: parseFloat(item.unit_price) || 0,
  //           total: parseFloat(item.amount) || 0,
  //         }));

  //         setInvoice((prev) => (prev ? { ...prev, items } : prev));
  //       }
  //     } else if (response.status === 404) {
  //       // Endpoint might not exist, which is OK
  //       console.log("Invoice items endpoint not found");
  //     }
  //   } catch (err) {
  //     console.error("Error fetching invoice items:", err);
  //   }
  // };

  const fetchPayments = async (invoiceId: string) => {
    try {
      const token = state?.accessToken || localStorage.getItem("token");

      // Try to fetch payments if the endpoint exists
      const response = await fetch(`/api/payments/${invoiceId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (response.ok) {
        const data = await response.json();
        if (data.data && Array.isArray(data.data)) {
          const payments = data.data.map((payment: any) => ({
            id: parseInt(payment.id),
            date: payment.payment_date || payment.created_at,
            amount: parseFloat(payment.amount) || 0,
            method: payment.payment_method || "cash",
            reference: payment.transaction_id || payment.reference || "",
            status: payment.status || "completed",
          }));

          // Calculate amount paid and balance due
          const amountPaid = payments.reduce(
            (sum: number, p: Payment) => sum + p.amount,
            0
          );
          // const balanceDue = invoice ? invoice.total - amountPaid : 0;

          setInvoice((prev) =>
            prev
              ? {
                  ...prev,
                  payments,
                  amountPaid,
                }
              : prev
          );
        }
      } else if (response.status === 404) {
        // Endpoint might not exist, which is OK
        console.log("Payments endpoint not found");
      }
    } catch (err) {
      console.error("Error fetching payments:", err);
    }
  };

  const getStatusBadge = (status: string) => {
    const statusConfig: Record<string, { color: string; label: string }> = {
      draft: { color: "secondary", label: "Draft" },
      sent: { color: "info", label: "Sent" },
      unpaid: { color: "warning", label: "Unpaid" },
      paid: { color: "success", label: "Paid" },
      overdue: { color: "danger", label: "Overdue" },
      partial: { color: "warning", label: "Partial" },
      cancelled: { color: "dark", label: "Cancelled" },
    };

    const config = statusConfig[status.toLowerCase()] || {
      color: "secondary",
      label: status,
    };
    return <Badge color={config.color}>{config.label}</Badge>;
  };

  const handleAddPayment = async () => {
    if (!invoice || !newPayment.amount || newPayment.amount <= 0) {
      toast.error("Please enter a valid payment amount");
      return;
    }

    if (newPayment.amount > invoice.balanceDue) {
      toast.error(
        `Payment amount cannot exceed balance due of $${invoice.balanceDue.toFixed(
          2
        )}`
      );
      return;
    }

    try {
      setAddingPayment(true);
      const token = state?.accessToken || localStorage.getItem("token");

      const payload = {
        invoice_id: invoiceId,
        amount: newPayment.amount,
        payment_method: newPayment.method,
        transaction_id: newPayment.reference || undefined,
        payment_date: newPayment.date,
      };

      const response = await fetch("/api/payments", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      });

      if (response.ok) {
        toast.success("Payment recorded successfully!");

        // Refresh invoice data
        await fetchInvoice();

        setShowPaymentForm(false);
        setNewPayment({
          date: new Date().toISOString().split("T")[0],
          amount: 0,
          method: "cash",
          reference: "",
        });
      } else {
        const errorData = await response.json();
        toast.error(errorData.message || "Failed to record payment");
      }
    } catch (err: any) {
      console.error("Error recording payment:", err);
      toast.error("Failed to record payment");
    } finally {
      setAddingPayment(false);
    }
  };

  const handleExportPDF = () => {
    if (!invoice) return;

    console.log("Exporting PDF for invoice:", invoice.invoiceNumber);
    toast.info(`Generating PDF for ${invoice.invoiceNumber}...`);

    // In a real app, you would call an API endpoint to generate PDF
    // window.open(`/api/invoices/${invoiceId}/pdf`, '_blank');
  };

  const handleSendReminder = () => {
    if (!invoice) return;

    toast.info(`Payment reminder sent to ${invoice.customerEmail}`);
  };

  const handleEmailInvoice = () => {
    if (!invoice) return;

    toast.info(`Invoice emailed to ${invoice.customerEmail}`);
  };

  const formatDate = (dateString: string) => {
    try {
      return new Date(dateString).toLocaleDateString("en-US", {
        year: "numeric",
        month: "short",
        day: "numeric",
      });
    } catch {
      return dateString;
    }
  };

  // Loading state
  if (loading) {
    return (
      <div className="page-body">
        <Breadcrumbs
          title="Invoice Details"
          mainTitle="Billing & Invoicing"
          parent="Invoices"
        />
        <Container fluid>
          <Row>
            <Col lg="12">
              <Card>
                <CardBody className="text-center py-5">
                  <Spinner color="primary" />
                  <p className="mt-3">Loading invoice details...</p>
                </CardBody>
              </Card>
            </Col>
          </Row>
        </Container>
      </div>
    );
  }

  // Error state
  if (error || !invoice) {
    return (
      <div className="page-body">
        <Breadcrumbs
          title="Error"
          mainTitle="Billing & Invoicing"
          parent="Invoices"
        />
        <Container fluid>
          <Card>
            <CardBody className="text-center py-5">
              <i className="fa fa-exclamation-triangle fa-3x text-danger mb-3"></i>
              <h4>Error Loading Invoice</h4>
              <p className="text-muted">{error || "Invoice not found"}</p>
              <Button
                color="primary"
                onClick={() => router.push("/admin/invoices")}
              >
                Back to Invoices
              </Button>
            </CardBody>
          </Card>
        </Container>
      </div>
    );
  }

  return (
    <div className="page-body">
      <Breadcrumbs
        title={`Invoice ${invoice.invoiceNumber}`}
        mainTitle="Billing & Invoicing"
        parent="Invoices"
      />

      <Container fluid>
        <Row>
          <Col lg="8">
            <Card>
              <CardBody>
                {/* Invoice Header */}
                <div className="d-flex justify-content-between align-items-center mb-4 text-muted">
                  <div>
                    <h4 className="mb-1">{invoice.invoiceNumber}</h4>
                    <p className="text-muted mb-0">
                      Job Card: JC-{invoice.jobCardId}
                    </p>
                  </div>
                  <div className="text-end">
                    {getStatusBadge(invoice.status)}
                    <div className="mt-2">
                      <Button
                        color="outline-primary"
                        size="sm"
                        onClick={handleExportPDF}
                      >
                        <i className="fa fa-file-pdf me-1"></i>PDF
                      </Button>
                      {invoice.status === "unpaid" &&
                        invoice.balanceDue > 0 && (
                          <Button
                            color="outline-warning"
                            size="sm"
                            className="ms-1"
                            onClick={handleSendReminder}
                          >
                            <i className="fa fa-bell me-1"></i>Reminder
                          </Button>
                        )}
                    </div>
                  </div>
                </div>

                {/* Customer and Dates */}
                <Row className="mb-4">
                  <Col md="6">
                    <Card className="bg-light">
                      <CardBody className="text-muted">
                        <h6>Bill To:</h6>
                        <strong>{invoice.customerName || "Customer"}</strong>
                        <br />
                        {invoice.customerAddress || "No address"}
                        <br />
                        {invoice.customerPhone || "No phone"}
                        <br />
                        {invoice.customerEmail || "No email"}
                      </CardBody>
                    </Card>
                  </Col>
                  <Col md="6">
                    <Card className="bg-light">
                      <CardBody className="text-muted">
                        <div className="d-flex justify-content-between">
                          <span>Issue Date:</span>
                          <strong>{formatDate(invoice.issueDate)}</strong>
                        </div>
                        <div className="d-flex justify-content-between">
                          <span>Due Date:</span>
                          <strong>{formatDate(invoice.dueDate)}</strong>
                        </div>
                        <div className="d-flex justify-content-between">
                          <span>Status:</span>
                          <strong>{getStatusBadge(invoice.status)}</strong>
                        </div>
                      </CardBody>
                    </Card>
                  </Col>
                </Row>
              </CardBody>
            </Card>
          </Col>

          {/* Invoice Summary */}
          <Col lg="4">
            <Card>
              <CardBody className="text-muted">
                <h6 className="card-title mb-3 text-muted">Invoice Summary</h6>

                <div className="border-bottom pb-3 mb-3">
                  <div className="d-flex justify-content-between mb-2">
                    <span>Subtotal:</span>
                    <span>${invoice.subtotal.toFixed(2)}</span>
                  </div>
                  <div className="d-flex justify-content-between mb-2">
                    <span>Tax ({invoice.taxRate.toFixed(1)}%):</span>
                    <span>${invoice.taxAmount.toFixed(2)}</span>
                  </div>
                  <div className="d-flex justify-content-between mb-2">
                    <span>Discount:</span>
                    <span>-${invoice.discount.toFixed(2)}</span>
                  </div>
                  <div className="d-flex justify-content-between mb-2 pt-2 border-top">
                    <strong>Total Amount:</strong>
                    <strong>${invoice.total.toFixed(2)}</strong>
                  </div>
                </div>

                <div className="border-bottom pb-3 mb-3">
                  <div className="d-flex justify-content-between mb-2">
                    <span>Amount Paid:</span>
                    <span className="text-success">
                      ${invoice.amountPaid.toFixed(2)}
                    </span>
                  </div>
                  <div className="d-flex justify-content-between mb-2">
                    <span>Balance Due:</span>
                    <span
                      className={
                        invoice.balanceDue > 0 ? "text-danger" : "text-success"
                      }
                    >
                      ${invoice.balanceDue.toFixed(2)}
                    </span>
                  </div>
                </div>

                <div className="mt-4">
                  <small className="text-muted">Created:</small>
                  <small>{formatDate(invoice.createdAt)}</small>
                </div>
              </CardBody>
            </Card>

            {/* Quick Actions */}
            <Card className="mt-4">
              <CardBody>
                <h6 className="card-title mb-3 text-muted">Quick Actions</h6>
                <div className="d-grid gap-2">
                  <Button color="outline-primary" onClick={handleExportPDF}>
                    <i className="fa fa-file-pdf me-2"></i>
                    Download PDF
                  </Button>

                  {invoice.balanceDue > 0 && (
                    <Button
                      color="primary"
                      onClick={() => setShowPaymentForm(true)}
                    >
                      <i className="fa fa-credit-card me-2"></i>
                      Record Payment
                    </Button>
                  )}
                  <Button
                    color="outline-secondary"
                    onClick={() => router.push("/admin/invoices")}
                  >
                    <i className="fa fa-arrow-left me-2"></i>
                    Back to Invoices
                  </Button>
                </div>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Container>
    </div>
  );
}

export default InvoiceDetailPage;
