// "use client";
// import Breadcrumbs from "@/CommonElements/Breadcrumbs";
// import {
//   Container,
//   Row,
//   Col,
//   Card,
//   CardBody,
//   Table,
//   Badge,
//   Button,
//   Input,
//   FormGroup,
//   Label,
// } from "reactstrap";
// import React, { useState, useEffect } from "react";
// import Link from "next/link";
// import { PaymentMethodConfig, WorkshopPayment } from "@/Types/payment";
// import CustomPagination from "@/CommonElements/Pagination";
// import withAuth from "@/helper/WithAuth";
// // import { WorkshopPayment, PaymentMethodConfig } from "@/types/payment";

// // Mock data
// const mockPayments: WorkshopPayment[] = [
//   {
//     id: 1,
//     invoiceId: 101,
//     invoiceNumber: "INV-2024-001",
//     customerId: 1,
//     customerName: "John Doe",
//     amount: 455.7,
//     amountDue: 455.7,
//     balanceAfter: 0,
//     paymentMethod: "credit_card",
//     paymentDate: "2024-01-15",
//     referenceNumber: "CHG-12345",
//     status: "completed",
//     notes: "Full payment for brake repair",
//     receiptNumber: "RCP-2024-001",
//     createdAt: "2024-01-15T10:00:00Z",
//     updatedAt: "2024-01-15T10:00:00Z",
//   },
//   {
//     id: 2,
//     invoiceId: 102,
//     invoiceNumber: "INV-2024-002",
//     customerId: 2,
//     customerName: "Jane Smith",
//     amount: 125.63,
//     amountDue: 125.63,
//     balanceAfter: 0,
//     paymentMethod: "upi",
//     paymentDate: "2024-01-16",
//     referenceNumber: "UPI-67890",
//     status: "completed",
//     notes: "Oil change service payment",
//     receiptNumber: "RCP-2024-002",
//     createdAt: "2024-01-16T09:00:00Z",
//     updatedAt: "2024-01-16T09:00:00Z",
//   },
//   {
//     id: 3,
//     invoiceId: 103,
//     invoiceNumber: "INV-2024-003",
//     customerId: 3,
//     customerName: "Mike Johnson",
//     amount: 200.0,
//     amountDue: 500.0,
//     balanceAfter: 300.0,
//     paymentMethod: "cash",
//     paymentDate: "2024-01-17",
//     referenceNumber: "CASH-001",
//     status: "completed",
//     notes: "Partial payment - balance $300",
//     receiptNumber: "RCP-2024-003",
//     createdAt: "2024-01-17T14:00:00Z",
//     updatedAt: "2024-01-17T14:00:00Z",
//   },
//   {
//     id: 4,
//     invoiceId: 104,
//     invoiceNumber: "INV-2024-004",
//     customerId: 4,
//     customerName: "Sarah Wilson",
//     amount: 350.0,
//     amountDue: 350.0,
//     balanceAfter: 0,
//     paymentMethod: "bank_transfer",
//     paymentDate: "2024-01-18",
//     referenceNumber: "BT-456789",
//     status: "pending",
//     notes: "Waiting for bank confirmation",
//     receiptNumber: "RCP-2024-004",
//     createdAt: "2024-01-18T11:00:00Z",
//     updatedAt: "2024-01-18T11:00:00Z",
//   },
// ];

// const paymentMethodConfig: PaymentMethodConfig[] = [
//   { method: "cash", label: "Cash", icon: "fa-money", color: "success" },
//   { method: "upi", label: "UPI", icon: "fa-mobile-phone", color: "primary" },
//   {
//     method: "credit_card",
//     label: "Credit Card",
//     icon: "fa-credit-card",
//     color: "info",
//   },
//   {
//     method: "debit_card",
//     label: "Debit Card",
//     icon: "fa-credit-card",
//     color: "warning",
//   },
//   {
//     method: "bank_transfer",
//     label: "Bank Transfer",
//     icon: "fa-university",
//     color: "dark",
//   },
//   {
//     method: "check",
//     label: "Check",
//     icon: "fa-money",
//     color: "secondary",
//   },
//   {
//     method: "wallet",
//     label: "Digital Wallet",
//     icon: "fa-square",
//     color: "danger",
//   },
// ];

// function PaymentsPage() {
//   const [payments, setPayments] = useState<WorkshopPayment[]>(mockPayments);
//   const [filteredPayments, setFilteredPayments] =
//     useState<WorkshopPayment[]>(mockPayments);
//   const [statusFilter, setStatusFilter] = useState<string>("all");
//   const [methodFilter, setMethodFilter] = useState<string>("all");
//   const [dateFilter, setDateFilter] = useState<string>("");
//   const [currentPage, setCurrentPage] = useState(1);
//   const itemsPerPage = 10;
//   // Apply filters
//   useEffect(() => {
//     let filtered = payments;

//     if (statusFilter !== "all") {
//       filtered = filtered.filter((payment) => payment.status === statusFilter);
//     }

//     if (methodFilter !== "all") {
//       filtered = filtered.filter(
//         (payment) => payment.paymentMethod === methodFilter
//       );
//     }

//     if (dateFilter) {
//       filtered = filtered.filter(
//         (payment) => payment.paymentDate === dateFilter
//       );
//     }

//     setFilteredPayments(filtered);
//   }, [payments, statusFilter, methodFilter, dateFilter]);

//   const getStatusBadge = (status: string) => {
//     const statusConfig = {
//       completed: { color: "success", label: "Completed" },
//       pending: { color: "warning", label: "Pending" },
//       failed: { color: "danger", label: "Failed" },
//       refunded: { color: "info", label: "Refunded" },
//     };

//     const config = statusConfig[status as keyof typeof statusConfig] || {
//       color: "secondary",
//       label: status,
//     };

//     return <Badge color={config.color}>{config.label}</Badge>;
//   };

//   const getMethodBadge = (method: string) => {
//     const config = paymentMethodConfig.find((m) => m.method === method);
//     if (!config) return <Badge color="secondary">{method}</Badge>;

//     return (
//       <Badge color={config.color}>
//         <i className={`fa ${config.icon} me-1`}></i>
//         {config.label}
//       </Badge>
//     );
//   };

//   const handlePrintReceipt = (payment: WorkshopPayment) => {
//     console.log("Printing receipt for:", payment.receiptNumber);
//     // In real app, this would generate a PDF receipt
//     alert(`Printing receipt: ${payment.receiptNumber}`);
//   };

//   const handleRefund = (paymentId: number) => {
//     if (
//       window.confirm(
//         "Are you sure you want to process a refund for this payment?"
//       )
//     ) {
//       setPayments(
//         payments.map((payment) =>
//           payment.id === paymentId
//             ? { ...payment, status: "refunded" as const }
//             : payment
//         )
//       );
//       alert("Refund processed successfully!");
//     }
//   };

//   const calculateTotals = () => {
//     const totalReceived = payments
//       .filter((p) => p.status === "completed")
//       .reduce((sum, p) => sum + p.amount, 0);

//     const pendingAmount = payments
//       .filter((p) => p.status === "pending")
//       .reduce((sum, p) => sum + p.amount, 0);

//     const todayAmount = payments
//       .filter(
//         (p) =>
//           p.paymentDate === new Date().toISOString().split("T")[0] &&
//           p.status === "completed"
//       )
//       .reduce((sum, p) => sum + p.amount, 0);

//     return { totalReceived, pendingAmount, todayAmount };
//   };

//   const totals = calculateTotals();

//   // Pagination
//   const totalPages = Math.ceil(filteredPayments.length / itemsPerPage);
//   const paginatedPayments = filteredPayments.slice(
//     (currentPage - 1) * itemsPerPage,
//     currentPage * itemsPerPage
//   );

//   return (
//     <div className="page-body">
//       <Breadcrumbs
//         title="Payments"
//         mainTitle="Payment Management"
//         parent="Finance"
//       />

//       <Container fluid>
//         <Row>
//           <Col sm="12">
//             <Card>
//               <CardBody>
//                 {/* Header with Actions */}
//                 <div className="d-flex justify-content-between align-items-center mb-4 ">
//                   <h5 className="card-title mb-0 text-muted">
//                     Payment Records
//                   </h5>
//                   <div className="d-flex gap-2">
//                     <Link href="/admin/payments/add">
//                       <Button color="primary">
//                         <i className="fa fa-plus me-2"></i>
//                         Record Payment
//                       </Button>
//                     </Link>
//                   </div>
//                 </div>

//                 {/* Summary Cards */}
//                 <Row className="mb-4">
//                   <Col md="4">
//                     <Card className="card-stats bg-success text-white">
//                       <CardBody className="text-white">
//                         <div className="d-flex align-items-center">
//                           <div className="flex-grow-1">
//                             <h4 className="mb-0">
//                               ${totals.totalReceived.toFixed(2)}
//                             </h4>
//                             <span>Total Received</span>
//                           </div>
//                           <div className="flex-shrink-0">
//                             <i className="fa fa-check-circle fa-2x opacity-50"></i>
//                           </div>
//                         </div>
//                       </CardBody>
//                     </Card>
//                   </Col>
//                   <Col md="4">
//                     <Card className="card-stats bg-warning text-white">
//                       <CardBody className="text-white">
//                         <div className="d-flex align-items-center">
//                           <div className="flex-grow-1">
//                             <h4 className="mb-0">
//                               ${totals.pendingAmount.toFixed(2)}
//                             </h4>
//                             <span>Pending Payments</span>
//                           </div>
//                           <div className="flex-shrink-0">
//                             <i className="fa fa-clock-o fa-2x opacity-50"></i>
//                           </div>
//                         </div>
//                       </CardBody>
//                     </Card>
//                   </Col>
//                   <Col md="4">
//                     <Card className="card-stats bg-info text-white">
//                       <CardBody className="text-white">
//                         <div className="d-flex align-items-center">
//                           <div className="flex-grow-1">
//                             <h4 className="mb-0">
//                               ${totals.todayAmount.toFixed(2)}
//                             </h4>
//                             <span>Today's Collection</span>
//                           </div>
//                           <div className="flex-shrink-0">
//                             <i className="fa fa-calendar-o fa-2x opacity-50"></i>
//                           </div>
//                         </div>
//                       </CardBody>
//                     </Card>
//                   </Col>
//                 </Row>

//                 {/* Filters */}
//                 <Card className="bg-light mb-4">
//                   <CardBody className="text-muted">
//                     <h6 className="mb-3">Filter Payments</h6>
//                     <Row>
//                       <Col md="3">
//                         <FormGroup>
//                           <Label>Status</Label>
//                           <Input
//                             type="select"
//                             value={statusFilter}
//                             className="border"
//                             onChange={(e) => setStatusFilter(e.target.value)}
//                           >
//                             <option value="all">All Status</option>
//                             <option value="completed">Completed</option>
//                             <option value="pending">Pending</option>
//                             <option value="failed">Failed</option>
//                             <option value="refunded">Refunded</option>
//                           </Input>
//                         </FormGroup>
//                       </Col>
//                       <Col md="3">
//                         <FormGroup>
//                           <Label>Payment Method</Label>
//                           <Input
//                             type="select"
//                             value={methodFilter}
//                             className="border"
//                             onChange={(e) => setMethodFilter(e.target.value)}
//                           >
//                             <option value="all">All Methods</option>
//                             {paymentMethodConfig.map((method) => (
//                               <option key={method.method} value={method.method}>
//                                 {method.label}
//                               </option>
//                             ))}
//                           </Input>
//                         </FormGroup>
//                       </Col>
//                       <Col md="3">
//                         <FormGroup>
//                           <Label>Date</Label>
//                           <Input
//                             type="date"
//                             value={dateFilter}
//                             onChange={(e) => setDateFilter(e.target.value)}
//                           />
//                         </FormGroup>
//                       </Col>
//                       <Col md="3">
//                         <FormGroup>
//                           <Label>&nbsp;</Label>
//                           <div>
//                             <Button
//                               color="outline-secondary"
//                               onClick={() => {
//                                 setStatusFilter("all");
//                                 setMethodFilter("all");
//                                 setDateFilter("");
//                               }}
//                             >
//                               Clear Filters
//                             </Button>
//                           </div>
//                         </FormGroup>
//                       </Col>
//                     </Row>
//                   </CardBody>
//                 </Card>

//                 {/* Payments Table */}
//                 <div className="table-responsive">
//                   <Table hover>
//                     <thead>
//                       <tr>
//                         <th>Receipt #</th>
//                         <th>Invoice</th>
//                         <th>Customer</th>
//                         <th>Amount</th>
//                         <th>Method</th>
//                         <th>Date</th>
//                         <th>Reference</th>
//                         <th>Status</th>
//                         <th>Balance After</th>
//                         <th>Actions</th>
//                       </tr>
//                     </thead>
//                     <tbody>
//                       {paginatedPayments.map((payment) => (
//                         <tr key={payment.id}>
//                           <td>
//                             <strong className="text-primary no-wrap">
//                               {payment.receiptNumber}
//                             </strong>
//                           </td>
//                           <td>
//                             <Link href={`/admin/invoices/${payment.invoiceId}`}>
//                               <span className="text-info no-wrap">
//                                 {payment.invoiceNumber}
//                               </span>
//                             </Link>
//                           </td>
//                           <td>
//                             <div>{payment.customerName}</div>
//                             <small className="text-muted">
//                               ID: {payment.customerId}
//                             </small>
//                           </td>
//                           <td>
//                             <strong className="text-success">
//                               ${payment.amount.toFixed(2)}
//                             </strong>
//                             <br />
//                             <small className="text-muted">
//                               Due: ${payment.amountDue.toFixed(2)}
//                             </small>
//                           </td>
//                           <td>{getMethodBadge(payment.paymentMethod)}</td>
//                           <td>
//                             {new Date(payment.paymentDate).toLocaleDateString()}
//                           </td>
//                           <td>
//                             <small className="text-muted">
//                               {payment.referenceNumber}
//                             </small>
//                           </td>
//                           <td>{getStatusBadge(payment.status)}</td>
//                           <td>
//                             <strong
//                               className={
//                                 payment.balanceAfter > 0
//                                   ? "text-warning"
//                                   : "text-success"
//                               }
//                             >
//                               ${payment.balanceAfter.toFixed(2)}
//                             </strong>
//                           </td>
//                           <td>
//                             <div className="d-flex gap-1">
//                               <Button
//                                 color="outline-primary"
//                                 size="sm"
//                                 onClick={() => handlePrintReceipt(payment)}
//                               >
//                                 <i className="icofont icofont-download-alt"></i>
//                               </Button>
//                               {/* {payment.status === "completed" && (
//                                 <Button
//                                   color="outline-warning"
//                                   size="sm"
//                                   onClick={() => handleRefund(payment.id)}
//                                 >
//                                   <i className="fa fa-undo"></i>
//                                 </Button>
//                               )} */}
//                             </div>
//                           </td>
//                         </tr>
//                       ))}
//                       {paginatedPayments.length === 0 && (
//                         <tr>
//                           <td colSpan={10} className="text-center py-4">
//                             <div className="text-muted">
//                               No payments found matching your criteria.
//                             </div>
//                           </td>
//                         </tr>
//                       )}
//                     </tbody>
//                   </Table>
//                 </div>
//                 {/* Pagination */}
//                 <div className="d-flex flex-column flex-md-row justify-content-between align-items-center gap-3 mt-4">
//                   <div className="text-center text-md-start text-muted">
//                     Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
//                     {Math.min(
//                       currentPage * itemsPerPage,
//                       filteredPayments.length
//                     )}{" "}
//                     of {filteredPayments.length} entries
//                   </div>
//                   <CustomPagination
//                     currentPage={currentPage}
//                     totalPages={totalPages}
//                     onPageChange={setCurrentPage}
//                     showFirstLast={true}
//                     maxVisiblePages={5}
//                     paginationType="primary"
//                     className="justify-content-center justify-content-md-end"
//                   />
//                 </div>
//                 {/* Payment Methods Summary */}
//                 <Card className="mt-4">
//                   <CardBody>
//                     <h6 className="mb-3 text-muted">Payment Methods Summary</h6>
//                     <Row>
//                       {paymentMethodConfig.map((method) => {
//                         const methodTotal = payments
//                           .filter(
//                             (p) =>
//                               p.paymentMethod === method.method &&
//                               p.status === "completed"
//                           )
//                           .reduce((sum, p) => sum + p.amount, 0);

//                         return (
//                           <Col key={method.method} md="4" className="mb-3">
//                             <div className="d-flex align-items-center p-3 border rounded">
//                               <div
//                                 className={`bg-${method.color} rounded-circle p-2 me-3`}
//                               >
//                                 <i
//                                   className={`fa ${method.icon} text-white`}
//                                 ></i>
//                               </div>
//                               <div className="flex-grow-1">
//                                 <div className="fw-bold text-muted">
//                                   {method.label}
//                                 </div>
//                                 <div className="text-muted">
//                                   ${methodTotal.toFixed(2)}
//                                 </div>
//                               </div>
//                             </div>
//                           </Col>
//                         );
//                       })}
//                     </Row>
//                   </CardBody>
//                 </Card>
//               </CardBody>
//             </Card>
//           </Col>
//         </Row>
//       </Container>

//       <style jsx global>{`
//         .card-stats {
//           border: none;
//           box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
//         }
//       `}</style>
//     </div>
//   );
// }

// export default withAuth(PaymentsPage, ["admin"]);

"use client";
import Breadcrumbs from "@/CommonElements/Breadcrumbs";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  Table,
  Badge,
  Button,
  Input,
  FormGroup,
  Label,
  Spinner,
  Alert,
} from "reactstrap";
import React, { useState, useEffect } from "react";
import Link from "next/link";
import { PaymentMethodConfig, WorkshopPayment } from "@/Types/payment";
import CustomPagination from "@/CommonElements/Pagination";
import withAuth from "@/helper/WithAuth";
import { useAuth } from "@/helper/AuthContext";
import { toast } from "react-toastify";

// API Response Interface
interface ApiPayment {
  id: string;
  invoice_id: string;
  job_card_id: string | null;
  amount: string;
  paid_by: string | null;
  method: string;
  reference: string;
  paid_at: string;
  created_at: string;
  job_number: string | null;
  invoice_number: string | null;
  customer_name?: string;
  customer_id?: string;
}

function PaymentsPage() {
  const { state } = useAuth();
  const [payments, setPayments] = useState<WorkshopPayment[]>([]);
  const [filteredPayments, setFilteredPayments] = useState<WorkshopPayment[]>(
    []
  );
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [methodFilter, setMethodFilter] = useState<string>("all");
  const [dateFilter, setDateFilter] = useState<string>("");
  const [currentPage, setCurrentPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const itemsPerPage = 10;

  // Payment Method Configuration - ADDED THIS BACK
  const paymentMethodConfig: PaymentMethodConfig[] = [
    { method: "cash", label: "Cash", icon: "fa-money", color: "success" },
    { method: "upi", label: "UPI", icon: "fa-mobile-phone", color: "primary" },
    {
      method: "credit_card",
      label: "Credit Card",
      icon: "fa-credit-card",
      color: "info",
    },
    {
      method: "debit_card",
      label: "Debit Card",
      icon: "fa-credit-card",
      color: "warning",
    },
    {
      method: "bank_transfer",
      label: "Bank Transfer",
      icon: "fa-university",
      color: "dark",
    },
    {
      method: "check",
      label: "Check",
      icon: "fa-money",
      color: "secondary",
    },
    {
      method: "wallet",
      label: "Digital Wallet",
      icon: "fa-square",
      color: "danger",
    },
  ];

  // Fetch payments from API
  const fetchPayments = async () => {
    try {
      setLoading(true);
      setError(null);

      const token = state?.accessToken || localStorage.getItem("token");

      const response = await fetch("/api/payments/history", {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch payments: ${response.status}`);
      }

      const data = await response.json();

      if (data.data && Array.isArray(data.data)) {
        // Transform API data to match WorkshopPayment type
        const transformedPayments: WorkshopPayment[] = data.data.map(
          (payment: ApiPayment) => ({
            id: parseInt(payment.id),
            invoiceId: parseInt(payment.invoice_id),
            invoiceNumber: payment.invoice_number,

            amount: parseFloat(payment.amount),
            paymentMethod: payment.method,
            paymentDate: payment.paid_at,

            referenceNumber: payment.reference,
            createdAt: payment.created_at,
          })
        );

        setPayments(transformedPayments);
        setFilteredPayments(transformedPayments);
      } else {
        setPayments([]);
        setFilteredPayments([]);
        toast.warning("No payment data available");
      }
    } catch (err: any) {
      console.error("Error fetching payments:", err);
      setError(err.message || "Failed to load payments");
      toast.error("Failed to load payments");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPayments();
  }, []);

  // Apply filters
  useEffect(() => {
    let filtered = payments;

    if (statusFilter !== "all") {
      filtered = filtered.filter((payment) => payment.status === statusFilter);
    }

    if (methodFilter !== "all") {
      filtered = filtered.filter(
        (payment) => payment.paymentMethod === methodFilter
      );
    }

    if (dateFilter) {
      filtered = filtered.filter(
        (payment) => payment.paymentDate === dateFilter
      );
    }

    setFilteredPayments(filtered);
    setCurrentPage(1); // Reset to first page when filters change
  }, [payments, statusFilter, methodFilter, dateFilter]);

  const getMethodBadge = (method: string) => {
    const config = paymentMethodConfig.find(
      (m: PaymentMethodConfig) => m.method === method
    );
    if (!config) return <Badge color="secondary">{method}</Badge>;

    return (
      <Badge color={config.color}>
        <i className={`fa ${config.icon} me-1`}></i>
        {config.label}
      </Badge>
    );
  };

  const handlePrintReceipt = (payment: WorkshopPayment) => {
    console.log("Printing receipt for:", payment.receiptNumber);
    // In real app, this would generate a PDF receipt
    alert(`Printing receipt: ${payment.receiptNumber}`);
  };

  const handleRefund = (paymentId: number) => {
    if (
      window.confirm(
        "Are you sure you want to process a refund for this payment?"
      )
    ) {
      // Here you would call your API to refund the payment
      // For now, we'll just update the local state
      setPayments(
        payments.map((payment) =>
          payment.id === paymentId
            ? { ...payment, status: "refunded" as const }
            : payment
        )
      );
      toast.success("Refund processed successfully!");
    }
  };

  const calculateTotals = () => {
    const totalReceived = payments
      .filter((p) => p.status === "completed")
      .reduce((sum, p) => sum + p.amount, 0);

    const pendingAmount = payments
      .filter((p) => p.status === "pending")
      .reduce((sum, p) => sum + p.amount, 0);

    const todayAmount = payments
      .filter(
        (p) =>
          p.paymentDate === new Date().toISOString().split("T")[0] &&
          p.status === "completed"
      )
      .reduce((sum, p) => sum + p.amount, 0);

    return { totalReceived, pendingAmount, todayAmount };
  };

  const totals = calculateTotals();

  // Pagination
  const totalPages = Math.ceil(filteredPayments.length / itemsPerPage);
  const paginatedPayments = filteredPayments.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  if (loading) {
    return (
      <div className="page-body">
        <Breadcrumbs
          title="Payments"
          mainTitle="Payment Management"
          parent="Finance"
        />
        <Container fluid>
          <Row>
            <Col sm="12">
              <Card>
                <CardBody className="text-center py-5">
                  <Spinner color="primary" />
                  <p className="mt-3">Loading payments...</p>
                </CardBody>
              </Card>
            </Col>
          </Row>
        </Container>
      </div>
    );
  }

  return (
    <div className="page-body">
      <Breadcrumbs
        title="Payments"
        mainTitle="Payment Management"
        parent="Finance"
      />

      <Container fluid>
        <Row>
          <Col sm="12">
            <Card>
              <CardBody>
                {/* Header with Actions */}
                <div className="d-flex justify-content-between align-items-center mb-4">
                  <h5 className="card-title mb-0 text-muted">
                    Payment Records
                  </h5>
                  <div className="d-flex gap-2">
                    <Link href="/admin/payments/add">
                      <Button color="primary">
                        <i className="fa fa-plus me-2"></i>
                        Record Payment
                      </Button>
                    </Link>
                    {/* <Button
                      color="outline-secondary"
                      onClick={fetchPayments}
                      disabled={loading}
                    >
                      <i className="fa fa-refresh me-2"></i>
                      Refresh
                    </Button> */}
                  </div>
                </div>

                {error && (
                  <Alert color="danger" className="mb-4">
                    <i className="fa fa-exclamation-triangle me-2"></i>
                    {error}
                  </Alert>
                )}

                {/* Summary Cards */}
                {/* <Row className="mb-4">
                  <Col md="4">
                    <Card className="card-stats bg-success text-white">
                      <CardBody className="text-white">
                        <div className="d-flex align-items-center">
                          <div className="flex-grow-1">
                            <h4 className="mb-0">
                              ${totals.totalReceived.toFixed(2)}
                            </h4>
                            <span>Total Received</span>
                          </div>
                          <div className="flex-shrink-0">
                            <i className="fa fa-check-circle fa-2x opacity-50"></i>
                          </div>
                        </div>
                      </CardBody>
                    </Card>
                  </Col>
                  <Col md="4">
                    <Card className="card-stats bg-warning text-white">
                      <CardBody className="text-white">
                        <div className="d-flex align-items-center">
                          <div className="flex-grow-1">
                            <h4 className="mb-0">
                              ${totals.pendingAmount.toFixed(2)}
                            </h4>
                            <span>Pending Payments</span>
                          </div>
                          <div className="flex-shrink-0">
                            <i className="fa fa-clock-o fa-2x opacity-50"></i>
                          </div>
                        </div>
                      </CardBody>
                    </Card>
                  </Col>
                  <Col md="4">
                    <Card className="card-stats bg-info text-white">
                      <CardBody className="text-white">
                        <div className="d-flex align-items-center">
                          <div className="flex-grow-1">
                            <h4 className="mb-0">
                              ${totals.todayAmount.toFixed(2)}
                            </h4>
                            <span>Today's Collection</span>
                          </div>
                          <div className="flex-shrink-0">
                            <i className="fa fa-calendar-o fa-2x opacity-50"></i>
                          </div>
                        </div>
                      </CardBody>
                    </Card>
                  </Col>
                </Row> */}

                {/* Filters */}
                <Card className="bg-light mb-4">
                  <CardBody className="text-muted">
                    <h6 className="mb-3">Filter Payments</h6>
                    <Row>
                      <Col md="3">
                        <FormGroup>
                          <Label>Status</Label>
                          <Input
                            type="select"
                            value={statusFilter}
                            className="border"
                            onChange={(e) => setStatusFilter(e.target.value)}
                          >
                            <option value="all">All Status</option>
                            <option value="completed">Completed</option>
                            <option value="pending">Pending</option>
                            <option value="failed">Failed</option>
                            <option value="refunded">Refunded</option>
                          </Input>
                        </FormGroup>
                      </Col>
                      <Col md="3">
                        <FormGroup>
                          <Label>Payment Method</Label>
                          <Input
                            type="select"
                            value={methodFilter}
                            className="border"
                            onChange={(e) => setMethodFilter(e.target.value)}
                          >
                            <option value="all">All Methods</option>
                            {paymentMethodConfig.map(
                              (method: PaymentMethodConfig) => (
                                <option
                                  key={method.method}
                                  value={method.method}
                                >
                                  {method.label}
                                </option>
                              )
                            )}
                          </Input>
                        </FormGroup>
                      </Col>
                      <Col md="3">
                        <FormGroup>
                          <Label>Date</Label>
                          <Input
                            type="date"
                            value={dateFilter}
                            onChange={(e) => setDateFilter(e.target.value)}
                          />
                        </FormGroup>
                      </Col>
                      <Col md="3">
                        <FormGroup>
                          <Label>&nbsp;</Label>
                          <div>
                            <Button
                              color="outline-secondary"
                              onClick={() => {
                                setStatusFilter("all");
                                setMethodFilter("all");
                                setDateFilter("");
                              }}
                            >
                              Clear Filters
                            </Button>
                          </div>
                        </FormGroup>
                      </Col>
                    </Row>
                  </CardBody>
                </Card>

                {/* Payments Table */}
                <div className="table-responsive">
                  <Table hover>
                    <thead>
                      <tr>
                        <th>#</th>
                        {/* <th>Receipt #</th> */}
                        <th>Invoice</th>
                        {/* <th>Customer</th> */}
                        <th>Amount</th>
                        <th>Method</th>
                        <th>Date</th>
                        <th>Reference</th>
                        {/* <th>Status</th> */}
                        {/* <th>Actions</th> */}
                      </tr>
                    </thead>
                    <tbody>
                      {paginatedPayments.map((payment, index) => (
                        <tr key={payment.id}>
                          <td>
                            {(currentPage - 1) * itemsPerPage + index + 1}
                          </td>
                          {/* <td>
                            <strong className="text-primary no-wrap">
                              {payment.receiptNumber}
                            </strong>
                          </td> */}
                          <td>
                            <Link href={`/admin/invoices/${payment.invoiceId}`}>
                              <span className="text-info no-wrap">
                                {payment.invoiceNumber}
                              </span>
                            </Link>
                          </td>
                          {/* <td>
                            <div>{payment.customerName}</div>
                            <small className="text-muted">
                              ID: {payment.customerId}
                            </small>
                          </td> */}
                          <td>
                            <strong className="text-success">
                              ${payment.amount.toFixed(2)}
                            </strong>
                          </td>
                          <td>{getMethodBadge(payment.paymentMethod)}</td>
                          <td>
                            {new Date(payment.paymentDate).toLocaleDateString()}
                          </td>
                          <td>
                            <small className="text-muted">
                              {payment.referenceNumber}
                            </small>
                          </td>
                          {/* <td>{getStatusBadge(payment.status)}</td> */}
                          {/* <td>
                            <div className="d-flex gap-1">
                              <Button
                                color="outline-primary"
                                size="sm"
                                onClick={() => handlePrintReceipt(payment)}
                              >
                                <i className="icofont icofont-download-alt"></i>
                              </Button>
                              {payment.status === "completed" && (
                                <Button
                                  color="outline-warning"
                                  size="sm"
                                  onClick={() => handleRefund(payment.id)}
                                >
                                  <i className="fa fa-undo"></i>
                                </Button>
                              )}
                            </div>
                          </td> */}
                        </tr>
                      ))}
                      {paginatedPayments.length === 0 && !loading && (
                        <tr>
                          <td colSpan={9} className="text-center py-4">
                            <div className="text-muted">
                              <i className="fa fa-search fa-2x mb-3"></i>
                              <p>No payments found</p>
                              {statusFilter !== "all" ||
                              methodFilter !== "all" ||
                              dateFilter ? (
                                <small>Try clearing your filters</small>
                              ) : (
                                <small>No payment records available</small>
                              )}
                            </div>
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </Table>
                </div>

                {/* Pagination */}
                <div className="d-flex flex-column flex-md-row justify-content-between align-items-center gap-3 mt-4">
                  <div className="text-center text-md-start text-muted">
                    Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
                    {Math.min(
                      currentPage * itemsPerPage,
                      filteredPayments.length
                    )}{" "}
                    of {filteredPayments.length} entries
                  </div>
                  <CustomPagination
                    currentPage={currentPage}
                    totalPages={totalPages}
                    onPageChange={setCurrentPage}
                    showFirstLast={true}
                    maxVisiblePages={5}
                    paginationType="primary"
                    className="justify-content-center justify-content-md-end"
                  />
                </div>

                {/* Payment Methods Summary */}
                {/* <Card className="mt-4">
                  <CardBody>
                    <h6 className="mb-3 text-muted">Payment Methods Summary</h6>
                    <Row>
                      {paymentMethodConfig.map(
                        (method: PaymentMethodConfig) => {
                          const methodTotal = payments
                            .filter(
                              (p) =>
                                p.paymentMethod === method.method &&
                                p.status === "completed"
                            )
                            .reduce((sum, p) => sum + p.amount, 0);

                          return (
                            <Col key={method.method} md="4" className="mb-3">
                              <div className="d-flex align-items-center p-3 border rounded">
                                <div
                                  className={`bg-${method.color} rounded-circle p-2 me-3`}
                                >
                                  <i
                                    className={`fa ${method.icon} text-white`}
                                  ></i>
                                </div>
                                <div className="flex-grow-1">
                                  <div className="fw-bold text-muted">
                                    {method.label}
                                  </div>
                                  <div className="text-muted">
                                    ${methodTotal.toFixed(2)}
                                  </div>
                                </div>
                              </div>
                            </Col>
                          );
                        }
                      )}
                    </Row>
                  </CardBody>
                </Card> */}
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Container>

      <style jsx global>{`
        .card-stats {
          border: none;
          box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
        }
        .no-wrap {
          white-space: nowrap;
        }
      `}</style>
    </div>
  );
}

export default withAuth(PaymentsPage, ["admin"]);
