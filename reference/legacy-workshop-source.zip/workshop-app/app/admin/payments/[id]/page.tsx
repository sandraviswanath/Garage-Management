"use client";

import Breadcrumbs from "@/CommonElements/Breadcrumbs";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  CardHeader,
  Table,
  Badge,
  Button,
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Form,
  FormGroup,
  Label,
  Input,
  Alert,
} from "reactstrap";
import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useAuth } from "@/helper/AuthContext";
import withAuth from "@/helper/WithAuth";
import { toast } from "react-toastify";
import { useRouter } from "next/navigation";

// Payment types
interface Payment {
  id: number;
  invoice_id: number;
  amount: number;
  method: string;
  reference?: string;
  notes?: string;
  payment_date: string;
  created_at: string;
  updated_at: string;
  status: string;
}

interface Invoice {
  id: number;
  invoice_number: string;
  customer_name: string;
  total: number;
  amount_paid: number;
  balance_due: number;
  status: string;
  issue_date: string;
  due_date: string;
}

function PaymentDetailsPage({ params }: { params: { id: string } }) {
  const router = useRouter();
  const { state } = useAuth();
  const [invoice, setInvoice] = useState<Invoice | null>(null);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [paymentToDelete, setPaymentToDelete] = useState<number | null>(null);

  // New payment form state
  const [newPayment, setNewPayment] = useState({
    amount: "",
    method: "cash",
    reference: "",
    notes: "",
    payment_date: new Date().toISOString().split("T")[0],
  });

  const invoiceId = params.id;

  useEffect(() => {
    if (invoiceId) {
      fetchInvoiceAndPayments();
    }
  }, [invoiceId]);

  const fetchInvoiceAndPayments = async () => {
    try {
      setLoading(true);
      setError(null);

      const token = state?.accessToken || localStorage.getItem("token");

      // Fetch invoice details
      const invoiceResponse = await fetch(`/api/invoices/${invoiceId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!invoiceResponse.ok) {
        throw new Error(`Failed to fetch invoice: ${invoiceResponse.status}`);
      }

      const invoiceData = await invoiceResponse.json();

      // Transform invoice data
      const invoiceTransformed: Invoice = {
        id: parseInt(invoiceData.data.id),
        invoice_number: invoiceData.data.invoice_number,
        customer_name: invoiceData.data.customer_name || "N/A",
        total: parseFloat(invoiceData.data.total_amount) || 0,
        // amount_paid: parseFloat(invoiceData.data.amount_paid) || 0,
        amount_paid: Math.max(
          parseFloat(invoiceData.data.total_amount) -
            parseFloat(invoiceData.data.due_amount),
          0
        ),
        // balance_due:
        //   parseFloat(invoiceData.data.balance_due) ||
        //   parseFloat(invoiceData.data.total_amount) ||
        //   0,
        balance_due: parseFloat(invoiceData.data.due_amount),
        status: invoiceData.data.status || "unpaid",
        issue_date: invoiceData.data.issue_date,
        due_date: invoiceData.data.due_date,
      };

      setInvoice(invoiceTransformed);

      // Fetch payments for this invoice
      const paymentsResponse = await fetch(`/api/payments/${invoiceId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (paymentsResponse.ok) {
        const paymentsData = await paymentsResponse.json();
        setPayments(paymentsData.data || []);
      } else {
        // If no payments endpoint exists, show empty array
        setPayments([]);
      }
    } catch (err) {
      console.error("Error fetching data:", err);
      setError(err instanceof Error ? err.message : "Failed to load data");
      toast.error("Failed to load payment details");
    } finally {
      setLoading(false);
    }
  };

  const handleAddPayment = async () => {
    try {
      const token = state?.accessToken || localStorage.getItem("token");
      const amount = parseFloat(newPayment.amount);

      if (isNaN(amount) || amount <= 0) {
        toast.error("Please enter a valid amount");
        return;
      }

      if (invoice && amount > invoice.balance_due) {
        toast.error("Payment amount cannot exceed the balance due");
        return;
      }

      const paymentData = {
        invoice_id: parseInt(invoiceId),
        amount: amount,
        method: newPayment.method,
        reference: newPayment.reference || null,
        notes: newPayment.notes || null,
        payment_date: newPayment.payment_date,
        status: "completed",
      };

      const response = await fetch("/api/payments", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(paymentData),
      });

      if (response.ok) {
        const result = await response.json();

        // Add new payment to the list
        setPayments([result.data, ...payments]);

        // Update invoice balance
        if (invoice) {
          const newBalanceDue = Math.max(0, invoice.balance_due - amount);
          const newAmountPaid = invoice.amount_paid + amount;
          const newStatus =
            newBalanceDue === 0
              ? "paid"
              : newBalanceDue < invoice.total
              ? "partial"
              : invoice.status;

          setInvoice({
            ...invoice,
            amount_paid: newAmountPaid,
            balance_due: newBalanceDue,
            status: newStatus,
          });
        }

        // Reset form and close modal
        setNewPayment({
          amount: "",
          method: "cash",
          reference: "",
          notes: "",
          payment_date: new Date().toISOString().split("T")[0],
        });
        setModalOpen(false);

        toast.success("Payment added successfully!");
      } else {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to add payment");
      }
    } catch (err: any) {
      console.error("Error adding payment:", err);
      toast.error(err.message || "Failed to add payment");
    }
  };

  const handleDeletePayment = async () => {
    if (!paymentToDelete) return;

    try {
      const token = state?.accessToken || localStorage.getItem("token");

      const response = await fetch(`/api/payments/${paymentToDelete}`, {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (response.ok) {
        // Remove payment from list
        const deletedPayment = payments.find((p) => p.id === paymentToDelete);
        setPayments(payments.filter((p) => p.id !== paymentToDelete));

        // Update invoice balance
        if (invoice && deletedPayment) {
          const newAmountPaid = Math.max(
            0,
            invoice.amount_paid - deletedPayment.amount
          );
          const newBalanceDue = invoice.total - newAmountPaid;
          const newStatus =
            newBalanceDue === 0
              ? "paid"
              : newBalanceDue < invoice.total
              ? "partial"
              : "unpaid";

          setInvoice({
            ...invoice,
            amount_paid: newAmountPaid,
            balance_due: newBalanceDue,
            status: newStatus,
          });
        }

        setDeleteModalOpen(false);
        setPaymentToDelete(null);

        toast.success("Payment deleted successfully!");
      } else {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to delete payment");
      }
    } catch (err: any) {
      console.error("Error deleting payment:", err);
      toast.error(err.message || "Failed to delete payment");
    }
  };

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      completed: { color: "success", label: "Completed" },
      pending: { color: "warning", label: "Pending" },
      failed: { color: "danger", label: "Failed" },
      refunded: { color: "info", label: "Refunded" },
    };

    const config = statusConfig[status as keyof typeof statusConfig] || {
      color: "secondary",
      label: status,
    };

    return <Badge color={config.color}>{config.label}</Badge>;
  };

  const getPaymentMethodIcon = (method: string) => {
    const icons = {
      cash: "fa-money-bill-wave",
      card: "fa-credit-card",
      bank_transfer: "fa-university",
      cheque: "fa-money-check",
      online: "fa-globe",
      mobile_money: "fa-mobile-alt",
    };

    return icons[method as keyof typeof icons] || "fa-money-bill";
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  };

  if (loading) {
    return (
      <div className="page-body">
        <Breadcrumbs
          title="Payment Details"
          mainTitle="Payment Management"
          parent="Invoices"
        />
        <Container fluid>
          <Row>
            <Col sm="12">
              <Card>
                <CardBody className="text-center py-5">
                  <div className="spinner-border text-primary" role="status">
                    <span className="visually-hidden">Loading...</span>
                  </div>
                  <p className="mt-3 mb-0">Loading payment details...</p>
                </CardBody>
              </Card>
            </Col>
          </Row>
        </Container>
      </div>
    );
  }

  if (error || !invoice) {
    return (
      <div className="page-body">
        <Breadcrumbs
          title="Payment Details"
          mainTitle="Payment Management"
          parent="Invoices"
        />
        <Container fluid>
          <Row>
            <Col sm="12">
              <Card>
                <CardBody className="text-center py-5">
                  <div className="text-danger mb-3">
                    <i className="fa fa-exclamation-triangle fa-3x"></i>
                  </div>
                  <h5 className="text-danger">Error Loading Details</h5>
                  <p className="text-muted">{error || "Invoice not found"}</p>
                  <Button color="primary" onClick={fetchInvoiceAndPayments}>
                    <i className="fa fa-refresh me-2"></i>
                    Try Again
                  </Button>
                  <Link href="/admin/invoices" className="ms-2">
                    <Button color="secondary">
                      <i className="fa fa-arrow-left me-2"></i>
                      Back to Invoices
                    </Button>
                  </Link>
                </CardBody>
              </Card>
            </Col>
          </Row>
        </Container>
      </div>
    );
  }

  return (
    <div className="page-body">
      <Breadcrumbs
        title={`Payments - ${invoice.invoice_number}`}
        mainTitle="Payment Management"
        parent="Payments"
      />

      <Container fluid>
        <Row>
          {/* Invoice Summary */}
          <Col lg="4" md="6" className="mb-4">
            <Card>
              <CardHeader className="bg-primary text-white">
                <h5 className="mb-0">Invoice Summary</h5>
              </CardHeader>
              <CardBody>
                <div className="mb-3">
                  <small className="text-muted">Invoice Number</small>
                  <h4>{invoice.invoice_number}</h4>
                </div>

                <div className="mb-3">
                  <small className="text-muted">Customer</small>
                  <h5>{invoice.customer_name}</h5>
                </div>

                <div className="mb-3">
                  <small className="text-muted">Status</small>
                  <div className="mt-1">{getStatusBadge(invoice.status)}</div>
                </div>

                <hr />

                <div className="d-flex justify-content-between mb-2">
                  <span>Total Amount:</span>
                  <strong>{formatCurrency(invoice.total)}</strong>
                </div>

                <div className="d-flex justify-content-between mb-2">
                  <span>Amount Paid:</span>
                  <strong className="text-success">
                    {formatCurrency(invoice.amount_paid)}
                  </strong>
                </div>

                <div className="d-flex justify-content-between mb-3">
                  <span>Balance Due:</span>
                  <strong
                    className={
                      invoice.balance_due > 0 ? "text-danger" : "text-success"
                    }
                  >
                    {formatCurrency(invoice.balance_due)}
                  </strong>
                </div>

                <div className="d-flex justify-content-between mb-2">
                  <small className="text-muted">Issue Date:</small>
                  <small>{formatDate(invoice.issue_date)}</small>
                </div>

                <div className="d-flex justify-content-between">
                  <small className="text-muted">Due Date:</small>
                  <small>{formatDate(invoice.due_date)}</small>
                </div>

                <hr />

                <div className="d-grid gap-2">
                  <Link href={`/admin/invoices/${invoice.id}`}>
                    <Button color="outline-primary" block>
                      <i className="fa fa-file-invoice me-2"></i>
                      View Invoice
                    </Button>
                  </Link>

                  {/* {invoice.balance_due > 0 && (
                    <Button
                      color="primary"
                      block
                      onClick={() => setModalOpen(true)}
                    >
                      <i className="fa fa-plus me-2"></i>
                      Add Payment
                    </Button>
                  )} */}
                </div>
              </CardBody>
            </Card>
          </Col>

          {/* Payment History */}
          <Col lg="8" md="6">
            <Card>
              <CardHeader className="d-flex justify-content-between align-items-center">
                <h5 className="mb-0">Payment History</h5>
                <div>
                  {/* <Button
                    color="primary"
                    size="sm"
                    onClick={() => setModalOpen(true)}
                    disabled={invoice.balance_due <= 0}
                  >
                    <i className="fa fa-plus me-1"></i>
                    New Payment
                  </Button> */}
                </div>
              </CardHeader>
              <CardBody>
                {payments.length === 0 ? (
                  <div className="text-center py-5">
                    <div className="text-muted mb-3">
                      <i className="fa fa-credit-card fa-3x"></i>
                    </div>
                    <h5 className="text-muted">No Payments Found</h5>
                    <p className="text-muted">
                      No payments have been recorded for this invoice yet.
                    </p>
                    {invoice.balance_due > 0 && (
                      <Button
                        color="primary"
                        onClick={() => setModalOpen(true)}
                      >
                        <i className="fa fa-plus me-2"></i>
                        Record First Payment
                      </Button>
                    )}
                  </div>
                ) : (
                  <div className="table-responsive">
                    <Table hover>
                      <thead>
                        <tr>
                          <th>Date</th>
                          <th>Amount</th>
                          <th>Method</th>
                          <th>Reference</th>
                          <th>Status</th>
                          {/* <th>Actions</th> */}
                        </tr>
                      </thead>
                      <tbody>
                        {payments.map((payment) => (
                          <tr key={payment.id}>
                            <td>
                              <div>{formatDate(payment.payment_date)}</div>
                              <small className="text-muted">
                                {new Date(
                                  payment.created_at
                                ).toLocaleTimeString()}
                              </small>
                            </td>
                            <td>
                              <strong className="text-success">
                                {formatCurrency(payment.amount)}
                              </strong>
                            </td>
                            <td>
                              <div>
                                <i
                                  className={`fa ${getPaymentMethodIcon(
                                    payment.method
                                  )} me-2`}
                                ></i>
                                {payment.method.replace("_", " ").toUpperCase()}
                                {/* {payment.method} */}
                              </div>
                            </td>
                            <td>
                              {payment.reference ? (
                                <code>{payment.reference}</code>
                              ) : (
                                <span className="text-muted">-</span>
                              )}
                            </td>
                            <td>{getStatusBadge(payment.status)}</td>
                            {/* <td>
                              <div className="d-flex gap-1">
                                <Button
                                  color="outline-info"
                                  size="sm"
                                  title="View Details"
                                  onClick={() => {
                                   
                                    toast.info(`Payment ${payment.id} details`);
                                  }}
                                >
                                  <i className="fa fa-eye"></i>
                                </Button>
                                <Button
                                  color="outline-danger"
                                  size="sm"
                                  title="Delete Payment"
                                  onClick={() => {
                                    setPaymentToDelete(payment.id);
                                    setDeleteModalOpen(true);
                                  }}
                                >
                                  <i className="fa fa-trash"></i>
                                </Button>
                              </div>
                            </td> */}
                          </tr>
                        ))}
                      </tbody>
                    </Table>
                  </div>
                )}

                {/* Payment Summary */}
                <Card className="mt-4 bg-light">
                  <CardBody>
                    <Row>
                      <Col md="4" className="text-center border-end">
                        <h6 className="text-muted">Total Payments</h6>
                        <h3>{payments.length}</h3>
                      </Col>
                      <Col md="4" className="text-center border-end">
                        <h6 className="text-muted">Total Received</h6>
                        <h3 className="text-success">
                          {formatCurrency(
                            payments.reduce((sum, p) => sum + p.amount, 0)
                          )}
                        </h3>
                      </Col>
                      <Col md="4" className="text-center">
                        <h6 className="text-muted">Remaining Balance</h6>
                        <h3
                          className={
                            invoice.balance_due > 0
                              ? "text-danger"
                              : "text-success"
                          }
                        >
                          {formatCurrency(invoice.balance_due)}
                        </h3>
                      </Col>
                    </Row>
                  </CardBody>
                </Card>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Container>

      {/* Add Payment Modal */}
      <Modal
        isOpen={modalOpen}
        toggle={() => setModalOpen(!modalOpen)}
        size="lg"
      >
        <ModalHeader toggle={() => setModalOpen(false)}>
          Add New Payment
        </ModalHeader>
        <ModalBody>
          <Form>
            <Row>
              <Col md="6">
                <FormGroup>
                  <Label for="paymentAmount">Amount *</Label>
                  <Input
                    type="number"
                    id="paymentAmount"
                    placeholder="Enter amount"
                    value={newPayment.amount}
                    onChange={(e) =>
                      setNewPayment({ ...newPayment, amount: e.target.value })
                    }
                    min="0"
                    max={invoice?.balance_due || 0}
                    step="0.01"
                  />
                  <small className="text-muted">
                    Maximum: {formatCurrency(invoice?.balance_due || 0)}
                  </small>
                </FormGroup>
              </Col>

              <Col md="6">
                <FormGroup>
                  <Label for="paymentDate">Payment Date *</Label>
                  <Input
                    type="date"
                    id="paymentDate"
                    value={newPayment.payment_date}
                    onChange={(e) =>
                      setNewPayment({
                        ...newPayment,
                        payment_date: e.target.value,
                      })
                    }
                  />
                </FormGroup>
              </Col>
            </Row>

            <Row>
              <Col md="6">
                <FormGroup>
                  <Label for="paymentMethod">Payment Method *</Label>
                  <Input
                    type="select"
                    id="paymentMethod"
                    value={newPayment.method}
                    onChange={(e) =>
                      setNewPayment({
                        ...newPayment,
                        method: e.target.value,
                      })
                    }
                  >
                    <option value="cash">Cash</option>
                    <option value="card">Credit/Debit Card</option>
                    <option value="bank_transfer">Bank Transfer</option>
                    <option value="cheque">Cheque</option>
                    <option value="online">Online Payment</option>
                    <option value="mobile_money">Mobile Money</option>
                  </Input>
                </FormGroup>
              </Col>

              <Col md="6">
                <FormGroup>
                  <Label for="referenceNumber">Reference Number</Label>
                  <Input
                    type="text"
                    id="referenceNumber"
                    placeholder="Optional reference"
                    value={newPayment.reference}
                    onChange={(e) =>
                      setNewPayment({
                        ...newPayment,
                        reference: e.target.value,
                      })
                    }
                  />
                </FormGroup>
              </Col>
            </Row>

            <FormGroup>
              <Label for="paymentNotes">Notes</Label>
              <Input
                type="textarea"
                id="paymentNotes"
                placeholder="Any additional notes about this payment..."
                rows="3"
                value={newPayment.notes}
                onChange={(e) =>
                  setNewPayment({ ...newPayment, notes: e.target.value })
                }
              />
            </FormGroup>
          </Form>
        </ModalBody>
        <ModalFooter>
          <Button color="secondary" onClick={() => setModalOpen(false)}>
            Cancel
          </Button>
          <Button color="primary" onClick={handleAddPayment}>
            <i className="fa fa-check me-2"></i>
            Record Payment
          </Button>
        </ModalFooter>
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal isOpen={deleteModalOpen} toggle={() => setDeleteModalOpen(false)}>
        <ModalHeader toggle={() => setDeleteModalOpen(false)}>
          Confirm Delete
        </ModalHeader>
        <ModalBody>
          <p>Are you sure you want to delete this payment?</p>
          <p className="text-danger">
            <strong>Warning:</strong> This action cannot be undone and will
            affect the invoice balance.
          </p>
        </ModalBody>
        <ModalFooter>
          <Button color="secondary" onClick={() => setDeleteModalOpen(false)}>
            Cancel
          </Button>
          {/* <Button color="danger" onClick={handleDeletePayment}>
            <i className="fa fa-trash me-2"></i>
            Delete Payment
          </Button> */}
        </ModalFooter>
      </Modal>
    </div>
  );
}

export default withAuth(PaymentDetailsPage, ["admin"]);
