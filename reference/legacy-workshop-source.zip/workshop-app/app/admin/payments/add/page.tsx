// "use client";
// import Breadcrumbs from "@/CommonElements/Breadcrumbs";
// import {
//   Container,
//   Row,
//   Col,
//   Card,
//   CardBody,
//   Form,
//   FormGroup,
//   Label,
//   Input,
//   Button,
//   Alert,
// } from "reactstrap";
// import React, { useState, useEffect } from "react";
// import { useRouter } from "next/navigation";
// import {
//   WorkshopPayment,
//   PaymentFormData,
//   PaymentMethodConfig,
// } from "@/Types/payment";
// // import { Payment, PaymentMethodConfig, PaymentFormData } from "@/types/payment";

// // Mock invoices data - in real app, this would come from API
// const mockInvoices = [
//   {
//     id: 101,
//     invoiceNumber: "INV-2024-001",
//     customerId: 1,
//     customerName: "John Doe",
//     total: 455.7,
//     amountPaid: 0,
//     balanceDue: 455.7,
//     status: "sent",
//   },
//   {
//     id: 102,
//     invoiceNumber: "INV-2024-002",
//     customerId: 2,
//     customerName: "Jane Smith",
//     total: 125.63,
//     amountPaid: 0,
//     balanceDue: 125.63,
//     status: "sent",
//   },
//   {
//     id: 103,
//     invoiceNumber: "INV-2024-003",
//     customerId: 3,
//     customerName: "Mike Johnson",
//     total: 500.0,
//     amountPaid: 200.0,
//     balanceDue: 300.0,
//     status: "partial",
//   },
// ];

// const paymentMethodConfig: PaymentMethodConfig[] = [
//   { method: "cash", label: "Cash", icon: "fa-money-bill", color: "success" },
//   { method: "upi", label: "UPI", icon: "fa-mobile-alt", color: "primary" },
//   {
//     method: "credit_card",
//     label: "Credit Card",
//     icon: "fa-credit-card",
//     color: "info",
//   },
//   {
//     method: "debit_card",
//     label: "Debit Card",
//     icon: "fa-credit-card",
//     color: "warning",
//   },
//   {
//     method: "bank_transfer",
//     label: "Bank Transfer",
//     icon: "fa-university",
//     color: "dark",
//   },
//   {
//     method: "check",
//     label: "Check",
//     icon: "fa-money-check",
//     color: "secondary",
//   },
//   {
//     method: "wallet",
//     label: "Digital Wallet",
//     icon: "fa-wallet",
//     color: "danger",
//   },
// ];

// function AddPaymentPage() {
//   const router = useRouter();
//   const [selectedInvoice, setSelectedInvoice] = useState<any>(null);
//   const [payment, setPayment] = useState<PaymentFormData>({
//     paymentDate: new Date().toISOString().split("T")[0],
//     paymentMethod: "cash",
//     amount: 0,
//     referenceNumber: "",
//     notes: "",
//     status: "completed",
//   });
//   const [showSuccess, setShowSuccess] = useState(false);

//   // Generate receipt number
//   const generateReceiptNumber = () => {
//     const timestamp = new Date().getTime();
//     return `RCP-2024-${String(timestamp).slice(-6)}`;
//   };

//   const handleInvoiceSelect = (invoiceId: number) => {
//     const invoice = mockInvoices.find((inv) => inv.id === invoiceId);
//     setSelectedInvoice(invoice);

//     if (invoice) {
//       setPayment((prev) => ({
//         ...prev,
//         invoiceId: invoice.id,
//         invoiceNumber: invoice.invoiceNumber,
//         customerId: invoice.customerId,
//         customerName: invoice.customerName,
//         amountDue: invoice.balanceDue,
//         amount: invoice.balanceDue, // Default to full amount
//         balanceAfter: 0, // Initialize balance after
//       }));
//     }
//   };

//   const handlePaymentChange = (field: keyof PaymentFormData, value: any) => {
//     setPayment((prev) => {
//       const updated = { ...prev, [field]: value };

//       // Auto-calculate balance after payment
//       if (field === "amount" && selectedInvoice) {
//         const amount = Number(value) || 0;
//         const balanceAfter = selectedInvoice.balanceDue - amount;
//         updated.balanceAfter = Math.max(0, balanceAfter);
//       }

//       return updated;
//     });
//   };

//   const handleSubmit = (e: React.FormEvent) => {
//     e.preventDefault();

//     if (!selectedInvoice) {
//       alert("Please select an invoice");
//       return;
//     }

//     if (!payment.amount || payment.amount <= 0) {
//       alert("Please enter a valid payment amount");
//       return;
//     }

//     // Create new payment record
//     const newPayment: WorkshopPayment = {
//       id: Math.floor(Math.random() * 1000),
//       invoiceId: payment.invoiceId!,
//       invoiceNumber: payment.invoiceNumber!,
//       customerId: payment.customerId!,
//       customerName: payment.customerName!,
//       amount: payment.amount!,
//       amountDue: payment.amountDue!,
//       balanceAfter: payment.balanceAfter!,
//       paymentMethod: payment.paymentMethod,
//       paymentDate: payment.paymentDate,
//       referenceNumber: payment.referenceNumber,
//       status: payment.status,
//       notes: payment.notes,
//       receiptNumber: generateReceiptNumber(),
//       createdAt: new Date().toISOString(),
//       updatedAt: new Date().toISOString(),
//     };

//     console.log("New payment recorded:", newPayment);

//     // Show success message
//     setShowSuccess(true);

//     // In real app, you would save to API here
//     setTimeout(() => {
//       router.push("/admin/payments");
//     }, 2000);
//   };

//   const handlePrintReceipt = () => {
//     if (!selectedInvoice) return;

//     const receiptData = {
//       receiptNumber: generateReceiptNumber(),
//       paymentDate: payment.paymentDate,
//       customerName: selectedInvoice.customerName,
//       customerAddress: "123 Main St, City, State", // Would come from customer data
//       invoiceNumber: selectedInvoice.invoiceNumber,
//       amount: payment.amount!,
//       paymentMethod:
//         paymentMethodConfig.find((m) => m.method === payment.paymentMethod)
//           ?.label || "",
//       referenceNumber: payment.referenceNumber,
//       balanceDue: payment.balanceAfter!,
//       amountPaid: payment.amount!,
//     };

//     console.log("Printing receipt:", receiptData);
//     alert(`Receipt ${receiptData.receiptNumber} printed!`);
//   };

//   return (
//     <div className="page-body">
//       <Breadcrumbs
//         title="Record Payment"
//         mainTitle="Payment Management"
//         parent="Payments"
//       />

//       <Container fluid>
//         <Row>
//           <Col lg="8">
//             <Card>
//               <CardBody>
//                 <h5 className="card-title mb-4 text-muted">
//                   Record New Payment
//                 </h5>

//                 {showSuccess && (
//                   <Alert color="success" className="mb-4">
//                     <i className="fa fa-check-circle me-2"></i>
//                     Payment recorded successfully! Redirecting...
//                   </Alert>
//                 )}

//                 <Form onSubmit={handleSubmit}>
//                   {/* Invoice Selection */}
//                   <Card className="bg-light mb-4">
//                     <CardBody className="text-muted">
//                       <h6 className="mb-3">Select Invoice</h6>
//                       <FormGroup>
//                         <Label>Invoice</Label>
//                         <Input
//                           type="select"
//                           className="border"
//                           value={selectedInvoice?.id || ""}
//                           onChange={(e) =>
//                             handleInvoiceSelect(Number(e.target.value))
//                           }
//                           required
//                         >
//                           <option value="">Select an invoice...</option>
//                           {mockInvoices
//                             .filter((inv) => inv.balanceDue > 0)
//                             .map((invoice) => (
//                               <option key={invoice.id} value={invoice.id}>
//                                 {invoice.invoiceNumber} - {invoice.customerName}{" "}
//                                 - Due: ${invoice.balanceDue.toFixed(2)}
//                               </option>
//                             ))}
//                         </Input>
//                       </FormGroup>

//                       {selectedInvoice && (
//                         <div className="mt-3 p-3 border rounded">
//                           <Row>
//                             <Col md="6">
//                               <strong>Customer:</strong>{" "}
//                               {selectedInvoice.customerName}
//                             </Col>
//                             <Col md="6">
//                               <strong>Invoice Total:</strong> $
//                               {selectedInvoice.total.toFixed(2)}
//                             </Col>
//                             <Col md="6">
//                               <strong>Amount Paid:</strong> $
//                               {selectedInvoice.amountPaid.toFixed(2)}
//                             </Col>
//                             <Col md="6">
//                               <strong className="text-danger">
//                                 Balance Due: $
//                                 {selectedInvoice.balanceDue.toFixed(2)}
//                               </strong>
//                             </Col>
//                           </Row>
//                         </div>
//                       )}
//                     </CardBody>
//                   </Card>

//                   {selectedInvoice && (
//                     <>
//                       {/* Payment Details */}
//                       <Card className="mb-4">
//                         <CardBody className="text-muted">
//                           <h6 className="mb-3">Payment Details</h6>
//                           <Row>
//                             <Col md="6">
//                               <FormGroup>
//                                 <Label>Payment Date</Label>
//                                 <Input
//                                   type="date"
//                                   value={payment.paymentDate}
//                                   onChange={(e) =>
//                                     handlePaymentChange(
//                                       "paymentDate",
//                                       e.target.value
//                                     )
//                                   }
//                                   required
//                                 />
//                               </FormGroup>
//                             </Col>
//                             <Col md="6">
//                               <FormGroup>
//                                 <Label>Payment Method</Label>
//                                 <Input
//                                   type="select"
//                                   className="border"
//                                   value={payment.paymentMethod}
//                                   onChange={(e) =>
//                                     handlePaymentChange(
//                                       "paymentMethod",
//                                       e.target
//                                         .value as WorkshopPayment["paymentMethod"]
//                                     )
//                                   }
//                                   required
//                                 >
//                                   {paymentMethodConfig.map((method) => (
//                                     <option
//                                       key={method.method}
//                                       value={method.method}
//                                     >
//                                       {method.label}
//                                     </option>
//                                   ))}
//                                 </Input>
//                               </FormGroup>
//                             </Col>
//                           </Row>

//                           <Row>
//                             <Col md="6">
//                               <FormGroup>
//                                 <Label>Amount</Label>
//                                 <Input
//                                   type="number"
//                                   step="0.01"
//                                   min="0.01"
//                                   max={selectedInvoice.balanceDue}
//                                   value={payment.amount}
//                                   onChange={(e) =>
//                                     handlePaymentChange(
//                                       "amount",
//                                       Number(e.target.value)
//                                     )
//                                   }
//                                   required
//                                 />
//                                 <small className="text-muted">
//                                   Maximum: $
//                                   {selectedInvoice.balanceDue.toFixed(2)}
//                                 </small>
//                               </FormGroup>
//                             </Col>
//                             <Col md="6">
//                               <FormGroup>
//                                 <Label>Reference Number</Label>
//                                 <Input
//                                   type="text"
//                                   value={payment.referenceNumber}
//                                   onChange={(e) =>
//                                     handlePaymentChange(
//                                       "referenceNumber",
//                                       e.target.value
//                                     )
//                                   }
//                                   placeholder="Transaction ID, Check #, etc."
//                                 />
//                               </FormGroup>
//                             </Col>
//                           </Row>

//                           {/* <FormGroup>
//                             <Label>Notes</Label>
//                             <Input
//                               type="textarea"
//                               rows="3"
//                               value={payment.notes}
//                               onChange={(e) =>
//                                 handlePaymentChange("notes", e.target.value)
//                               }
//                               placeholder="Additional payment notes..."
//                             />
//                           </FormGroup> */}

//                           {/* Payment Method Specific Fields */}
//                           {(payment.paymentMethod === "upi" ||
//                             payment.paymentMethod === "wallet") && (
//                             <FormGroup>
//                               <Label>Transaction ID</Label>
//                               <Input
//                                 type="text"
//                                 placeholder="Enter UPI transaction ID"
//                               />
//                             </FormGroup>
//                           )}

//                           {(payment.paymentMethod === "credit_card" ||
//                             payment.paymentMethod === "debit_card") && (
//                             <Row>
//                               <Col md="6">
//                                 <FormGroup>
//                                   <Label>Last 4 Digits</Label>
//                                   <Input
//                                     type="text"
//                                     maxLength={4}
//                                     placeholder="1234"
//                                   />
//                                 </FormGroup>
//                               </Col>
//                               <Col md="6">
//                                 <FormGroup>
//                                   <Label>Authorization Code</Label>
//                                   <Input type="text" placeholder="Auth code" />
//                                 </FormGroup>
//                               </Col>
//                             </Row>
//                           )}

//                           {payment.paymentMethod === "bank_transfer" && (
//                             <FormGroup>
//                               <Label>Bank Reference</Label>
//                               <Input
//                                 type="text"
//                                 placeholder="Bank transaction reference"
//                               />
//                             </FormGroup>
//                           )}

//                           {payment.paymentMethod === "check" && (
//                             <Row>
//                               <Col md="6">
//                                 <FormGroup>
//                                   <Label>Check Number</Label>
//                                   <Input
//                                     type="text"
//                                     placeholder="Check number"
//                                   />
//                                 </FormGroup>
//                               </Col>
//                               <Col md="6">
//                                 <FormGroup>
//                                   <Label>Bank Name</Label>
//                                   <Input type="text" placeholder="Bank name" />
//                                 </FormGroup>
//                               </Col>
//                             </Row>
//                           )}
//                         </CardBody>
//                       </Card>

//                       {/* Action Buttons */}
//                       <div className="d-flex gap-2">
//                         <Button type="submit" color="primary">
//                           <i className="fa fa-save me-2"></i>
//                           Record Payment
//                         </Button>
//                         <Button
//                           type="button"
//                           color="outline-success"
//                           onClick={handlePrintReceipt}
//                         >
//                           <i className="fa fa-receipt me-2"></i>
//                           Print Receipt
//                         </Button>
//                         <Button
//                           type="button"
//                           color="outline-secondary"
//                           onClick={() => router.back()}
//                         >
//                           Cancel
//                         </Button>
//                       </div>
//                     </>
//                   )}
//                 </Form>
//               </CardBody>
//             </Card>
//           </Col>

//           {/* Payment Summary */}
//           <Col lg="4">
//             <Card>
//               <CardBody>
//                 <h6 className="card-title mb-3 text-muted">Payment Summary</h6>

//                 {selectedInvoice ? (
//                   <>
//                     <div className="mb-3 text-muted">
//                       <strong>Invoice:</strong> {selectedInvoice.invoiceNumber}
//                       <br />
//                       <strong>Customer:</strong> {selectedInvoice.customerName}
//                       <br />
//                       <strong>Payment Method:</strong>{" "}
//                       {
//                         paymentMethodConfig.find(
//                           (m) => m.method === payment.paymentMethod
//                         )?.label
//                       }
//                     </div>

//                     <div className="border-top pt-3 text-muted">
//                       <div className="d-flex justify-content-between mb-2">
//                         <span>Amount Due:</span>
//                         <span className="text-danger">
//                           ${selectedInvoice.balanceDue.toFixed(2)}
//                         </span>
//                       </div>
//                       <div className="d-flex justify-content-between mb-2">
//                         <span>Payment Amount:</span>
//                         <span className="text-success">
//                           ${payment.amount?.toFixed(2) || "0.00"}
//                         </span>
//                       </div>
//                       <div className="d-flex justify-content-between mb-2 border-top pt-2">
//                         <strong>Balance After:</strong>
//                         <strong
//                           className={
//                             payment.balanceAfter && payment.balanceAfter > 0
//                               ? "text-warning"
//                               : "text-success"
//                           }
//                         >
//                           $
//                           {payment.balanceAfter?.toFixed(2) ||
//                             selectedInvoice.balanceDue.toFixed(2)}
//                         </strong>
//                       </div>
//                     </div>

//                     {payment.balanceAfter === 0 && (
//                       <div className="alert alert-success mt-3">
//                         <i className="fa fa-check me-2"></i>
//                         Invoice will be marked as fully paid!
//                       </div>
//                     )}

//                     {payment.balanceAfter && payment.balanceAfter > 0 && (
//                       <div className="alert alert-warning mt-3">
//                         <i className="fa fa-info-circle me-2"></i>
//                         Invoice will have partial payment balance.
//                       </div>
//                     )}
//                   </>
//                 ) : (
//                   <div className="text-center text-muted py-4">
//                     <i className="fa fa-credit-card fa-3x mb-3"></i>
//                     <p>Select an invoice to record payment</p>
//                   </div>
//                 )}
//               </CardBody>
//             </Card>

//             {/* Quick Actions */}
//             <Card className="mt-4">
//               <CardBody>
//                 <h6 className="card-title mb-3 text-muted">Quick Actions</h6>
//                 <div className="d-grid gap-2">
//                   <Button
//                     color="outline-primary"
//                     onClick={() => router.push("/admin/invoices")}
//                   >
//                     <i className="fa fa-file-invoice me-2"></i>
//                     View All Invoices
//                   </Button>
//                   <Button
//                     color="outline-info"
//                     onClick={() => router.push("/admin/customer")}
//                   >
//                     <i className="fa fa-users me-2"></i>
//                     Manage Customers
//                   </Button>
//                 </div>
//               </CardBody>
//             </Card>
//           </Col>
//         </Row>
//       </Container>
//     </div>
//   );
// }

// export default AddPaymentPage;

"use client";
import Breadcrumbs from "@/CommonElements/Breadcrumbs";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  Form,
  FormGroup,
  Label,
  Input,
  Button,
  Alert,
  Spinner,
} from "reactstrap";
import React, { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { PaymentMethodConfig } from "@/Types/payment";
import { useAuth } from "@/helper/AuthContext";
import { toast } from "react-toastify";
import { Currency } from "@/utils/Utils";

// Types based on your API response
interface Invoice {
  id: string;
  invoice_number: string;
  job_card_id: string;
  customer_id: string;
  created_by: string;
  issue_date: string;
  due_date: string;
  subtotal: string;
  tax_amount: string;
  discount_amount: string;
  total_amount: string;
  status: string;
  meta: string;
  created_at: string;
  updated_at: string;
  due_amount: string;
  customer_name: string;
  job_number: string;
}

interface PaymentAPIRequest {
  invoice_id: string;
  paid_at: string;
  method: string;
  amount: string;
  reference?: string;
}
// In your @/Types/payment.tsx file, update the types:

export interface PaymentFormData {
  invoiceId?: string; // Change from number to string
  invoiceNumber?: string;
  customerId?: string; // Change from number to string
  customerName?: string;
  amountDue?: number;
  amount?: number;
  balanceAfter?: number;
  paymentMethod:
    | "cash"
    | "upi"
    | "credit_card"
    | "debit_card"
    | "bank_transfer"
    | "check"
    | "wallet";
  paymentDate: string;
  referenceNumber?: string;
  notes?: string;
  status: "completed" | "pending" | "failed" | "refunded";
}

export interface WorkshopPayment {
  id: string; // Change from number to string if API returns string IDs
  invoiceId: string; // Change from number to string
  invoiceNumber: string;
  customerId: string; // Change from number to string
  customerName: string;
  amount: number;
  amountDue: number;
  balanceAfter: number;
  paymentMethod:
    | "cash"
    | "upi"
    | "credit_card"
    | "debit_card"
    | "bank_transfer"
    | "check"
    | "wallet";
  paymentDate: string;
  referenceNumber?: string;
  status: "completed" | "pending" | "failed" | "refunded";
  notes?: string;
  receiptNumber: string;
  createdAt: string;
  updatedAt: string;
}

// Or if you want to keep numbers but convert from API strings:
export interface WorkshopPayment {
  id: string;
  invoiceId: string;
  invoiceNumber: string;
  customerId: string;
  customerName: string;
  amount: number;
  amountDue: number;
  balanceAfter: number;
  paymentMethod:
    | "cash"
    | "upi"
    | "credit_card"
    | "debit_card"
    | "bank_transfer"
    | "check"
    | "wallet";
  paymentDate: string;
  referenceNumber?: string;
  status: "completed" | "pending" | "failed" | "refunded";
  notes?: string;
  receiptNumber: string;
  createdAt: string;
  updatedAt: string;
}
const paymentMethodConfig: PaymentMethodConfig[] = [
  { method: "cash", label: "Cash", icon: "fa-money-bill", color: "success" },
  { method: "upi", label: "UPI", icon: "fa-mobile-alt", color: "primary" },
  {
    method: "credit_card",
    label: "Credit Card",
    icon: "fa-credit-card",
    color: "info",
  },
  {
    method: "debit_card",
    label: "Debit Card",
    icon: "fa-credit-card",
    color: "warning",
  },
  {
    method: "bank_transfer",
    label: "Bank Transfer",
    icon: "fa-university",
    color: "dark",
  },
  {
    method: "check",
    label: "Check",
    icon: "fa-money-check",
    color: "secondary",
  },
  {
    method: "wallet",
    label: "Digital Wallet",
    icon: "fa-wallet",
    color: "danger",
  },
];

function AddPaymentPage() {
  const router = useRouter();
  const { state } = useAuth();
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadingInvoices, setLoadingInvoices] = useState(true);
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
  const [payment, setPayment] = useState<PaymentFormData>({
    paymentDate: new Date().toISOString().split("T")[0],
    paymentMethod: "cash",
    amount: 0,
    referenceNumber: "",
    notes: "",
    status: "completed",
  });
  const [showSuccess, setShowSuccess] = useState(false);

  // Fetch invoices from API
  useEffect(() => {
    fetchInvoices();
  }, []);

  const fetchInvoices = async () => {
    try {
      setLoadingInvoices(true);
      const token = state?.accessToken || localStorage.getItem("token");

      if (!token) {
        toast.error("Authentication required. Please login again.");
        router.push("/login");
        return;
      }

      const response = await fetch("/api/invoices", {
        method: "GET",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }

      const data = await response.json();

      if (data.data && Array.isArray(data.data)) {
        // Filter invoices with due amount > 0 (unpaid or partially paid)
        const filteredInvoices = data.data.filter(
          (invoice: Invoice) => parseFloat(invoice.due_amount) > 0
          // (invoice: Invoice) => invoice.status !== "paid"
        );
        setInvoices(filteredInvoices);
      } else {
        toast.error("Invalid data format received from API");
        setInvoices([]);
      }
    } catch (error: any) {
      console.error("Error fetching invoices:", error);
      toast.error(`Failed to load invoices: ${error.message}`);
      setInvoices([]);
    } finally {
      setLoadingInvoices(false);
    }
  };

  // Format date for display
  const formatDate = (dateString: string) => {
    if (!dateString || dateString === "0000-00-00 00:00:00") return "Not set";
    try {
      return new Date(dateString).toLocaleDateString("en-US", {
        year: "numeric",
        month: "short",
        day: "numeric",
      });
    } catch {
      return "Invalid date";
    }
  };

  // Generate receipt number
  const generateReceiptNumber = () => {
    const timestamp = new Date().getTime();
    return `RCP-${new Date().getFullYear()}-${String(timestamp).slice(-6)}`;
  };

  const handleInvoiceSelect = (invoiceId: string) => {
    const invoice = invoices.find((inv) => inv.id === invoiceId);
    setSelectedInvoice(invoice || null);

    if (invoice) {
      const dueAmount = parseFloat(invoice.due_amount) || 0;
      setPayment((prev) => ({
        ...prev,
        invoiceId: invoice.id,
        invoiceNumber: invoice.invoice_number,
        customerId: invoice.customer_id,
        customerName: invoice.customer_name,
        amountDue: dueAmount,
        amount: dueAmount, // Default to full amount
        balanceAfter: 0, // Initialize balance after
      }));
    }
  };

  const handlePaymentChange = (field: keyof PaymentFormData, value: any) => {
    setPayment((prev) => {
      const updated = { ...prev, [field]: value };

      // Auto-calculate balance after payment
      if (field === "amount" && selectedInvoice) {
        const amount = Number(value) || 0;
        const dueAmount = parseFloat(selectedInvoice.due_amount) || 0;
        const balanceAfter = dueAmount - amount;
        updated.balanceAfter = Math.max(0, balanceAfter);
      }

      return updated;
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!selectedInvoice) {
      toast.error("Please select an invoice");
      return;
    }

    if (!payment.amount || payment.amount <= 0) {
      toast.error("Please enter a valid payment amount");
      return;
    }

    // Validate amount doesn't exceed due amount
    const dueAmount = parseFloat(selectedInvoice.due_amount) || 0;
    if (payment.amount > dueAmount) {
      toast.error(
        `Payment amount cannot exceed due amount of $${dueAmount.toFixed(2)}`
      );
      return;
    }

    setLoading(true);

    try {
      const token = state?.accessToken || localStorage.getItem("token");

      // Format date for API (DD-MM-YYYY)
      const paymentDate = new Date(payment.paymentDate);
      const formattedDate = `${paymentDate
        .getDate()
        .toString()
        .padStart(2, "0")}-${(paymentDate.getMonth() + 1)
        .toString()
        .padStart(2, "0")}-${paymentDate.getFullYear()}`;

      // Prepare API request body
      const paymentData: PaymentAPIRequest = {
        invoice_id: selectedInvoice.id,
        paid_at: formattedDate, // DD-MM-YYYY format
        method: payment.paymentMethod,
        amount: payment.amount.toString(),
      };

      // Add reference if provided
      if (payment.referenceNumber) {
        paymentData.reference = payment.referenceNumber;
      }

      const response = await fetch("/api/payments", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(paymentData),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to record payment");
      }

      const result = await response.json();

      // Create payment record for local state
      const newPayment: WorkshopPayment = {
        id: result.data?.id || Math.floor(Math.random() * 1000),
        invoiceId: selectedInvoice.id,
        invoiceNumber: selectedInvoice.invoice_number,
        customerId: selectedInvoice.customer_id,
        customerName: selectedInvoice.customer_name,
        amount: payment.amount,
        amountDue: dueAmount,
        balanceAfter: payment.balanceAfter || 0,
        paymentMethod: payment.paymentMethod,
        paymentDate: payment.paymentDate,
        referenceNumber: payment.referenceNumber,
        status: payment.status,
        notes: payment.notes,
        receiptNumber: generateReceiptNumber(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      console.log("Payment recorded successfully:", newPayment);

      toast.success("Payment recorded successfully!");
      setShowSuccess(true);

      // Refresh invoices to update due amounts
      fetchInvoices();

      // Redirect after 2 seconds
      setTimeout(() => {
        router.push("/admin/payments");
      }, 2000);
    } catch (error: any) {
      console.error("Error recording payment:", error);
      toast.error(`Failed to record payment: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handlePrintReceipt = () => {
    if (!selectedInvoice) return;

    const receiptData = {
      receiptNumber: generateReceiptNumber(),
      paymentDate: payment.paymentDate,
      customerName: selectedInvoice.customer_name,
      invoiceNumber: selectedInvoice.invoice_number,
      amount: payment.amount!,
      paymentMethod:
        paymentMethodConfig.find((m) => m.method === payment.paymentMethod)
          ?.label || "",
      referenceNumber: payment.referenceNumber,
      balanceDue: payment.balanceAfter!,
      amountPaid: payment.amount!,
    };

    console.log("Printing receipt:", receiptData);

    // Open print dialog
    const printWindow = window.open("", "_blank");
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>Receipt ${receiptData.receiptNumber}</title>
            <style>
              body { font-family: Arial, sans-serif; margin: 20px; }
              .receipt { max-width: 400px; margin: 0 auto; }
              .header { text-align: center; border-bottom: 2px solid #000; padding-bottom: 10px; margin-bottom: 20px; }
              .details { margin-bottom: 20px; }
              .row { display: flex; justify-content: space-between; margin-bottom: 5px; }
              .total { border-top: 1px solid #000; padding-top: 10px; margin-top: 20px; }
              .footer { text-align: center; margin-top: 30px; font-size: 12px; color: #666; }
            </style>
          </head>
          <body>
            <div class="receipt">
              <div class="header">
                <h2>Payment Receipt</h2>
                <h3>${receiptData.receiptNumber}</h3>
              </div>
              <div class="details">
                <div class="row">
                  <span>Date:</span>
                  <span>${new Date(
                    receiptData.paymentDate
                  ).toLocaleDateString()}</span>
                </div>
                <div class="row">
                  <span>Customer:</span>
                  <span>${receiptData.customerName}</span>
                </div>
                <div class="row">
                  <span>Invoice:</span>
                  <span>${receiptData.invoiceNumber}</span>
                </div>
                <div class="row">
                  <span>Payment Method:</span>
                  <span>${receiptData.paymentMethod}</span>
                </div>
                ${
                  receiptData.referenceNumber
                    ? `
                <div class="row">
                  <span>Reference:</span>
                  <span>${receiptData.referenceNumber}</span>
                </div>`
                    : ""
                }
              </div>
              <div class="total">
                <div class="row">
                  <strong>Amount Paid:</strong>
                  <strong>$${receiptData.amountPaid.toFixed(2)}</strong>
                </div>
                <div class="row">
                  <span>Balance Due:</span>
                  <span>$${receiptData.balanceDue.toFixed(2)}</span>
                </div>
              </div>
              <div class="footer">
                <p>Thank you for your business!</p>
                <p>Printed: ${new Date().toLocaleString()}</p>
              </div>
            </div>
          </body>
        </html>
      `);
      printWindow.document.close();
      printWindow.focus();
      printWindow.print();
      printWindow.close();
    } else {
      toast.info(`Receipt ${receiptData.receiptNumber} generated!`);
    }
  };

  // Calculate total due amount
  const totalDueAmount = invoices.reduce(
    (sum, invoice) => sum + parseFloat(invoice.due_amount),
    0
  );

  return (
    <div className="page-body">
      <Breadcrumbs
        title="Record Payment"
        mainTitle="Payment Management"
        parent="Payments"
      />

      <Container fluid>
        <Row>
          <Col lg="8">
            <Card>
              <CardBody>
                <h5 className="card-title mb-4 text-muted">
                  Record New Payment
                </h5>

                {showSuccess && (
                  <Alert color="success" className="mb-4">
                    <i className="fa fa-check-circle me-2"></i>
                    Payment recorded successfully! Redirecting...
                  </Alert>
                )}

                <Form onSubmit={handleSubmit}>
                  {/* Invoice Selection */}
                  <Card className="bg-light mb-4">
                    <CardBody className="text-muted">
                      <h6 className="mb-3">Select Invoice</h6>
                      {loadingInvoices ? (
                        <div className="text-center py-3">
                          <Spinner size="sm" className="me-2" />
                          Loading invoices...
                        </div>
                      ) : (
                        <>
                          <FormGroup>
                            <Label>Invoice</Label>
                            <Input
                              type="select"
                              className="border"
                              value={selectedInvoice?.id || ""}
                              onChange={(e) =>
                                handleInvoiceSelect(e.target.value)
                              }
                              required
                              disabled={invoices.length === 0}
                            >
                              <option value="">Select an invoice...</option>
                              {invoices.map((invoice) => (
                                <option key={invoice.id} value={invoice.id}>
                                  {invoice.invoice_number} -{" "}
                                  {invoice.customer_name} - Due: $
                                  {parseFloat(invoice.due_amount).toFixed(2)}
                                </option>
                              ))}
                            </Input>
                          </FormGroup>

                          {invoices.length === 0 && !loadingInvoices && (
                            <Alert color="info" className="mt-3">
                              <i className="fa fa-info-circle me-2"></i>
                              No unpaid invoices found.
                            </Alert>
                          )}

                          {selectedInvoice && (
                            <div className="mt-3 p-3 border rounded">
                              <Row>
                                <Col md="6">
                                  <strong>Invoice #:</strong>{" "}
                                  {selectedInvoice.invoice_number}
                                </Col>
                                <Col md="6">
                                  <strong>Job #:</strong>{" "}
                                  {selectedInvoice.job_number}
                                </Col>

                                <Col md="6">
                                  <strong>Issue Date:</strong>{" "}
                                  {formatDate(selectedInvoice.issue_date)}
                                </Col>
                                <Col md="6">
                                  <strong>Due Date:</strong>{" "}
                                  {formatDate(selectedInvoice.due_date)}
                                </Col>
                                <Col md="6">
                                  <strong>Customer:</strong>{" "}
                                  {selectedInvoice.customer_name}
                                </Col>
                                <Col md="6">
                                  <strong>Invoice Total:</strong> {Currency}
                                  {selectedInvoice.total_amount}
                                </Col>
                                <Col md="6">
                                  <strong>Amount Paid:</strong>
                                  {Currency}
                                  {Number(selectedInvoice?.total_amount || 0) -
                                    Number(selectedInvoice?.due_amount || 0)}
                                </Col>
                                <Col md="6">
                                  <strong className="text-danger">
                                    Balance Due: {Currency}
                                    {selectedInvoice.due_amount}
                                  </strong>
                                </Col>
                              </Row>
                            </div>
                          )}
                        </>
                      )}
                    </CardBody>
                  </Card>

                  {selectedInvoice && (
                    <>
                      {/* Payment Details */}
                      <Card className="mb-4">
                        <CardBody className="text-muted">
                          <h6 className="mb-3">Payment Details</h6>
                          <Row>
                            <Col md="6">
                              <FormGroup>
                                <Label>Payment Date</Label>
                                <Input
                                  type="date"
                                  value={payment.paymentDate}
                                  onChange={(e) =>
                                    handlePaymentChange(
                                      "paymentDate",
                                      e.target.value
                                    )
                                  }
                                  required
                                />
                              </FormGroup>
                            </Col>
                            <Col md="6">
                              <FormGroup>
                                <Label>Payment Method</Label>
                                <Input
                                  type="select"
                                  className="border"
                                  value={payment.paymentMethod}
                                  onChange={(e) =>
                                    handlePaymentChange(
                                      "paymentMethod",
                                      e.target.value
                                    )
                                  }
                                  required
                                >
                                  {paymentMethodConfig.map((method) => (
                                    <option
                                      key={method.method}
                                      value={method.method}
                                    >
                                      {method.label}
                                    </option>
                                  ))}
                                </Input>
                              </FormGroup>
                            </Col>
                          </Row>

                          <Row>
                            <Col md="6">
                              <FormGroup>
                                <Label>Amount</Label>
                                <Input
                                  type="number"
                                  step="0.01"
                                  min="0.01"
                                  max={parseFloat(selectedInvoice.due_amount)}
                                  value={payment.amount}
                                  onChange={(e) =>
                                    handlePaymentChange(
                                      "amount",
                                      Number(e.target.value)
                                    )
                                  }
                                  required
                                />
                                <small className="text-muted">
                                  Maximum: $
                                  {parseFloat(
                                    selectedInvoice.due_amount
                                  ).toFixed(2)}
                                </small>
                              </FormGroup>
                            </Col>
                            <Col md="6">
                              <FormGroup>
                                <Label>Reference Number</Label>
                                <Input
                                  type="text"
                                  value={payment.referenceNumber}
                                  onChange={(e) =>
                                    handlePaymentChange(
                                      "referenceNumber",
                                      e.target.value
                                    )
                                  }
                                  placeholder="Transaction ID, Check #, etc."
                                />
                              </FormGroup>
                            </Col>
                          </Row>

                          {/* Payment Method Specific Fields */}
                          {(payment.paymentMethod === "upi" ||
                            payment.paymentMethod === "wallet") && (
                            <FormGroup>
                              <Label>Transaction ID</Label>
                              <Input
                                type="text"
                                placeholder="Enter UPI transaction ID"
                              />
                            </FormGroup>
                          )}

                          {(payment.paymentMethod === "credit_card" ||
                            payment.paymentMethod === "debit_card") && (
                            <Row>
                              <Col md="6">
                                <FormGroup>
                                  <Label>Last 4 Digits</Label>
                                  <Input
                                    type="text"
                                    maxLength={4}
                                    placeholder="1234"
                                  />
                                </FormGroup>
                              </Col>
                              <Col md="6">
                                <FormGroup>
                                  <Label>Authorization Code</Label>
                                  <Input type="text" placeholder="Auth code" />
                                </FormGroup>
                              </Col>
                            </Row>
                          )}

                          {payment.paymentMethod === "bank_transfer" && (
                            <FormGroup>
                              <Label>Bank Reference</Label>
                              <Input
                                type="text"
                                placeholder="Bank transaction reference"
                              />
                            </FormGroup>
                          )}

                          {payment.paymentMethod === "check" && (
                            <Row>
                              <Col md="6">
                                <FormGroup>
                                  <Label>Check Number</Label>
                                  <Input
                                    type="text"
                                    placeholder="Check number"
                                  />
                                </FormGroup>
                              </Col>
                              <Col md="6">
                                <FormGroup>
                                  <Label>Bank Name</Label>
                                  <Input type="text" placeholder="Bank name" />
                                </FormGroup>
                              </Col>
                            </Row>
                          )}
                        </CardBody>
                      </Card>

                      {/* Action Buttons */}
                      <div className="d-flex gap-2">
                        <Button
                          type="submit"
                          color="primary"
                          disabled={loading}
                        >
                          {loading ? (
                            <>
                              <Spinner size="sm" className="me-2" />
                              Processing...
                            </>
                          ) : (
                            <>
                              <i className="fa fa-save me-2"></i>
                              Record Payment
                            </>
                          )}
                        </Button>
                        <Button
                          type="button"
                          color="outline-success"
                          onClick={handlePrintReceipt}
                          disabled={loading}
                        >
                          <i className="fa fa-receipt me-2"></i>
                          Print Receipt
                        </Button>
                        <Button
                          type="button"
                          color="outline-secondary"
                          onClick={() => router.back()}
                          disabled={loading}
                        >
                          Cancel
                        </Button>
                      </div>
                    </>
                  )}
                </Form>
              </CardBody>
            </Card>
          </Col>

          {/* Payment Summary */}
          <Col lg="4">
            <Card>
              <CardBody>
                <h6 className="card-title mb-3 text-muted">Payment Summary</h6>

                {selectedInvoice ? (
                  <>
                    <div className="mb-3 text-muted">
                      <strong>Invoice:</strong> {selectedInvoice.invoice_number}
                      <br />
                      <strong>Customer:</strong> {selectedInvoice.customer_name}
                      <br />
                      <strong>Payment Method:</strong>{" "}
                      {
                        paymentMethodConfig.find(
                          (m) => m.method === payment.paymentMethod
                        )?.label
                      }
                    </div>

                    <div className="border-top pt-3 text-muted">
                      <div className="d-flex justify-content-between mb-2">
                        <span>Amount Due:</span>
                        <span className="text-danger">
                          ${parseFloat(selectedInvoice.due_amount).toFixed(2)}
                        </span>
                      </div>
                      <div className="d-flex justify-content-between mb-2">
                        <span>Payment Amount:</span>
                        <span className="text-success">
                          ${payment.amount?.toFixed(2) || "0.00"}
                        </span>
                      </div>
                      <div className="d-flex justify-content-between mb-2 border-top pt-2">
                        <strong>Balance After:</strong>
                        <strong
                          className={
                            payment.balanceAfter && payment.balanceAfter > 0
                              ? "text-warning"
                              : "text-success"
                          }
                        >
                          $
                          {payment.balanceAfter?.toFixed(2) ||
                            parseFloat(selectedInvoice.due_amount).toFixed(2)}
                        </strong>
                      </div>
                    </div>

                    {payment.balanceAfter === 0 && (
                      <div className="alert alert-success mt-3">
                        <i className="fa fa-check me-2"></i>
                        Invoice will be marked as fully paid!
                      </div>
                    )}

                    {payment.balanceAfter && payment.balanceAfter > 0 && (
                      <div className="alert alert-warning mt-3">
                        <i className="fa fa-info-circle me-2"></i>
                        Invoice will have partial payment balance.
                      </div>
                    )}
                  </>
                ) : (
                  <div className="text-center text-muted py-4">
                    <i className="fa fa-credit-card fa-3x mb-3"></i>
                    <p>Select an invoice to record payment</p>
                    {!loadingInvoices && invoices.length === 0 && (
                      <small className="text-info">
                        All invoices are fully paid.
                      </small>
                    )}
                  </div>
                )}
              </CardBody>
            </Card>

            {/* Quick Stats */}
            {/* <Card className="mt-4">
              <CardBody>
                <h6 className="card-title mb-3 text-muted">Quick Stats</h6>
                <div className="text-muted">
                  <div className="d-flex justify-content-between mb-2">
                    <span>Total Unpaid Invoices:</span>
                    <span>{invoices.length}</span>
                  </div>
                  <div className="d-flex justify-content-between mb-2">
                    <span>Total Due Amount:</span>
                    <span className="text-danger">
                      ${totalDueAmount.toFixed(2)}
                    </span>
                  </div>
                  <div className="d-flex justify-content-between">
                    <span>Last Payment:</span>
                    <span>
                      {invoices.length > 0
                        ? formatDate(invoices[0].due_date)
                        : "N/A"}
                    </span>
                  </div>
                </div>
              </CardBody>
            </Card> */}

            {/* Quick Actions */}
            <Card className="mt-4">
              <CardBody>
                <h6 className="card-title mb-3 text-muted">Quick Actions</h6>
                <div className="d-grid gap-2">
                  <Button
                    color="outline-primary"
                    onClick={() => router.push("/admin/invoices")}
                  >
                    <i className="fa fa-file-invoice me-2"></i>
                    View All Invoices
                  </Button>
                  <Button
                    color="outline-info"
                    onClick={() => router.push("/admin/customer")}
                  >
                    <i className="fa fa-users me-2"></i>
                    Manage Customers
                  </Button>
                  <Button
                    color="outline-success"
                    onClick={fetchInvoices}
                    disabled={loadingInvoices}
                  >
                    {loadingInvoices ? (
                      <>
                        <Spinner size="sm" className="me-2" />
                        Refreshing...
                      </>
                    ) : (
                      <>
                        <i className="fa fa-sync me-2"></i>
                        Refresh Invoices
                      </>
                    )}
                  </Button>
                </div>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Container>
    </div>
  );
}

export default AddPaymentPage;
