"use client";
import Breadcrumbs from "@/CommonElements/Breadcrumbs";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  Table,
  Badge,
  Button,
} from "reactstrap";
import React, { useEffect, useState } from "react";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import { useAuth } from "@/helper/AuthContext";
import { toast } from "react-toastify";

// This would typically come from your API
interface vehicleData {
  id: string;
  customer_id: string;
  vehicle_type: string;
  make: string;
  model: string;
  year: string;
  registration_number: string;
  chassis_number: string;
  engine_number: string;
  km_reading: string;
  meta: string;
  created_at: string;
  updated_at: string;

  customer_name: string;

  color: string;
  fuelType: string;
  status: string;
  vin: string;

  // id: 1,
  // customerId: 1,
  // customerName: "John Doe",
  // customerEmail: "john.doe@email.com",
  // customerPhone: "+1-555-0101",
  // make: "Toyota",
  // model: "Camry",
  // year: 2022,
  // registrationNo: "ABC123",
  // vin: "1HGCM82633A123456",
  // engineNo: "2AZ1234567",
  // color: "White",
  // fuelType: "petrol",
  // kmDriven: 25400,
  // lastServiceDate: "2024-01-15",
  // nextServiceDue: "2024-04-15",
  // status: "active",
  // insuranceExpiry: "2024-12-31",
  // registrationExpiry: "2025-03-31",
  // createdAt: "2022-05-15",
}
interface Service {
  id: string;
  // date:string;
  job_number: string;
  total_estimate: string;
  reported_issue: string;
  created_at: string;
  serviceType: string;
  description: string;
  amount: string;
  status: string;
  assigned_to_user: string;
}
function VehicleDetailPage() {
  //{ params }: { params: { id: string } }

  const { state } = useAuth();
  const params = useParams();
  const router = useRouter();

  const [vehicleId, setVehicleId] = useState<string | null>(null);
  const [vehicleData, setVehicleData] = useState<vehicleData | null>(null);
  const [serviceHistory, setserviceHistory] = useState<Service[]>([]);
  const [loading, setLoading] = useState(true);

  //get vehicle id
  useEffect(() => {
    if (params?.id) {
      const id = Array.isArray(params.id) ? params.id[0] : params.id;
      setVehicleId(id);

      console.log("vehicle id", id);

      fetchVehicleData(id);
      fetchServiceDetails(id);
    }
  }, [params]);

  //fetch single vehicle details from id
  const fetchVehicleData = async (id: string) => {
    try {
      setLoading(true);

      const response = await fetch(`/api/vehicles/${id}`, {
        method: "GET",
        headers: {
          Authorization: `Bearer ${
            state?.accessToken || localStorage.getItem("token")
          }`,
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error("Vehicle Not Found");
      }

      const data = await response.json();
      console.log(data);
      setVehicleData(data.data);
    } catch (error) {
      console.error("Error in fetching data", error);
    }
  };

  const fetchServiceDetails = async (id: string) => {
    console.log("vehicleId", id);
    try {
      const response = await fetch("/api/service_list", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${state?.accessToken}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          vehicle_id: id,
        }),
      });

      if (!response.ok) {
        console.log("Service Not Found");
        toast.error("Service Not Found");
      }

      console.log(response);
      const data = await response.json();
      console.log(data.data);
      setserviceHistory(data.data);
    } catch (error) {
      console.error(`Error fetching service details`, error);
    }
  };

  const renderStatusBadge = (status?: string) => {
    const mode = status || "active";

    const config = {
      active: { class: "bg-success", label: "Active" },
      inactive: { class: "bg-secondary", label: "Inactive" },
      maintenance: { class: "bg-warning", label: "In Maintenance" },
    }[mode] || { class: "bg-secondary", label: mode };

    return <Badge className={config.class}>{config.label}</Badge>;
  };

  const renderFuelTypeBadge = (fuelType: string) => {
    const config = {
      petrol: { class: "bg-info", label: "Petrol" },
      diesel: { class: "bg-dark", label: "Diesel" },
      electric: { class: "bg-success", label: "Electric" },
      hybrid: { class: "bg-primary", label: "Hybrid" },
    }[fuelType] || { class: "bg-secondary", label: fuelType };

    return <Badge className={config.class}>{config.label}</Badge>;
  };

  return (
    <div className="page-body">
      <Breadcrumbs
        title="Vehicle Details"
        mainTitle={`${vehicleData?.make} ${vehicleData?.model}`}
        parent="Vehicles"
      />

      <Container fluid>
        <Row>
          {/* Vehicle Information */}
          <Col lg="4">
            <Card className="mb-4 text-muted">
              <CardBody>
                <h5 className="card-title mb-4 text-muted">
                  Vehicle Information
                </h5>
                <div className="vehicle-info">
                  <div className="mb-3 text-muted">
                    <strong>Registration No:</strong>
                    <div className="text-primary fw-bold fs-4">
                      {vehicleData?.registration_number}
                    </div>
                  </div>

                  <div className="row text-muted">
                    <div className="col-6 mb-2">
                      <small className="text-muted">Make</small>
                      <div>{vehicleData?.make}</div>
                    </div>
                    <div className="col-6 mb-2">
                      <small className="text-muted">Model</small>
                      <div>{vehicleData?.model}</div>
                    </div>
                    <div className="col-6 mb-2">
                      <small className="text-muted">Year</small>
                      <div>{vehicleData?.year}</div>
                    </div>
                    {/* <div className="col-6 mb-2">
                      <small className="text-muted">Color</small>
                      <div>{vehicleData?.color}</div>
                    </div> */}
                    <div className="col-6 mb-2">
                      <small className="text-muted">Fuel Type</small>
                      <div>
                        {vehicleData?.fuelType
                          ? renderFuelTypeBadge(vehicleData?.fuelType)
                          : "-"}
                      </div>
                    </div>
                    {/* <div className="col-6 mb-2">
                      <small className="text-muted">Status</small>
                      <div>{renderStatusBadge(vehicleData?.status)}</div>
                    </div> */}
                    <div className="col-12 mb-2">
                      <small className="text-muted">VIN</small>
                      <div className="font-monospace">{vehicleData?.vin}</div>
                    </div>
                    <div className="col-12 mb-2">
                      <small className="text-muted">Engine No</small>
                      <div>{vehicleData?.engine_number}</div>
                    </div>
                    <div className="col-6 mb-2">
                      <small className="text-muted">KM Driven</small>
                      <div>
                        {/* {vehicleData?.km_reading.toLocaleString()} km */}
                        {vehicleData?.km_reading} km
                      </div>
                    </div>
                  </div>
                </div>
              </CardBody>
            </Card>

            {/* Customer Information */}
            <Card className="mb-4 ">
              <CardBody>
                <h5 className="card-title mb-4 text-muted">
                  Customer Information
                </h5>
                <div className="customer-info text-muted">
                  <div className="mb-2">
                    <i className="fa fa-user me-2 text-muted"></i>
                    <strong>{vehicleData?.customer_name}</strong>
                  </div>
                  <div className="mb-1">
                    <i className="fa fa-envelope me-2 text-muted"></i>
                    {/* {vehicleData.customerEmail} */}
                  </div>
                  <div className="mb-1">
                    <i className="fa fa-phone me-2 text-muted"></i>
                    {/* {vehicleData.customerPhone} */}
                  </div>
                  <div className="mt-3">
                    <small className="text-muted">
                      Customer ID: {vehicleData?.customer_id}
                    </small>
                  </div>
                </div>
              </CardBody>
            </Card>

            {/* Important Dates */}
            {/* <Card>
              <CardBody>
                <h5 className="card-title mb-4 text-muted">Important Dates</h5>
                <div className="dates-info text-muted">
                  <div className="mb-2 text-muted">
                    <small className="text-muted">Last Service</small>
                    <div>
                      {new Date(
                        vehicleData.lastServiceDate
                      ).toLocaleDateString()}
                    </div>
                  </div>
                  <div className="mb-2">
                    <small className="text-muted">Next Service Due</small>
                    <div
                      className={
                        new Date(vehicleData.nextServiceDue) < new Date()
                          ? "text-danger fw-bold"
                          : ""
                      }
                    >
                      {new Date(
                        vehicleData.nextServiceDue
                      ).toLocaleDateString()}
                    </div>
                  </div>
                  <div className="mb-2">
                    <small className="text-muted">Insurance Expiry</small>
                    <div>
                      {new Date(
                        vehicleData.insuranceExpiry
                      ).toLocaleDateString()}
                    </div>
                  </div>
                  <div className="mb-2">
                    <small className="text-muted">Registration Expiry</small>
                    <div>
                      {new Date(
                        vehicleData.registrationExpiry
                      ).toLocaleDateString()}
                    </div>
                  </div>
                </div>
              </CardBody>
            </Card> */}
          </Col>

          {/* Service History and Job Cards */}
          <Col lg="8">
            {/* Recent Service History */}
            <Card className="mb-4">
              <CardBody>
                <div className="d-flex justify-content-between align-items-center mb-4">
                  <h5 className="card-title mb-0 text-muted">
                    Service History
                  </h5>
                  {/* <Button color="primary" size="sm">
                    <i className="fa fa-plus me-2"></i>
                    Add Service
                  </Button> */}
                </div>
                <div className="table-responsive">
                  <Table hover size="sm">
                    <thead>
                      <tr>
                        <th>Date</th>
                        <th>Service Type</th>
                        <th>KM Reading</th>
                        <th>Cost</th>
                        <th>Technician</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {serviceHistory.map((service) => (
                        <tr key={service.id}>
                          <td>
                            {new Date(service.created_at).toLocaleDateString()}
                          </td>
                          <td>
                            <div>
                              <div className="fw-bold no-wrap">
                                {service.serviceType}
                              </div>
                              <small className="text-muted">
                                {service.description}
                              </small>
                            </div>
                          </td>
                          <td className="no-wrap"></td>
                          <td>${service.total_estimate}</td>
                          <td>{service.assigned_to_user}</td>
                          <td>
                            <button
                              className="action-btn text-white border btn-primary"
                              title="View Details"
                            >
                              <i className="fa fa-eye"></i>
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </Table>
                </div>
              </CardBody>
            </Card>

            {/* Linked Job Cards */}
            <Card>
              <CardBody>
                <h5 className="card-title mb-4 text-muted">Linked Job Cards</h5>
                <div className="table-responsive">
                  <Table hover size="sm">
                    <thead>
                      <tr>
                        <th>Job Card No</th>
                        <th>Date</th>
                        <th>Service</th>
                        <th>Status</th>
                        <th>Cost</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    {/* <tbody>
                      {jobCards.map((job) => (
                        <tr key={job.id}>
                          <td className="no-wrap">
                            <Link
                              href={`/admin/jobcards/${job.id}`}
                              className="text-primary"
                            >
                              {job.id}
                            </Link>
                          </td>
                          <td>{new Date(job.date).toLocaleDateString()}</td>
                          <td>{job.service}</td>
                          <td>
                            <Badge color="success">{job.status}</Badge>
                          </td>
                          <td>${job.cost.toFixed(2)}</td>
                          <td>
                            <button
                              className="action-btn text-white border btn-info"
                              onClick={() =>
                                router.push(`/admin/jobcards/${job.id}`)
                              }
                              title="View Job Card"
                            >
                              <i className="fa fa-eye"></i>
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody> */}
                  </Table>
                </div>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Container>

      <style jsx global>{`
        .action-btn {
          padding: 0.25rem 0.5rem;
          border-radius: 5px;
          font-size: 0.75rem;
          border: none;
          display: flex;
          align-items: center;
          justify-content: center;
          width: 32px;
          height: 32px;
        }
      `}</style>
    </div>
  );
}

export default VehicleDetailPage;
