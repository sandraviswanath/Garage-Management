// "use client";
// import Breadcrumbs from "@/CommonElements/Breadcrumbs";
// import {
//   Container,
//   Row,
//   Col,
//   Card,
//   CardBody,
//   Form,
//   FormGroup,
//   Label,
//   Input,
//   Button,
//   Spinner,
//   Alert,
// } from "reactstrap";
// import React, { useState, ChangeEvent, useEffect, useRef } from "react";
// import Link from "next/link";
// import { useRouter, useSearchParams } from "next/navigation";
// import { useAuth } from "@/helper/AuthContext";
// import { toast } from "react-toastify";

// // Customer Type based on API response
// interface Customer {
//   id: string;
//   name: string;
//   contact_phone: string;
//   email: string;
//   address: string;
//   status: string;
//   gst_number: string | null;
//   meta: string;
//   created_at: string;
//   updated_at: string;
// }

// interface ApiResponse {
//   data: Customer[];
// }

// const vehicleTypes = [
//   { value: "car", label: "Car" },
//   { value: "bike", label: "Bike" },
//   { value: "suv", label: "SUV" },
//   { value: "truck", label: "Truck" },
//   { value: "van", label: "Van" },
//   { value: "bus", label: "Bus" },
//   { value: "other", label: "Other" },
// ];

// function AddVehiclePage() {
//   const { state } = useAuth();
//   const router = useRouter();
//   const [customers, setCustomers] = useState<Customer[]>([]);
//   const [loading, setLoading] = useState(true);
//   const [submitting, setSubmitting] = useState(false);
//   const [error, setError] = useState<string | null>(null);

//   // for edit vehicle
//   const searchParams = useSearchParams();
//   const vehicleId = searchParams.get("id");
//   const [isEditMode, setIsEditMode] = useState(false);

//   // Customer dropdown state
//   const [customerSearchTerm, setCustomerSearchTerm] = useState("");
//   const [isCustomerDropdownOpen, setIsCustomerDropdownOpen] = useState(false);
//   const [selectedCustomerName, setSelectedCustomerName] = useState("");
//   const customerDropdownRef = useRef<HTMLDivElement | null>(null);

//   const [formData, setFormData] = useState({
//     customer_id: "",
//     vehicle_type: "", // Changed from "car" to empty string
//     make: "",
//     model: "",
//     year: "",
//     registration_number: "",
//     chassis_number: "",
//     engine_number: "",
//     km_reading: "0", // Changed to string "0" instead of empty string
//   });

//   // Fetch customers from API
//   useEffect(() => {
//     const fetchCustomers = async () => {
//       try {
//         setLoading(true);
//         setError(null);

//         const token = state?.accessToken || localStorage.getItem("token");
//         if (!token) {
//           toast.error("Authentication required. Please login again.");
//           router.push("/login");
//           return;
//         }

//         const response = await fetch("/api/customers_list", {
//           method: "GET",
//           headers: {
//             Authorization: `Bearer ${token}`,
//             "Content-Type": "application/json",
//           },
//         });

//         if (!response.ok) {
//           throw new Error(`Failed to fetch customers: ${response.status}`);
//         }

//         const data: ApiResponse = await response.json();
//         setCustomers(data.data || []);
//       } catch (err) {
//         console.error("Error fetching customers:", err);
//         setError(
//           err instanceof Error ? err.message : "Failed to load customers"
//         );
//         toast.error("Failed to load customers");
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchCustomers();
//   }, []);
//   useEffect(() => {
//     const handleClickOutside = (event: MouseEvent) => {
//       if (
//         customerDropdownRef.current &&
//         !customerDropdownRef.current.contains(event.target as Node)
//       ) {
//         setIsCustomerDropdownOpen(false);
//       }
//     };

//     document.addEventListener("mousedown", handleClickOutside);
//     return () => {
//       document.removeEventListener("mousedown", handleClickOutside);
//     };
//   }, []);

//   const handleInputChange = (
//     e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
//   ) => {
//     const { name, value } = e.target;
//     setFormData((prev) => ({
//       ...prev,
//       [name]: value,
//     }));
//   };

//   // Handle customer selection
//   const handleCustomerSelect = (customerId: string, customerName: string) => {
//     setFormData((prev) => ({
//       ...prev,
//       customer_id: customerId,
//     }));
//     setSelectedCustomerName(customerName);
//     setIsCustomerDropdownOpen(false);
//     setCustomerSearchTerm("");
//   };

//   // Filter customers based on search term
//   const filteredCustomers = customers.filter((customer) =>
//     customer.name.toLowerCase().includes(customerSearchTerm.toLowerCase())
//   );

//   const handleSubmit = async (e: React.FormEvent) => {
//     e.preventDefault();

//     // Validate required fields
//     const requiredFields = [
//       "customer_id",
//       "registration_number",
//       "make",
//       "model",
//       "year",
//       "vehicle_type",
//     ];

//     const missingFields = requiredFields.filter(
//       (field) => !formData[field as keyof typeof formData]
//     );

//     if (missingFields.length > 0) {
//       toast.error(
//         `Please fill all required fields: ${missingFields.join(", ")}`
//       );
//       return;
//     }

//     // Validate year is a valid number
//     const yearNum = parseInt(formData.year);
//     if (
//       isNaN(yearNum) ||
//       yearNum < 1900 ||
//       yearNum > new Date().getFullYear() + 1
//     ) {
//       toast.error("Please enter a valid year");
//       return;
//     }

//     // Validate vehicle type is from allowed list
//     const validVehicleTypes = vehicleTypes.map((vt) => vt.value);
//     if (!validVehicleTypes.includes(formData.vehicle_type)) {
//       toast.error("Please select a valid vehicle type");
//       return;
//     }

//     try {
//       setSubmitting(true);
//       setError(null);

//       // Prepare data for API - ensure all fields match API expectations
//       const vehicleData = {
//         customer_id: formData.customer_id,
//         vehicle_type: formData.vehicle_type,
//         make: formData.make,
//         model: formData.model,
//         year: formData.year,
//         registration_number: formData.registration_number,
//         chassis_number: formData.chassis_number || null,
//         engine_number: formData.engine_number || null,
//         km_reading: formData.km_reading || "0",
//       };

//       console.log("Submitting vehicle data:", vehicleData);

//       let method;
//       let url;

//       if (isEditMode && vehicleId) {
//         method = "PUT";
//         url = `/api/vehicles/${vehicleId}`;
//       } else {
//         method = "POST";
//         url = "/api/vehicles";
//       }

//       const response = await fetch(url, {
//         method,
//         headers: {
//           "Content-Type": "application/json",
//           Authorization: `Bearer ${
//             state?.accessToken ?? (localStorage.getItem("token") || "")
//           }`,
//         },
//         body: JSON.stringify(vehicleData),
//       });

//       const result = await response.json();

//       if (!response.ok) {
//         // Handle validation errors from API
//         if (result.errors) {
//           const errorMessages = Object.values(result.errors).flat().join(", ");
//           throw new Error(errorMessages);
//         }
//         throw new Error(
//           result.message ||
//             `Failed to ${isEditMode ? "Update" : "Add"} vehicle: ${
//               response.status
//             }`
//         );
//       }

//       console.log(
//         `Vehicle ${isEditMode ? "updated" : "added"} successfully:`,
//         result
//       );

//       toast.success(
//         result.message ||
//           `Vehicle ${isEditMode ? "Updated" : "Added"} Successfully`
//       );

//       // Redirect after successful submission
//       setTimeout(() => {
//         router.push("/admin/vehicles");
//       }, 1000);
//     } catch (err) {
//       console.error(
//         `Error ${isEditMode ? "updating" : "adding"} vehicle:`,
//         err
//       );

//       const errorMessage =
//         err instanceof Error
//           ? err.message
//           : `Failed to ${
//               isEditMode ? "update" : "add"
//             } vehicle. Please try again.`;
//       setError(errorMessage);
//       toast.error(errorMessage);
//     } finally {
//       setSubmitting(false);
//     }
//   };

//   // Generate years from 1900 to current year + 1
//   const currentYear = new Date().getFullYear();
//   const years = Array.from(
//     { length: currentYear - 1899 },
//     (_, i) => currentYear + 1 - i
//   );

//   // for edit vehicle
//   useEffect(() => {
//     if (vehicleId) {
//       setIsEditMode(true);
//       fetchVehicleData(vehicleId);
//     }
//   }, [vehicleId]);

//   const fetchVehicleData = async (id: string) => {
//     try {
//       setLoading(true);

//       const token = state?.accessToken || localStorage.getItem("token");
//       const response = await fetch(`/api/vehicles/${id}`, {
//         method: "GET",
//         headers: {
//           Authorization: `Bearer ${token}`,
//           "Content-Type": "application/json",
//         },
//       });

//       if (!response.ok) {
//         throw new Error(`Failed to fetch vehicle: ${response.status}`);
//       }

//       const data = await response.json();
//       console.log("Fetched vehicle data:", data);

//       if (data.data) {
//         setFormData({
//           customer_id: data.data.customer_id || "",
//           vehicle_type: data.data.vehicle_type || "",
//           make: data.data.make || "",
//           model: data.data.model || "",
//           year: data.data.year || "",
//           registration_number: data.data.registration_number || "",
//           chassis_number: data.data.chassis_number || "",
//           engine_number: data.data.engine_number || "",
//           km_reading: data.data.km_reading || "0",
//         });
//       }
//     } catch (error) {
//       console.error("Error Fetching Vehicle Data", error);
//       toast.error("Failed to load vehicle data");
//     } finally {
//       setLoading(false);
//     }
//   };

//   return (
//     <div className="page-body">
//       <Breadcrumbs
//         title={isEditMode ? "Edit Vehicle" : "Add Vehicle"}
//         mainTitle={isEditMode ? "Edit Vehicle" : "Add New Vehicle"}
//         parent="Vehicles"
//       />

//       <Container fluid>
//         <Row>
//           <Col sm="12">
//             <Card>
//               <CardBody>
//                 {/* Error Alert */}
//                 {error && (
//                   <Alert color="danger" className="mb-4">
//                     <h5 className="alert-heading">Error</h5>
//                     <p>{error}</p>
//                   </Alert>
//                 )}

//                 <Form onSubmit={handleSubmit}>
//                   <Row className="text-muted">
//                     {/* Customer Selection */}
//                     {/* <Col md="6">
//                       <FormGroup>
//                         <Label>Customer *</Label>
//                         {loading ? (
//                           <div className="d-flex align-items-center">
//                             <Spinner size="sm" className="me-2" />
//                             Loading customers...
//                           </div>
//                         ) : customers.length === 0 ? (
//                           <div className="text-danger">
//                             No customers found. Please add a customer first.
//                           </div>
//                         ) : (
//                           <Input
//                             type="select"
//                             name="customer_id"
//                             className="form-control border"
//                             value={formData.customer_id}
//                             onChange={handleInputChange}
//                             required
//                             disabled={submitting || loading}
//                           >
//                             <option value="">Select Customer</option>
//                             {customers.map((customer) => (
//                               <option key={customer.id} value={customer.id}>
//                                 {customer.name}

//                               </option>
//                             ))}
//                           </Input>
//                         )}
//                       </FormGroup>
//                     </Col> */}

//                     {/* <Col md="6">
//                       <FormGroup>
//                         <Label>Customer *</Label>
//                         {loading ? (
//                           <div className="d-flex align-items-center">
//                             <Spinner size="sm" className="me-2" />
//                             Loading customers...
//                           </div>
//                         ) : customers.length === 0 ? (
//                           <div className="text-danger">
//                             No customers found. Please add a customer first.
//                           </div>
//                         ) : (
//                           <div
//                             className="position-relative"
//                             ref={customerDropdownRef}
//                           >
//                             <div
//                               onClick={() =>
//                                 setIsCustomerDropdownOpen(
//                                   !isCustomerDropdownOpen
//                                 )
//                               }
//                               className="flex w-full items-center justify-between shadow-sm cursor-pointer sm:text-sm form-control border"
//                               style={{ minHeight: "38px" }}
//                             >
//                               <span className="truncate max-w-[calc(100%-20px)]">
//                                 {selectedCustomerName || "Select Customer"}
//                               </span>
//                               <span
//                                 className="float-right text-[#3d4247] dark:text-slate-400/70 flex-shrink-0"
//                                 style={{ float: "right", color: "#212529bf" }}
//                               >
//                                 {isCustomerDropdownOpen ? "▲" : "▼"}
//                               </span>
//                             </div>

//                             {isCustomerDropdownOpen && (
//                               <div
//                                 className="dropdown-menu show w-100 mt-1"
//                                 style={{
//                                   maxHeight: "300px",
//                                   overflow: "auto",
//                                   position: "absolute",
//                                   zIndex: 1000,
//                                   backgroundColor: "white",
//                                   border: "1px solid #e5e7eb",
//                                   borderRadius: "0.375rem",
//                                   boxShadow: "0 4px 6px -1px rgb(0 0 0 / 0.1)",
//                                 }}
//                               >
//                                 <input
//                                   type="text"
//                                   value={customerSearchTerm}
//                                   onChange={(e) => {
//                                     setCustomerSearchTerm(e.target.value);
//                                   }}
//                                   placeholder="Search customers..."
//                                   className="w-full border-b border-gray-300 px-3 py-2 text-sm focus:outline-none"
//                                   autoFocus
//                                 />

//                                 <ul className="px-0 max-h-48 overflow-y-auto">
//                                   {filteredCustomers.length > 0 ? (
//                                     <>
//                                       {filteredCustomers.map((customer) => (
//                                         <li
//                                           key={customer.id}
//                                           onClick={() =>
//                                             handleCustomerSelect(
//                                               customer.id,
//                                               customer.name
//                                             )
//                                           }
//                                           className="cursor-pointer px-3 py-2 hover:bg-gray-100"
//                                         >
//                                           <div className="d-flex align-items-center">
//                                             {customer.name}
//                                           </div>
//                                         </li>
//                                       ))}
//                                     </>
//                                   ) : (
//                                     <li className="px-3 py-2 text-gray-500">
//                                       {customerSearchTerm
//                                         ? "No matching customers found"
//                                         : "No customers available"}
//                                     </li>
//                                   )}
//                                 </ul>
//                               </div>
//                             )}

//                             <input
//                               type="hidden"
//                               name="customer_id"
//                               value={formData.customer_id}
//                               required
//                             />
//                           </div>
//                         )}
//                       </FormGroup>
//                     </Col> */}

//                     <Col md="6">
//                       <FormGroup>
//                         <Label>Customer *</Label>
//                         {loading ? (
//                           <div className="d-flex align-items-center">
//                             <Spinner size="sm" className="me-2" />
//                             Loading customers...
//                           </div>
//                         ) : customers.length === 0 ? (
//                           <div className="text-danger">
//                             No customers found. Please add a customer first.
//                           </div>
//                         ) : (
//                           <div
//                             className="position-relative"
//                             ref={customerDropdownRef}
//                           >

//                             <div
//                               onClick={() =>
//                                 setIsCustomerDropdownOpen(
//                                   !isCustomerDropdownOpen
//                                 )
//                               }
//                               className="d-flex w-100 align-items-center justify-content-between cursor-pointer form-control border"
//                               style={{
//                                 minHeight: "38px",
//                                 padding: "0.375rem 0.75rem",
//                                 cursor: "pointer",
//                               }}
//                             >
//                               <span
//                                 className="text-truncate"
//                                 style={{ maxWidth: "calc(100% - 20px)" }}
//                               >
//                                 {selectedCustomerName || "Select Customer"}
//                               </span>
//                               <span
//                                 className="ms-2 text-muted"
//                                 style={{ flexShrink: 0 }}
//                               >
//                                 {isCustomerDropdownOpen ? "▲" : "▼"}
//                               </span>
//                             </div>

//                             {isCustomerDropdownOpen && (
//                               <div
//                                 className="position-absolute w-100 mt-1 bg-white border rounded shadow"
//                                 style={{
//                                   maxHeight: "300px",
//                                   overflow: "auto",
//                                   zIndex: 1050,
//                                 }}
//                               >

//                                 <div className="p-2 border-bottom">
//                                   <Input
//                                     type="text"
//                                     value={customerSearchTerm}
//                                     onChange={(e) => {
//                                       setCustomerSearchTerm(e.target.value);
//                                     }}
//                                     placeholder="Search customers..."
//                                     className="form-control form-control-sm"
//                                     autoFocus
//                                     onClick={(e) => e.stopPropagation()}
//                                   />
//                                 </div>

//                                 <div
//                                   style={{
//                                     maxHeight: "200px",
//                                     overflowY: "auto",
//                                   }}
//                                 >
//                                   {filteredCustomers.length > 0 ? (
//                                     <ul className="list-unstyled mb-0">
//                                       {filteredCustomers.map((customer) => (
//                                         <li
//                                           key={customer.id}
//                                           onClick={() =>
//                                             handleCustomerSelect(
//                                               customer.id,
//                                               customer.name
//                                             )
//                                           }
//                                           className="px-3 py-2 cursor-pointer hover-bg-light"
//                                           style={{ cursor: "pointer" }}
//                                         >
//                                           <div className="d-flex align-items-center">
//                                             {customer.name}
//                                           </div>
//                                         </li>
//                                       ))}
//                                     </ul>
//                                   ) : (
//                                     <div className="px-3 py-2 text-muted">
//                                       {customerSearchTerm
//                                         ? "No matching customers found"
//                                         : "No customers available"}
//                                     </div>
//                                   )}
//                                 </div>
//                               </div>
//                             )}

//                             <input
//                               type="hidden"
//                               name="customer_id"
//                               value={formData.customer_id}
//                               required
//                             />
//                           </div>
//                         )}
//                       </FormGroup>
//                     </Col>

//                     <Col md="6">
//                       <FormGroup>
//                         <Label>Registration Number *</Label>
//                         <Input
//                           type="text"
//                           name="registration_number"
//                           className="form-control"
//                           value={formData.registration_number}
//                           onChange={handleInputChange}
//                           required
//                           placeholder="e.g., ABC123, KL784566"
//                           disabled={submitting}
//                         />
//                       </FormGroup>
//                     </Col>

//                     {/* Vehicle Type - Moved up for better flow */}
//                     <Col md="4">
//                       <FormGroup>
//                         <Label>Vehicle Type *</Label>
//                         <Input
//                           type="select"
//                           name="vehicle_type"
//                           className="form-control border"
//                           value={formData.vehicle_type}
//                           onChange={handleInputChange}
//                           required
//                           disabled={submitting}
//                         >
//                           <option value="">Select Type</option>
//                           {vehicleTypes.map((type) => (
//                             <option key={type.value} value={type.value}>
//                               {type.label}
//                             </option>
//                           ))}
//                         </Input>
//                       </FormGroup>
//                     </Col>

//                     <Col md="4">
//                       <FormGroup>
//                         <Label>Make *</Label>
//                         <Input
//                           type="text"
//                           name="make"
//                           className="form-control"
//                           value={formData.make}
//                           onChange={handleInputChange}
//                           required
//                           placeholder="e.g., Toyota, Honda, Suzuki"
//                           disabled={submitting}
//                         />
//                       </FormGroup>
//                     </Col>

//                     <Col md="4">
//                       <FormGroup>
//                         <Label>Model *</Label>
//                         <Input
//                           type="text"
//                           name="model"
//                           className="form-control"
//                           value={formData.model}
//                           onChange={handleInputChange}
//                           required
//                           placeholder="e.g., Camry, Civic, Swift"
//                           disabled={submitting}
//                         />
//                       </FormGroup>
//                     </Col>

//                     <Col md="4">
//                       <FormGroup>
//                         <Label>Year *</Label>
//                         <Input
//                           type="select"
//                           name="year"
//                           className="form-control border"
//                           value={formData.year}
//                           onChange={handleInputChange}
//                           required
//                           disabled={submitting}
//                         >
//                           <option value="">Select Year</option>
//                           {years.map((year) => (
//                             <option key={year} value={year}>
//                               {year}
//                             </option>
//                           ))}
//                         </Input>
//                       </FormGroup>
//                     </Col>

//                     <Col md="4">
//                       <FormGroup>
//                         <Label>Chassis Number</Label>
//                         <Input
//                           type="text"
//                           name="chassis_number"
//                           className="form-control"
//                           value={formData.chassis_number}
//                           onChange={handleInputChange}
//                           placeholder="Enter chassis number"
//                           disabled={submitting}
//                         />
//                       </FormGroup>
//                     </Col>

//                     <Col md="4">
//                       <FormGroup>
//                         <Label>Engine Number</Label>
//                         <Input
//                           type="text"
//                           name="engine_number"
//                           className="form-control"
//                           value={formData.engine_number}
//                           onChange={handleInputChange}
//                           placeholder="Enter engine number"
//                           disabled={submitting}
//                         />
//                       </FormGroup>
//                     </Col>

//                     <Col md="4">
//                       <FormGroup>
//                         <Label>Current KM Reading</Label>
//                         <Input
//                           type="number"
//                           name="km_reading"
//                           className="form-control"
//                           value={formData.km_reading}
//                           onChange={handleInputChange}
//                           min="0"
//                           step="1"
//                           placeholder="0"
//                           disabled={submitting}
//                         />
//                         <small className="text-muted">
//                           Leave as 0 if unknown
//                         </small>
//                       </FormGroup>
//                     </Col>
//                   </Row>

//                   <div className="d-flex gap-2 mt-4">
//                     <Button
//                       color="primary"
//                       type="submit"
//                       disabled={submitting || loading || customers.length === 0}
//                       className="d-flex align-items-center"
//                     >
//                       {submitting ? (
//                         <>
//                           <Spinner size="sm" className="me-2" />
//                           {isEditMode
//                             ? "Updating Vehicle..."
//                             : "Adding Vehicle..."}
//                         </>
//                       ) : (
//                         <>
//                           <i className="fa fa-save me-2"></i>
//                           {isEditMode ? "Update Vehicle" : "Add Vehicle"}
//                         </>
//                       )}
//                     </Button>
//                     <Link href="/admin/vehicles">
//                       <Button
//                         color="secondary"
//                         type="button"
//                         disabled={submitting}
//                       >
//                         Cancel
//                       </Button>
//                     </Link>

//                     {customers.length === 0 && !loading && (
//                       <Link href="/admin/customers/add" className="ms-auto">
//                         <Button color="info" type="button">
//                           <i className="fa fa-plus me-2"></i>
//                           Add Customer First
//                         </Button>
//                       </Link>
//                     )}
//                   </div>
//                 </Form>
//               </CardBody>
//             </Card>
//           </Col>
//         </Row>
//       </Container>

//       <style jsx>{`
//         .form-control:disabled {
//           background-color: #e9ecef;
//           opacity: 1;
//         }

//         .text-muted {
//           font-size: 0.875rem;
//         }
//       `}</style>
//     </div>
//   );
// }

// export default AddVehiclePage;

// "use client";
// import Breadcrumbs from "@/CommonElements/Breadcrumbs";
// import {
//   Container,
//   Row,
//   Col,
//   Card,
//   CardBody,
//   Form,
//   FormGroup,
//   Label,
//   Input,
//   Button,
//   Spinner,
//   Alert,
// } from "reactstrap";
// import React, { useState, ChangeEvent, useEffect, useRef } from "react";
// import Link from "next/link";
// import { useRouter, useSearchParams } from "next/navigation";
// import { useAuth } from "@/helper/AuthContext";
// import { toast } from "react-toastify";

// // Customer Type based on API response
// interface Customer {
//   id: string;
//   name: string;
//   contact_phone?: string;
//   email?: string;
//   address?: string;
//   status?: string;
//   gst_number?: string | null;
//   meta?: string;
//   created_at?: string;
//   updated_at?: string;
// }

// interface ApiResponse {
//   data: Customer[];
// }

// const vehicleTypes = [
//   { value: "car", label: "Car" },
//   { value: "bike", label: "Bike" },
//   { value: "suv", label: "SUV" },
//   { value: "truck", label: "Truck" },
//   { value: "van", label: "Van" },
//   { value: "bus", label: "Bus" },
//   { value: "other", label: "Other" },
// ];

// function AddVehiclePage() {
//   const { state } = useAuth();
//   const router = useRouter();
//   const [customers, setCustomers] = useState<Customer[]>([]);
//   const [loading, setLoading] = useState(true);
//   const [submitting, setSubmitting] = useState(false);
//   const [error, setError] = useState<string | null>(null);

//   // for edit vehicle
//   const searchParams = useSearchParams();
//   const vehicleId = searchParams.get("id");
//   const [isEditMode, setIsEditMode] = useState(false);

//   // Customer dropdown state
//   const [customerSearchTerm, setCustomerSearchTerm] = useState("");
//   const [isCustomerDropdownOpen, setIsCustomerDropdownOpen] = useState(false);
//   const [selectedCustomerName, setSelectedCustomerName] = useState("");
//   const customerDropdownRef = useRef<HTMLDivElement | null>(null);

//   const [yearSearchTerm, setYearSearchTerm] = useState("");
//   const [isYearDropdownOpen, setIsYearDropdownOpen] = useState(false);
//   const yearDropdownRef = useRef<HTMLDivElement | null>(null);

//   const [formData, setFormData] = useState({
//     customer_id: "",
//     vehicle_type: "",
//     make: "",
//     model: "",
//     year: "",
//     registration_number: "",
//     chassis_number: "",
//     engine_number: "",
//     km_reading: "0",
//   });

//   // Fetch customers from API
//   useEffect(() => {
//     const fetchCustomers = async () => {
//       try {
//         setLoading(true);
//         setError(null);

//         const token = state?.accessToken || localStorage.getItem("token");
//         if (!token) {
//           toast.error("Authentication required. Please login again.");
//           router.push("/login");
//           return;
//         }

//         const response = await fetch("/api/customers_list", {
//           method: "GET",
//           headers: {
//             Authorization: `Bearer ${token}`,
//             "Content-Type": "application/json",
//           },
//         });

//         if (!response.ok) {
//           throw new Error(`Failed to fetch customers: ${response.status}`);
//         }

//         const data: ApiResponse = await response.json();
//         setCustomers(data.data || []);
//       } catch (err) {
//         console.error("Error fetching customers:", err);
//         setError(
//           err instanceof Error ? err.message : "Failed to load customers"
//         );
//         toast.error("Failed to load customers");
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchCustomers();
//   }, []);

//   // Update selected customer name when customers are loaded and formData.customer_id exists
//   useEffect(() => {
//     if (formData.customer_id && customers.length > 0) {
//       const customer = customers.find((c) => c.id === formData.customer_id);
//       if (customer) {
//         setSelectedCustomerName(customer.name);
//       }
//     }
//   }, [customers, formData.customer_id]);

//   // Close dropdown when clicking outside
//   useEffect(() => {
//     const handleClickOutside = (event: MouseEvent) => {
//       if (
//         customerDropdownRef.current &&
//         !customerDropdownRef.current.contains(event.target as Node)
//       ) {
//         setIsCustomerDropdownOpen(false);
//       }
//       // Close year dropdown
//       if (
//         yearDropdownRef.current &&
//         !yearDropdownRef.current.contains(event.target as Node)
//       ) {
//         setIsYearDropdownOpen(false);
//       }
//     };

//     document.addEventListener("mousedown", handleClickOutside);
//     return () => {
//       document.removeEventListener("mousedown", handleClickOutside);
//     };
//   }, []);

//   const handleInputChange = (
//     e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
//   ) => {
//     const { name, value } = e.target;
//     setFormData((prev) => ({
//       ...prev,
//       [name]: value,
//     }));
//   };

//   // Handle customer selection
//   const handleCustomerSelect = (customerId: string, customerName: string) => {
//     setFormData((prev) => ({
//       ...prev,
//       customer_id: customerId,
//     }));
//     setSelectedCustomerName(customerName);
//     setIsCustomerDropdownOpen(false);
//     setCustomerSearchTerm("");
//   };

//   // Handle year selection
//   const handleYearSelect = (year: string) => {
//     setFormData((prev) => ({
//       ...prev,
//       year: year,
//     }));
//     setIsYearDropdownOpen(false);
//     setYearSearchTerm("");
//   };

//   // Filter customers based on search term
//   const filteredCustomers = customers.filter((customer) =>
//     customer.name.toLowerCase().includes(customerSearchTerm.toLowerCase())
//   );

//   // Generate years from 1900 to current year + 1
//   const currentYear = new Date().getFullYear();
//   const years = Array.from(
//     { length: currentYear - 1899 },
//     (_, i) => currentYear + 1 - i
//   );

//   // Filter years based on search term
//   const filteredYears = yearSearchTerm
//     ? years.filter((year) => year.toString().includes(yearSearchTerm))
//     : years;

//   const handleSubmit = async (e: React.FormEvent) => {
//     e.preventDefault();

//     // Validate required fields
//     const requiredFields = [
//       "customer_id",
//       "registration_number",
//       "make",
//       "model",
//       "year",
//       "vehicle_type",
//     ];

//     const missingFields = requiredFields.filter(
//       (field) => !formData[field as keyof typeof formData]
//     );

//     if (missingFields.length > 0) {
//       toast.error(
//         `Please fill all required fields: ${missingFields.join(", ")}`
//       );
//       return;
//     }

//     // Validate year is a valid number
//     const yearNum = parseInt(formData.year);
//     if (
//       isNaN(yearNum) ||
//       yearNum < 1900 ||
//       yearNum > new Date().getFullYear() + 1
//     ) {
//       toast.error("Please enter a valid year");
//       return;
//     }

//     // Validate vehicle type is from allowed list
//     const validVehicleTypes = vehicleTypes.map((vt) => vt.value);
//     if (!validVehicleTypes.includes(formData.vehicle_type)) {
//       toast.error("Please select a valid vehicle type");
//       return;
//     }

//     try {
//       setSubmitting(true);
//       setError(null);

//       // Prepare data for API - ensure all fields match API expectations
//       const vehicleData = {
//         customer_id: formData.customer_id,
//         vehicle_type: formData.vehicle_type,
//         make: formData.make,
//         model: formData.model,
//         year: formData.year,
//         registration_number: formData.registration_number,
//         chassis_number: formData.chassis_number || null,
//         engine_number: formData.engine_number || null,
//         km_reading: formData.km_reading || "0",
//       };

//       console.log("Submitting vehicle data:", vehicleData);

//       let method;
//       let url;

//       if (isEditMode && vehicleId) {
//         method = "PUT";
//         url = `/api/vehicles/${vehicleId}`;
//       } else {
//         method = "POST";
//         url = "/api/vehicles";
//       }

//       const response = await fetch(url, {
//         method,
//         headers: {
//           "Content-Type": "application/json",
//           Authorization: `Bearer ${
//             state?.accessToken ?? (localStorage.getItem("token") || "")
//           }`,
//         },
//         body: JSON.stringify(vehicleData),
//       });

//       const result = await response.json();

//       if (!response.ok) {
//         // Handle validation errors from API
//         if (result.errors) {
//           const errorMessages = Object.values(result.errors).flat().join(", ");
//           throw new Error(errorMessages);
//         }
//         throw new Error(
//           result.message ||
//             `Failed to ${isEditMode ? "Update" : "Add"} vehicle: ${
//               response.status
//             }`
//         );
//       }

//       console.log(
//         `Vehicle ${isEditMode ? "updated" : "added"} successfully:`,
//         result
//       );

//       toast.success(
//         result.message ||
//           `Vehicle ${isEditMode ? "Updated" : "Added"} Successfully`
//       );

//       // Redirect after successful submission
//       setTimeout(() => {
//         router.push("/admin/vehicles");
//       }, 1000);
//     } catch (err) {
//       console.error(
//         `Error ${isEditMode ? "updating" : "adding"} vehicle:`,
//         err
//       );

//       const errorMessage =
//         err instanceof Error
//           ? err.message
//           : `Failed to ${
//               isEditMode ? "update" : "add"
//             } vehicle. Please try again.`;
//       setError(errorMessage);
//       toast.error(errorMessage);
//     } finally {
//       setSubmitting(false);
//     }
//   };

//   // Fetch vehicle data for edit mode
//   useEffect(() => {
//     if (vehicleId) {
//       setIsEditMode(true);
//       fetchVehicleData(vehicleId);
//     }
//   }, [vehicleId]);

//   const fetchVehicleData = async (id: string) => {
//     try {
//       setLoading(true);

//       const token = state?.accessToken || localStorage.getItem("token");
//       const response = await fetch(`/api/vehicles/${id}`, {
//         method: "GET",
//         headers: {
//           Authorization: `Bearer ${token}`,
//           "Content-Type": "application/json",
//         },
//       });

//       if (!response.ok) {
//         throw new Error(`Failed to fetch vehicle: ${response.status}`);
//       }

//       const data = await response.json();
//       console.log("Fetched vehicle data:", data);

//       if (data.data) {
//         setFormData({
//           customer_id: data.data.customer_id || "",
//           vehicle_type: data.data.vehicle_type || "",
//           make: data.data.make || "",
//           model: data.data.model || "",
//           year: data.data.year || "",
//           registration_number: data.data.registration_number || "",
//           chassis_number: data.data.chassis_number || "",
//           engine_number: data.data.engine_number || "",
//           km_reading: data.data.km_reading || "0",
//         });

//         // We'll set the customer name in the useEffect that watches customers and formData.customer_id
//       }
//     } catch (error) {
//       console.error("Error Fetching Vehicle Data", error);
//       toast.error("Failed to load vehicle data");
//     } finally {
//       setLoading(false);
//     }
//   };

//   return (
//     <div className="page-body">
//       <Breadcrumbs
//         title={isEditMode ? "Edit Vehicle" : "Add Vehicle"}
//         mainTitle={isEditMode ? "Edit Vehicle" : "Add New Vehicle"}
//         parent="Vehicles"
//       />

//       <Container fluid>
//         <Row>
//           <Col sm="12">
//             <Card>
//               <CardBody>
//                 {/* Error Alert */}
//                 {error && (
//                   <Alert color="danger" className="mb-4">
//                     <h5 className="alert-heading">Error</h5>
//                     <p>{error}</p>
//                   </Alert>
//                 )}

//                 <Form onSubmit={handleSubmit}>
//                   <Row className="text-muted">
//                     {/* Customer Selection - Searchable Dropdown */}
//                     <Col md="6">
//                       <FormGroup>
//                         <Label>Customer *</Label>
//                         {loading ? (
//                           <div className="d-flex align-items-center">
//                             <Spinner size="sm" className="me-2" />
//                             Loading customers...
//                           </div>
//                         ) : customers.length === 0 ? (
//                           <div className="text-danger">
//                             No customers found. Please add a customer first.
//                           </div>
//                         ) : (
//                           <div
//                             className="position-relative"
//                             ref={customerDropdownRef}
//                           >
//                             {/* Dropdown trigger */}
//                             <div
//                               onClick={() =>
//                                 setIsCustomerDropdownOpen(
//                                   !isCustomerDropdownOpen
//                                 )
//                               }
//                               className="d-flex w-100 align-items-center justify-content-between cursor-pointer form-control border"
//                               style={{
//                                 minHeight: "38px",
//                                 padding: "0.375rem 0.75rem",
//                                 cursor: "pointer",
//                               }}
//                             >
//                               <span
//                                 className="text-truncate"
//                                 style={{ maxWidth: "calc(100% - 20px)" }}
//                               >
//                                 {selectedCustomerName || "Select Customer"}
//                               </span>
//                               <span
//                                 className="ms-2 text-muted"
//                                 style={{ flexShrink: 0 }}
//                               >
//                                 {isCustomerDropdownOpen ? "▲" : "▼"}
//                               </span>
//                             </div>

//                             {/* Dropdown menu */}
//                             {isCustomerDropdownOpen && (
//                               <div
//                                 className="position-absolute w-100 mt-1 bg-white border rounded shadow"
//                                 style={{
//                                   maxHeight: "300px",
//                                   overflow: "auto",
//                                   zIndex: 1050,
//                                 }}
//                               >
//                                 {/* Search input */}
//                                 <div className="p-2 border-bottom">
//                                   <Input
//                                     type="text"
//                                     value={customerSearchTerm}
//                                     onChange={(e) => {
//                                       setCustomerSearchTerm(e.target.value);
//                                     }}
//                                     placeholder="Search customers..."
//                                     className="form-control form-control-sm"
//                                     autoFocus
//                                     onClick={(e) => e.stopPropagation()}
//                                   />
//                                 </div>

//                                 {/* Customer list */}
//                                 <div
//                                   style={{
//                                     maxHeight: "200px",
//                                     overflowY: "auto",
//                                   }}
//                                 >
//                                   {filteredCustomers.length > 0 ? (
//                                     <ul className="list-unstyled mb-0">
//                                       {filteredCustomers.map((customer) => (
//                                         <li
//                                           key={customer.id}
//                                           onClick={() =>
//                                             handleCustomerSelect(
//                                               customer.id,
//                                               customer.name
//                                             )
//                                           }
//                                           className="px-3 py-2 cursor-pointer hover-bg-light"
//                                           style={{ cursor: "pointer" }}
//                                         >
//                                           <div className="d-flex align-items-center">
//                                             {customer.name}
//                                             {formData.customer_id ===
//                                               customer.id && (
//                                               <span className="ms-2 badge bg-primary">
//                                                 Selected
//                                               </span>
//                                             )}
//                                           </div>
//                                         </li>
//                                       ))}
//                                     </ul>
//                                   ) : (
//                                     <div className="px-3 py-2 text-muted">
//                                       {customerSearchTerm
//                                         ? "No matching customers found"
//                                         : "No customers available"}
//                                     </div>
//                                   )}
//                                 </div>
//                               </div>
//                             )}

//                             {/* Hidden input for form submission */}
//                             <input
//                               type="hidden"
//                               name="customer_id"
//                               value={formData.customer_id}
//                               required
//                             />
//                           </div>
//                         )}
//                       </FormGroup>
//                     </Col>

//                     <Col md="6">
//                       <FormGroup>
//                         <Label>Registration Number *</Label>
//                         <Input
//                           type="text"
//                           name="registration_number"
//                           className="form-control"
//                           value={formData.registration_number}
//                           onChange={handleInputChange}
//                           required
//                           placeholder="e.g., ABC123, KL784566"
//                           disabled={submitting}
//                         />
//                       </FormGroup>
//                     </Col>

//                     {/* Vehicle Type */}
//                     <Col md="4">
//                       <FormGroup>
//                         <Label>Vehicle Type *</Label>
//                         <Input
//                           type="select"
//                           name="vehicle_type"
//                           className="form-control border"
//                           value={formData.vehicle_type}
//                           onChange={handleInputChange}
//                           required
//                           disabled={submitting}
//                         >
//                           <option value="">Select Type</option>
//                           {vehicleTypes.map((type) => (
//                             <option key={type.value} value={type.value}>
//                               {type.label}
//                             </option>
//                           ))}
//                         </Input>
//                       </FormGroup>
//                     </Col>

//                     <Col md="4">
//                       <FormGroup>
//                         <Label>Make *</Label>
//                         <Input
//                           type="text"
//                           name="make"
//                           className="form-control"
//                           value={formData.make}
//                           onChange={handleInputChange}
//                           required
//                           placeholder="e.g., Toyota, Honda, Suzuki"
//                           disabled={submitting}
//                         />
//                       </FormGroup>
//                     </Col>

//                     <Col md="4">
//                       <FormGroup>
//                         <Label>Model *</Label>
//                         <Input
//                           type="text"
//                           name="model"
//                           className="form-control"
//                           value={formData.model}
//                           onChange={handleInputChange}
//                           required
//                           placeholder="e.g., Camry, Civic, Swift"
//                           disabled={submitting}
//                         />
//                       </FormGroup>
//                     </Col>

//                     {/* <Col md="4">
//                       <FormGroup>
//                         <Label>Year *</Label>
//                         <Input
//                           type="select"
//                           name="year"
//                           className="form-control border"
//                           value={formData.year}
//                           onChange={handleInputChange}
//                           required
//                           disabled={submitting}
//                         >
//                           <option value="">Select Year</option>
//                           {years.map((year) => (
//                             <option key={year} value={year}>
//                               {year}
//                             </option>
//                           ))}
//                         </Input>
//                       </FormGroup>
//                     </Col> */}
//                     {/* Year Selection - Searchable Dropdown */}
//                     <Col md="4">
//                       <FormGroup>
//                         <Label>Year *</Label>
//                         <div
//                           className="position-relative"
//                           ref={yearDropdownRef}
//                         >
//                           {/* Dropdown trigger */}
//                           <div
//                             onClick={() =>
//                               setIsYearDropdownOpen(!isYearDropdownOpen)
//                             }
//                             className="d-flex w-100 align-items-center justify-content-between cursor-pointer form-control border"
//                             style={{
//                               minHeight: "38px",
//                               padding: "0.375rem 0.75rem",
//                               cursor: "pointer",
//                             }}
//                           >
//                             <span
//                               className="text-truncate"
//                               style={{ maxWidth: "calc(100% - 20px)" }}
//                             >
//                               {formData.year || "Select Year"}
//                             </span>
//                             <span
//                               className="ms-2 text-muted"
//                               style={{ flexShrink: 0 }}
//                             >
//                               {isYearDropdownOpen ? "▲" : "▼"}
//                             </span>
//                           </div>

//                           {/* Dropdown menu */}
//                           {isYearDropdownOpen && (
//                             <div
//                               className="position-absolute w-100 mt-1 bg-white border rounded shadow"
//                               style={{
//                                 maxHeight: "300px",
//                                 overflow: "auto",
//                                 zIndex: 1050,
//                               }}
//                             >
//                               {/* Search input */}
//                               <div className="p-2 border-bottom">
//                                 <Input
//                                   type="text"
//                                   value={yearSearchTerm}
//                                   onChange={(e) => {
//                                     setYearSearchTerm(e.target.value);
//                                   }}
//                                   placeholder="Search year..."
//                                   className="form-control form-control-sm"
//                                   autoFocus
//                                   onClick={(e) => e.stopPropagation()}
//                                 />
//                               </div>

//                               {/* Year list */}
//                               <div
//                                 style={{
//                                   maxHeight: "200px",
//                                   overflowY: "auto",
//                                 }}
//                               >
//                                 {filteredYears.length > 0 ? (
//                                   <ul className="list-unstyled mb-0">
//                                     {filteredYears.map((year) => (
//                                       <li
//                                         key={year}
//                                         onClick={() =>
//                                           handleYearSelect(year.toString())
//                                         }
//                                         className="px-3 py-2 cursor-pointer hover-bg-light"
//                                         style={{ cursor: "pointer" }}
//                                       >
//                                         <div className="d-flex align-items-center justify-content-between">
//                                           <span>{year}</span>
//                                           {formData.year ===
//                                             year.toString() && (
//                                             <span className="ms-2 badge bg-primary">
//                                               Selected
//                                             </span>
//                                           )}
//                                         </div>
//                                       </li>
//                                     ))}
//                                   </ul>
//                                 ) : (
//                                   <div className="px-3 py-2 text-muted">
//                                     {yearSearchTerm
//                                       ? "No matching years found"
//                                       : "No years available"}
//                                   </div>
//                                 )}
//                               </div>
//                             </div>
//                           )}

//                           {/* Hidden input for form submission */}
//                           <input
//                             type="hidden"
//                             name="year"
//                             value={formData.year}
//                             required
//                           />
//                         </div>
//                       </FormGroup>
//                     </Col>

//                     <Col md="4">
//                       <FormGroup>
//                         <Label>Chassis Number</Label>
//                         <Input
//                           type="text"
//                           name="chassis_number"
//                           className="form-control"
//                           value={formData.chassis_number}
//                           onChange={handleInputChange}
//                           placeholder="Enter chassis number"
//                           disabled={submitting}
//                         />
//                       </FormGroup>
//                     </Col>

//                     <Col md="4">
//                       <FormGroup>
//                         <Label>Engine Number</Label>
//                         <Input
//                           type="text"
//                           name="engine_number"
//                           className="form-control"
//                           value={formData.engine_number}
//                           onChange={handleInputChange}
//                           placeholder="Enter engine number"
//                           disabled={submitting}
//                         />
//                       </FormGroup>
//                     </Col>

//                     <Col md="4">
//                       <FormGroup>
//                         <Label>Current KM Reading</Label>
//                         <Input
//                           type="number"
//                           name="km_reading"
//                           className="form-control"
//                           value={formData.km_reading}
//                           onChange={handleInputChange}
//                           min="0"
//                           step="1"
//                           placeholder="0"
//                           disabled={submitting}
//                         />
//                         <small className="text-muted">
//                           Leave as 0 if unknown
//                         </small>
//                       </FormGroup>
//                     </Col>
//                   </Row>

//                   <div className="d-flex gap-2 mt-4">
//                     <Button
//                       color="primary"
//                       type="submit"
//                       disabled={submitting || loading || customers.length === 0}
//                       className="d-flex align-items-center"
//                     >
//                       {submitting ? (
//                         <>
//                           <Spinner size="sm" className="me-2" />
//                           {isEditMode
//                             ? "Updating Vehicle..."
//                             : "Adding Vehicle..."}
//                         </>
//                       ) : (
//                         <>
//                           <i className="fa fa-save me-2"></i>
//                           {isEditMode ? "Update Vehicle" : "Add Vehicle"}
//                         </>
//                       )}
//                     </Button>
//                     <Link href="/admin/vehicles">
//                       <Button
//                         color="secondary"
//                         type="button"
//                         disabled={submitting}
//                       >
//                         Cancel
//                       </Button>
//                     </Link>

//                     {customers.length === 0 && !loading && (
//                       <Link href="/admin/customers/add" className="ms-auto">
//                         <Button color="info" type="button">
//                           <i className="fa fa-plus me-2"></i>
//                           Add Customer First
//                         </Button>
//                       </Link>
//                     )}
//                   </div>
//                 </Form>
//               </CardBody>
//             </Card>
//           </Col>
//         </Row>
//       </Container>

//       <style jsx>{`
//         .form-control:disabled {
//           background-color: #e9ecef;
//           opacity: 1;
//         }

//         .text-muted {
//           font-size: 0.875rem;
//         }

//         .cursor-pointer {
//           cursor: pointer;
//         }

//         .text-truncate {
//           overflow: hidden;
//           text-overflow: ellipsis;
//           white-space: nowrap;
//         }

//         .hover-bg-light:hover {
//           background-color: #f8f9fa;
//         }
//       `}</style>
//     </div>
//   );
// }

// export default AddVehiclePage;

// with add customer modal
// "use client";
// import Breadcrumbs from "@/CommonElements/Breadcrumbs";
// import {
//   Container,
//   Row,
//   Col,
//   Card,
//   CardBody,
//   Form,
//   FormGroup,
//   Label,
//   Input,
//   Button,
//   Spinner,
//   Alert,
//   Modal,
//   ModalHeader,
//   ModalBody,
//   ModalFooter,
// } from "reactstrap";
// import React, { useState, ChangeEvent, useEffect, useRef } from "react";
// import Link from "next/link";
// import { useRouter, useSearchParams } from "next/navigation";
// import { useAuth } from "@/helper/AuthContext";
// import { toast } from "react-toastify";

// // Customer Type based on API response
// interface Customer {
//   id: string;
//   name: string;
//   contact_phone?: string;
//   email?: string;
//   address?: string;
//   status?: string;
//   gst_number?: string | null;
//   meta?: string;
//   created_at?: string;
//   updated_at?: string;
// }

// interface ApiResponse {
//   data: Customer[];
// }

// const vehicleTypes = [
//   { value: "car", label: "Car" },
//   { value: "bike", label: "Bike" },
//   { value: "suv", label: "SUV" },
//   { value: "truck", label: "Truck" },
//   { value: "van", label: "Van" },
//   { value: "bus", label: "Bus" },
//   { value: "other", label: "Other" },
// ];

// function AddVehiclePage() {
//   const { state } = useAuth();
//   const router = useRouter();
//   const [customers, setCustomers] = useState<Customer[]>([]);
//   const [loading, setLoading] = useState(true);
//   const [submitting, setSubmitting] = useState(false);
//   const [error, setError] = useState<string | null>(null);

//   // for edit vehicle
//   const searchParams = useSearchParams();
//   const vehicleId = searchParams.get("id");
//   const [isEditMode, setIsEditMode] = useState(false);

//   // Customer dropdown state
//   const [customerSearchTerm, setCustomerSearchTerm] = useState("");
//   const [isCustomerDropdownOpen, setIsCustomerDropdownOpen] = useState(false);
//   const [selectedCustomerName, setSelectedCustomerName] = useState("");
//   const customerDropdownRef = useRef<HTMLDivElement | null>(null);

//   // Year dropdown state
//   const [yearSearchTerm, setYearSearchTerm] = useState("");
//   const [isYearDropdownOpen, setIsYearDropdownOpen] = useState(false);
//   const yearDropdownRef = useRef<HTMLDivElement | null>(null);

//   // Add customer modal state
//   const [showAddCustomerModal, setShowAddCustomerModal] = useState(false);
//   const [addingCustomer, setAddingCustomer] = useState(false);
//   const [newCustomerData, setNewCustomerData] = useState({
//     name: "",
//     contact_phone: "",
//     email: "",
//     address: "",
//   });

//   const [formData, setFormData] = useState({
//     customer_id: "",
//     vehicle_type: "",
//     make: "",
//     model: "",
//     year: "",
//     registration_number: "",
//     chassis_number: "",
//     engine_number: "",
//     km_reading: "0",
//   });

//   // Fetch customers from API
//   const fetchCustomers = async () => {
//     try {
//       setLoading(true);
//       setError(null);

//       const token = state?.accessToken || localStorage.getItem("token");
//       if (!token) {
//         toast.error("Authentication required. Please login again.");
//         router.push("/login");
//         return;
//       }

//       const response = await fetch("/api/customers_list", {
//         method: "GET",
//         headers: {
//           Authorization: `Bearer ${token}`,
//           "Content-Type": "application/json",
//         },
//       });

//       if (!response.ok) {
//         throw new Error(`Failed to fetch customers: ${response.status}`);
//       }

//       const data: ApiResponse = await response.json();
//       setCustomers(data.data || []);
//     } catch (err) {
//       console.error("Error fetching customers:", err);
//       setError(err instanceof Error ? err.message : "Failed to load customers");
//       toast.error("Failed to load customers");
//     } finally {
//       setLoading(false);
//     }
//   };

//   useEffect(() => {
//     fetchCustomers();
//   }, []);

//   // Update selected customer name when customers are loaded and formData.customer_id exists
//   useEffect(() => {
//     if (formData.customer_id && customers.length > 0) {
//       const customer = customers.find((c) => c.id === formData.customer_id);
//       if (customer) {
//         setSelectedCustomerName(customer.name);
//       }
//     }
//   }, [customers, formData.customer_id]);

//   // Close dropdown when clicking outside
//   useEffect(() => {
//     const handleClickOutside = (event: MouseEvent) => {
//       if (
//         customerDropdownRef.current &&
//         !customerDropdownRef.current.contains(event.target as Node)
//       ) {
//         setIsCustomerDropdownOpen(false);
//       }
//       // Close year dropdown
//       if (
//         yearDropdownRef.current &&
//         !yearDropdownRef.current.contains(event.target as Node)
//       ) {
//         setIsYearDropdownOpen(false);
//       }
//     };

//     document.addEventListener("mousedown", handleClickOutside);
//     return () => {
//       document.removeEventListener("mousedown", handleClickOutside);
//     };
//   }, []);

//   const handleInputChange = (
//     e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
//   ) => {
//     const { name, value } = e.target;
//     setFormData((prev) => ({
//       ...prev,
//       [name]: value,
//     }));
//   };

//   // Handle new customer input change
//   const handleNewCustomerInputChange = (
//     e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
//   ) => {
//     const { name, value } = e.target;
//     setNewCustomerData((prev) => ({
//       ...prev,
//       [name]: value,
//     }));
//   };

//   // Handle customer selection
//   const handleCustomerSelect = (customerId: string, customerName: string) => {
//     setFormData((prev) => ({
//       ...prev,
//       customer_id: customerId,
//     }));
//     setSelectedCustomerName(customerName);
//     setIsCustomerDropdownOpen(false);
//     setCustomerSearchTerm("");
//   };

//   // Handle year selection
//   const handleYearSelect = (year: string) => {
//     setFormData((prev) => ({
//       ...prev,
//       year: year,
//     }));
//     setIsYearDropdownOpen(false);
//     setYearSearchTerm("");
//   };

//   // Handle add new customer
//   const handleAddNewCustomer = async () => {
//     // Validate required fields
//     if (!newCustomerData.name.trim()) {
//       toast.error("Customer name is required");
//       return;
//     }

//     try {
//       setAddingCustomer(true);
//       const token = state?.accessToken || localStorage.getItem("token");

//       const response = await fetch("/api/customers", {
//         method: "POST",
//         headers: {
//           "Content-Type": "application/json",
//           Authorization: `Bearer ${token}`,
//         },
//         body: JSON.stringify({
//           name: newCustomerData.name,
//           contact_phone: newCustomerData.contact_phone || null,
//           email: newCustomerData.email || null,
//           address: newCustomerData.address || null,
//           status: "active",
//         }),
//       });

//       const result = await response.json();

//       if (!response.ok) {
//         throw new Error(result.message || "Failed to add customer");
//       }

//       toast.success("Customer added successfully!");

//       // Close modal and reset form
//       setShowAddCustomerModal(false);
//       setNewCustomerData({
//         name: "",
//         contact_phone: "",
//         email: "",
//         address: "",
//       });

//       // Refresh customers list
//       await fetchCustomers();

//       // Auto-select the newly added customer
//       if (result.data && result.data.id) {
//         setFormData((prev) => ({
//           ...prev,
//           customer_id: result.data.id,
//         }));
//         setSelectedCustomerName(result.data.name);
//       }
//     } catch (err) {
//       console.error("Error adding customer:", err);
//       toast.error(
//         err instanceof Error ? err.message : "Failed to add customer"
//       );
//     } finally {
//       setAddingCustomer(false);
//     }
//   };

//   // Filter customers based on search term
//   const filteredCustomers = customers.filter((customer) =>
//     customer.name.toLowerCase().includes(customerSearchTerm.toLowerCase())
//   );

//   // Generate years from 1900 to current year + 1
//   const currentYear = new Date().getFullYear();
//   const years = Array.from(
//     { length: currentYear - 1899 },
//     (_, i) => currentYear + 1 - i
//   );

//   // Filter years based on search term
//   const filteredYears = yearSearchTerm
//     ? years.filter((year) => year.toString().includes(yearSearchTerm))
//     : years;

//   const handleSubmit = async (e: React.FormEvent) => {
//     e.preventDefault();

//     // Validate required fields
//     const requiredFields = [
//       "customer_id",
//       "registration_number",
//       "make",
//       "model",
//       "year",
//       "vehicle_type",
//     ];

//     const missingFields = requiredFields.filter(
//       (field) => !formData[field as keyof typeof formData]
//     );

//     if (missingFields.length > 0) {
//       toast.error(
//         `Please fill all required fields: ${missingFields.join(", ")}`
//       );
//       return;
//     }

//     // Validate year is a valid number
//     const yearNum = parseInt(formData.year);
//     if (
//       isNaN(yearNum) ||
//       yearNum < 1900 ||
//       yearNum > new Date().getFullYear() + 1
//     ) {
//       toast.error("Please enter a valid year");
//       return;
//     }

//     // Validate vehicle type is from allowed list
//     const validVehicleTypes = vehicleTypes.map((vt) => vt.value);
//     if (!validVehicleTypes.includes(formData.vehicle_type)) {
//       toast.error("Please select a valid vehicle type");
//       return;
//     }

//     try {
//       setSubmitting(true);
//       setError(null);

//       // Prepare data for API - ensure all fields match API expectations
//       const vehicleData = {
//         customer_id: formData.customer_id,
//         vehicle_type: formData.vehicle_type,
//         make: formData.make,
//         model: formData.model,
//         year: formData.year,
//         registration_number: formData.registration_number,
//         chassis_number: formData.chassis_number || null,
//         engine_number: formData.engine_number || null,
//         km_reading: formData.km_reading || "0",
//       };

//       console.log("Submitting vehicle data:", vehicleData);

//       let method;
//       let url;

//       if (isEditMode && vehicleId) {
//         method = "PUT";
//         url = `/api/vehicles/${vehicleId}`;
//       } else {
//         method = "POST";
//         url = "/api/vehicles";
//       }

//       const response = await fetch(url, {
//         method,
//         headers: {
//           "Content-Type": "application/json",
//           Authorization: `Bearer ${
//             state?.accessToken ?? (localStorage.getItem("token") || "")
//           }`,
//         },
//         body: JSON.stringify(vehicleData),
//       });

//       const result = await response.json();

//       if (!response.ok) {
//         // Handle validation errors from API
//         if (result.errors) {
//           const errorMessages = Object.values(result.errors).flat().join(", ");
//           throw new Error(errorMessages);
//         }
//         throw new Error(
//           result.message ||
//             `Failed to ${isEditMode ? "Update" : "Add"} vehicle: ${
//               response.status
//             }`
//         );
//       }

//       console.log(
//         `Vehicle ${isEditMode ? "updated" : "added"} successfully:`,
//         result
//       );

//       toast.success(
//         result.message ||
//           `Vehicle ${isEditMode ? "Updated" : "Added"} Successfully`
//       );

//       // Redirect after successful submission
//       setTimeout(() => {
//         router.push("/admin/vehicles");
//       }, 1000);
//     } catch (err) {
//       console.error(
//         `Error ${isEditMode ? "updating" : "adding"} vehicle:`,
//         err
//       );

//       const errorMessage =
//         err instanceof Error
//           ? err.message
//           : `Failed to ${
//               isEditMode ? "update" : "add"
//             } vehicle. Please try again.`;
//       setError(errorMessage);
//       toast.error(errorMessage);
//     } finally {
//       setSubmitting(false);
//     }
//   };

//   // Fetch vehicle data for edit mode
//   useEffect(() => {
//     if (vehicleId) {
//       setIsEditMode(true);
//       fetchVehicleData(vehicleId);
//     }
//   }, [vehicleId]);

//   const fetchVehicleData = async (id: string) => {
//     try {
//       setLoading(true);

//       const token = state?.accessToken || localStorage.getItem("token");
//       const response = await fetch(`/api/vehicles/${id}`, {
//         method: "GET",
//         headers: {
//           Authorization: `Bearer ${token}`,
//           "Content-Type": "application/json",
//         },
//       });

//       if (!response.ok) {
//         throw new Error(`Failed to fetch vehicle: ${response.status}`);
//       }

//       const data = await response.json();
//       console.log("Fetched vehicle data:", data);

//       if (data.data) {
//         setFormData({
//           customer_id: data.data.customer_id || "",
//           vehicle_type: data.data.vehicle_type || "",
//           make: data.data.make || "",
//           model: data.data.model || "",
//           year: data.data.year || "",
//           registration_number: data.data.registration_number || "",
//           chassis_number: data.data.chassis_number || "",
//           engine_number: data.data.engine_number || "",
//           km_reading: data.data.km_reading || "0",
//         });
//       }
//     } catch (error) {
//       console.error("Error Fetching Vehicle Data", error);
//       toast.error("Failed to load vehicle data");
//     } finally {
//       setLoading(false);
//     }
//   };

//   return (
//     <div className="page-body">
//       <Breadcrumbs
//         title={isEditMode ? "Edit Vehicle" : "Add Vehicle"}
//         mainTitle={isEditMode ? "Edit Vehicle" : "Add New Vehicle"}
//         parent="Vehicles"
//       />

//       <Container fluid>
//         <Row>
//           <Col sm="12">
//             <Card>
//               <CardBody>
//                 {/* Error Alert */}
//                 {error && (
//                   <Alert color="danger" className="mb-4">
//                     <h5 className="alert-heading">Error</h5>
//                     <p>{error}</p>
//                   </Alert>
//                 )}

//                 <Form onSubmit={handleSubmit}>
//                   <Row className="text-muted">
//                     {/* Customer Selection - Searchable Dropdown */}
//                     <Col md="6">
//                       <FormGroup>
//                         <Label className="d-flex justify-content-between align-items-center">
//                           <span>Customer *</span>
//                           <Link
//                             href="/admin/customer/add"
//                             color="link"
//                             // size="sm"
//                             className="p-0 text-decoration-none"
//                             // onClick={() => setShowAddCustomerModal(true)}
//                             target="_blank"
//                           >
//                             <i className="fa fa-plus me-1"></i>
//                             Add New Customer
//                           </Link>
//                         </Label>
//                         {loading ? (
//                           <div className="d-flex align-items-center">
//                             <Spinner size="sm" className="me-2" />
//                             Loading customers...
//                           </div>
//                         ) : customers.length === 0 ? (
//                           <div className="d-flex flex-column gap-2">
//                             <div className="text-danger">
//                               No customers found. Please add a customer first.
//                             </div>
//                             <Button
//                               color="info"
//                               size="sm"
//                               onClick={() => setShowAddCustomerModal(true)}
//                               className="align-self-start"
//                             >
//                               <i className="fa fa-plus me-2"></i>
//                               Add Customer
//                             </Button>
//                           </div>
//                         ) : (
//                           <div
//                             className="position-relative"
//                             ref={customerDropdownRef}
//                           >
//                             {/* Dropdown trigger */}
//                             <div
//                               onClick={() =>
//                                 setIsCustomerDropdownOpen(
//                                   !isCustomerDropdownOpen
//                                 )
//                               }
//                               className="d-flex w-100 align-items-center justify-content-between cursor-pointer form-control border"
//                               style={{
//                                 minHeight: "38px",
//                                 padding: "0.375rem 0.75rem",
//                                 cursor: "pointer",
//                               }}
//                             >
//                               <span
//                                 className="text-truncate"
//                                 style={{ maxWidth: "calc(100% - 20px)" }}
//                               >
//                                 {selectedCustomerName || "Select Customer"}
//                               </span>
//                               <span
//                                 className="ms-2 text-muted"
//                                 style={{ flexShrink: 0 }}
//                               >
//                                 {isCustomerDropdownOpen ? "▲" : "▼"}
//                               </span>
//                             </div>

//                             {/* Dropdown menu */}
//                             {isCustomerDropdownOpen && (
//                               <div
//                                 className="position-absolute w-100 mt-1 bg-white border rounded shadow"
//                                 style={{
//                                   maxHeight: "300px",
//                                   overflow: "auto",
//                                   zIndex: 1050,
//                                 }}
//                               >
//                                 {/* Search input */}
//                                 <div className="p-2 border-bottom">
//                                   <div className="d-flex gap-2">
//                                     <Input
//                                       type="text"
//                                       value={customerSearchTerm}
//                                       onChange={(e) => {
//                                         setCustomerSearchTerm(e.target.value);
//                                       }}
//                                       placeholder="Search customers..."
//                                       className="form-control form-control-sm"
//                                       autoFocus
//                                       onClick={(e) => e.stopPropagation()}
//                                     />
//                                     <Button
//                                       color="info"
//                                       size="sm"
//                                       onClick={() =>
//                                         setShowAddCustomerModal(true)
//                                       }
//                                       className="flex-shrink-0"
//                                       title="Add new customer"
//                                     >
//                                       <i className="fa fa-plus"></i>
//                                     </Button>
//                                   </div>
//                                 </div>

//                                 {/* Customer list */}
//                                 <div
//                                   style={{
//                                     maxHeight: "200px",
//                                     overflowY: "auto",
//                                   }}
//                                 >
//                                   {filteredCustomers.length > 0 ? (
//                                     <ul className="list-unstyled mb-0">
//                                       {filteredCustomers.map((customer) => (
//                                         <li
//                                           key={customer.id}
//                                           onClick={() =>
//                                             handleCustomerSelect(
//                                               customer.id,
//                                               customer.name
//                                             )
//                                           }
//                                           className="px-3 py-2 cursor-pointer hover-bg-light"
//                                           style={{ cursor: "pointer" }}
//                                         >
//                                           <div className="d-flex align-items-center justify-content-between">
//                                             <div>
//                                               {customer.name}
//                                               {customer.contact_phone && (
//                                                 <small className="text-muted d-block">
//                                                   {customer.contact_phone}
//                                                 </small>
//                                               )}
//                                             </div>
//                                             {formData.customer_id ===
//                                               customer.id && (
//                                               <span className="ms-2 badge bg-primary">
//                                                 Selected
//                                               </span>
//                                             )}
//                                           </div>
//                                         </li>
//                                       ))}
//                                     </ul>
//                                   ) : (
//                                     <div className="px-3 py-2 text-muted text-center">
//                                       {customerSearchTerm ? (
//                                         <>
//                                           No matching customers found
//                                           <div className="mt-2">
//                                             <Button
//                                               color="link"
//                                               size="sm"
//                                               onClick={() =>
//                                                 setShowAddCustomerModal(true)
//                                               }
//                                             >
//                                               <i className="fa fa-plus me-1"></i>
//                                               Add New Customer
//                                             </Button>
//                                           </div>
//                                         </>
//                                       ) : (
//                                         "No customers available"
//                                       )}
//                                     </div>
//                                   )}
//                                 </div>
//                               </div>
//                             )}

//                             {/* Hidden input for form submission */}
//                             <input
//                               type="hidden"
//                               name="customer_id"
//                               value={formData.customer_id}
//                               required
//                             />
//                           </div>
//                         )}
//                       </FormGroup>
//                     </Col>

//                     <Col md="6">
//                       <FormGroup>
//                         <Label>Registration Number *</Label>
//                         <Input
//                           type="text"
//                           name="registration_number"
//                           className="form-control"
//                           value={formData.registration_number}
//                           onChange={handleInputChange}
//                           required
//                           placeholder="e.g., ABC123, KL784566"
//                           disabled={submitting}
//                         />
//                       </FormGroup>
//                     </Col>

//                     {/* Vehicle Type */}
//                     <Col md="4">
//                       <FormGroup>
//                         <Label>Vehicle Type *</Label>
//                         <Input
//                           type="select"
//                           name="vehicle_type"
//                           className="form-control border"
//                           value={formData.vehicle_type}
//                           onChange={handleInputChange}
//                           required
//                           disabled={submitting}
//                         >
//                           <option value="">Select Type</option>
//                           {vehicleTypes.map((type) => (
//                             <option key={type.value} value={type.value}>
//                               {type.label}
//                             </option>
//                           ))}
//                         </Input>
//                       </FormGroup>
//                     </Col>

//                     <Col md="4">
//                       <FormGroup>
//                         <Label>Make *</Label>
//                         <Input
//                           type="text"
//                           name="make"
//                           className="form-control"
//                           value={formData.make}
//                           onChange={handleInputChange}
//                           required
//                           placeholder="e.g., Toyota, Honda, Suzuki"
//                           disabled={submitting}
//                         />
//                       </FormGroup>
//                     </Col>

//                     <Col md="4">
//                       <FormGroup>
//                         <Label>Model *</Label>
//                         <Input
//                           type="text"
//                           name="model"
//                           className="form-control"
//                           value={formData.model}
//                           onChange={handleInputChange}
//                           required
//                           placeholder="e.g., Camry, Civic, Swift"
//                           disabled={submitting}
//                         />
//                       </FormGroup>
//                     </Col>

//                     {/* Year Selection - Searchable Dropdown */}
//                     <Col md="4">
//                       <FormGroup>
//                         <Label>Year *</Label>
//                         <div
//                           className="position-relative"
//                           ref={yearDropdownRef}
//                         >
//                           {/* Dropdown trigger */}
//                           <div
//                             onClick={() =>
//                               setIsYearDropdownOpen(!isYearDropdownOpen)
//                             }
//                             className="d-flex w-100 align-items-center justify-content-between cursor-pointer form-control border"
//                             style={{
//                               minHeight: "38px",
//                               padding: "0.375rem 0.75rem",
//                               cursor: "pointer",
//                             }}
//                           >
//                             <span
//                               className="text-truncate"
//                               style={{ maxWidth: "calc(100% - 20px)" }}
//                             >
//                               {formData.year || "Select Year"}
//                             </span>
//                             <span
//                               className="ms-2 text-muted"
//                               style={{ flexShrink: 0 }}
//                             >
//                               {isYearDropdownOpen ? "▲" : "▼"}
//                             </span>
//                           </div>

//                           {/* Dropdown menu */}
//                           {isYearDropdownOpen && (
//                             <div
//                               className="position-absolute w-100 mt-1 bg-white border rounded shadow"
//                               style={{
//                                 maxHeight: "300px",
//                                 overflow: "auto",
//                                 zIndex: 1050,
//                               }}
//                             >
//                               {/* Search input */}
//                               <div className="p-2 border-bottom">
//                                 <Input
//                                   type="text"
//                                   value={yearSearchTerm}
//                                   onChange={(e) => {
//                                     setYearSearchTerm(e.target.value);
//                                   }}
//                                   placeholder="Search year..."
//                                   className="form-control form-control-sm"
//                                   autoFocus
//                                   onClick={(e) => e.stopPropagation()}
//                                 />
//                               </div>

//                               {/* Year list */}
//                               <div
//                                 style={{
//                                   maxHeight: "200px",
//                                   overflowY: "auto",
//                                 }}
//                               >
//                                 {filteredYears.length > 0 ? (
//                                   <ul className="list-unstyled mb-0">
//                                     {filteredYears.map((year) => (
//                                       <li
//                                         key={year}
//                                         onClick={() =>
//                                           handleYearSelect(year.toString())
//                                         }
//                                         className="px-3 py-2 cursor-pointer hover-bg-light"
//                                         style={{ cursor: "pointer" }}
//                                       >
//                                         <div className="d-flex align-items-center justify-content-between">
//                                           <span>{year}</span>
//                                           {formData.year ===
//                                             year.toString() && (
//                                             <span className="ms-2 badge bg-primary">
//                                               Selected
//                                             </span>
//                                           )}
//                                         </div>
//                                       </li>
//                                     ))}
//                                   </ul>
//                                 ) : (
//                                   <div className="px-3 py-2 text-muted">
//                                     {yearSearchTerm
//                                       ? "No matching years found"
//                                       : "No years available"}
//                                   </div>
//                                 )}
//                               </div>
//                             </div>
//                           )}

//                           {/* Hidden input for form submission */}
//                           <input
//                             type="hidden"
//                             name="year"
//                             value={formData.year}
//                             required
//                           />
//                         </div>
//                       </FormGroup>
//                     </Col>

//                     <Col md="4">
//                       <FormGroup>
//                         <Label>Chassis Number</Label>
//                         <Input
//                           type="text"
//                           name="chassis_number"
//                           className="form-control"
//                           value={formData.chassis_number}
//                           onChange={handleInputChange}
//                           placeholder="Enter chassis number"
//                           disabled={submitting}
//                         />
//                       </FormGroup>
//                     </Col>

//                     <Col md="4">
//                       <FormGroup>
//                         <Label>Engine Number</Label>
//                         <Input
//                           type="text"
//                           name="engine_number"
//                           className="form-control"
//                           value={formData.engine_number}
//                           onChange={handleInputChange}
//                           placeholder="Enter engine number"
//                           disabled={submitting}
//                         />
//                       </FormGroup>
//                     </Col>

//                     <Col md="4">
//                       <FormGroup>
//                         <Label>Current KM Reading</Label>
//                         <Input
//                           type="number"
//                           name="km_reading"
//                           className="form-control"
//                           value={formData.km_reading}
//                           onChange={handleInputChange}
//                           min="0"
//                           step="1"
//                           placeholder="0"
//                           disabled={submitting}
//                         />
//                         <small className="text-muted">
//                           Leave as 0 if unknown
//                         </small>
//                       </FormGroup>
//                     </Col>
//                   </Row>

//                   <div className="d-flex gap-2 mt-4">
//                     <Button
//                       color="primary"
//                       type="submit"
//                       disabled={submitting || loading || customers.length === 0}
//                       className="d-flex align-items-center"
//                     >
//                       {submitting ? (
//                         <>
//                           <Spinner size="sm" className="me-2" />
//                           {isEditMode
//                             ? "Updating Vehicle..."
//                             : "Adding Vehicle..."}
//                         </>
//                       ) : (
//                         <>
//                           <i className="fa fa-save me-2"></i>
//                           {isEditMode ? "Update Vehicle" : "Add Vehicle"}
//                         </>
//                       )}
//                     </Button>
//                     <Link href="/admin/vehicles">
//                       <Button
//                         color="secondary"
//                         type="button"
//                         disabled={submitting}
//                       >
//                         Cancel
//                       </Button>
//                     </Link>
//                   </div>
//                 </Form>
//               </CardBody>
//             </Card>
//           </Col>
//         </Row>
//       </Container>

//       {/* Add Customer Modal */}
//       {/* <Modal
//         isOpen={showAddCustomerModal}
//         toggle={() => setShowAddCustomerModal(!showAddCustomerModal)}
//         centered
//       >
//         <ModalHeader toggle={() => setShowAddCustomerModal(false)}>
//           <i className="fa fa-user-plus me-2"></i>
//           Add New Customer
//         </ModalHeader>
//         <ModalBody>
//           <Form>
//             <FormGroup>
//               <Label>Customer Name *</Label>
//               <Input
//                 type="text"
//                 name="name"
//                 value={newCustomerData.name}
//                 onChange={handleNewCustomerInputChange}
//                 placeholder="Enter customer name"
//                 required
//                 disabled={addingCustomer}
//               />
//             </FormGroup>

//             <FormGroup>
//               <Label>Contact Phone</Label>
//               <Input
//                 type="text"
//                 name="contact_phone"
//                 value={newCustomerData.contact_phone}
//                 onChange={handleNewCustomerInputChange}
//                 placeholder="Enter phone number"
//                 disabled={addingCustomer}
//               />
//             </FormGroup>

//             <FormGroup>
//               <Label>Email</Label>
//               <Input
//                 type="email"
//                 name="email"
//                 value={newCustomerData.email}
//                 onChange={handleNewCustomerInputChange}
//                 placeholder="Enter email address"
//                 disabled={addingCustomer}
//               />
//             </FormGroup>

//             <FormGroup>
//               <Label>Address</Label>
//               <Input
//                 type="textarea"
//                 name="address"
//                 value={newCustomerData.address}
//                 onChange={handleNewCustomerInputChange}
//                 placeholder="Enter address"
//                 rows={3}
//                 disabled={addingCustomer}
//               />
//             </FormGroup>
//           </Form>
//         </ModalBody>
//         <ModalFooter>
//           <Button
//             color="secondary"
//             onClick={() => setShowAddCustomerModal(false)}
//             disabled={addingCustomer}
//           >
//             Cancel
//           </Button>
//           <Button
//             color="primary"
//             onClick={handleAddNewCustomer}
//             disabled={addingCustomer || !newCustomerData.name.trim()}
//           >
//             {addingCustomer ? (
//               <>
//                 <Spinner size="sm" className="me-2" />
//                 Adding...
//               </>
//             ) : (
//               <>
//                 <i className="fa fa-save me-2"></i>
//                 Add Customer
//               </>
//             )}
//           </Button>
//         </ModalFooter>
//       </Modal> */}

//       <style jsx>{`
//         .form-control:disabled {
//           background-color: #e9ecef;
//           opacity: 1;
//         }

//         .text-muted {
//           font-size: 0.875rem;
//         }

//         .cursor-pointer {
//           cursor: pointer;
//         }

//         .text-truncate {
//           overflow: hidden;
//           text-overflow: ellipsis;
//           white-space: nowrap;
//         }

//         .hover-bg-light:hover {
//           background-color: #f8f9fa;
//         }
//       `}</style>
//     </div>
//   );
// }

// export default AddVehiclePage;

"use client";
import Breadcrumbs from "@/CommonElements/Breadcrumbs";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  Form,
  FormGroup,
  Label,
  Input,
  Button,
  Spinner,
  Alert,
} from "reactstrap";
import React, { useState, ChangeEvent, useEffect, useRef } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useAuth } from "@/helper/AuthContext";
import { toast } from "react-toastify";

// Customer Type based on API response
interface Customer {
  id: string;
  name: string;
  contact_phone?: string;
  email?: string;
  address?: string;
  status?: string;
  gst_number?: string | null;
  meta?: string;
  created_at?: string;
  updated_at?: string;
}

interface ApiResponse {
  data: Customer[];
}

const vehicleTypes = [
  { value: "car", label: "Car" },
  { value: "bike", label: "Bike" },
  { value: "suv", label: "SUV" },
  { value: "truck", label: "Truck" },
  { value: "van", label: "Van" },
  { value: "bus", label: "Bus" },
  { value: "other", label: "Other" },
];

function AddVehiclePage() {
  const { state } = useAuth();
  const router = useRouter();
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // for edit vehicle
  const searchParams = useSearchParams();
  const vehicleId = searchParams.get("id");
  const [isEditMode, setIsEditMode] = useState(false);

  // Customer dropdown state
  const [customerSearchTerm, setCustomerSearchTerm] = useState("");
  const [isCustomerDropdownOpen, setIsCustomerDropdownOpen] = useState(false);
  const [selectedCustomerName, setSelectedCustomerName] = useState("");
  const customerDropdownRef = useRef<HTMLDivElement | null>(null);

  // Year dropdown state
  const [yearSearchTerm, setYearSearchTerm] = useState("");
  const [isYearDropdownOpen, setIsYearDropdownOpen] = useState(false);
  const yearDropdownRef = useRef<HTMLDivElement | null>(null);

  // Vehicle Type dropdown state
  const [vehicleTypeSearchTerm, setVehicleTypeSearchTerm] = useState("");
  const [isVehicleTypeDropdownOpen, setIsVehicleTypeDropdownOpen] =
    useState(false);
  const [selectedVehicleTypeLabel, setSelectedVehicleTypeLabel] = useState("");
  const vehicleTypeDropdownRef = useRef<HTMLDivElement | null>(null);

  const [formData, setFormData] = useState({
    customer_id: "",
    vehicle_type: "",
    make: "",
    model: "",
    year: "",
    registration_number: "",
    chassis_number: "",
    engine_number: "",
    km_reading: "0",
  });

  // Fetch customers from API
  const fetchCustomers = async () => {
    try {
      setLoading(true);
      setError(null);

      const token = state?.accessToken || localStorage.getItem("token");
      if (!token) {
        toast.error("Authentication required. Please login again.");
        router.push("/login");
        return;
      }

      const response = await fetch("/api/customers_list", {
        method: "GET",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch customers: ${response.status}`);
      }

      const data: ApiResponse = await response.json();
      setCustomers(data.data || []);
    } catch (err) {
      console.error("Error fetching customers:", err);
      setError(err instanceof Error ? err.message : "Failed to load customers");
      toast.error("Failed to load customers");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCustomers();
  }, []);

  // Update selected customer name when customers are loaded and formData.customer_id exists
  useEffect(() => {
    if (formData.customer_id && customers.length > 0) {
      const customer = customers.find((c) => c.id === formData.customer_id);
      if (customer) {
        setSelectedCustomerName(customer.name);
      }
    }
  }, [customers, formData.customer_id]);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        customerDropdownRef.current &&
        !customerDropdownRef.current.contains(event.target as Node)
      ) {
        setIsCustomerDropdownOpen(false);
      }
      // Close year dropdown
      if (
        yearDropdownRef.current &&
        !yearDropdownRef.current.contains(event.target as Node)
      ) {
        setIsYearDropdownOpen(false);
      }
      // Close vehicle type dropdown
      if (
        vehicleTypeDropdownRef.current &&
        !vehicleTypeDropdownRef.current.contains(event.target as Node)
      ) {
        setIsVehicleTypeDropdownOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const handleInputChange = (
    e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  // Handle customer selection
  const handleCustomerSelect = (customerId: string, customerName: string) => {
    setFormData((prev) => ({
      ...prev,
      customer_id: customerId,
    }));
    setSelectedCustomerName(customerName);
    setIsCustomerDropdownOpen(false);
    setCustomerSearchTerm("");
  };

  // Handle year selection
  const handleYearSelect = (year: string) => {
    setFormData((prev) => ({
      ...prev,
      year: year,
    }));
    setIsYearDropdownOpen(false);
    setYearSearchTerm("");
  };

  // Handle vehicle type selection
  const handleVehicleTypeSelect = (
    vehicleTypeValue: string,
    vehicleTypeLabel: string
  ) => {
    setFormData((prev) => ({
      ...prev,
      vehicle_type: vehicleTypeValue,
    }));
    setSelectedVehicleTypeLabel(vehicleTypeLabel);
    setIsVehicleTypeDropdownOpen(false);
    setVehicleTypeSearchTerm("");
  };

  // Filter customers based on search term
  const filteredCustomers = customers.filter((customer) =>
    customer.name.toLowerCase().includes(customerSearchTerm.toLowerCase())
  );

  // Generate years from 1900 to current year + 1
  const currentYear = new Date().getFullYear();
  const years = Array.from(
    { length: currentYear - 1899 },
    (_, i) => currentYear + 1 - i
  );

  // Filter years based on search term
  const filteredYears = yearSearchTerm
    ? years.filter((year) => year.toString().includes(yearSearchTerm))
    : years;

  // Filter vehicle types based on search term
  const filteredVehicleTypes = vehicleTypeSearchTerm
    ? vehicleTypes.filter(
        (type) =>
          type.label
            .toLowerCase()
            .includes(vehicleTypeSearchTerm.toLowerCase()) ||
          type.value.toLowerCase().includes(vehicleTypeSearchTerm.toLowerCase())
      )
    : vehicleTypes;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validate required fields
    const requiredFields = [
      "customer_id",
      "registration_number",
      "make",
      "model",
      "year",
      "vehicle_type",
    ];

    const missingFields = requiredFields.filter(
      (field) => !formData[field as keyof typeof formData]
    );

    if (missingFields.length > 0) {
      toast.error(
        `Please fill all required fields: ${missingFields.join(", ")}`
      );
      return;
    }

    // Validate year is a valid number
    const yearNum = parseInt(formData.year);
    if (
      isNaN(yearNum) ||
      yearNum < 1900 ||
      yearNum > new Date().getFullYear() + 1
    ) {
      toast.error("Please enter a valid year");
      return;
    }

    // Validate vehicle type is from allowed list
    const validVehicleTypes = vehicleTypes.map((vt) => vt.value);
    if (!validVehicleTypes.includes(formData.vehicle_type)) {
      toast.error("Please select a valid vehicle type");
      return;
    }

    try {
      setSubmitting(true);
      setError(null);

      // Prepare data for API - ensure all fields match API expectations
      const vehicleData = {
        customer_id: formData.customer_id,
        vehicle_type: formData.vehicle_type,
        make: formData.make,
        model: formData.model,
        year: formData.year,
        registration_number: formData.registration_number,
        chassis_number: formData.chassis_number || null,
        engine_number: formData.engine_number || null,
        km_reading: formData.km_reading || "0",
      };

      console.log("Submitting vehicle data:", vehicleData);

      let method;
      let url;

      if (isEditMode && vehicleId) {
        method = "PUT";
        url = `/api/vehicles/${vehicleId}`;
      } else {
        method = "POST";
        url = "/api/vehicles";
      }

      const response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${
            state?.accessToken ?? (localStorage.getItem("token") || "")
          }`,
        },
        body: JSON.stringify(vehicleData),
      });

      const result = await response.json();

      if (!response.ok) {
        // Handle validation errors from API
        if (result.errors) {
          const errorMessages = Object.values(result.errors).flat().join(", ");
          throw new Error(errorMessages);
        }
        throw new Error(
          result.message ||
            `Failed to ${isEditMode ? "Update" : "Add"} vehicle: ${
              response.status
            }`
        );
      }

      console.log(
        `Vehicle ${isEditMode ? "updated" : "added"} successfully:`,
        result
      );

      toast.success(
        result.message ||
          `Vehicle ${isEditMode ? "Updated" : "Added"} Successfully`
      );

      // Redirect after successful submission
      setTimeout(() => {
        router.push("/admin/vehicles");
      }, 1000);
    } catch (err) {
      console.error(
        `Error ${isEditMode ? "updating" : "adding"} vehicle:`,
        err
      );

      const errorMessage =
        err instanceof Error
          ? err.message
          : `Failed to ${
              isEditMode ? "update" : "add"
            } vehicle. Please try again.`;
      setError(errorMessage);
      toast.error(errorMessage);
    } finally {
      setSubmitting(false);
    }
  };

  // Fetch vehicle data for edit mode
  useEffect(() => {
    if (vehicleId) {
      setIsEditMode(true);
      fetchVehicleData(vehicleId);
    }
  }, [vehicleId]);

  const fetchVehicleData = async (id: string) => {
    try {
      setLoading(true);

      const token = state?.accessToken || localStorage.getItem("token");
      const response = await fetch(`/api/vehicles/${id}`, {
        method: "GET",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch vehicle: ${response.status}`);
      }

      const data = await response.json();
      console.log("Fetched vehicle data:", data);

      if (data.data) {
        setFormData({
          customer_id: data.data.customer_id || "",
          vehicle_type: data.data.vehicle_type || "",
          make: data.data.make || "",
          model: data.data.model || "",
          year: data.data.year || "",
          registration_number: data.data.registration_number || "",
          chassis_number: data.data.chassis_number || "",
          engine_number: data.data.engine_number || "",
          km_reading: data.data.km_reading || "0",
        });
      }
    } catch (error) {
      console.error("Error Fetching Vehicle Data", error);
      toast.error("Failed to load vehicle data");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page-body">
      <Breadcrumbs
        title={isEditMode ? "Edit Vehicle" : "Add Vehicle"}
        mainTitle={isEditMode ? "Edit Vehicle" : "Add New Vehicle"}
        parent="Vehicles"
      />

      <Container fluid>
        <Row>
          <Col sm="12">
            <Card>
              <CardBody>
                {/* Error Alert */}
                {error && (
                  <Alert color="danger" className="mb-4">
                    <h5 className="alert-heading">Error</h5>
                    <p>{error}</p>
                  </Alert>
                )}

                <Form onSubmit={handleSubmit}>
                  <Row className="text-muted">
                    {/* Customer Selection - Searchable Dropdown */}
                    <Col md="6">
                      <FormGroup>
                        <Label className="d-flex justify-content-between align-items-center">
                          <span>Customer *</span>
                          <Link
                            href="/admin/customer/add"
                            className="btn btn-link btn-sm p-0 text-decoration-none"
                          >
                            <i className="fa fa-plus me-1"></i>
                            Add New Customer
                          </Link>
                        </Label>
                        {loading ? (
                          <div className="d-flex align-items-center">
                            <Spinner size="sm" className="me-2" />
                            Loading customers...
                          </div>
                        ) : customers.length === 0 ? (
                          <div className="d-flex flex-column gap-2">
                            <div className="text-danger">
                              No customers found. Please add a customer first.
                            </div>
                            <Link href="/admin/customer/add">
                              <Button
                                color="info"
                                size="sm"
                                className="align-self-start"
                              >
                                <i className="fa fa-plus me-2"></i>
                                Add Customer
                              </Button>
                            </Link>
                          </div>
                        ) : (
                          <div
                            className="position-relative"
                            ref={customerDropdownRef}
                          >
                            {/* Dropdown trigger */}
                            <div
                              onClick={() =>
                                setIsCustomerDropdownOpen(
                                  !isCustomerDropdownOpen
                                )
                              }
                              className="d-flex w-100 align-items-center justify-content-between cursor-pointer form-select border"
                              style={{
                                minHeight: "38px",
                                padding: "0.375rem 0.75rem",
                                cursor: "pointer",
                              }}
                            >
                              <span
                                className="text-truncate"
                                style={{ maxWidth: "calc(100% - 20px)" }}
                              >
                                {selectedCustomerName || "Select Customer"}
                              </span>
                              {/* <span
                                className="ms-2 text-muted"
                                style={{ flexShrink: 0 }}
                              >
                                {isCustomerDropdownOpen ? "▲" : "▼"}
                              </span> */}
                            </div>

                            {/* Dropdown menu */}
                            {/* {isCustomerDropdownOpen && (
                              <div
                                className="position-absolute w-100 mt-1 bg-white border rounded shadow"
                                style={{
                                  maxHeight: "300px",
                                  overflow: "auto",
                                  zIndex: 1050,
                                }}
                              >
                                <div className="p-2 border-bottom">
                                  <div className="d-flex gap-2">
                                    <Input
                                      type="text"
                                      value={customerSearchTerm}
                                      onChange={(e) => {
                                        setCustomerSearchTerm(e.target.value);
                                      }}
                                      placeholder="Search customers..."
                                      className="form-control form-control-sm"
                                      autoFocus
                                      onClick={(e) => e.stopPropagation()}
                                    />
                                    <Link
                                      href="/admin/customer/add"
                                      className="btn btn-info btn-sm flex-shrink-0"
                                      title="Add new customer"
                                    >
                                      <i className="fa fa-plus"></i>
                                    </Link>
                                  </div>
                                </div>

                                <div
                                  style={{
                                    maxHeight: "200px",
                                    overflowY: "auto",
                                  }}
                                >
                                  {filteredCustomers.length > 0 ? (
                                    <ul className="list-unstyled mb-0">
                                      {filteredCustomers.map((customer) => (
                                        <li
                                          key={customer.id}
                                          onClick={() =>
                                            handleCustomerSelect(
                                              customer.id,
                                              customer.name
                                            )
                                          }
                                          className="px-3 py-2 cursor-pointer hover-bg-light"
                                          style={{ cursor: "pointer" }}
                                        >
                                          <div className="d-flex align-items-center justify-content-between">
                                            <div>
                                              {customer.name}
                                              {customer.contact_phone && (
                                                <small className="text-muted d-block">
                                                  {customer.contact_phone}
                                                </small>
                                              )}
                                            </div>
                                            {formData.customer_id ===
                                              customer.id && (
                                              <span className="ms-2 badge bg-primary">
                                                Selected
                                              </span>
                                            )}
                                          </div>
                                        </li>
                                      ))}
                                    </ul>
                                  ) : (
                                    <div className="px-3 py-2 text-muted text-center">
                                      {customerSearchTerm ? (
                                        <>
                                          No matching customers found
                                          <div className="mt-2">
                                            <Link
                                              href="/admin/customer/add"
                                              className="btn btn-link btn-sm"
                                            >
                                              <i className="fa fa-plus me-1"></i>
                                              Add New Customer
                                            </Link>
                                          </div>
                                        </>
                                      ) : (
                                        "No customers available"
                                      )}
                                    </div>
                                  )}
                                </div>
                              </div>
                            )} */}
                            {isCustomerDropdownOpen && (
                              <div
                                className="position-absolute w-100 mt-1 border rounded shadow dropdown-menu show"
                                style={{
                                  maxHeight: "300px",
                                  overflow: "auto",
                                  zIndex: 1050,
                                }}
                              >
                                {/* Search input */}
                                <div className="p-2 border-bottom">
                                  <div className="d-flex gap-2">
                                    <Input
                                      type="text"
                                      value={customerSearchTerm}
                                      onChange={(e) => {
                                        setCustomerSearchTerm(e.target.value);
                                      }}
                                      placeholder="Search customers..."
                                      className="form-control form-control-sm"
                                      autoFocus
                                      onClick={(e) => e.stopPropagation()}
                                    />
                                    <Link
                                      href="/admin/customer/add"
                                      className="btn btn-info btn-sm flex-shrink-0"
                                      title="Add new customer"
                                    >
                                      <i className="fa fa-plus"></i>
                                    </Link>
                                  </div>
                                </div>

                                {/* Customer list */}
                                <div
                                  style={{
                                    maxHeight: "200px",
                                    overflowY: "auto",
                                  }}
                                >
                                  {filteredCustomers.length > 0 ? (
                                    <ul className="list-unstyled mb-0">
                                      {filteredCustomers.map((customer) => (
                                        <li
                                          key={customer.id}
                                          onClick={() =>
                                            handleCustomerSelect(
                                              customer.id,
                                              customer.name
                                            )
                                          }
                                          className="px-3 py-2 cursor-pointer dropdown-item"
                                          style={{ cursor: "pointer" }}
                                        >
                                          <div className="d-flex align-items-center justify-content-between">
                                            <div>
                                              {customer.name}
                                              {customer.contact_phone && (
                                                <small className="text-muted d-block">
                                                  {customer.contact_phone}
                                                </small>
                                              )}
                                            </div>
                                            {/* {formData.customer_id ===
                                              customer.id && (
                                              <span className="ms-2 badge bg-primary">
                                                Selected
                                              </span>
                                            )} */}
                                          </div>
                                        </li>
                                      ))}
                                    </ul>
                                  ) : (
                                    <div className="px-3 py-2 text-muted text-center">
                                      {customerSearchTerm ? (
                                        <>
                                          No matching customers found
                                          <div className="mt-2">
                                            <Link
                                              href="/admin/customer/add"
                                              className="btn btn-link btn-sm"
                                            >
                                              <i className="fa fa-plus me-1"></i>
                                              Add New Customer
                                            </Link>
                                          </div>
                                        </>
                                      ) : (
                                        "No customers available"
                                      )}
                                    </div>
                                  )}
                                </div>
                              </div>
                            )}

                            {/* Hidden input for form submission */}
                            <input
                              type="hidden"
                              name="customer_id"
                              value={formData.customer_id}
                              required
                            />
                          </div>
                        )}
                      </FormGroup>
                    </Col>

                    <Col md="6">
                      <FormGroup>
                        <Label>Registration Number *</Label>
                        <Input
                          type="text"
                          name="registration_number"
                          className="form-control"
                          value={formData.registration_number}
                          onChange={handleInputChange}
                          required
                          placeholder="e.g., ABC123, KL784566"
                          disabled={submitting}
                        />
                      </FormGroup>
                    </Col>

                    {/* Vehicle Type */}
                    {/* <Col md="4">
                      <FormGroup>
                        <Label>Vehicle Type *</Label>
                        <Input
                          type="select"
                          name="vehicle_type"
                          className="form-control border"
                          value={formData.vehicle_type}
                          onChange={handleInputChange}
                          required
                          disabled={submitting}
                        >
                          <option value="">Select Type</option>
                          {vehicleTypes.map((type) => (
                            <option key={type.value} value={type.value}>
                              {type.label}
                            </option>
                          ))}
                        </Input>
                      </FormGroup>
                    </Col> */}
                    {/* Vehicle Type - Searchable Dropdown */}
                    <Col md="4">
                      <FormGroup>
                        <Label>Vehicle Type *</Label>
                        <div
                          className="position-relative"
                          ref={vehicleTypeDropdownRef}
                        >
                          {/* Dropdown trigger */}
                          <div
                            onClick={() =>
                              setIsVehicleTypeDropdownOpen(
                                !isVehicleTypeDropdownOpen
                              )
                            }
                            className="d-flex w-100 align-items-center justify-content-between cursor-pointer form-select border"
                            // className="form-select border"
                            style={{
                              minHeight: "38px",
                              padding: "0.375rem 0.75rem",
                              cursor: "pointer",
                            }}
                          >
                            <span
                              className="text-truncate"
                              style={{ maxWidth: "calc(100% - 20px)" }}
                            >
                              {selectedVehicleTypeLabel ||
                                "Select Vehicle Type"}
                            </span>
                            {/* <span
                              className="ms-2 text-muted"
                              style={{ flexShrink: 0 }}
                            >
                              {isVehicleTypeDropdownOpen ? "▲" : "▼"}
                            </span> */}
                          </div>

                          {/* Dropdown menu */}
                          {/* {isVehicleTypeDropdownOpen && (
                            <div
                              className="position-absolute w-100 mt-1 bg-white border rounded shadow"
                              style={{
                                maxHeight: "300px",
                                overflow: "auto",
                                zIndex: 1050,
                              }}
                            >
                              
                              <div className="p-2 border-bottom">
                                <Input
                                  type="text"
                                  value={vehicleTypeSearchTerm}
                                  onChange={(e) => {
                                    setVehicleTypeSearchTerm(e.target.value);
                                  }}
                                  placeholder="Search vehicle type..."
                                  className="form-control form-control-sm"
                                  autoFocus
                                  onClick={(e) => e.stopPropagation()}
                                />
                              </div>

                              
                              <div
                                style={{
                                  maxHeight: "200px",
                                  overflowY: "auto",
                                }}
                              >
                                {filteredVehicleTypes.length > 0 ? (
                                  <ul className="list-unstyled mb-0">
                                    {filteredVehicleTypes.map((type) => (
                                      <li
                                        key={type.value}
                                        onClick={() =>
                                          handleVehicleTypeSelect(
                                            type.value,
                                            type.label
                                          )
                                        }
                                        className="px-3 py-2 cursor-pointer hover-bg-light"
                                        style={{ cursor: "pointer" }}
                                      >
                                        <div className="d-flex align-items-center justify-content-between">
                                          <span>{type.label}</span>
                                          {formData.vehicle_type ===
                                            type.value && (
                                            <span className="ms-2 badge bg-primary">
                                              Selected
                                            </span>
                                          )}
                                        </div>
                                      </li>
                                    ))}
                                  </ul>
                                ) : (
                                  <div className="px-3 py-2 text-muted">
                                    {vehicleTypeSearchTerm
                                      ? "No matching vehicle types found"
                                      : "No vehicle types available"}
                                  </div>
                                )}
                              </div>
                            </div>
                          )} */}

                          {isVehicleTypeDropdownOpen && (
                            <div
                              className="position-absolute w-100 mt-1 border rounded shadow dropdown-menu show"
                              style={{
                                maxHeight: "300px",
                                overflow: "auto",
                                zIndex: 1050,
                              }}
                            >
                              {/* Search input */}
                              <div className="p-2 border-bottom">
                                <Input
                                  type="text"
                                  value={vehicleTypeSearchTerm}
                                  onChange={(e) => {
                                    setVehicleTypeSearchTerm(e.target.value);
                                  }}
                                  placeholder="Search vehicle type..."
                                  className="form-control form-control-sm"
                                  autoFocus
                                  onClick={(e) => e.stopPropagation()}
                                />
                              </div>

                              {/* Vehicle type list */}
                              <div
                                style={{
                                  maxHeight: "200px",
                                  overflowY: "auto",
                                }}
                              >
                                {filteredVehicleTypes.length > 0 ? (
                                  <ul className="list-unstyled mb-0">
                                    {filteredVehicleTypes.map((type) => (
                                      <li
                                        key={type.value}
                                        onClick={() =>
                                          handleVehicleTypeSelect(
                                            type.value,
                                            type.label
                                          )
                                        }
                                        className="px-3 py-2 cursor-pointer dropdown-item"
                                        style={{ cursor: "pointer" }}
                                      >
                                        <div className="d-flex align-items-center justify-content-between">
                                          <span>{type.label}</span>
                                          {/* {formData.vehicle_type ===
                                            type.value && (
                                            <span className="ms-2 badge bg-primary">
                                              Selected
                                            </span>
                                          )} */}
                                        </div>
                                      </li>
                                    ))}
                                  </ul>
                                ) : (
                                  <div className="px-3 py-2 text-muted">
                                    {vehicleTypeSearchTerm
                                      ? "No matching vehicle types found"
                                      : "No vehicle types available"}
                                  </div>
                                )}
                              </div>
                            </div>
                          )}
                          <input
                            type="hidden"
                            name="vehicle_type"
                            value={formData.vehicle_type}
                            required
                          />
                        </div>
                      </FormGroup>
                    </Col>

                    <Col md="4">
                      <FormGroup>
                        <Label>Make *</Label>
                        <Input
                          type="text"
                          name="make"
                          className="form-control"
                          value={formData.make}
                          onChange={handleInputChange}
                          required
                          placeholder="e.g., Toyota, Honda, Suzuki"
                          disabled={submitting}
                        />
                      </FormGroup>
                    </Col>

                    <Col md="4">
                      <FormGroup>
                        <Label>Model *</Label>
                        <Input
                          type="text"
                          name="model"
                          className="form-control"
                          value={formData.model}
                          onChange={handleInputChange}
                          required
                          placeholder="e.g., Camry, Civic, Swift"
                          disabled={submitting}
                        />
                      </FormGroup>
                    </Col>

                    {/* Year Selection - Searchable Dropdown */}
                    <Col md="4">
                      <FormGroup>
                        <Label>Year *</Label>
                        <div
                          className="position-relative"
                          ref={yearDropdownRef}
                        >
                          {/* Dropdown trigger */}
                          <div
                            onClick={() =>
                              setIsYearDropdownOpen(!isYearDropdownOpen)
                            }
                            // className="d-flex w-100 align-items-center justify-content-between cursor-pointer form-control border"
                            className="form-select border"
                            style={{
                              minHeight: "38px",
                              padding: "0.375rem 0.75rem",
                              cursor: "pointer",
                            }}
                          >
                            <span
                              className="text-truncate"
                              style={{ maxWidth: "calc(100% - 20px)" }}
                            >
                              {formData.year || "Select Year"}
                            </span>
                            {/* <span
                              className="ms-2 text-muted"
                              style={{ flexShrink: 0 }}
                            >
                              {isYearDropdownOpen ? "▲" : "▼"}
                            </span> */}
                          </div>

                          {/* Dropdown menu */}
                          {/* {isYearDropdownOpen && (
                            <div
                              className="position-absolute w-100 mt-1 bg-white border rounded shadow"
                              style={{
                                maxHeight: "300px",
                                overflow: "auto",
                                zIndex: 1050,
                              }}
                            >
                              
                              <div className="p-2 border-bottom">
                                <Input
                                  type="text"
                                  value={yearSearchTerm}
                                  onChange={(e) => {
                                    setYearSearchTerm(e.target.value);
                                  }}
                                  placeholder="Search year..."
                                  className="form-control form-control-sm"
                                  autoFocus
                                  onClick={(e) => e.stopPropagation()}
                                />
                              </div>

                             
                              <div
                                style={{
                                  maxHeight: "200px",
                                  overflowY: "auto",
                                }}
                              >
                                {filteredYears.length > 0 ? (
                                  <ul className="list-unstyled mb-0">
                                    {filteredYears.map((year) => (
                                      <li
                                        key={year}
                                        onClick={() =>
                                          handleYearSelect(year.toString())
                                        }
                                        className="px-3 py-2 cursor-pointer hover-bg-light"
                                        style={{ cursor: "pointer" }}
                                      >
                                        <div className="d-flex align-items-center justify-content-between">
                                          <span>{year}</span>
                                          {formData.year ===
                                            year.toString() && (
                                            <span className="ms-2 badge bg-primary">
                                              Selected
                                            </span>
                                          )}
                                        </div>
                                      </li>
                                    ))}
                                  </ul>
                                ) : (
                                  <div className="px-3 py-2 text-muted">
                                    {yearSearchTerm
                                      ? "No matching years found"
                                      : "No years available"}
                                  </div>
                                )}
                              </div>
                            </div>
                          )} */}
                          {isYearDropdownOpen && (
                            <div
                              className="position-absolute w-100 mt-1 border rounded shadow dropdown-menu show"
                              style={{
                                maxHeight: "300px",
                                overflow: "auto",
                                zIndex: 1050,
                              }}
                            >
                              {/* Search input */}
                              <div className="p-2 border-bottom">
                                <Input
                                  type="text"
                                  value={yearSearchTerm}
                                  onChange={(e) => {
                                    setYearSearchTerm(e.target.value);
                                  }}
                                  placeholder="Search year..."
                                  className="form-control form-control-sm"
                                  autoFocus
                                  onClick={(e) => e.stopPropagation()}
                                />
                              </div>

                              {/* Year list */}
                              <div
                                style={{
                                  maxHeight: "200px",
                                  overflowY: "auto",
                                }}
                              >
                                {filteredYears.length > 0 ? (
                                  <ul className="list-unstyled mb-0">
                                    {filteredYears.map((year) => (
                                      <li
                                        key={year}
                                        onClick={() =>
                                          handleYearSelect(year.toString())
                                        }
                                        className="px-3 py-2 cursor-pointer dropdown-item"
                                        style={{ cursor: "pointer" }}
                                      >
                                        <div className="d-flex align-items-center justify-content-between">
                                          <span>{year}</span>
                                          {formData.year ===
                                            year.toString() && (
                                            <span className="ms-2 badge bg-primary">
                                              Selected
                                            </span>
                                          )}
                                        </div>
                                      </li>
                                    ))}
                                  </ul>
                                ) : (
                                  <div className="px-3 py-2 text-muted">
                                    {yearSearchTerm
                                      ? "No matching years found"
                                      : "No years available"}
                                  </div>
                                )}
                              </div>
                            </div>
                          )}

                          {/* Hidden input for form submission */}
                          <input
                            type="hidden"
                            name="year"
                            value={formData.year}
                            required
                          />
                        </div>
                      </FormGroup>
                    </Col>

                    <Col md="4">
                      <FormGroup>
                        <Label>Chassis Number</Label>
                        <Input
                          type="text"
                          name="chassis_number"
                          className="form-control"
                          value={formData.chassis_number}
                          onChange={handleInputChange}
                          placeholder="Enter chassis number"
                          disabled={submitting}
                        />
                      </FormGroup>
                    </Col>

                    <Col md="4">
                      <FormGroup>
                        <Label>Engine Number</Label>
                        <Input
                          type="text"
                          name="engine_number"
                          className="form-control"
                          value={formData.engine_number}
                          onChange={handleInputChange}
                          placeholder="Enter engine number"
                          disabled={submitting}
                        />
                      </FormGroup>
                    </Col>

                    <Col md="4">
                      <FormGroup>
                        <Label>Current KM Reading</Label>
                        <Input
                          type="number"
                          name="km_reading"
                          className="form-control"
                          value={formData.km_reading}
                          onChange={handleInputChange}
                          min="0"
                          step="1"
                          placeholder="0"
                          disabled={submitting}
                        />
                        <small className="text-muted">
                          Leave as 0 if unknown
                        </small>
                      </FormGroup>
                    </Col>
                  </Row>

                  <div className="d-flex gap-2 mt-4">
                    <Button
                      color="primary"
                      type="submit"
                      disabled={submitting || loading || customers.length === 0}
                      className="d-flex align-items-center"
                    >
                      {submitting ? (
                        <>
                          <Spinner size="sm" className="me-2" />
                          {isEditMode
                            ? "Updating Vehicle..."
                            : "Adding Vehicle..."}
                        </>
                      ) : (
                        <>
                          <i className="fa fa-save me-2"></i>
                          {isEditMode ? "Update Vehicle" : "Add Vehicle"}
                        </>
                      )}
                    </Button>
                    <Link href="/admin/vehicles">
                      <Button
                        color="secondary"
                        type="button"
                        disabled={submitting}
                      >
                        Cancel
                      </Button>
                    </Link>

                    {customers.length === 0 && !loading && (
                      <Link href="/admin/customer/add" className="ms-auto">
                        <Button color="info" type="button">
                          <i className="fa fa-plus me-2"></i>
                          Add Customer First
                        </Button>
                      </Link>
                    )}
                  </div>
                </Form>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Container>

      {/* <style jsx>{`
        .form-control:disabled {
          background-color: #e9ecef;
          opacity: 1;
        }

        .text-muted {
          font-size: 0.875rem;
        }

        .cursor-pointer {
          cursor: pointer;
        }

        .text-truncate {
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        .hover-bg-light:hover {
          background-color: #f8f9fa;
        }
      `}</style> */}
      <style jsx>{`
        .form-control:disabled {
          background-color: #e9ecef;
          opacity: 1;
        }

        .text-muted {
          font-size: 0.875rem;
        }

        .cursor-pointer {
          cursor: pointer;
        }

        .text-truncate {
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        /* Dark mode styles for dropdowns */
        :global(.dark-mode) .dropdown-menu {
          background-color: #2a3042 !important;
          border-color: #404656 !important;
          color: #e0e0e0 !important;
        }

        :global(.dark-mode) .dropdown-item {
          color: #e0e0e0 !important;
        }

        :global(.dark-mode) .dropdown-item:hover {
          background-color: #3a4054 !important;
          color: #ffffff !important;
        }

        :global(.dark-mode) .text-muted {
          color: #a0a0a0 !important;
        }

        :global(.dark-mode) .border-bottom {
          border-color: #404656 !important;
        }

        :global(.dark-mode) .form-control {
          background-color: #2a3042 !important;
          border-color: #404656 !important;
          color: #e0e0e0 !important;
        }

        :global(.dark-mode) .form-control::placeholder {
          color: #a0a0a0 !important;
        }

        /* Make dropdown trigger adapt to dark mode */
        :global(.dark-mode) .dropdown-toggle {
          background-color: #2a3042 !important;
          border-color: #404656 !important;
          color: #e0e0e0 !important;
        }
      `}</style>
    </div>
  );
}

export default AddVehiclePage;
