// api
// "use client";
// import Breadcrumbs from "@/CommonElements/Breadcrumbs";
// import CustomPagination from "@/CommonElements/Pagination";
// import {
//   Container,
//   Row,
//   Col,
//   Card,
//   CardBody,
//   Input,
//   Button,
//   Table,
//   Spinner,
//   Alert,
// } from "reactstrap";
// import React, { useState, useEffect } from "react";
// import Link from "next/link";
// import { useRouter } from "next/navigation";
// import { useAuth } from "@/helper/AuthContext";
// import { toast } from "react-toastify";

// // Vehicle Type based on API response
// interface Vehicle {
//   id: string;
//   customer_id: string;
//   vehicle_type: string;
//   make: string;
//   model: string;
//   year: string;
//   registration_number: string;
//   chassis_number: string;
//   engine_number: string;
//   km_reading: string;
//   meta: string;
//   created_at: string;
//   updated_at: string;
//   status?: "active" | "inactive" | "pending"; // Optional field for UI
// }

// // API Response Type
// interface ApiResponse {
//   data: Vehicle[];
// }

// function VehiclePage() {
//   const { state } = useAuth();

//   const router = useRouter();
//   const [currentPage, setCurrentPage] = useState(1);
//   const [vehicles, setVehicles] = useState<Vehicle[]>([]);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState<string | null>(null);
//   const [searchTerm, setSearchTerm] = useState("");
//   const [statusFilter, setStatusFilter] = useState("all");
//   const itemsPerPage = 5;

//   // Fetch vehicles from API
//   useEffect(() => {
//     fetchVehicles();
//   }, []);

//   const fetchVehicles = async () => {
//     try {
//       setLoading(true);
//       setError(null);

//       const response = await fetch("/api/vehicles", {
//         method: "GET",
//         headers: {
//           Authorization: `Bearer ${
//             state?.accessToken || localStorage.getItem("token")
//           }`,
//           "Content-Type": "application/json",
//         },
//       });

//       if (!response.ok) {
//         throw new Error(`Failed to fetch vehicles: ${response.status}`);
//       }

//       const data: ApiResponse = await response.json();

//       // Add a status field to each vehicle for UI purposes
//       // You might want to get this from your API or calculate it based on some logic
//       const vehiclesWithStatus = data.data.map((vehicle) => ({
//         ...vehicle,
//         status: "active" as const, // Default status, adjust based on your business logic
//       }));

//       setVehicles(vehiclesWithStatus);
//     } catch (err) {
//       console.error("Error fetching vehicles:", err);
//       setError(err instanceof Error ? err.message : "Failed to load vehicles");
//     } finally {
//       setLoading(false);
//     }
//   };

//   // Filter vehicles based on search & status
//   const filteredVehicles = vehicles.filter((vehicle) => {
//     const matchesSearch =
//       vehicle.make.toLowerCase().includes(searchTerm.toLowerCase()) ||
//       vehicle.model.toLowerCase().includes(searchTerm.toLowerCase()) ||
//       vehicle.registration_number
//         .toLowerCase()
//         .includes(searchTerm.toLowerCase()) ||
//       vehicle.chassis_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
//       vehicle.vehicle_type.toLowerCase().includes(searchTerm.toLowerCase());

//     const matchesStatus =
//       statusFilter === "all" || vehicle.status === statusFilter;

//     return matchesSearch && matchesStatus;
//   });

//   //delete vehicle
//   const handleDeleteVehicle = async (id: string) => {
//     if (!confirm("Are you sure you want to delete this vehicle?")) {
//       return;
//     }

//     try {
//       const token = localStorage.getItem("token");
//       // give correct api for deleting
//       const response = await fetch(`/api/vehicles/${id}`, {
//         method: "DELETE",
//         headers: {
//           Authorization: `Bearer ${state?.accessToken || token}`,
//           "Content-Type": "application/json",
//         },
//       });

//       if (response.ok) {
//         toast.success("Vehicle Deleted Successfully");

//         //call fetch api
//         fetchVehicles();
//       } else {
//         const errorData = await response.json();
//         toast.error(
//           errorData.message || "Failed to Delete Vehicle! Please try again..."
//         );
//       }
//     } catch (error: any) {
//       console.error("Error deleting Vehicle", error);
//       toast.error("Failed to Delete Vehicle ! Please try again", error.message);
//     }
//   };

//   // Pagination logic
//   const totalPages = Math.ceil(filteredVehicles.length / itemsPerPage);
//   const paginatedVehicles = filteredVehicles.slice(
//     (currentPage - 1) * itemsPerPage,
//     currentPage * itemsPerPage
//   );

//   // Status badge renderer
//   const renderStatusBadge = (value: string) => {
//     const statusConfig = {
//       active: { class: "bg-success", label: "Active" },
//       inactive: { class: "bg-secondary", label: "Inactive" },
//       pending: { class: "bg-warning", label: "Pending" },
//     };

//     const config = statusConfig[value as keyof typeof statusConfig] || {
//       class: "bg-secondary",
//       label: value,
//     };

//     return (
//       <span className={`badge ${config.class} text-white`}>{config.label}</span>
//     );
//   };

//   // Delete Vehicle

//   // Handle page reset when filters change
//   useEffect(() => {
//     setCurrentPage(1);
//   }, [searchTerm, statusFilter]);

//   return (
//     <div className="page-body">
//       <Breadcrumbs
//         title="Vehicle Management"
//         mainTitle="Vehicle Management"
//         parent="Dashboard"
//       />

//       <Container fluid>
//         <Row>
//           <Col sm={12}>
//             <Card className="vehicle-card">
//               <CardBody>
//                 {/* Search, Filter and Add Button */}
//                 <div className="row align-items-center mb-4 g-3">
//                   {/* Search Bar */}
//                   <div className="col-12 col-md-3">
//                     <div className="position-relative">
//                       <Input
//                         type="search"
//                         placeholder="Search vehicles..."
//                         value={searchTerm}
//                         onChange={(e) => setSearchTerm(e.target.value)}
//                       />
//                       {searchTerm.length === 0 && (
//                         <i
//                           className="fa fa-search position-absolute"
//                           style={{
//                             right: "10px",
//                             top: "50%",
//                             transform: "translateY(-50%)",
//                             color: "#aaa",
//                           }}
//                         ></i>
//                       )}
//                     </div>
//                   </div>

//                   {/* Status Filter */}
//                   <div className="col-12 col-md-3">
//                     <Input
//                       type="select"
//                       value={statusFilter}
//                       onChange={(e) => setStatusFilter(e.target.value)}
//                     >
//                       <option value="all">All Status</option>
//                       <option value="active">Active</option>
//                       <option value="inactive">Inactive</option>
//                       <option value="pending">Pending</option>
//                     </Input>
//                   </div>

//                   {/* Spacer */}
//                   <div className="d-none d-md-block col-md-3"></div>

//                   {/* Add Vehicle Button */}
//                   <div className="col-12 col-md-3 d-flex justify-content-md-end">
//                     <Link
//                       href="/admin/vehicles/add"
//                       className="w-100 w-md-auto"
//                     >
//                       <Button color="primary" className="w-100 w-md-auto">
//                         <i className="fa fa-plus me-2"></i>
//                         Add Vehicle
//                       </Button>
//                     </Link>
//                   </div>
//                 </div>

//                 {/* Loading State */}
//                 {loading && (
//                   <div className="text-center py-5">
//                     <Spinner color="primary" />
//                     <p className="mt-2">Loading vehicles...</p>
//                   </div>
//                 )}

//                 {/* Error State */}
//                 {error && !loading && (
//                   <Alert color="danger" className="mb-4">
//                     <h5 className="alert-heading">Error</h5>
//                     <p>{error}</p>
//                     <Button
//                       color="danger"
//                       size="sm"
//                       onClick={() => window.location.reload()}
//                     >
//                       Retry
//                     </Button>
//                   </Alert>
//                 )}

//                 {/* Vehicle Table */}
//                 {!loading && !error && (
//                   <>
//                     <div className="table-responsive">
//                       <Table hover className="vehicle-table mb-0">
//                         <thead>
//                           <tr>
//                             <th>ID</th>
//                             <th>Type</th>
//                             <th>Make</th>
//                             <th>Model</th>
//                             <th>Year</th>
//                             <th>Reg No.</th>
//                             <th>KM Reading</th>
//                             <th>Chassis No.</th>
//                             <th>Status</th>
//                             <th>Actions</th>
//                           </tr>
//                         </thead>
//                         <tbody>
//                           {paginatedVehicles.length === 0 ? (
//                             <tr>
//                               <td colSpan={10} className="text-center py-4">
//                                 {vehicles.length === 0
//                                   ? "No vehicles found. Add your first vehicle!"
//                                   : "No vehicles match your search criteria."}
//                               </td>
//                             </tr>
//                           ) : (
//                             paginatedVehicles.map((vehicle, index) => (
//                               <tr key={vehicle.id}>
//                                 <td>
//                                   <strong>
//                                     #
//                                     {(currentPage - 1) * itemsPerPage +
//                                       index +
//                                       1}
//                                   </strong>
//                                 </td>
//                                 <td>{vehicle.vehicle_type}</td>
//                                 <td>{vehicle.make}</td>
//                                 <td>{vehicle.model}</td>
//                                 <td>{vehicle.year}</td>
//                                 <td>
//                                   <span className="badge bg-light text-muted">
//                                     {vehicle.registration_number}
//                                   </span>
//                                 </td>
//                                 <td>
//                                   {parseInt(
//                                     vehicle.km_reading
//                                   ).toLocaleString()}{" "}
//                                   km
//                                 </td>
//                                 <td>{vehicle.chassis_number}</td>
//                                 <td>
//                                   {renderStatusBadge(
//                                     vehicle.status || "active"
//                                   )}
//                                 </td>
//                                 <td>
//                                   <div className="d-flex gap-1 flex-wrap">
//                                     {/* <button
//                                       className="action-btn text-white border btn-primary"
//                                       onClick={() =>
//                                         router.push(`/admin/vehicles/${vehicle.id}`)
//                                       }
//                                       title="View"
//                                     >
//                                       <i className="fa fa-eye"></i>
//                                     </button> */}

//                                     {/* view button */}
//                                     <Link
//                                       href={`/admin/vehicles/${vehicle.id}`}
//                                     >
//                                       <button
//                                         className="action-btn text-white border btn-primary"
//                                         title="View Details"
//                                       >
//                                         <i className="fa fa-eye"></i>
//                                       </button>
//                                     </Link>

//                                     {/* edit button */}
//                                     <button
//                                       className="action-btn text-white border btn-warning"
//                                       onClick={() =>
//                                         router.push(
//                                           `/admin/vehicles/add?id=${vehicle.id}`
//                                         )
//                                       }
//                                       title="Edit"
//                                     >
//                                       <i className="icofont icofont-pencil-alt-5"></i>
//                                     </button>

//                                     {/* delete button */}
//                                     <button
//                                       className="action-btn text-white border btn-danger"
//                                       onClick={() =>
//                                         handleDeleteVehicle(vehicle.id)
//                                       }
//                                       title="Delete"
//                                     >
//                                       <i className="icofont icofont-ui-delete"></i>
//                                     </button>
//                                   </div>
//                                 </td>
//                               </tr>
//                             ))
//                           )}
//                         </tbody>
//                       </Table>
//                     </div>

//                     {/* Pagination */}
//                     {filteredVehicles.length > 0 && (
//                       <div className="d-flex flex-column flex-md-row justify-content-between align-items-center gap-3 mt-4">
//                         <div className="text-center text-md-start text-muted">
//                           Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
//                           {Math.min(
//                             currentPage * itemsPerPage,
//                             filteredVehicles.length
//                           )}{" "}
//                           of {filteredVehicles.length} entries
//                         </div>
//                         <CustomPagination
//                           currentPage={currentPage}
//                           totalPages={totalPages}
//                           onPageChange={setCurrentPage}
//                           showFirstLast={true}
//                           maxVisiblePages={5}
//                           paginationType="primary"
//                           className="justify-content-center justify-content-md-end"
//                         />
//                       </div>
//                     )}
//                   </>
//                 )}
//               </CardBody>
//             </Card>
//           </Col>
//         </Row>
//       </Container>

//       <style jsx>{`
//         .vehicle-card {
//           box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
//           border: 1px solid rgba(0, 0, 0, 0.125);
//         }

//         .action-btn {
//           padding: 0.25rem 0.5rem;
//           border-radius: 5px;
//           font-size: 0.75rem;
//         }

//         .vehicle-table {
//           font-size: 0.875rem;
//         }

//         .vehicle-table td {
//           vertical-align: middle;
//         }

//         @media (max-width: 768px) {
//           .vehicle-card .card-body {
//             padding: 1rem;
//           }

//           .table-responsive {
//             border: 1px solid #dee2e6;
//             border-radius: 0.375rem;
//           }

//           .vehicle-table {
//             min-width: 800px;
//           }
//         }
//       `}</style>
//     </div>
//   );
// }

// export default VehiclePage;

"use client";
import Breadcrumbs from "@/CommonElements/Breadcrumbs";
import CustomPagination from "@/CommonElements/Pagination";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  Input,
  Button,
  Table,
  Spinner,
  Alert,
} from "reactstrap";
import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useAuth } from "@/helper/AuthContext";
import { toast } from "react-toastify";
import withAuth from "@/helper/WithAuth";

// Vehicle Type based on API response
interface Vehicle {
  id: string;
  customer_id: string;
  vehicle_type: string | null;
  make: string | null;
  model: string;
  year: string;
  registration_number: string;
  chassis_number: string | null;
  engine_number: string | null;
  km_reading: string | null;
  meta: string;
  created_at: string;
  updated_at: string;
  customer_name: string; // Added this field from API response
  status?: "active" | "inactive" | "pending"; // Optional field for UI
}

// API Response Type
interface ApiResponse {
  data: Vehicle[];
}

function VehiclePage() {
  const { state } = useAuth();

  const router = useRouter();
  const [currentPage, setCurrentPage] = useState(1);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const itemsPerPage = 5;

  // Fetch vehicles from API
  useEffect(() => {
    fetchVehicles();
  }, []);

  const fetchVehicles = async () => {
    try {
      setLoading(true);
      setError(null);

      const token = state?.accessToken || localStorage.getItem("token");
      if (!token) {
        toast.error("Authentication required. Please login again.");
        router.push("/login");
        return;
      }

      const response = await fetch("/api/vehicles", {
        method: "GET",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch vehicles: ${response.status}`);
      }

      const data: ApiResponse = await response.json();

      // Add a status field to each vehicle for UI purposes
      const vehiclesWithStatus = data.data.map((vehicle) => ({
        ...vehicle,
        status: "active" as const, // Default status, adjust based on your business logic
      }));

      setVehicles(vehiclesWithStatus);
    } catch (err) {
      console.error("Error fetching vehicles:", err);
      setError(err instanceof Error ? err.message : "Failed to load vehicles");
      toast.error("Failed to load vehicles. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  // Helper function to safely check string inclusion with null handling
  const safeIncludes = (value: string | null, search: string): boolean => {
    if (!value) return false;
    return value.toLowerCase().includes(search.toLowerCase());
  };

  // Filter vehicles based on search & status
  const filteredVehicles = vehicles.filter((vehicle) => {
    const searchLower = searchTerm.toLowerCase();

    const matchesSearch =
      safeIncludes(vehicle.make, searchTerm) ||
      safeIncludes(vehicle.model, searchTerm) ||
      safeIncludes(vehicle.registration_number, searchTerm) ||
      safeIncludes(vehicle.chassis_number, searchTerm) ||
      safeIncludes(vehicle.vehicle_type, searchTerm) ||
      safeIncludes(vehicle.customer_name, searchTerm) ||
      safeIncludes(vehicle.year, searchTerm);

    const matchesStatus =
      statusFilter === "all" || vehicle.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  // Delete vehicle
  const handleDeleteVehicle = async (id: string) => {
    if (!confirm("Are you sure you want to delete this vehicle?")) {
      return;
    }

    try {
      const token = state?.accessToken || localStorage.getItem("token");
      const response = await fetch(`/api/vehicles/${id}`, {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      if (response.ok) {
        toast.success("Vehicle Deleted Successfully");
        // Refresh the list
        fetchVehicles();
      } else {
        const errorData = await response.json();
        toast.error(
          errorData.message || "Failed to Delete Vehicle! Please try again..."
        );
      }
    } catch (error: any) {
      console.error("Error deleting Vehicle", error);
      toast.error("Failed to Delete Vehicle! Please try again.");
    }
  };

  // Pagination logic
  const totalPages = Math.max(
    1,
    Math.ceil(filteredVehicles.length / itemsPerPage)
  );
  const paginatedVehicles = filteredVehicles.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  // Status badge renderer
  const renderStatusBadge = (value: string) => {
    const statusConfig = {
      active: { class: "bg-success", label: "Active" },
      inactive: { class: "bg-secondary", label: "Inactive" },
      pending: { class: "bg-warning", label: "Pending" },
    };

    const config = statusConfig[value as keyof typeof statusConfig] || {
      class: "bg-secondary",
      label: value,
    };

    return (
      <span className={`badge ${config.class} text-white`}>{config.label}</span>
    );
  };

  // Format KM reading with null handling
  const formatKmReading = (kmReading: string | null) => {
    if (!kmReading || kmReading === "0") return "0 km";

    try {
      const kmNum = parseInt(kmReading);
      if (isNaN(kmNum)) return "N/A";
      return `${kmNum.toLocaleString()} km`;
    } catch {
      return "N/A";
    }
  };

  // Format null values for display
  const formatNullable = (value: string | null) => {
    return value || <span className="text-muted">-</span>;
  };

  // Handle page reset when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, statusFilter]);

  return (
    <div className="page-body">
      <Breadcrumbs
        title="Vehicle Management"
        mainTitle="Vehicle Management"
        parent="Dashboard"
      />

      <Container fluid>
        <Row>
          <Col sm={12}>
            <Card className="vehicle-card">
              <CardBody>
                {/* Search, Filter and Add Button */}
                <div className="row align-items-center mb-4 g-3">
                  {/* Search Bar */}
                  <div className="col-12 col-md-3">
                    <div className="position-relative">
                      <Input
                        type="search"
                        placeholder="Search vehicles..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="form-control"
                      />
                      {searchTerm.length === 0 && (
                        <i
                          className="fa fa-search position-absolute"
                          style={{
                            right: "10px",
                            top: "50%",
                            transform: "translateY(-50%)",
                            color: "#aaa",
                          }}
                        ></i>
                      )}
                    </div>
                  </div>

                  {/* Status Filter */}
                  <div className="col-12 col-md-3">
                    <Input
                      type="select"
                      value={statusFilter}
                      onChange={(e) => setStatusFilter(e.target.value)}
                      className="form-control"
                    >
                      <option value="all">All Status</option>
                      <option value="active">Active</option>
                      <option value="inactive">Inactive</option>
                      <option value="pending">Pending</option>
                    </Input>
                  </div>

                  {/* Spacer */}
                  <div className="d-none d-md-block col-md-3"></div>

                  {/* Add Vehicle Button */}
                  <div className="col-12 col-md-3 d-flex justify-content-md-end">
                    <Link
                      href="/admin/vehicles/add"
                      className="w-100 w-md-auto"
                    >
                      <Button color="primary" className="w-100 w-md-auto">
                        <i className="fa fa-plus me-2"></i>
                        Add Vehicle
                      </Button>
                    </Link>
                  </div>
                </div>

                {/* Loading State */}
                {loading && (
                  <div className="text-center py-5">
                    <Spinner color="primary" />
                    <p className="mt-2">Loading vehicles...</p>
                  </div>
                )}

                {/* Error State */}
                {error && !loading && (
                  <Alert color="danger" className="mb-4">
                    <h5 className="alert-heading">Error</h5>
                    <p>{error}</p>
                    <Button
                      color="danger"
                      size="sm"
                      onClick={() => fetchVehicles()}
                    >
                      Retry
                    </Button>
                  </Alert>
                )}

                {/* Vehicle Table */}
                {!loading && !error && (
                  <>
                    <div className="table-responsive">
                      <Table hover className="vehicle-table mb-0">
                        <thead>
                          <tr>
                            <th>#</th>
                            <th>Customer</th>
                            <th>Type</th>
                            <th>Make</th>
                            <th>Model</th>
                            <th>Year</th>
                            <th>Reg No.</th>
                            <th>KM Reading</th>
                            <th>Chassis No.</th>
                            {/* <th>Status</th> */}
                            <th>Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {paginatedVehicles.length === 0 ? (
                            <tr>
                              <td colSpan={11} className="text-center py-4">
                                {vehicles.length === 0
                                  ? "No vehicles found. Add your first vehicle!"
                                  : "No vehicles match your search criteria."}
                              </td>
                            </tr>
                          ) : (
                            paginatedVehicles.map((vehicle, index) => (
                              <tr key={vehicle.id}>
                                <td>
                                  <strong>
                                    {(currentPage - 1) * itemsPerPage +
                                      index +
                                      1}
                                  </strong>
                                </td>
                                <td>
                                  <small className="text-muted">
                                    {formatNullable(vehicle.customer_name)}
                                  </small>
                                </td>
                                <td>{formatNullable(vehicle.vehicle_type)}</td>
                                <td>{formatNullable(vehicle.make)}</td>
                                <td>{vehicle.model}</td>
                                <td>{formatNullable(vehicle.year)}</td>
                                <td>
                                  <span className="badge bg-light text-muted">
                                    {vehicle.registration_number}
                                  </span>
                                </td>
                                <td>{formatKmReading(vehicle.km_reading)}</td>
                                <td>
                                  {formatNullable(vehicle.chassis_number)}
                                </td>
                                {/* <td>
                                  {renderStatusBadge(
                                    vehicle.status || "active"
                                  )}
                                </td> */}
                                <td>
                                  <div className="d-flex gap-1 flex-wrap">
                                    {/* View button */}
                                    <Link
                                      href={`/admin/vehicles/${vehicle.id}`}
                                    >
                                      <button
                                        className="action-btn text-white border btn-primary"
                                        title="View Details"
                                      >
                                        <i className="fa fa-eye"></i>
                                      </button>
                                    </Link>

                                    {/* Edit button */}
                                    <button
                                      className="action-btn text-white border btn-warning"
                                      onClick={() =>
                                        router.push(
                                          `/admin/vehicles/add?id=${vehicle.id}`
                                        )
                                      }
                                      title="Edit"
                                    >
                                      <i className="icofont icofont-pencil-alt-5"></i>
                                    </button>

                                    {/* Delete button */}
                                    <button
                                      className="action-btn text-white border btn-danger"
                                      onClick={() =>
                                        handleDeleteVehicle(vehicle.id)
                                      }
                                      title="Delete"
                                    >
                                      <i className="icofont icofont-ui-delete"></i>
                                    </button>
                                  </div>
                                </td>
                              </tr>
                            ))
                          )}
                        </tbody>
                      </Table>
                    </div>

                    {/* Pagination */}
                    {filteredVehicles.length > 0 && (
                      <div className="d-flex flex-column flex-md-row justify-content-between align-items-center gap-3 mt-4">
                        <div className="text-center text-md-start text-muted">
                          Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
                          {Math.min(
                            currentPage * itemsPerPage,
                            filteredVehicles.length
                          )}{" "}
                          of {filteredVehicles.length} entries
                        </div>
                        <CustomPagination
                          currentPage={currentPage}
                          totalPages={totalPages}
                          onPageChange={setCurrentPage}
                          showFirstLast={true}
                          maxVisiblePages={5}
                          paginationType="primary"
                          className="justify-content-center justify-content-md-end"
                        />
                      </div>
                    )}
                  </>
                )}
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Container>

      <style jsx>{`
        .vehicle-card {
          box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
          border: 1px solid rgba(0, 0, 0, 0.125);
        }

        .action-btn {
          padding: 0.25rem 0.5rem;
          border-radius: 5px;
          font-size: 0.75rem;
          border: none;
          cursor: pointer;
          transition: opacity 0.2s;
        }

        .action-btn:hover {
          opacity: 0.9;
        }

        .vehicle-table {
          font-size: 0.875rem;
        }

        .vehicle-table td {
          vertical-align: middle;
        }

        @media (max-width: 768px) {
          .vehicle-card .card-body {
            padding: 1rem;
          }

          .table-responsive {
            border: 1px solid #dee2e6;
            border-radius: 0.375rem;
            overflow-x: auto;
          }

          .vehicle-table {
            min-width: 1000px;
          }
        }
      `}</style>
    </div>
  );
}

// export default VehiclePage;
export default withAuth(VehiclePage, ["admin"]);
