// "use client";
// import Breadcrumbs from "@/CommonElements/Breadcrumbs";
// import ActivityCard from "@/components/dashboard/Default/ActivityCard";
// import GreetingCard from "@/components/dashboard/Default/GreetingCard";
// import OverBalance from "@/components/dashboard/Default/OverBalance";
// import PaperNote from "@/components/dashboard/Default/PaperNote";
// import PreAccountCard from "@/components/dashboard/Default/PreAcoountCard/Index";
// import RecentJobcardList from "@/components/dashboard/Default/RecentJobcardList";
// import RecentOrders from "@/components/dashboard/Default/RecentOrders";
// import RecentSales from "@/components/dashboard/Default/RecentSales";
// import TimeLineCard from "@/components/dashboard/Default/TimeLineCard";
// import TotalUserAndFollower from "@/components/dashboard/Default/TotalUserAndFollower";
// import GoodsReturn from "@/components/dashboard/Default/WidgetsWrapper/GoodsReturn";
// import OrderProfit from "@/components/dashboard/Default/WidgetsWrapper/OrderProfit";
// import SalePurchase from "@/components/dashboard/Default/WidgetsWrapper/SalePurchase";
// import { Dashboard, Default_Util } from "@/utils/Constant";
// import React from "react";
// import { Container, Row } from "reactstrap";

// const AdminDashboard = () => {
//   return (
//     <div className="page-body">
//       <Breadcrumbs
//         title={Default_Util}
//         mainTitle={Default_Util}
//         parent={Dashboard}
//       />
//       <Container fluid={true}>
//         <Row className="widget-grid">
//           <GreetingCard />
//           <SalePurchase />
//           <GoodsReturn />
//           <OrderProfit />
//           <RecentJobcardList />
//           <OverBalance />
//           <RecentOrders />
//           <ActivityCard />
//           <RecentSales />
//           <TimeLineCard />
//           <PreAccountCard />
//           <TotalUserAndFollower />
//           <PaperNote />
//         </Row>
//       </Container>
//     </div>
//   );
// };

// export default AdminDashboard;

// "use client";
// import Breadcrumbs from "@/CommonElements/Breadcrumbs";
// import ActivityCard from "@/components/dashboard/Default/ActivityCard";
// import GreetingCard from "@/components/dashboard/Default/GreetingCard";
// import OverBalance from "@/components/dashboard/Default/OverBalance";
// import PaperNote from "@/components/dashboard/Default/PaperNote";
// import PreAccountCard from "@/components/dashboard/Default/PreAcoountCard/Index";
// import RecentJobcardList from "@/components/dashboard/Default/RecentJobcardList";
// import RecentOrders from "@/components/dashboard/Default/RecentOrders";
// import RecentSales from "@/components/dashboard/Default/RecentSales";
// import TimeLineCard from "@/components/dashboard/Default/TimeLineCard";
// import TotalUserAndFollower from "@/components/dashboard/Default/TotalUserAndFollower";
// import GoodsReturn from "@/components/dashboard/Default/WidgetsWrapper/GoodsReturn";
// import OrderProfit from "@/components/dashboard/Default/WidgetsWrapper/OrderProfit";
// import SalePurchase from "@/components/dashboard/Default/WidgetsWrapper/SalePurchase";
// import { useAuth } from "@/helper/AuthContext";
// import withAuth from "@/helper/WithAuth";
// import { Dashboard, Default_Util } from "@/utils/Constant";
// import { useRouter } from "next/navigation";
// import React, { useEffect, useState } from "react";
// import { toast } from "react-toastify";
// import { Container, Row } from "reactstrap";

// interface DashboardData {
//   active_jobs: number;
//   pending_invoice: number;
//   revenu_month: number;
//   jobs_in_progress: number;
// }

// const AdminDashboard = () => {
//   const { state } = useAuth();
//   const router = useRouter();
//   const [dashboardData, setDashboardData] = useState<DashboardData | null>(
//     null
//   );
//   const [loading, setLoading] = useState(true);

//   useEffect(() => {
//     fetchDashboardData();
//   }, []);

//   const fetchDashboardData = async () => {
//     try {
//       setLoading(true);
//       const token = localStorage.getItem("token");

//       if (!token) {
//         toast.error("Authentication required. Please login again.");
//         router.push("/login");
//         return;
//       }

//       const response = await fetch("/api/dashboard", {
//         method: "GET",
//         headers: {
//           Authorization: `Bearer ${
//             state?.accessToken || localStorage.getItem("token")
//           }`,
//           "Content-Type": "application/json",
//         },
//       });

//       if (!response.ok) {
//         throw new Error(`API error: ${response.status}`);
//       }

//       const data = await response.json();

//       if (data.data && typeof data.data === "object") {
//         setDashboardData(data.data);
//       } else {
//         toast.error("Invalid data format received from API");
//         setDashboardData(null);
//       }
//     } catch (error: any) {
//       console.error("Error fetching dashboard data:", error);
//       toast.error(`Failed to load dashboard: ${error.message}`);
//       setDashboardData(null);
//     } finally {
//       setLoading(false);
//     }
//   };

//   if (loading) {
//     return (
//       <div className="page-body">
//         <Breadcrumbs
//           title={Default_Util}
//           mainTitle={Default_Util}
//           parent={Dashboard}
//         />
//         <Container fluid={true}>
//           <Row className="justify-content-center py-5">
//             <div className="text-center">
//               <div className="spinner-border text-primary" role="status">
//                 <span className="visually-hidden">Loading...</span>
//               </div>
//               <p className="mt-3">Loading dashboard data...</p>
//             </div>
//           </Row>
//         </Container>
//       </div>
//     );
//   }

//   return (
//     <div className="page-body">
//       <Breadcrumbs
//         title={Default_Util}
//         mainTitle={Default_Util}
//         parent={Dashboard}
//       />
//       <Container fluid={true}>
//         <Row className="widget-grid">
//           <GreetingCard />
//           <SalePurchase
//             revenue={dashboardData?.revenu_month}
//             activeJobs={dashboardData?.active_jobs}
//           />
//           <GoodsReturn
//             pendingInvoices={dashboardData?.pending_invoice}
//             jobsInProgress={dashboardData?.jobs_in_progress}
//           />
//           <OrderProfit />
//           <RecentJobcardList />
//           <OverBalance />
//           <RecentOrders />
//           <ActivityCard />
//           <RecentSales />
//           <TimeLineCard />
//           <PreAccountCard />
//           <TotalUserAndFollower />
//           <PaperNote />
//         </Row>
//       </Container>
//     </div>
//   );
// };

// // export default AdminDashboard;
// export default withAuth(AdminDashboard, ["admin"]);

// og*****
// "use client";
// import Breadcrumbs from "@/CommonElements/Breadcrumbs";
// import ActivityCard from "@/components/dashboard/Default/ActivityCard";
// import GreetingCard from "@/components/dashboard/Default/GreetingCard";
// import OverBalance from "@/components/dashboard/Default/OverBalance";
// import PaperNote from "@/components/dashboard/Default/PaperNote";
// import PreAccountCard from "@/components/dashboard/Default/PreAcoountCard/Index";
// import RecentJobcardList from "@/components/dashboard/Default/RecentJobcardList";
// import RecentOrders from "@/components/dashboard/Default/RecentOrders";
// import RecentSales from "@/components/dashboard/Default/RecentSales";
// import TimeLineCard from "@/components/dashboard/Default/TimeLineCard";
// import TotalUserAndFollower from "@/components/dashboard/Default/TotalUserAndFollower";
// import GoodsReturn from "@/components/dashboard/Default/WidgetsWrapper/GoodsReturn";
// import OrderProfit from "@/components/dashboard/Default/WidgetsWrapper/OrderProfit";
// import SalePurchase from "@/components/dashboard/Default/WidgetsWrapper/SalePurchase";
// import { useAuth } from "@/helper/AuthContext";
// import withAuth from "@/helper/WithAuth";
// import { Dashboard, Default_Util } from "@/utils/Constant";
// import { useRouter } from "next/navigation";
// import React, { useEffect, useState } from "react";
// import { toast } from "react-toastify";
// import { Container, Row } from "reactstrap";

// interface JobCard {
//   id: string;
//   job_number: string;
//   customer_name: string;
//   registration_number: string;
//   status: string;
//   total_estimate: string;
//   created_by_user: string;
//   assigned_to_user: string | null;
//   vehicle_id: string;
//   // Add other fields as needed
// }

// interface DashboardData {
//   active_jobs: number;
//   pending_invoice: number;
//   revenu_month: number;
//   jobs_in_progress: number;
//   recent_job_cards: JobCard[];
//   jobs_per_day: number;
//   jobs_per_month: number;
//   jobs_per_week: number;
//   technician_performance: any[];
// }

// const AdminDashboard = () => {
//   const { state } = useAuth();
//   const router = useRouter();
//   const [dashboardData, setDashboardData] = useState<DashboardData | null>(
//     null
//   );
//   const [loading, setLoading] = useState(true);

//   useEffect(() => {
//     fetchDashboardData();
//   }, []);

//   const fetchDashboardData = async () => {
//     try {
//       setLoading(true);
//       const token = localStorage.getItem("token");

//       if (!token) {
//         toast.error("Authentication required. Please login again.");
//         router.push("/login");
//         return;
//       }

//       const response = await fetch("/api/dashboard", {
//         method: "GET",
//         headers: {
//           Authorization: `Bearer ${
//             state?.accessToken || localStorage.getItem("token")
//           }`,
//           "Content-Type": "application/json",
//         },
//       });

//       if (!response.ok) {
//         throw new Error(`API error: ${response.status}`);
//       }

//       const data = await response.json();

//       if (data.data && typeof data.data === "object") {
//         setDashboardData(data.data);
//       } else {
//         toast.error("Invalid data format received from API");
//         setDashboardData(null);
//       }
//     } catch (error: any) {
//       console.error("Error fetching dashboard data:", error);
//       toast.error(`Failed to load dashboard: ${error.message}`);
//       setDashboardData(null);
//     } finally {
//       setLoading(false);
//     }
//   };

//   if (loading) {
//     return (
//       <div className="page-body">
//         <Breadcrumbs
//           title={Default_Util}
//           mainTitle={Default_Util}
//           parent={Dashboard}
//         />
//         <Container fluid={true}>
//           <Row className="justify-content-center py-5">
//             <div className="text-center">
//               <div className="spinner-border text-primary" role="status">
//                 <span className="visually-hidden">Loading...</span>
//               </div>
//               <p className="mt-3">Loading dashboard data...</p>
//             </div>
//           </Row>
//         </Container>
//       </div>
//     );
//   }

//   return (
//     <div className="page-body">
//       <Breadcrumbs
//         title={Default_Util}
//         mainTitle={Default_Util}
//         parent={Dashboard}
//       />
//       <Container fluid={true}>
//         <Row className="widget-grid">
//           <GreetingCard />
//           <SalePurchase
//             revenue={dashboardData?.revenu_month}
//             activeJobs={dashboardData?.active_jobs}
//           />
//           <GoodsReturn
//             pendingInvoices={dashboardData?.pending_invoice}
//             jobsInProgress={dashboardData?.jobs_in_progress}
//           />
//           <OrderProfit />
//           <RecentJobcardList jobCards={dashboardData?.recent_job_cards || []} />
//           <OverBalance />
//           <RecentOrders />
//           <ActivityCard />
//           <RecentSales />
//           <TimeLineCard />
//           <PreAccountCard />
//           <TotalUserAndFollower />
//           <PaperNote />
//         </Row>
//       </Container>
//     </div>
//   );
// };

// export default withAuth(AdminDashboard, ["admin"]);

"use client";
import Breadcrumbs from "@/CommonElements/Breadcrumbs";
import ActivityCard from "@/components/dashboard/Default/ActivityCard";
import GreetingCard from "@/components/dashboard/Default/GreetingCard";
import OverBalance from "@/components/dashboard/Default/OverBalance";
import PaperNote from "@/components/dashboard/Default/PaperNote";
import PreAccountCard from "@/components/dashboard/Default/PreAcoountCard/Index";
import RecentJobcardList from "@/components/dashboard/Default/RecentJobcardList";
import RecentOrders from "@/components/dashboard/Default/RecentOrders";
import RecentSales from "@/components/dashboard/Default/RecentSales";
import TimeLineCard from "@/components/dashboard/Default/TimeLineCard";
import TotalUserAndFollower from "@/components/dashboard/Default/TotalUserAndFollower";
import GoodsReturn from "@/components/dashboard/Default/WidgetsWrapper/GoodsReturn";
import OrderProfit from "@/components/dashboard/Default/WidgetsWrapper/OrderProfit";
import SalePurchase from "@/components/dashboard/Default/WidgetsWrapper/SalePurchase";
import { useAuth } from "@/helper/AuthContext";
import withAuth from "@/helper/WithAuth";
import { Dashboard, Default_Util } from "@/utils/Constant";
import { useRouter } from "next/navigation";
import React, { useEffect, useState } from "react";
import { toast } from "react-toastify";
import { Container, Row } from "reactstrap";

interface JobCard {
  id: string;
  job_number: string;
  customer_name: string;
  registration_number: string;
  status: string;
  total_estimate: string;
  created_by_user: string;
  assigned_to_user: string | null;
  vehicle_id: string;
  created_at: string;
  updated_at: string;
}

interface TechnicianPerformance {
  assigned_to: string;
  total_jobs: string;
  assigned_username: string;
}

interface DashboardData {
  active_jobs: number;
  pending_invoice: number;
  revenu_month: number;
  jobs_in_progress: number;
  recent_job_cards: JobCard[];
  jobs_per_day: number;
  jobs_per_month: number;
  jobs_per_week: number;
  technician_performance: TechnicianPerformance[];
}

const AdminDashboard = () => {
  const { state } = useAuth();
  const router = useRouter();
  const [dashboardData, setDashboardData] = useState<DashboardData | null>(
    null
  );
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem("token");

      if (!token) {
        toast.error("Authentication required. Please login again.");
        router.push("/login");
        return;
      }

      const response = await fetch("/api/dashboard", {
        method: "GET",
        headers: {
          Authorization: `Bearer ${
            state?.accessToken || localStorage.getItem("token")
          }`,
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }

      const data = await response.json();

      if (data.data && typeof data.data === "object") {
        setDashboardData(data.data);
      } else {
        toast.error("Invalid data format received from API");
        setDashboardData(null);
      }
    } catch (error: any) {
      console.error("Error fetching dashboard data:", error);
      toast.error(`Failed to load dashboard: ${error.message}`);
      setDashboardData(null);
    } finally {
      setLoading(false);
    }
  };

  // Calculate derived statistics
  const calculateStats = () => {
    if (!dashboardData) return null;

    const completedJobs = dashboardData.recent_job_cards.filter(
      (job) => job.status === "completed"
    ).length;

    const pendingJobs = dashboardData.recent_job_cards.filter(
      (job) => job.status === "open" || job.status === "assigned"
    ).length;

    const totalRevenue = dashboardData.recent_job_cards.reduce((sum, job) => {
      return sum + parseFloat(job.total_estimate || "0");
    }, 0);

    const averageJobsPerDay = dashboardData.jobs_per_day;
    const averageJobsPerWeek = dashboardData.jobs_per_week;
    const totalJobsThisMonth = dashboardData.jobs_per_month;

    return {
      completedJobs,
      pendingJobs,
      totalRevenue,
      averageJobsPerDay,
      averageJobsPerWeek,
      totalJobsThisMonth,
    };
  };

  if (loading) {
    return (
      <div className="page-body">
        <Breadcrumbs
          title={Default_Util}
          mainTitle={Default_Util}
          parent={Dashboard}
        />
        <Container fluid={true}>
          <Row className="justify-content-center py-5">
            <div className="text-center">
              <div className="spinner-border text-primary" role="status">
                <span className="visually-hidden">Loading...</span>
              </div>
              <p className="mt-3">Loading dashboard data...</p>
            </div>
          </Row>
        </Container>
      </div>
    );
  }

  const stats = calculateStats();

  return (
    <div className="page-body">
      <Breadcrumbs
        title={Default_Util}
        mainTitle={Default_Util}
        parent={Dashboard}
      />
      <Container fluid={true}>
        <Row className="widget-grid">
          {/* Greeting Card - Show daily jobs and welcome */}
          <GreetingCard
            username={state?.user?.name || "Admin"}
            dailyJobs={dashboardData?.jobs_per_day || 0}
            totalJobsThisMonth={stats?.totalJobsThisMonth || 0}
          />
          {/* <GreetingCard /> */}
          {/* Sale Purchase - Show monthly revenue and active jobs */}
          <SalePurchase
            revenue={dashboardData?.revenu_month || 0}
            activeJobs={dashboardData?.active_jobs || 0}
          />
          {/* Goods Return - Show pending invoices and jobs in progress */}
          <GoodsReturn
            pendingInvoices={dashboardData?.pending_invoice || 0}
            jobsInProgress={dashboardData?.jobs_in_progress || 0}
          />

          <OrderProfit
            jobsPerDay={dashboardData?.jobs_per_day || 0}
            jobsPerMonth={dashboardData?.jobs_per_month || 0}
            jobsPerWeek={dashboardData?.jobs_per_week || 0}
          />
          {/* <OrderProfit /> */}
          {/* Recent Jobcard List - Show recent job cards */}
          <RecentJobcardList jobCards={dashboardData?.recent_job_cards || []} />

          {/* Activity Card - Show recent job activities */}
          <ActivityCard
            recentJobCards={dashboardData?.recent_job_cards?.slice(0, 5) || []}
            technicianPerformance={dashboardData?.technician_performance || []}
          />
          {/* Recent Sales - Show technician performance */}
          <RecentSales
            technicianPerformance={dashboardData?.technician_performance || []}
            recentJobCards={dashboardData?.recent_job_cards || []}
          />
          {/* TimeLine Card - Show job timeline */}
          <TimeLineCard
            recentJobCards={dashboardData?.recent_job_cards?.slice(0, 4) || []}
          />
        </Row>
      </Container>
    </div>
  );
};

export default withAuth(AdminDashboard, ["admin"]);
