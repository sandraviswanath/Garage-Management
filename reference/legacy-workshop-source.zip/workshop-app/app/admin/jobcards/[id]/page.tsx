// "use client";
// import Breadcrumbs from "@/CommonElements/Breadcrumbs";
// import {
//   Container,
//   Row,
//   Col,
//   Card,
//   CardBody,
//   Badge,
//   Button,
//   TabContent,
//   TabPane,
//   Nav,
//   NavItem,
//   NavLink,
//   Table,
//   Progress,
//   Input,
//   Spinner,
//   Alert,
// } from "reactstrap";
// import React, { useState, useEffect } from "react";
// import { useRouter } from "next/navigation";
// import { useAuth } from "@/helper/AuthContext";
// import { toast } from "react-toastify";

// // Types based on API response
// interface JobCardItem {
//   id: string;
//   job_card_id: string;
//   sequence: string;
//   description: string;
//   labor_hours: string;
//   labor_rate: string;
//   amount: string;
//   status: string;
//   assigned_to: string | null;
//   notes: string | null;
//   created_at: string;
//   updated_at: string;
// }

// interface JobCardPart {
//   id: string;
//   job_card_id: string;
//   part_id: string;
//   part_name: string;
//   quantity: string;
//   unit_price: string;
//   amount: string;
//   source: string;
//   created_at: string;
//   updated_at: string;
// }

// interface JobCardPayment {
//   id: string;
//   job_card_id: string;
//   amount: string;
//   payment_method: string;
//   transaction_id: string | null;
//   status: string;
//   created_at: string;
//   updated_at: string;
// }

// interface JobCardData {
//   id: string;
//   job_number: string;
//   customer_id: string;
//   vehicle_id: string;
//   created_by: string;
//   assigned_to: string;
//   assigned_to_user: string;
//   status: string;
//   reported_issue: string;
//   diagnosis: string | null;
//   labor_estimate: string;
//   parts_estimate: string;
//   total_estimate: string;
//   priority: string;
//   expected_completion: string;
//   actual_completion: string | null;
//   is_paid: string;
//   meta: string;
//   created_at: string;
//   updated_at: string;
//   customer_name: string;
//   registration_number: string;
//   created_by_user: string;
//   items: JobCardItem[];
//   parts: JobCardPart[];
//   payments: JobCardPayment[];
// }

// function JobCardDetailPage({ params }: { params: { id: string } }) {
//   const { state } = useAuth();
//   const router = useRouter();
//   const [activeTab, setActiveTab] = useState("1");
//   const [jobCard, setJobCard] = useState<JobCardData | null>(null);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState<string | null>(null);
//   const [updating, setUpdating] = useState<string | null>(null);
//   const [vehicleDetails, setVehicleDetails] = useState<any>(null);
//   const [technicianDetails, setTechnicianDetails] = useState<any>(null);

//   // Fetch job card data
//   useEffect(() => {
//     const fetchJobCard = async () => {
//       try {
//         setLoading(true);
//         setError(null);

//         const token = state?.accessToken || localStorage.getItem("token");
//         const response = await fetch(`/api/jobcards/${params.id}`, {
//           method: "GET",
//           headers: {
//             Authorization: `Bearer ${token}`,
//             "Content-Type": "application/json",
//           },
//         });

//         if (!response.ok) {
//           const errorData = await response.json();
//           throw new Error(errorData.message || "Failed to fetch job card");
//         }

//         const result = await response.json();

//         if (result.data) {
//           setJobCard(result.data);

//           // Fetch additional vehicle details if needed
//           if (result.data.vehicle_id) {
//             fetchVehicleDetails(result.data.vehicle_id);
//           }

//           // Fetch technician details if needed
//           if (result.data.assigned_to) {
//             fetchTechnicianDetails(result.data.assigned_to);
//           }
//         } else {
//           throw new Error("No data received");
//         }
//       } catch (err: any) {
//         console.error("Error fetching job card:", err);
//         setError(err.message || "An error occurred");
//         toast.error("Failed to load job card details");
//       } finally {
//         setLoading(false);
//       }
//     };

//     if (params.id) {
//       fetchJobCard();
//     }
//   }, [params.id]);

//   const fetchVehicleDetails = async (vehicleId: string) => {
//     try {
//       const token = state?.accessToken || localStorage.getItem("token");
//       const response = await fetch(`/api/vehicles/${vehicleId}`, {
//         headers: {
//           Authorization: `Bearer ${token}`,
//         },
//       });

//       if (response.ok) {
//         const data = await response.json();
//         setVehicleDetails(data.data);
//       }
//     } catch (err) {
//       console.error("Error fetching vehicle details:", err);
//     }
//   };

//   const fetchTechnicianDetails = async (technicianId: string) => {
//     try {
//       const token = state?.accessToken || localStorage.getItem("token");
//       const response = await fetch(`/api/technicians/${technicianId}`, {
//         headers: {
//           Authorization: `Bearer ${token}`,
//         },
//       });

//       if (response.ok) {
//         const data = await response.json();
//         setTechnicianDetails(data.data);
//       }
//     } catch (err) {
//       console.error("Error fetching technician details:", err);
//     }
//   };

//   const renderStatusBadge = (status: string) => {
//     const statusConfig: Record<string, { color: string; label: string }> = {
//       open: { color: "primary", label: "Open" },
//       in_progress: { color: "warning", label: "In Progress" },
//       completed: { color: "success", label: "Completed" },
//       // closed: { color: "success", label: "Closed" },
//       cancelled: { color: "danger", label: "Cancelled" },
//       pending: { color: "secondary", label: "Pending" },
//     };

//     const config = statusConfig[status.toLowerCase()] || {
//       color: "secondary",
//       label: status.charAt(0).toUpperCase() + status.slice(1),
//     };

//     return <Badge color={config.color}>{config.label}</Badge>;
//   };

//   const handleStatusChange = async (newStatus: string) => {
//     if (!jobCard) return;

//     try {
//       setUpdating("jobStatus");
//       const token = state?.accessToken || localStorage.getItem("token");

//       const response = await fetch(`/api/jobcards/${params.id}`, {
//         method: "PUT",
//         headers: {
//           "Content-Type": "application/json",
//           Authorization: `Bearer ${token}`,
//         },
//         body: JSON.stringify({ status: newStatus }),
//       });

//       if (response.ok) {
//         setJobCard({ ...jobCard, status: newStatus });
//         toast.success(`Job status updated to ${newStatus}`);
//       } else {
//         const errorData = await response.json();
//         throw new Error(errorData.message || "Failed to update status");
//       }
//     } catch (err: any) {
//       console.error("Error updating status:", err);
//       toast.error(err.message || "Failed to update status");
//     } finally {
//       setUpdating(null);
//     }
//   };

//   const handleTaskStatusChange = async (taskId: string, newStatus: string) => {
//     if (!jobCard) return;

//     try {
//       setUpdating(`task-${taskId}`);
//       const token = state?.accessToken || localStorage.getItem("token");

//       const response = await fetch(`/api/jobcard-items/${taskId}`, {
//         method: "PUT",
//         headers: {
//           "Content-Type": "application/json",
//           Authorization: `Bearer ${token}`,
//         },
//         body: JSON.stringify({ status: newStatus }),
//       });

//       if (response.ok) {
//         const updatedItems = jobCard.items.map((item) =>
//           item.id === taskId ? { ...item, status: newStatus } : item
//         );
//         setJobCard({ ...jobCard, items: updatedItems });
//         toast.success("Task status updated");
//       } else {
//         const errorData = await response.json();
//         throw new Error(errorData.message || "Failed to update task");
//       }
//     } catch (err: any) {
//       console.error("Error updating task status:", err);
//       toast.error(err.message || "Failed to update task");
//     } finally {
//       setUpdating(null);
//     }
//   };

//   const handleTaskNotesChange = async (
//     taskId: string,
//     e: React.ChangeEvent<HTMLInputElement>
//   ) => {
//     if (!jobCard) return;

//     const updatedItems = jobCard.items.map((t) =>
//       t.id === taskId ? { ...t, notes: e.target.value } : t
//     );
//     setJobCard({ ...jobCard, items: updatedItems });
//   };

//   const saveTaskNotes = async (taskId: string) => {
//     if (!jobCard) return;

//     const task = jobCard.items.find((item) => item.id === taskId);
//     if (!task) return;

//     try {
//       const token = state?.accessToken || localStorage.getItem("token");
//       await fetch(`/api/jobcard-items/${taskId}`, {
//         method: "PUT",
//         headers: {
//           "Content-Type": "application/json",
//           Authorization: `Bearer ${token}`,
//         },
//         body: JSON.stringify({ notes: task.notes }),
//       });
//       toast.success("Task notes saved");
//     } catch (err: any) {
//       console.error("Error saving task notes:", err);
//       toast.error("Failed to save notes");
//     }
//   };

//   const handleMarkAsPaid = async () => {
//     if (!jobCard) return;

//     try {
//       setUpdating("payment");
//       const token = state?.accessToken || localStorage.getItem("token");

//       const response = await fetch(`/api/jobcards/${params.id}`, {
//         method: "PUT",
//         headers: {
//           "Content-Type": "application/json",
//           Authorization: `Bearer ${token}`,
//         },
//         body: JSON.stringify({ is_paid: "1" }),
//       });

//       if (response.ok) {
//         setJobCard({ ...jobCard, is_paid: "1" });
//         toast.success("Job marked as paid");
//       } else {
//         const errorData = await response.json();
//         throw new Error(errorData.message || "Failed to update payment status");
//       }
//     } catch (err: any) {
//       console.error("Error marking as paid:", err);
//       toast.error(err.message || "Failed to update payment");
//     } finally {
//       setUpdating(null);
//     }
//   };

//   const handleMarkAsUnpaid = async () => {
//     if (!jobCard) return;

//     try {
//       setUpdating("payment");
//       const token = state?.accessToken || localStorage.getItem("token");

//       const response = await fetch(`/api/jobcards/${params.id}`, {
//         method: "PUT",
//         headers: {
//           "Content-Type": "application/json",
//           Authorization: `Bearer ${token}`,
//         },
//         body: JSON.stringify({ is_paid: "0" }),
//       });

//       if (response.ok) {
//         setJobCard({ ...jobCard, is_paid: "0" });
//         toast.success("Job marked as unpaid");
//       } else {
//         const errorData = await response.json();
//         throw new Error(errorData.message || "Failed to update payment status");
//       }
//     } catch (err: any) {
//       console.error("Error marking as unpaid:", err);
//       toast.error(err.message || "Failed to update payment");
//     } finally {
//       setUpdating(null);
//     }
//   };

//   // Calculate progress
//   const calculateProgress = () => {
//     if (!jobCard || !jobCard.items.length)
//       return { percentage: 0, completed: 0, total: 0 };

//     const completedTasks = jobCard.items.filter(
//       (item) => item.status === "completed"
//     ).length;
//     const totalTasks = jobCard.items.length;
//     const progressPercentage =
//       totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;

//     return {
//       percentage: progressPercentage,
//       completed: completedTasks,
//       total: totalTasks,
//     };
//   };

//   const formatDate = (dateString: string | null) => {
//     if (!dateString || dateString === "0000-00-00 00:00:00") return "Not set";
//     try {
//       return new Date(dateString).toLocaleDateString("en-US", {
//         year: "numeric",
//         month: "short",
//         day: "numeric",
//       });
//     } catch {
//       return "Invalid date";
//     }
//   };

//   const formatDateTime = (dateString: string | null) => {
//     if (!dateString || dateString === "0000-00-00 00:00:00") return "Not set";
//     try {
//       return new Date(dateString).toLocaleString("en-US", {
//         year: "numeric",
//         month: "short",
//         day: "numeric",
//         hour: "2-digit",
//         minute: "2-digit",
//       });
//     } catch {
//       return "Invalid date";
//     }
//   };

//   // Loading state
//   if (loading) {
//     return (
//       <div className="page-body">
//         <Container fluid>
//           <div className="text-center py-5">
//             <Spinner color="primary" />
//             <p className="mt-2">Loading job card details...</p>
//           </div>
//         </Container>
//       </div>
//     );
//   }

//   // Error state
//   if (error || !jobCard) {
//     return (
//       <div className="page-body">
//         <Breadcrumbs
//           title="Error"
//           mainTitle="Job Card Details"
//           parent="Job Card Management"
//         />
//         <Container fluid>
//           <Card>
//             <CardBody className="text-center py-5">
//               <i className="fa fa-exclamation-triangle fa-3x text-danger mb-3"></i>
//               <h4>Error Loading Job Card</h4>
//               <p className="text-muted">{error || "Job card not found"}</p>
//               <Button
//                 color="primary"
//                 onClick={() => router.push("/admin/jobcards")}
//               >
//                 Back to Job Cards
//               </Button>
//             </CardBody>
//           </Card>
//         </Container>
//       </div>
//     );
//   }

//   const {
//     percentage: progressPercentage,
//     completed: completedTasks,
//     total: totalTasks,
//   } = calculateProgress();

//   // Calculate totals
//   const laborTotal = jobCard.items.reduce(
//     (sum, item) => sum + parseFloat(item.amount),
//     0
//   );
//   const partsTotal = jobCard.parts.reduce(
//     (sum, part) => sum + parseFloat(part.amount),
//     0
//   );
//   const actualTotal = laborTotal + partsTotal;

//   return (
//     <div className="page-body">
//       <Breadcrumbs
//         title={`Job Card - ${jobCard.job_number}`}
//         mainTitle="Job Card Details"
//         parent="Job Card Management"
//       />

//       <Container fluid>
//         {/* Alert if data mismatch */}
//         {/* {parseFloat(jobCard.total_estimate) !== actualTotal && (
//           <Alert color="warning" className="mb-3">
//             <i className="fa fa-exclamation-triangle me-2"></i>
//             Note: Calculated total (${actualTotal.toFixed(2)}) differs from
//             estimated total (${parseFloat(jobCard.total_estimate).toFixed(2)})
//           </Alert>
//         )} */}

//         <Row>
//           <Col lg={8}>
//             {/* Job Card Info Card */}
//             <Card className="mb-4">
//               <CardBody>
//                 <div className="text-center mb-4">
//                   <h4 className="text-primary">{jobCard.job_number}</h4>
//                   {renderStatusBadge(jobCard.status)}

//                   {/* Add Estimated Total Display */}
//                   <div className="mt-3">
//                     <h5 className="text-dark">
//                       Total Estimated Amount:
//                       <span className="ms-2 text-primary">
//                         ₹{parseFloat(jobCard.total_estimate).toFixed(2)}
//                       </span>
//                     </h5>
//                     <small className="text-muted">
//                       (Labor: ₹{parseFloat(jobCard.labor_estimate).toFixed(2)} +
//                       Parts: ₹{parseFloat(jobCard.parts_estimate).toFixed(2)})
//                     </small>
//                   </div>
//                 </div>

//                 <div className="mb-3">
//                   <strong>Customer Information</strong>
//                   <div className="mt-2">
//                     <div className="d-flex justify-content-between py-2 border-bottom">
//                       <span>Name:</span>
//                       <span>{jobCard.customer_name || "N/A"}</span>
//                     </div>
//                     <div className="d-flex justify-content-between py-2 border-bottom">
//                       <span>Customer ID:</span>
//                       <span>{jobCard.customer_id}</span>
//                     </div>
//                   </div>
//                 </div>

//                 <div className="mb-3">
//                   <strong>Vehicle Information</strong>
//                   <div className="mt-2">
//                     <div className="d-flex justify-content-between py-2 border-bottom">
//                       <span>Registration No:</span>
//                       <span>{jobCard.registration_number || "N/A"}</span>
//                     </div>
//                     <div className="d-flex justify-content-between py-2 border-bottom">
//                       <span>Vehicle ID:</span>
//                       <span>{jobCard.vehicle_id}</span>
//                     </div>
//                     {vehicleDetails && (
//                       <>
//                         <div className="d-flex justify-content-between py-2 border-bottom">
//                           <span>Make/Model:</span>
//                           <span>
//                             {vehicleDetails.make || "N/A"}{" "}
//                             {vehicleDetails.model || ""}
//                           </span>
//                         </div>
//                         <div className="d-flex justify-content-between py-2">
//                           <span>Year:</span>
//                           <span>{vehicleDetails.year || "N/A"}</span>
//                         </div>
//                       </>
//                     )}
//                   </div>
//                 </div>

//                 <div className="mb-3">
//                   <strong>Job Information</strong>
//                   <div className="mt-2">
//                     <div className="d-flex justify-content-between py-2 border-bottom">
//                       <span>Created By:</span>
//                       <span>
//                         {jobCard.created_by_user ||
//                           "User " + jobCard.created_by}
//                       </span>
//                     </div>
//                     <div className="d-flex justify-content-between py-2 border-bottom">
//                       <span>Assigned To:</span>
//                       <span>
//                         {/* {technicianDetails?.name ||
//                           `Technician ${jobCard.assigned_to}`} */}
//                         {jobCard.assigned_to_user}
//                       </span>
//                     </div>
//                     {/* <div className="d-flex justify-content-between py-2 border-bottom">
//                       <span>Priority:</span>
//                       <Badge
//                         color={
//                           jobCard.priority === "1"
//                             ? "danger"
//                             : jobCard.priority === "2"
//                             ? "warning"
//                             : "info"
//                         }
//                       >
//                         {jobCard.priority === "1"
//                           ? "High"
//                           : jobCard.priority === "2"
//                           ? "Medium"
//                           : "Low"}
//                       </Badge>
//                     </div> */}
//                     <div className="d-flex justify-content-between py-2 border-bottom">
//                       <span>Created:</span>
//                       <span>{formatDateTime(jobCard.created_at)}</span>
//                     </div>
//                     <div className="d-flex justify-content-between py-2 border-bottom">
//                       <span>Expected Completion:</span>
//                       <span>{formatDate(jobCard.expected_completion)}</span>
//                     </div>

//                     <div className="d-flex justify-content-between py-2 border-bottom">
//                       <span>Total Estimated:</span>
//                       <span className="fw-bold text-primary">
//                         ₹{parseFloat(jobCard.total_estimate).toFixed(2)}
//                       </span>
//                     </div>
//                     <div className="d-flex justify-content-between py-2">
//                       <span>Payment Status:</span>
//                       <div className="d-flex align-items-center">
//                         <Badge
//                           color={
//                             jobCard.is_paid === "1" ? "success" : "warning"
//                           }
//                           className="me-2"
//                         >
//                           {jobCard.is_paid === "1" ? "Paid" : "Unpaid"}
//                         </Badge>
//                         {/* {jobCard.is_paid === "0" ? (
//                           <Button
//                             color="outline-success"
//                             size="sm"
//                             onClick={handleMarkAsPaid}
//                             disabled={updating === "payment"}
//                           >
//                             {updating === "payment" ? (
//                               <Spinner size="sm" />
//                             ) : (
//                               "Mark Paid"
//                             )}
//                           </Button>
//                         ) : (
//                           <Button
//                             color="outline-warning"
//                             size="sm"
//                             onClick={handleMarkAsUnpaid}
//                             disabled={updating === "payment"}
//                           >
//                             {updating === "payment" ? (
//                               <Spinner size="sm" />
//                             ) : (
//                               "Mark Unpaid"
//                             )}
//                           </Button>
//                         )} */}
//                       </div>
//                     </div>
//                   </div>
//                 </div>

//                 <div className="d-grid gap-2">
//                   <Button
//                     color="warning"
//                     onClick={() =>
//                       router.push(`/admin/jobcards/create?id=${jobCard.id}`)
//                     }
//                   >
//                     <i className="fa fa-edit me-2"></i>
//                     Edit Job Card
//                   </Button>
//                   <Button color="info" onClick={() => window.print()}>
//                     <i className="fa fa-print me-2"></i>
//                     Print Job Card
//                   </Button>
//                   <Button
//                     color="outline-primary"
//                     onClick={() => router.push("/admin/jobcards")}
//                   >
//                     <i className="fa fa-arrow-left me-2"></i>
//                     Back to List
//                   </Button>
//                 </div>
//               </CardBody>
//             </Card>

//             {/* Quick Actions Card */}
//             {/* <Card>
//               <CardBody>
//                 <h6 className="mb-3">Quick Actions</h6>
//                 <div className="d-grid gap-2">
//                   {jobCard.status !== "completed" &&
//                     jobCard.status !== "closed" && (
//                       <Button
//                         color="success"
//                         onClick={() => handleStatusChange("completed")}
//                         disabled={updating === "jobStatus"}
//                       >
//                         {updating === "jobStatus" ? (
//                           <Spinner size="sm" className="me-2" />
//                         ) : (
//                           <i className="fa fa-check me-2"></i>
//                         )}
//                         Mark as Completed
//                       </Button>
//                     )}

//                   {jobCard.status !== "in-progress" && (
//                     <Button
//                       color="warning"
//                       onClick={() => handleStatusChange("in-progress")}
//                       disabled={updating === "jobStatus"}
//                     >
//                       {updating === "jobStatus" ? (
//                         <Spinner size="sm" className="me-2" />
//                       ) : (
//                         <i className="fa fa-play me-2"></i>
//                       )}
//                       Start Progress
//                     </Button>
//                   )}

//                   <Button
//                     color="primary"
//                     onClick={() =>
//                       router.push(
//                         `/admin/invoices/create?job_card_id=${jobCard.id}`
//                       )
//                     }
//                   >
//                     <i className="fa fa-file-invoice me-2"></i>
//                     Create Invoice
//                   </Button>

//                   <Button
//                     color="info"
//                     onClick={() => {
//                       // TODO: Implement send update
//                       toast.info("Send update feature coming soon");
//                     }}
//                   >
//                     <i className="fa fa-envelope me-2"></i>
//                     Send Update
//                   </Button>
//                 </div>
//               </CardBody>
//             </Card> */}
//           </Col>

//           {/* <Col lg={8}>
//             <Card className="mb-4">
//               <CardBody>
//                 <div className="d-flex justify-content-between align-items-center mb-2">
//                   <h6 className="mb-0">Job Progress</h6>
//                   <span>
//                     {completedTasks}/{totalTasks} tasks completed
//                   </span>
//                 </div>
//                 <Progress
//                   value={progressPercentage}
//                   color={
//                     progressPercentage < 30
//                       ? "danger"
//                       : progressPercentage < 70
//                       ? "warning"
//                       : "success"
//                   }
//                   className="mb-2"
//                 />
//                 <small>{progressPercentage.toFixed(0)}% complete</small>
//               </CardBody>
//             </Card>
//             <Card>
//               <CardBody>
//                 <Nav tabs>
//                   <NavItem>
//                     <NavLink
//                       className={activeTab === "1" ? "active" : ""}
//                       onClick={() => setActiveTab("1")}
//                     >
//                       <i className="fa fa-info-circle me-1"></i>
//                       Overview
//                     </NavLink>
//                   </NavItem>
//                   <NavItem>
//                     <NavLink
//                       className={activeTab === "2" ? "active" : ""}
//                       onClick={() => setActiveTab("2")}
//                     >
//                       <i className="fa fa-tasks me-1"></i>
//                       Tasks ({jobCard.items.length})
//                     </NavLink>
//                   </NavItem>
//                   <NavItem>
//                     <NavLink
//                       className={activeTab === "3" ? "active" : ""}
//                       onClick={() => setActiveTab("3")}
//                     >
//                       <i className="fa fa-cogs me-1"></i>
//                       Parts ({jobCard.parts.length})
//                     </NavLink>
//                   </NavItem>
//                   <NavItem>
//                     <NavLink
//                       className={activeTab === "4" ? "active" : ""}
//                       onClick={() => setActiveTab("4")}
//                     >
//                       <i className="fa fa-credit-card me-1"></i>
//                       Payments ({jobCard.payments.length})
//                     </NavLink>
//                   </NavItem>
//                 </Nav>
//                 <TabContent activeTab={activeTab} className="pt-3">
//                   <TabPane tabId="1">
//                     <div className="mb-4">
//                       <h6>Reported Issue</h6>
//                       <Card>
//                         <CardBody>
//                           <p className="mb-0">
//                             {jobCard.reported_issue || "No issue reported"}
//                           </p>
//                         </CardBody>
//                       </Card>
//                     </div>

//                     {jobCard.diagnosis && (
//                       <div className="mb-4">
//                         <h6>Diagnosis</h6>
//                         <Card>
//                           <CardBody>
//                             <p className="mb-0 text-info">
//                               {jobCard.diagnosis}
//                             </p>
//                           </CardBody>
//                         </Card>
//                       </div>
//                     )}

//                     <div className="row text-center">
//                       <div className="col-md-3 mb-3">
//                         <Card
//                           className={`border-${
//                             actualTotal > parseFloat(jobCard.total_estimate)
//                               ? "warning"
//                               : "primary"
//                           }`}
//                         >
//                           <CardBody>
//                             <h4 className="text-primary">
//                               ${actualTotal.toFixed(2)}
//                             </h4>
//                             <p className="mb-0">Actual Total</p>
//                             <small className="text-muted">
//                               Est: $
//                               {parseFloat(jobCard.total_estimate).toFixed(2)}
//                             </small>
//                           </CardBody>
//                         </Card>
//                       </div>
//                       <div className="col-md-3 mb-3">
//                         <Card className="border-warning">
//                           <CardBody>
//                             <h4 className="text-warning">
//                               ${laborTotal.toFixed(2)}
//                             </h4>
//                             <p className="mb-0">Labor Cost</p>
//                             <small className="text-muted">
//                               Est: $
//                               {parseFloat(jobCard.labor_estimate).toFixed(2)}
//                             </small>
//                           </CardBody>
//                         </Card>
//                       </div>
//                       <div className="col-md-3 mb-3">
//                         <Card className="border-success">
//                           <CardBody>
//                             <h4 className="text-success">
//                               ${partsTotal.toFixed(2)}
//                             </h4>
//                             <p className="mb-0">Parts Cost</p>
//                             <small className="text-muted">
//                               Est: $
//                               {parseFloat(jobCard.parts_estimate).toFixed(2)}
//                             </small>
//                           </CardBody>
//                         </Card>
//                       </div>
//                       <div className="col-md-3 mb-3">
//                         <Card className="border-info">
//                           <CardBody>
//                             <h4 className="text-info">
//                               {jobCard.items.length}
//                             </h4>
//                             <p className="mb-0">Total Tasks</p>
//                             <small className="text-muted">
//                               {completedTasks} completed
//                             </small>
//                           </CardBody>
//                         </Card>
//                       </div>
//                     </div>
//                   </TabPane>

//                   <TabPane tabId="2">
//                     <div className="table-responsive">
//                       <Table bordered hover>
//                         <thead>
//                           <tr>
//                             <th>#</th>
//                             <th>Task Description</th>
//                             <th>Hours</th>
//                             <th>Rate</th>
//                             <th>Amount</th>
//                             <th>Status</th>
//                             <th>Notes</th>
//                           </tr>
//                         </thead>
//                         <tbody>
//                           {jobCard.items.map((task, index) => (
//                             <tr key={task.id}>
//                               <td>{index + 1}</td>
//                               <td>{task.description}</td>
//                               <td>{parseFloat(task.labor_hours).toFixed(2)}</td>
//                               <td>${parseFloat(task.labor_rate).toFixed(2)}</td>
//                               <td>${parseFloat(task.amount).toFixed(2)}</td>

//                               <td>{task.status}</td>
//                               <td>{task.notes}</td>
//                             </tr>
//                           ))}
//                         </tbody>
//                       </Table>
//                     </div>
//                   </TabPane>

//                   <TabPane tabId="3">
//                     <div className="table-responsive">
//                       <Table bordered hover>
//                         <thead>
//                           <tr>
//                             <th>Part ID</th>
//                             <th>Part Name</th>
//                             <th>Quantity</th>
//                             <th>Unit Price</th>
//                             <th>Total</th>
//                             <th>Source</th>
//                           </tr>
//                         </thead>
//                         <tbody>
//                           {jobCard.parts.length > 0 ? (
//                             jobCard.parts.map((part) => (
//                               <tr key={part.id}>
//                                 <td>{part.part_id}</td>
//                                 <td>{part.part_name || "Unnamed Part"}</td>
//                                 <td>{part.quantity}</td>
//                                 <td>
//                                   ${parseFloat(part.unit_price).toFixed(2)}
//                                 </td>
//                                 <td>${parseFloat(part.amount).toFixed(2)}</td>
//                                 <td>
//                                   <Badge
//                                     color={
//                                       part.source === "stock"
//                                         ? "success"
//                                         : "info"
//                                     }
//                                   >
//                                     {part.source}
//                                   </Badge>
//                                 </td>
//                               </tr>
//                             ))
//                           ) : (
//                             <tr>
//                               <td colSpan={6} className="text-center">
//                                 <div className="py-3 text-muted">
//                                   <i className="fa fa-box fa-2x mb-2"></i>
//                                   <p>No parts used in this job</p>
//                                 </div>
//                               </td>
//                             </tr>
//                           )}
//                           <tr className="table-primary">
//                             <td colSpan={4} className="text-end">
//                               <strong>Parts Total:</strong>
//                             </td>
//                             <td>
//                               <strong>${partsTotal.toFixed(2)}</strong>
//                             </td>
//                             <td></td>
//                           </tr>
//                         </tbody>
//                       </Table>
//                     </div>
//                   </TabPane>

//                   <TabPane tabId="4">
//                     <Table bordered hover>
//                       <thead>
//                         <tr>
//                           <th>Date</th>
//                           <th>Amount</th>
//                           <th>Method</th>
//                           <th>Transaction ID</th>
//                           <th>Status</th>
//                         </tr>
//                       </thead>
//                       <tbody>
//                         {jobCard.payments.length > 0 ? (
//                           jobCard.payments.map((payment) => (
//                             <tr key={payment.id}>
//                               <td>{formatDateTime(payment.created_at)}</td>
//                               <td>${parseFloat(payment.amount).toFixed(2)}</td>
//                               <td>{payment.payment_method || "-"}</td>
//                               <td>{payment.transaction_id || "-"}</td>
//                               <td>
//                                 <Badge
//                                   color={
//                                     payment.status === "completed"
//                                       ? "success"
//                                       : payment.status === "pending"
//                                       ? "warning"
//                                       : "danger"
//                                   }
//                                 >
//                                   {payment.status}
//                                 </Badge>
//                               </td>
//                             </tr>
//                           ))
//                         ) : (
//                           <tr>
//                             <td colSpan={5} className="text-center">
//                               <div className="py-3 text-muted">
//                                 <i className="fa fa-credit-card fa-2x mb-2"></i>
//                                 <p>No payments recorded</p>
//                                 <Button
//                                   color="primary"
//                                   size="sm"
//                                   onClick={() => {
//                                     toast.info(
//                                       "Add payment feature coming soon"
//                                     );
//                                   }}
//                                 >
//                                   Add Payment
//                                 </Button>
//                               </div>
//                             </td>
//                           </tr>
//                         )}
//                         {jobCard.payments.length > 0 && (
//                           <tr className="table-info">
//                             <td colSpan={1} className="text-end">
//                               <strong>Total Received:</strong>
//                             </td>
//                             <td>
//                               <strong>
//                                 $
//                                 {jobCard.payments
//                                   .reduce(
//                                     (sum, payment) =>
//                                       sum + parseFloat(payment.amount),
//                                     0
//                                   )
//                                   .toFixed(2)}
//                               </strong>
//                             </td>
//                             <td colSpan={3}></td>
//                           </tr>
//                         )}
//                       </tbody>
//                     </Table>
//                   </TabPane>
//                 </TabContent>
//               </CardBody>
//             </Card>
//           </Col> */}
//         </Row>
//       </Container>
//     </div>
//   );
// }

// export default JobCardDetailPage;

"use client";
import Breadcrumbs from "@/CommonElements/Breadcrumbs";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  Badge,
  Button,
  Table,
  Spinner,
  Alert,
} from "reactstrap";
import React, { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/helper/AuthContext";
import { toast } from "react-toastify";

// Types based on API response
interface JobCardItem {
  id: string;
  job_card_id: string;
  sequence: string;
  description: string;
  labor_hours: string;
  labor_rate: string;
  amount: string;
  status: string;
  assigned_to: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

interface JobCardPart {
  id: string;
  job_card_id: string;
  part_id: string;
  part_name: string;
  quantity: string;
  unit_price: string;
  amount: string;
  source: string;
  created_at: string;
  updated_at: string;
}

interface JobCardData {
  id: string;
  job_number: string;
  customer_id: string;
  vehicle_id: string;
  created_by: string;
  assigned_to: string;
  assigned_to_user: string;
  status: string;
  reported_issue: string;
  diagnosis: string | null;
  labor_estimate: string;
  parts_estimate: string;
  total_estimate: string;
  priority: string;
  expected_completion: string;
  actual_completion: string | null;
  is_paid: string;
  meta: string;
  created_at: string;
  updated_at: string;
  customer_name: string;
  registration_number: string;
  created_by_user: string;
  items: JobCardItem[];
  parts: JobCardPart[];
}

function JobCardDetailPage({ params }: { params: { id: string } }) {
  const { state } = useAuth();
  const router = useRouter();
  const [jobCard, setJobCard] = useState<JobCardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [vehicleDetails, setVehicleDetails] = useState<any>(null);

  // Fetch job card data
  useEffect(() => {
    const fetchJobCard = async () => {
      try {
        setLoading(true);
        setError(null);

        const token = state?.accessToken || localStorage.getItem("token");
        const response = await fetch(`/api/jobcards/${params.id}`, {
          method: "GET",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        });

        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.message || "Failed to fetch job card");
        }

        const result = await response.json();

        if (result.data) {
          setJobCard(result.data);

          // Fetch additional vehicle details if needed
          if (result.data.vehicle_id) {
            fetchVehicleDetails(result.data.vehicle_id);
          }
        } else {
          throw new Error("No data received");
        }
      } catch (err: any) {
        console.error("Error fetching job card:", err);
        setError(err.message || "An error occurred");
        toast.error("Failed to load job card details");
      } finally {
        setLoading(false);
      }
    };

    if (params.id) {
      fetchJobCard();
    }
  }, [params.id]);

  const fetchVehicleDetails = async (vehicleId: string) => {
    try {
      const token = state?.accessToken || localStorage.getItem("token");
      const response = await fetch(`/api/vehicles/${vehicleId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (response.ok) {
        const data = await response.json();
        setVehicleDetails(data.data);
      }
    } catch (err) {
      console.error("Error fetching vehicle details:", err);
    }
  };

  const renderStatusBadge = (status: string) => {
    const statusConfig: Record<string, { color: string; label: string }> = {
      open: { color: "primary", label: "Open" },
      in_progress: { color: "warning", label: "In Progress" },
      completed: { color: "success", label: "Completed" },
      cancelled: { color: "danger", label: "Cancelled" },
      pending: { color: "secondary", label: "Pending" },
    };

    const config = statusConfig[status.toLowerCase()] || {
      color: "secondary",
      label: status.charAt(0).toUpperCase() + status.slice(1),
    };

    return <Badge color={config.color}>{config.label}</Badge>;
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString || dateString === "0000-00-00 00:00:00") return "Not set";
    try {
      return new Date(dateString).toLocaleDateString("en-US", {
        year: "numeric",
        month: "short",
        day: "numeric",
      });
    } catch {
      return "Invalid date";
    }
  };

  const formatDateTime = (dateString: string | null) => {
    if (!dateString || dateString === "0000-00-00 00:00:00") return "Not set";
    try {
      return new Date(dateString).toLocaleString("en-US", {
        year: "numeric",
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      });
    } catch {
      return "Invalid date";
    }
  };

  // Calculate totals
  const laborTotal =
    jobCard?.items.reduce((sum, item) => sum + parseFloat(item.amount), 0) || 0;

  const partsTotal =
    jobCard?.parts.reduce((sum, part) => sum + parseFloat(part.amount), 0) || 0;

  const actualTotal = laborTotal + partsTotal;

  // Loading state
  if (loading) {
    return (
      <div className="page-body">
        <Container fluid>
          <div className="text-center py-5">
            <Spinner color="primary" />
            <p className="mt-2">Loading job card details...</p>
          </div>
        </Container>
      </div>
    );
  }

  // Error state
  if (error || !jobCard) {
    return (
      <div className="page-body">
        <Breadcrumbs
          title="Error"
          mainTitle="Job Card Details"
          parent="Job Card Management"
        />
        <Container fluid>
          <Card>
            <CardBody className="text-center py-5">
              <i className="fa fa-exclamation-triangle fa-3x text-danger mb-3"></i>
              <h4>Error Loading Job Card</h4>
              <p className="text-muted">{error || "Job card not found"}</p>
              <Button
                color="primary"
                onClick={() => router.push("/admin/jobcards")}
              >
                Back to Job Cards
              </Button>
            </CardBody>
          </Card>
        </Container>
      </div>
    );
  }

  return (
    <div className="page-body">
      <Breadcrumbs
        title={`Job Card - ${jobCard.job_number}`}
        mainTitle="Job Card Details"
        parent="Job Card Management"
      />

      <Container fluid>
        <Row>
          <Col lg={12}>
            {/* Print Button */}
            {/* <div className="d-flex justify-content-end mb-3 print:hidden">
              <Button color="primary" onClick={() => window.print()}>
                <i className="fa fa-print me-2"></i>
                Print Job Card
              </Button>
            </div> */}

            {/* Main Job Card for Print */}
            <Card className="job-card-print">
              <CardBody>
                {/* Header Section */}
                <div className="text-center mb-4 border-bottom pb-4">
                  {/* <h2 className="text-primary mb-1">JOB CARD</h2> */}
                  {/* <h4 className="text-dark mb-3">{jobCard.job_number}</h4> */}
                  <h4 className="text-primary">{jobCard.job_number}</h4>
                  {renderStatusBadge(jobCard.status)}

                  <div className="mt-3">
                    <h5 className="text-dark">
                      Total Estimated Amount:
                      <span className="ms-2 text-primary">
                        ₹{parseFloat(jobCard.total_estimate).toFixed(2)}
                      </span>
                    </h5>
                    <small className="text-muted">
                      (Labor: ₹{parseFloat(jobCard.labor_estimate).toFixed(2)} +
                      Parts: ₹{parseFloat(jobCard.parts_estimate).toFixed(2)})
                    </small>
                  </div>
                </div>

                {/* Customer and Vehicle Information */}
                <Row className="mb-4">
                  <Col md={6}>
                    <Card className="h-100">
                      <CardBody>
                        <h6 className="card-title text-primary mb-3">
                          <i className="fa fa-user me-2"></i>
                          CUSTOMER INFORMATION
                        </h6>
                        <div className="mb-2">
                          <strong>Name:</strong>
                          <span className="ms-2">
                            {jobCard.customer_name || "N/A"}
                          </span>
                        </div>
                        <div className="mb-2">
                          <strong>Customer ID:</strong>
                          <span className="ms-2">{jobCard.customer_id}</span>
                        </div>
                        <div>
                          <strong>Created By:</strong>
                          <span className="ms-2">
                            {jobCard.created_by_user ||
                              "User " + jobCard.created_by}
                          </span>
                        </div>
                      </CardBody>
                    </Card>
                  </Col>

                  <Col md={6}>
                    <Card className="h-100">
                      <CardBody>
                        <h6 className="card-title text-primary mb-3">
                          <i className="fa fa-car me-2"></i>
                          VEHICLE INFORMATION
                        </h6>
                        <div className="mb-2">
                          <strong>Registration No:</strong>
                          <span className="ms-2">
                            {jobCard.registration_number || "N/A"}
                          </span>
                        </div>
                        <div className="mb-2">
                          <strong>Vehicle ID:</strong>
                          <span className="ms-2">{jobCard.vehicle_id}</span>
                        </div>
                        {vehicleDetails && (
                          <>
                            <div className="mb-2">
                              <strong>Make/Model:</strong>
                              <span className="ms-2">
                                {vehicleDetails.make || "N/A"}{" "}
                                {vehicleDetails.model || ""}
                              </span>
                            </div>
                            <div>
                              <strong>Year:</strong>
                              <span className="ms-2">
                                {vehicleDetails.year || "N/A"}
                              </span>
                            </div>
                          </>
                        )}
                      </CardBody>
                    </Card>
                  </Col>
                </Row>

                {/* Job Details */}
                <Card className="mb-4">
                  <CardBody>
                    <h6 className="card-title text-primary mb-3">
                      <i className="fa fa-clipboard-list me-2"></i>
                      JOB DETAILS
                    </h6>
                    <Row>
                      <Col md={6}>
                        <div className="mb-2">
                          <strong>Assigned To:</strong>
                          <span className="ms-2">
                            {jobCard.assigned_to_user}
                          </span>
                        </div>
                        <div className="mb-2">
                          <strong>Priority:</strong>
                          <Badge
                            color={
                              jobCard.priority === "1"
                                ? "danger"
                                : jobCard.priority === "2"
                                ? "warning"
                                : "info"
                            }
                            className="ms-2"
                          >
                            {jobCard.priority === "1"
                              ? "High"
                              : jobCard.priority === "2"
                              ? "Medium"
                              : "Low"}
                          </Badge>
                        </div>
                      </Col>
                      <Col md={6}>
                        <div className="mb-2">
                          <strong>Created Date:</strong>
                          <span className="ms-2">
                            {formatDateTime(jobCard.created_at)}
                          </span>
                        </div>
                        <div className="mb-2">
                          <strong>Expected Completion:</strong>
                          <span className="ms-2">
                            {formatDate(jobCard.expected_completion)}
                          </span>
                        </div>
                      </Col>
                    </Row>

                    {/* Reported Issue */}
                    <div className="mt-3">
                      <strong>Reported Issue:</strong>
                      <Card
                        className="mt-2 bg-light"
                        style={{ color: "#8950fc" }}
                      >
                        <CardBody>
                          <p className="mb-0">
                            {jobCard.reported_issue || "No issue reported"}
                          </p>
                        </CardBody>
                      </Card>
                    </div>

                    {/* Diagnosis */}
                    {jobCard.diagnosis && (
                      <div className="mt-3">
                        <strong>Diagnosis:</strong>
                        <Card className="mt-2 bg-info bg-opacity-10">
                          <CardBody>
                            <p className="mb-0 text-info">
                              {jobCard.diagnosis}
                            </p>
                          </CardBody>
                        </Card>
                      </div>
                    )}
                  </CardBody>
                </Card>

                {/* Tasks/Items Table */}
                <Card className="mb-4">
                  <CardBody>
                    <h6 className="card-title text-primary mb-3">
                      <i className="fa fa-tasks me-2"></i>
                      WORK ITEMS ({jobCard.items.length})
                    </h6>
                    {jobCard.items.length > 0 ? (
                      <div className="table-responsive">
                        <Table bordered size="sm">
                          <thead className="table-light">
                            <tr>
                              <th>#</th>
                              <th>Description</th>
                              <th>Hours</th>
                              <th>Rate</th>
                              <th>Amount</th>
                              <th>Status</th>
                            </tr>
                          </thead>
                          <tbody>
                            {jobCard.items.map((task, index) => (
                              <tr key={task.id}>
                                <td>{index + 1}</td>
                                <td>{task.description}</td>
                                <td>
                                  {parseFloat(task.labor_hours).toFixed(2)}
                                </td>
                                <td>
                                  ₹{parseFloat(task.labor_rate).toFixed(2)}
                                </td>
                                <td>₹{parseFloat(task.amount).toFixed(2)}</td>
                                <td>
                                  <Badge
                                    color={
                                      task.status === "completed"
                                        ? "success"
                                        : task.status === "in_progress"
                                        ? "warning"
                                        : "info"
                                    }
                                  >
                                    {task.status}
                                  </Badge>
                                </td>
                              </tr>
                            ))}
                            <tr className="table-primary">
                              <td colSpan={4} className="text-end fw-bold">
                                Labor Total:
                              </td>
                              <td colSpan={2} className="fw-bold">
                                ₹{laborTotal.toFixed(2)}
                              </td>
                            </tr>
                          </tbody>
                        </Table>
                      </div>
                    ) : (
                      <div className="text-center py-3 text-muted">
                        <i className="fa fa-tasks fa-2x mb-2"></i>
                        <p>No work items added</p>
                      </div>
                    )}
                  </CardBody>
                </Card>

                {/* Parts Table */}
                <Card className="mb-4">
                  <CardBody>
                    <h6 className="card-title text-primary mb-3">
                      <i className="fa fa-cogs me-2"></i>
                      PARTS USED ({jobCard.parts.length})
                    </h6>
                    {jobCard.parts.length > 0 ? (
                      <div className="table-responsive">
                        <Table bordered size="sm">
                          <thead className="table-light">
                            <tr>
                              <th>Part ID</th>
                              <th>Part Name</th>
                              <th>Qty</th>
                              <th>Unit Price</th>
                              <th>Total</th>
                              <th>Source</th>
                            </tr>
                          </thead>
                          <tbody>
                            {jobCard.parts.map((part) => (
                              <tr key={part.id}>
                                <td>{part.part_id}</td>
                                <td>{part.part_name || "Unnamed Part"}</td>
                                <td>{part.quantity}</td>
                                <td>
                                  ₹{parseFloat(part.unit_price).toFixed(2)}
                                </td>
                                <td>₹{parseFloat(part.amount).toFixed(2)}</td>
                                <td>
                                  <Badge
                                    color={
                                      part.source === "stock"
                                        ? "success"
                                        : "info"
                                    }
                                  >
                                    {part.source}
                                  </Badge>
                                </td>
                              </tr>
                            ))}
                            <tr className="table-success">
                              <td colSpan={4} className="text-end fw-bold">
                                Parts Total:
                              </td>
                              <td colSpan={2} className="fw-bold">
                                ₹{partsTotal.toFixed(2)}
                              </td>
                            </tr>
                          </tbody>
                        </Table>
                      </div>
                    ) : (
                      <div className="text-center py-3 text-muted">
                        <i className="fa fa-box fa-2x mb-2"></i>
                        <p>No parts used</p>
                      </div>
                    )}
                  </CardBody>
                </Card>

                {/* Summary Section */}
                <Card className="mb-4">
                  <CardBody>
                    <h6 className="card-title text-primary mb-3">
                      <i className="fa fa-calculator me-2"></i>
                      JOB SUMMARY
                    </h6>
                    <Row>
                      <Col md={6}>
                        <div className="mb-2">
                          <strong>Labor Estimate:</strong>
                          <span className="ms-2">
                            ₹{parseFloat(jobCard.labor_estimate).toFixed(2)}
                          </span>
                        </div>
                        <div className="mb-2">
                          <strong>Parts Estimate:</strong>
                          <span className="ms-2">
                            ₹{parseFloat(jobCard.parts_estimate).toFixed(2)}
                          </span>
                        </div>
                      </Col>
                      <Col md={6}>
                        <div className="mb-2">
                          <strong>Actual Labor:</strong>
                          <span className="ms-2">₹{laborTotal.toFixed(2)}</span>
                        </div>
                        <div className="mb-2">
                          <strong>Actual Parts:</strong>
                          <span className="ms-2">₹{partsTotal.toFixed(2)}</span>
                        </div>
                      </Col>
                    </Row>
                    <hr />
                    <div className="text-center">
                      <h6 className="text-primary">
                        <strong>
                          Total Estimated: ₹
                          {parseFloat(jobCard.total_estimate).toFixed(2)}
                        </strong>
                      </h6>
                      {/* <h6
                        className={
                          actualTotal > parseFloat(jobCard.total_estimate)
                            ? "text-danger"
                            : "text-success"
                        }
                      >
                        <strong>Actual Total: ₹{actualTotal.toFixed(2)}</strong>
                      </h6> */}
                      {actualTotal > parseFloat(jobCard.total_estimate) && (
                        <small className="text-danger">
                          <i className="fa fa-exclamation-triangle me-1"></i>
                          Actual cost exceeds estimate by ₹
                          {(
                            actualTotal - parseFloat(jobCard.total_estimate)
                          ).toFixed(2)}
                        </small>
                      )}
                    </div>
                  </CardBody>
                </Card>

                {/* Payment Status and Footer */}
                <Card>
                  <CardBody>
                    <Row className="align-items-center">
                      <Col md={6}>
                        <div>
                          <strong>Payment Status:</strong>
                          <Badge
                            color={
                              jobCard.is_paid === "1" ? "success" : "warning"
                            }
                            className="ms-2"
                          >
                            {jobCard.is_paid === "1" ? "PAID" : "UNPAID"}
                          </Badge>
                        </div>
                      </Col>
                      <Col md={6} className="text-end">
                        <div className="text-muted">
                          <small>
                            Generated on: {new Date().toLocaleDateString()}
                          </small>
                        </div>
                      </Col>
                    </Row>
                  </CardBody>
                </Card>

                {/* Action Buttons (Non-printable) */}
                <div className="d-grid gap-2 d-md-flex justify-content-md-end mt-4 print:hidden">
                  <Button
                    color="warning"
                    onClick={() =>
                      router.push(`/admin/jobcards/create?id=${jobCard.id}`)
                    }
                  >
                    <i className="fa fa-edit me-2"></i>
                    Edit Job Card
                  </Button>
                  <Button color="info" onClick={() => window.print()}>
                    <i className="fa fa-print me-2"></i>
                    Print Job Card
                  </Button>
                  <Button
                    color="outline-primary"
                    onClick={() => router.push("/admin/jobcards")}
                  >
                    <i className="fa fa-arrow-left me-2"></i>
                    Back to List
                  </Button>
                </div>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Container>

      {/* Print Styles */}
      <style jsx>{`
        @media print {
          /* Hide non-printable elements */
          .print\\:hidden,
          .page-title,
          .breadcrumb,
          .page-header,
          .no-print {
            display: none !important;
          }

          /* Reset margins and padding */
          body,
          .page-body,
          .container-fluid,
          .job-card-print {
            margin: 0 !important;
            padding: 0 !important;
            width: 100% !important;
            background: white !important;
          }

          /* Force page breaks */
          .job-card-print {
            page-break-before: always;
            break-before: page;
          }

          /* Ensure proper card display */
          .card {
            border: 1px solid #ddd !important;
            page-break-inside: avoid;
            break-inside: avoid;
          }

          /* Table styling for print */
          table {
            font-size: 11px !important;
            width: 100% !important;
            border-collapse: collapse !important;
          }

          th,
          td {
            border: 1px solid #ccc !important;
            padding: 4px 6px !important;
          }

          /* Ensure badges are visible */
          .badge {
            border: 1px solid #000 !important;
            color: #000 !important;
            background-color: transparent !important;
            font-weight: bold;
          }

          /* Show URLs for links */
          a[href]:after {
            content: " (" attr(href) ")";
          }

          /* Remove button styling */
          .btn {
            display: none !important;
          }

          /* Typography for print */
          h1,
          h2,
          h3,
          h4,
          h5,
          h6 {
            color: #000 !important;
            margin: 8px 0 !important;
          }

          .text-primary {
            color: #000 !important;
            font-weight: bold !important;
          }

          /* Ensure proper spacing */
          .mb-1,
          .mb-2,
          .mb-3,
          .mb-4,
          .mb-5 {
            margin-bottom: 4px !important;
          }

          .mt-1,
          .mt-2,
          .mt-3,
          .mt-4,
          .mt-5 {
            margin-top: 4px !important;
          }

          /* Force black and white for print */
          * {
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
            color-adjust: exact !important;
          }

          /* Avoid page breaks inside important sections */
          .table-responsive,
          .row {
            page-break-inside: avoid !important;
            break-inside: avoid !important;
          }

          /* Header styling */
          .border-bottom {
            border-bottom: 2px solid #000 !important;
          }

          .text-center h2 {
            text-decoration: underline;
          }
        }

        /* Screen styles */
        @media screen {
          .job-card-print {
            background: white;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
          }

          .card-title {
            border-bottom: 2px solid #007bff;
            padding-bottom: 8px;
          }
        }
      `}</style>
    </div>
  );
}

export default JobCardDetailPage;
