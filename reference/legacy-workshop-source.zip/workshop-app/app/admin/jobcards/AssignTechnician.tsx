// AssignTechnician.tsx
import { useState, useEffect, useRef } from "react";
import {
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Button,
  Input,
  FormGroup,
  Label,
  Alert,
  Spinner,
  Col,
} from "reactstrap";
import { useAuth } from "@/helper/AuthContext";
import { toast } from "react-toastify";

interface Technician {
  id: string;
  username: string;
  fullName?: string;
  email?: string;
}

interface AssignTechnicianProps {
  isOpen: boolean;
  toggle: () => void;
  jobId: string;
  jobName: string;
  onSuccess: () => void;
}

function AssignTechnician({
  isOpen,
  toggle,
  jobId,
  jobName,
  onSuccess,
}: AssignTechnicianProps) {
  const { state } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [technicians, setTechnicians] = useState<Technician[]>([]);
  const [technicianSearchTerm, setTechnicianSearchTerm] = useState("");
  const [isTechnicianDropdownOpen, setIsTechnicianDropdownOpen] =
    useState(false);
  const [selectedTechnicianId, setSelectedTechnicianId] = useState<string>("");
  const [selectedTechnicianName, setSelectedTechnicianName] = useState("");
  const technicianDropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      fetchTechnicians();
    }
  }, [isOpen]);

  const fetchTechnicians = async () => {
    try {
      setLoading(true);
      const response = await fetch("/api/technicians_list", {
        method: "GET",
        headers: {
          Authorization: `Bearer ${
            state?.accessToken || localStorage.getItem("token")
          }`,
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error("Failed to fetch technicians");
      }

      const data = await response.json();
      setTechnicians(data.data || []);
    } catch (err: any) {
      console.error("Error fetching technicians:", err);
      setError("Failed to load technicians");
    } finally {
      setLoading(false);
    }
  };

  const filteredTechnicians = technicians.filter((technician) =>
    technician.username
      .toLowerCase()
      .includes(technicianSearchTerm.toLowerCase())
  );

  const handleTechnicianSelect = (id: string, username: string) => {
    setSelectedTechnicianId(id);
    setSelectedTechnicianName(username);
    setIsTechnicianDropdownOpen(false);
    setTechnicianSearchTerm("");
  };

  const handleSubmit = async () => {
    if (!selectedTechnicianId) {
      setError("Please select a technician");
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const response = await fetch(`/api/work_assign/${jobId}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${
            state?.accessToken || localStorage.getItem("token")
          }`,
        },
        body: JSON.stringify({ assigned_to: selectedTechnicianId }),
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.message || "Failed to assign technician");
      }

      setSuccess("Technician assigned successfully!");

      setTimeout(() => {
        onSuccess();
        setSelectedTechnicianId("");
        setSelectedTechnicianName("");
        setSuccess(null);
        toggle();
      }, 1500);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    setSelectedTechnicianId("");
    setSelectedTechnicianName("");
    setError(null);
    setSuccess(null);
    setTechnicianSearchTerm("");
    setIsTechnicianDropdownOpen(false);
    toggle();
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        technicianDropdownRef.current &&
        !technicianDropdownRef.current.contains(event.target as Node)
      ) {
        setIsTechnicianDropdownOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <Modal isOpen={isOpen} toggle={handleClose}>
      <ModalHeader toggle={handleClose}>
        <h4 className="modal-title"> Assign Technician - {jobName}</h4>
      </ModalHeader>
      <ModalBody>
        {success && (
          <Alert color="success">
            <i className="fa fa-check-circle me-2"></i>
            {success}
          </Alert>
        )}

        {error && (
          <Alert color="danger">
            <i className="fa fa-exclamation-circle me-2"></i>
            {error}
          </Alert>
        )}

        <Col md="12">
          <FormGroup>
            <Label>Assign Technician</Label>
            {loading && technicians.length === 0 ? (
              <div className="d-flex align-items-center">
                <Spinner size="sm" className="me-2" />
                Loading technicians...
              </div>
            ) : technicians.length === 0 ? (
              <div className="text-danger">No technicians found.</div>
            ) : (
              <div className="position-relative" ref={technicianDropdownRef}>
                {/* Dropdown trigger */}
                <div
                  onClick={() =>
                    setIsTechnicianDropdownOpen(!isTechnicianDropdownOpen)
                  }
                  className="d-flex w-100 align-items-center justify-content-between cursor-pointer form-select border"
                  style={{
                    minHeight: "38px",
                    padding: "0.375rem 0.75rem",
                    cursor: "pointer",
                  }}
                >
                  <span
                    className="text-truncate"
                    style={{ maxWidth: "calc(100% - 20px)" }}
                  >
                    {selectedTechnicianName || "Select Technician"}
                  </span>
                  {/* <span className="ms-2 text-muted" style={{ flexShrink: 0 }}>
                    {isTechnicianDropdownOpen ? "▲" : "▼"}
                  </span> */}
                </div>

                {/* Dropdown menu */}
                {isTechnicianDropdownOpen && (
                  <div
                    // className="position-absolute w-100 mt-1 bg-white border rounded shadow"
                    className="position-absolute w-100 mt-1 border rounded shadow dropdown-menu show"
                    style={{
                      maxHeight: "300px",
                      overflow: "auto",
                      zIndex: 1050,
                    }}
                  >
                    {/* Search input */}
                    <div className="p-2 border-bottom">
                      <Input
                        type="text"
                        value={technicianSearchTerm}
                        onChange={(e) => {
                          setTechnicianSearchTerm(e.target.value);
                        }}
                        placeholder="Search technicians..."
                        className="form-control form-control-sm"
                        autoFocus
                        onClick={(e) => e.stopPropagation()}
                      />
                    </div>

                    {/* Technician list */}
                    <div
                      style={{
                        maxHeight: "200px",
                        overflowY: "auto",
                      }}
                    >
                      {filteredTechnicians.length > 0 ? (
                        <ul className="list-unstyled mb-0">
                          {filteredTechnicians.map((technician) => (
                            <li
                              key={technician.id}
                              onClick={() =>
                                handleTechnicianSelect(
                                  technician.id,
                                  technician.username
                                )
                              }
                              // className="px-3 py-2 cursor-pointer hover-bg-light"
                              // style={{
                              //   cursor: "pointer",
                              //   backgroundColor:
                              //     selectedTechnicianId === technician.id
                              //       ? "#f8f9fa"
                              //       : "transparent",
                              // }}
                              className="px-3 py-2 cursor-pointer dropdown-item"
                              style={{ cursor: "pointer" }}
                            >
                              <div className="d-flex align-items-center">
                                {technician.username}
                                {technician.fullName && (
                                  <small className="text-muted ms-2">
                                    ({technician.fullName})
                                  </small>
                                )}
                              </div>
                            </li>
                          ))}
                        </ul>
                      ) : (
                        <div className="px-3 py-2 text-muted">
                          {technicianSearchTerm
                            ? "No matching technician found"
                            : "No technicians available"}
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}
          </FormGroup>
        </Col>
      </ModalBody>
      <ModalFooter>
        <Button color="secondary" onClick={handleClose} disabled={loading}>
          Cancel
        </Button>
        <Button
          color="primary"
          onClick={handleSubmit}
          disabled={loading || success !== null || !selectedTechnicianId}
        >
          {loading ? (
            <>
              <span
                className="spinner-border spinner-border-sm me-2"
                role="status"
              ></span>
              Assigning...
            </>
          ) : (
            "Assign Technician"
          )}
        </Button>
      </ModalFooter>
    </Modal>
  );
}

export default AssignTechnician;
