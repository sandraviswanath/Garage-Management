"use client";
import Breadcrumbs from "@/CommonElements/Breadcrumbs";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  Form,
  FormGroup,
  Label,
  Input,
  Button,
  Alert,
  Table,
  Spinner,
  Badge,
} from "reactstrap";
import React, { useState, useEffect, useRef } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { toast } from "react-toastify";
import { useAuth } from "@/helper/AuthContext";

import { FaPlus } from "react-icons/fa";
import Link from "next/link";

// Types based on your API
interface Customer {
  id: string;
  name: string;
}

interface Vehicle {
  id: string;
  registration_number: string;
  customer_id: string;
}

interface Technician {
  id: string;
  // name: string;
  username: string;
  email: string;
  phone: string;
  specialization: string | null;
}

interface Part {
  id: string;
  name: string;
  sku: string;
  unit_cost: string | number;
  quantity: number;
}

interface JobItem {
  id: number;
  description: string;
  labor_hours: number;
  labor_rate: number;
  total: number;
}

interface PartUsed {
  id: number;
  part_id: string;
  part_name: string;
  quantity: number;
  unit_cost: number;
  total: number;
  // name:string;
}

interface JobType {
  value: string;
  label: string;
}

function CreateJobCardPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { state } = useAuth();

  // Check if we're in edit mode
  const jobCardId = searchParams.get("id");
  const isEditMode = !!jobCardId;

  const [showAlert, setShowAlert] = useState(false);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [technicians, setTechnicians] = useState<Technician[]>([]);
  const [parts, setParts] = useState<Part[]>([]);

  // For edit mode: existing job items and parts
  const [existingJobItems, setExistingJobItems] = useState<JobItem[]>([]);
  const [existingPartsUsed, setExistingPartsUsed] = useState<PartUsed[]>([]);

  // Customer dropdown state
  const [customerSearchTerm, setCustomerSearchTerm] = useState("");
  const [isCustomerDropdownOpen, setIsCustomerDropdownOpen] = useState(false);
  const [selectedCustomerName, setSelectedCustomerName] = useState("");
  const customerDropdownRef = useRef<HTMLDivElement | null>(null);

  const [vehicleSearchTerm, setVehicleSearchTerm] = useState("");
  const [isVehicleDropdownOpen, setIsVehicleDropdownOpen] = useState(false);
  const [selectedVehicleName, setSelectedVehicleName] = useState("");
  const vehicleDropdownRef = useRef<HTMLDivElement | null>(null);

  const [jobTypeSearchTerm, setJobTypeSearchTerm] = useState("");
  const [isJobDropdownOpen, setIsJobDropdownOpen] = useState(false);
  const [selectedJobName, setSelectedJobName] = useState("");
  const jobDropdownRef = useRef<HTMLDivElement | null>(null);

  const [technicianSearchTerm, setTechnicianSearchTerm] = useState("");
  const [istechnicianDropdownOpen, setIsTechnicianDropdownOpen] =
    useState(false);
  const [selectedTechnicianName, setSelectedTechnicianName] = useState("");
  const technicianDropdownRef = useRef<HTMLDivElement | null>(null);

  const [formData, setFormData] = useState({
    customer_id: "",
    vehicle_id: "",
    job_type: "service",
    reported_issues: "",
    assigned_to: "",
    labour_estimate: "",
    expected_completion: "",
    special_instructions: "",
  });

  const [jobItems, setJobItems] = useState<JobItem[]>([]);
  const [partsUsed, setPartsUsed] = useState<PartUsed[]>([]);

  const [newJobItem, setNewJobItem] = useState({
    description: "",
    // labor_hours: 0,
    labor_hours: 0,
    labor_rate: 75,
  });

  const [selectedPart, setSelectedPart] = useState({
    part_id: "",
    quantity: 1,
  });

  // Fetch initial data
  useEffect(() => {
    fetchInitialData();

    // If edit mode, fetch existing job card data
    if (isEditMode && jobCardId) {
      fetchJobCardData(jobCardId);
    }
  }, [jobCardId, isEditMode]);

  const fetchJobCardData = async (id: string) => {
    try {
      setLoading(true);
      const token = state?.accessToken || localStorage.getItem("token");

      const response = await fetch(`/api/jobcards/${id}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (response.ok) {
        const jobCardData = await response.json();

        if (jobCardData.data) {
          const jobCard = jobCardData.data;

          // Set form data from existing job card
          setFormData({
            customer_id: jobCard.customer_id || "",
            vehicle_id: jobCard.vehicle_id || "",
            job_type: "service",
            reported_issues: jobCard.reported_issues || "",
            assigned_to: jobCard.assigned_to || "",
            labour_estimate: jobCard.labor_estimate || "",
            expected_completion: jobCard.expected_completion
              ? jobCard.expected_completion.split(" ")[0]
              : "",
            special_instructions: "",
          });

          // Set customer name
          if (jobCard.customer_name) {
            setSelectedCustomerName(jobCard.customer_name);
          }

          // Set existing job items
          if (jobCard.items && jobCard.items.length > 0) {
            const items = jobCard.items.map((item: any, index: number) => ({
              id: index + 1,
              description: item.description || "",
              labor_hours: parseFloat(item.labor_hours) || 0,
              labor_rate: parseFloat(item.labor_rate) || 0,
              total: parseFloat(item.amount) || 0,
            }));
            setExistingJobItems(items);
          }

          // Set existing parts used
          if (jobCard.parts && jobCard.parts.length > 0) {
            const parts = jobCard.parts.map((part: any, index: number) => ({
              id: index + 1,
              part_id: part.part_id || "",
              part_name: part.part_name || "",
              quantity: parseFloat(part.quantity) || 0,
              unit_cost: parseFloat(part.unit_price) || 0,
              total: parseFloat(part.amount) || 0,
            }));
            setExistingPartsUsed(parts);
          }
        }
      } else {
        toast.error("Failed to load job card details");
      }
    } catch (error: any) {
      console.error("Error fetching job card data:", error);
      toast.error("Failed to load job card data");
    }
  };

  const fetchInitialData = async () => {
    try {
      setLoading(true);
      const token = state?.accessToken || localStorage.getItem("token");

      // Fetch customers
      const customersRes = await fetch("/api/customers_list", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      if (customersRes.ok) {
        const customersData = await customersRes.json();
        setCustomers(customersData.data || []);
      } else {
        toast.error("Failed to load customers");
      }

      // Fetch vehicles
      const vehiclesRes = await fetch("/api/vehicle_list", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      if (vehiclesRes.ok) {
        const vehiclesData = await vehiclesRes.json();
        setVehicles(vehiclesData.data || []);
      } else {
        toast.error("Failed to load vehicles");
      }

      // Fetch technicians
      const technicianRes = await fetch("/api/technicians_list", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      if (technicianRes.ok) {
        const techniciansData = await technicianRes.json();
        setTechnicians(techniciansData.data || []);
      } else {
        toast.error("Failed to load technicians");
      }

      // Fetch parts
      const partsRes = await fetch("/api/parts_list", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      if (partsRes.ok) {
        const partsData = await partsRes.json();
        setParts(partsData.data || []);
      } else {
        toast.error("Failed to load parts");
      }
    } catch (error: any) {
      console.error("Error fetching data:", error);
      toast.error("Failed to load initial data");
    } finally {
      setLoading(false);
    }
  };

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        customerDropdownRef.current &&
        !customerDropdownRef.current.contains(event.target as Node)
      ) {
        setIsCustomerDropdownOpen(false);
      }
      if (
        vehicleDropdownRef.current &&
        !vehicleDropdownRef.current.contains(event.target as Node)
      ) {
        setIsVehicleDropdownOpen(false);
      }
      if (
        technicianDropdownRef.current &&
        !technicianDropdownRef.current.contains(event.target as Node)
      ) {
        setIsTechnicianDropdownOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  // Filter customers based on search term
  const filteredCustomers = customers.filter((customer) =>
    customer.name.toLowerCase().includes(customerSearchTerm.toLowerCase())
  );

  // Filter vehicles based on selected customer
  const filteredVehicles = formData.customer_id
    ? vehicles.filter((vehicle) => vehicle.customer_id === formData.customer_id)
    : [];

  const filteredTechnicians = technicians.filter((technicians) =>
    technicians.username
      .toLowerCase()
      .includes(technicianSearchTerm.toLowerCase())
  );

  // Handle customer selection
  const handleCustomerSelect = (customerId: string, customerName: string) => {
    setFormData((prev) => ({
      ...prev,
      customer_id: customerId,
      vehicle_id: "", // Reset vehicle selection when customer changes
    }));
    setSelectedCustomerName(customerName);
    setIsCustomerDropdownOpen(false);
    setCustomerSearchTerm("");
  };
  const handleVehicleSelect = (vehicleId: string, vehicleName: string) => {
    setFormData((prev) => ({ ...prev, vehicle_id: vehicleId }));
    setSelectedVehicleName(vehicleName);
    setIsVehicleDropdownOpen(false);
    setVehicleSearchTerm("");
  };

  const handleFormChange = (
    e: React.ChangeEvent<
      HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement
    >
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    console.log("submitting");
    e.preventDefault();

    if (!formData.customer_id) {
      toast.error("Please select a customer");
      return;
    }

    if (!formData.vehicle_id) {
      toast.error("Please select a vehicle");
      return;
    }

    if (!formData.reported_issues) {
      toast.error("Please enter reported issues");
      return;
    }

    if (!formData.expected_completion) {
      toast.error("Please select expected completion date");
      return;
    }

    try {
      setSubmitting(true);
      const token = state?.accessToken || localStorage.getItem("token");

      if (isEditMode) {
        const payload = {
          customer_id: formData.customer_id,
          vehicle_id: formData.vehicle_id,
          reported_issue: formData.reported_issues,
          expected_completion: formData.expected_completion + " 00:00:00",
        };

        console.log("Updating job card with payload:", payload);

        const response = await fetch(`/api/jobcards/${jobCardId}`, {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify(payload),
        });

        if (response.ok) {
          toast.success("Job card updated successfully!");
          setShowAlert(true);
          setTimeout(() => {
            router.push(`/admin/jobcards/${jobCardId}`);
          }, 1500);
        } else {
          const errorData = await response.json();
          console.error("API Error:", errorData);
          toast.error(errorData.message || "Failed to update job card");
        }
      } else {
        // Build payload EXACTLY as your backend expects
        const payload = {
          customer_id: formData.customer_id,
          vehicle_id: formData.vehicle_id,
          reported_issues: formData.reported_issues,
          expected_completion: formData.expected_completion + " 00:00:00",
        };

        console.log(
          "Sending payload to backend:",
          JSON.stringify(payload, null, 2)
        );

        const response = await fetch("/api/jobcards", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify(payload),
        });

        if (response.ok) {
          const result = await response.json();
          const newJobCardId = result.data?.id || result.id;
          toast.success("Job card created successfully!");
          setShowAlert(true);
          setTimeout(() => {
            // router.push("/admin/jobcards");
            router.push(`/admin/jobcards/addservice?id=${newJobCardId}`);
          }, 1500);
        } else {
          const errorData = await response.json();
          console.error("API Error Response:", errorData);

          // More detailed error message
          if (errorData.errors) {
            // Show validation errors if available
            const errorMessages = Object.values(errorData.errors)
              .flat()
              .join(", ");
            toast.error(`Validation errors: ${errorMessages}`);
          } else {
            toast.error(errorData.message || "Failed to create job card");
          }
        }
      }
    } catch (error: any) {
      console.error(
        `Error ${isEditMode ? "updating" : "creating"} job card:`,
        error
      );
      toast.error(
        `Failed to ${
          isEditMode ? "update" : "create"
        } job card. Please try again.`
      );
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="page-body">
        <Breadcrumbs
          title={isEditMode ? "Edit Job Card" : "Create Job Card"}
          mainTitle={isEditMode ? "Edit Job Card" : "Create Job Card"}
          parent="Job Card Management"
        />
        <Container fluid>
          <Row>
            <Col lg={12}>
              <Card>
                <CardBody className="text-center py-5">
                  <Spinner color="primary" />
                  <p className="mt-3">Loading...</p>
                </CardBody>
              </Card>
            </Col>
          </Row>
        </Container>
      </div>
    );
  }

  return (
    <div className="page-body">
      <Breadcrumbs
        title={isEditMode ? "Edit Job Card" : "Create Job Card"}
        mainTitle={isEditMode ? "Edit Job Card" : "Create Job Card"}
        parent="Job Card Management"
      />

      <Container fluid>
        <Row>
          <Col lg={12}>
            <Card>
              <CardBody>
                {showAlert && (
                  <Alert color="success" className="mb-3">
                    Job card {isEditMode ? "updated" : "created"} successfully!
                    Redirecting...
                  </Alert>
                )}

                <div className="d-flex justify-content-between align-items-center mb-4 text-muted">
                  <h5>
                    {isEditMode ? "Edit Job Card" : "Create New Job Card"}
                  </h5>
                </div>

                <Form onSubmit={handleSubmit}>
                  {/* Customer & Vehicle Section */}
                  <div className="mb-4">
                    {/* <h6 className="mb-3 text-muted">
                      Customer & Vehicle Information
                    </h6> */}
                    <Row>
                      <Col md={4}>
                        <FormGroup>
                          <Label className="d-flex justify-content-between align-items-center">
                            <span className="text-muted">Customer *</span>
                            {/* <Link
                              href="/admin/customer/add"
                              className="p-0 text-decoration-none"
                              target="_blank"
                            >
                              <FaPlus className="mr-1" /> Add Customer
                            </Link> */}
                            <Link
                              href="/admin/customer/add"
                              className="btn btn-link btn-sm p-0 text-decoration-none"
                            >
                              <i className="fa fa-plus me-1"></i>
                              Add New Customer
                            </Link>
                          </Label>
                          {customers.length === 0 ? (
                            <div className="text-danger">
                              No customers found. Please add a customer first.
                            </div>
                          ) : (
                            <div
                              className="position-relative"
                              ref={customerDropdownRef}
                            >
                              {/* Dropdown trigger */}
                              <div
                                onClick={() =>
                                  setIsCustomerDropdownOpen(
                                    !isCustomerDropdownOpen
                                  )
                                }
                                className="d-flex w-100 align-items-center justify-content-between cursor-pointer form-select border"
                                style={{
                                  minHeight: "38px",
                                  padding: "0.375rem 0.75rem",
                                  cursor: "pointer",
                                }}
                              >
                                <span
                                  className="text-truncate"
                                  style={{ maxWidth: "calc(100% - 20px)" }}
                                >
                                  {selectedCustomerName || "Select Customer"}
                                </span>
                                {/* <span
                                  className="ms-2 text-muted"
                                  style={{ flexShrink: 0 }}
                                >
                                  {isCustomerDropdownOpen ? "▲" : "▼"}
                                </span> */}
                              </div>

                              {/* Dropdown menu */}
                              {/* {isCustomerDropdownOpen && (
                                <div
                                  className="position-absolute w-100 mt-1 bg-white border rounded shadow"
                                  style={{
                                    maxHeight: "300px",
                                    overflow: "auto",
                                    zIndex: 1050,
                                  }}
                                >
                                  
                                  <div className="p-2 border-bottom">
                                    <Input
                                      type="text"
                                      value={customerSearchTerm}
                                      onChange={(e) => {
                                        setCustomerSearchTerm(e.target.value);
                                      }}
                                      placeholder="Search customers..."
                                      className="form-control form-control-sm"
                                      autoFocus
                                      onClick={(e) => e.stopPropagation()}
                                    />
                                  </div>

                                 
                                  <div
                                    style={{
                                      maxHeight: "200px",
                                      overflowY: "auto",
                                    }}
                                  >
                                    {filteredCustomers.length > 0 ? (
                                      <ul className="list-unstyled mb-0">
                                        {filteredCustomers.map((customer) => (
                                          <li
                                            key={customer.id}
                                            onClick={() =>
                                              handleCustomerSelect(
                                                customer.id,
                                                customer.name
                                              )
                                            }
                                            className="px-3 py-2 cursor-pointer hover-bg-light"
                                            style={{ cursor: "pointer" }}
                                          >
                                            <div className="d-flex align-items-center">
                                              {customer.name}
                                              {formData.customer_id ===
                                                customer.id && (
                                                <span className="ms-2 badge bg-primary">
                                                  Selected
                                                </span>
                                              )}
                                            </div>
                                          </li>
                                        ))}
                                      </ul>
                                    ) : (
                                      <div className="px-3 py-2 text-muted">
                                        {customerSearchTerm
                                          ? "No matching customers found"
                                          : "No customers available"}
                                      </div>
                                    )}
                                  </div>
                                </div>
                              )} */}
                              {isCustomerDropdownOpen && (
                                <div
                                  className="position-absolute w-100 mt-1 border rounded shadow dropdown-menu show"
                                  style={{
                                    maxHeight: "300px",
                                    overflow: "auto",
                                    zIndex: 1050,
                                  }}
                                >
                                  {/* Search input */}
                                  <div className="p-2 border-bottom">
                                    <div className="d-flex gap-2">
                                      <Input
                                        type="text"
                                        value={customerSearchTerm}
                                        onChange={(e) => {
                                          setCustomerSearchTerm(e.target.value);
                                        }}
                                        placeholder="Search customers..."
                                        className="form-control form-control-sm"
                                        autoFocus
                                        onClick={(e) => e.stopPropagation()}
                                      />
                                      <Link
                                        href="/admin/customer/add"
                                        className="btn btn-info btn-sm flex-shrink-0"
                                        title="Add new customer"
                                      >
                                        <i className="fa fa-plus"></i>
                                      </Link>
                                    </div>
                                  </div>

                                  {/* Customer list */}
                                  <div
                                    style={{
                                      maxHeight: "200px",
                                      overflowY: "auto",
                                    }}
                                  >
                                    {filteredCustomers.length > 0 ? (
                                      <ul className="list-unstyled mb-0">
                                        {filteredCustomers.map((customer) => (
                                          <li
                                            key={customer.id}
                                            onClick={() =>
                                              handleCustomerSelect(
                                                customer.id,
                                                customer.name
                                              )
                                            }
                                            className="px-3 py-2 cursor-pointer dropdown-item"
                                            style={{ cursor: "pointer" }}
                                          >
                                            <div className="d-flex align-items-center justify-content-between">
                                              <div>{customer.name}</div>
                                              {/* {formData.customer_id ===
                                              customer.id && (
                                              <span className="ms-2 badge bg-primary">
                                                Selected
                                              </span>
                                            )} */}
                                            </div>
                                          </li>
                                        ))}
                                      </ul>
                                    ) : (
                                      <div className="px-3 py-2 text-muted text-center">
                                        {customerSearchTerm ? (
                                          <>
                                            No matching customers found
                                            <div className="mt-2">
                                              <Link
                                                href="/admin/customer/add"
                                                className="btn btn-link btn-sm"
                                              >
                                                <i className="fa fa-plus me-1"></i>
                                                Add New Customer
                                              </Link>
                                            </div>
                                          </>
                                        ) : (
                                          "No customers available"
                                        )}
                                      </div>
                                    )}
                                  </div>
                                </div>
                              )}

                              <input
                                type="hidden"
                                name="customer_id"
                                value={formData.customer_id}
                                required
                              />
                            </div>
                          )}
                        </FormGroup>
                      </Col>

                      <Col md={4}>
                        <FormGroup>
                          <Label className="d-flex justify-content-between align-items-center">
                            <span className="text-muted">Select Vehicle *</span>
                            {/* <Link
                              href="/admin/vehicles/add"
                              // className="float-right mr-4 flex items-center text-sm text-blue-600 hover:underline"
                              style={{
                                float: "right",
                                display: "flex",
                                marginRight: "4px",
                                alignItems: "center",
                                color: "",
                              }}
                              target="_blank"
                            >
                              <FaPlus className="mr-1" /> Add Vehicle
                            </Link> */}
                            <Link
                              href="/admin/vehicles/add"
                              className="btn btn-link btn-sm p-0 text-decoration-none"
                            >
                              <i className="fa fa-plus me-1"></i>
                              Add New Vehicle
                            </Link>
                          </Label>
                          {customers.length === 0 ? (
                            <div className="text-danger">
                              No vehicle found. Please add a vehicle first.
                            </div>
                          ) : (
                            <div
                              className="position-relative"
                              ref={vehicleDropdownRef}
                            >
                              {/* Dropdown trigger */}
                              <div
                                onClick={() =>
                                  setIsVehicleDropdownOpen(
                                    !isVehicleDropdownOpen
                                  )
                                }
                                className="d-flex w-100 align-items-center justify-content-between cursor-pointer form-select border"
                                style={{
                                  minHeight: "38px",
                                  padding: "0.375rem 0.75rem",
                                  cursor: "pointer",
                                }}
                              >
                                <span
                                  className="text-truncate"
                                  style={{ maxWidth: "calc(100% - 20px)" }}
                                >
                                  {selectedVehicleName || "Select Vehicle"}
                                </span>
                                {/* <span
                                  className="ms-2 text-muted"
                                  style={{ flexShrink: 0 }}
                                >
                                  {isVehicleDropdownOpen ? "▲" : "▼"}
                                </span> */}
                              </div>

                              {/* Dropdown menu */}
                              {isVehicleDropdownOpen && (
                                <div
                                  // className="position-absolute w-100 mt-1 bg-white border rounded shadow"
                                  // style={{
                                  //   maxHeight: "300px",
                                  //   overflow: "auto",
                                  //   zIndex: 1050,
                                  // }}
                                  className="position-absolute w-100 mt-1 border rounded shadow dropdown-menu show"
                                  style={{
                                    maxHeight: "300px",
                                    overflow: "auto",
                                    zIndex: 1050,
                                  }}
                                >
                                  {/* <div className="p-2 border-bottom">
                                    <Input
                                      type="text"
                                      value={vehicleSearchTerm}
                                      onChange={(e) => {
                                        setVehicleSearchTerm(e.target.value);
                                      }}
                                      placeholder="Search vehicles..."
                                      className="form-control form-control-sm"
                                      autoFocus
                                      onClick={(e) => e.stopPropagation()}
                                    />
                                  </div> */}
                                  {/* Search input */}
                                  <div className="p-2 border-bottom">
                                    <div className="d-flex gap-2">
                                      <Input
                                        type="text"
                                        value={vehicleSearchTerm}
                                        onChange={(e) => {
                                          setVehicleSearchTerm(e.target.value);
                                        }}
                                        placeholder="Search vehicles..."
                                        className="form-control form-control-sm"
                                        autoFocus
                                        onClick={(e) => e.stopPropagation()}
                                      />
                                      <Link
                                        href="/admin/vehicles/add"
                                        className="btn btn-info btn-sm flex-shrink-0"
                                        title="Add new vehicle"
                                      >
                                        <i className="fa fa-plus"></i>
                                      </Link>
                                    </div>
                                  </div>

                                  <div
                                    style={{
                                      maxHeight: "200px",
                                      overflowY: "auto",
                                    }}
                                  >
                                    {filteredVehicles.length > 0 ? (
                                      <ul className="list-unstyled mb-0">
                                        {filteredVehicles.map((vehicle) => (
                                          <li
                                            key={vehicle.id}
                                            onClick={() =>
                                              handleVehicleSelect(
                                                vehicle.id,
                                                vehicle.registration_number
                                              )
                                            }
                                            // className="px-3 py-2 cursor-pointer hover-bg-light"
                                            // style={{ cursor: "pointer" }}
                                            className="px-3 py-2 cursor-pointer dropdown-item"
                                            style={{ cursor: "pointer" }}
                                          >
                                            <div className="d-flex align-items-center">
                                              {vehicle.registration_number}
                                              {formData.customer_id ===
                                                vehicle.id && (
                                                <span className="ms-2 badge bg-primary">
                                                  Selected
                                                </span>
                                              )}
                                            </div>
                                          </li>
                                        ))}
                                      </ul>
                                    ) : (
                                      <div className="px-3 py-2 text-muted">
                                        {vehicleSearchTerm
                                          ? "No matching vehicle found"
                                          : "No vehicle available"}
                                      </div>
                                    )}
                                  </div>
                                </div>
                              )}
                              {formData.customer_id &&
                                filteredVehicles.length === 0 && (
                                  <small className="text-danger">
                                    No vehicles found for this customer. Please
                                    add a vehicle first.
                                  </small>
                                )}
                              {/* <input
                                type="hidden"
                                name="customer_id"
                                value={formData.customer_id}
                                required
                              /> */}
                            </div>
                          )}
                        </FormGroup>
                      </Col>
                      <Col md={4}>
                        <FormGroup>
                          <Label
                            for="expected_completion"
                            className="text-muted"
                          >
                            Expected Completion *
                          </Label>
                          <Input
                            type="date"
                            name="expected_completion"
                            id="expected_completion"
                            value={formData.expected_completion}
                            onChange={handleFormChange}
                            required
                            min={new Date().toISOString().split("T")[0]}
                          />
                        </FormGroup>
                      </Col>
                    </Row>
                  </div>

                  {/* Job Details Section */}
                  <div className="mb-4">
                    {/* <h6 className="mb-3 text-muted">Job Details</h6> */}
                    <Row>
                      {/* <Col md={6}>
                        <FormGroup>
                          <Label for="job_type">Job Type *</Label>
                          <select
                            name="job_type"
                            id="job_type"
                            className="form-select border"
                            value={formData.job_type}
                            onChange={handleFormChange}
                            required
                          >
                            <option value="service">Service</option>
                            <option value="repair">Repair</option>
                            <option value="inspection">Inspection</option>
                            <option value="custom">Custom</option>
                          </select>
                        </FormGroup>
                      </Col> */}
                      {/* <Col md={6}>
                        <FormGroup>
                          <Label
                            for="expected_completion"
                            className="text-muted"
                          >
                            Expected Completion *
                          </Label>
                          <Input
                            type="date"
                            name="expected_completion"
                            id="expected_completion"
                            value={formData.expected_completion}
                            onChange={handleFormChange}
                            required
                            min={new Date().toISOString().split("T")[0]}
                          />
                        </FormGroup>
                      </Col> */}
                    </Row>
                    {/* <Row>
                      <Col md="6">
                        <FormGroup>
                          <Label>Assign Technician *</Label>
                          {loading ? (
                            <div className="d-flex align-items-center">
                              <Spinner size="sm" className="me-2" />
                              Loading customers...
                            </div>
                          ) : technicians.length === 0 ? (
                            <div className="text-danger">
                              No technician found. Please add a customer first.
                            </div>
                          ) : (
                            <div
                              className="position-relative"
                              ref={technicianDropdownRef}
                            >
                              <div
                                onClick={() =>
                                  setIsTechnicianDropdownOpen(
                                    !istechnicianDropdownOpen
                                  )
                                }
                                className="d-flex w-100 align-items-center justify-content-between cursor-pointer form-control border"
                                style={{
                                  minHeight: "38px",
                                  padding: "0.375rem 0.75rem",
                                  cursor: "pointer",
                                }}
                              >
                                <span
                                  className="text-truncate"
                                  style={{ maxWidth: "calc(100% - 20px)" }}
                                >
                                  {selectedTechnicianName ||
                                    "Select Technician"}
                                </span>
                                <span
                                  className="ms-2 text-muted"
                                  style={{ flexShrink: 0 }}
                                >
                                  {istechnicianDropdownOpen ? "▲" : "▼"}
                                </span>
                              </div>

                              {istechnicianDropdownOpen && (
                                <div
                                  className="position-absolute w-100 mt-1 bg-white border rounded shadow"
                                  style={{
                                    maxHeight: "300px",
                                    overflow: "auto",
                                    zIndex: 1050,
                                  }}
                                >
                                  <div className="p-2 border-bottom">
                                    <Input
                                      type="text"
                                      value={technicianSearchTerm}
                                      onChange={(e) => {
                                        setTechnicianSearchTerm(e.target.value);
                                      }}
                                      placeholder="Search technicians..."
                                      className="form-control form-control-sm"
                                      autoFocus
                                      onClick={(e) => e.stopPropagation()}
                                    />
                                  </div>

                                  <div
                                    style={{
                                      maxHeight: "200px",
                                      overflowY: "auto",
                                    }}
                                  >
                                    {filteredTechnicians.length > 0 ? (
                                      <ul className="list-unstyled mb-0">
                                        {filteredTechnicians.map(
                                          (technician) => (
                                            <li
                                              key={technician.id}
                                              onClick={() =>
                                                handleTechnicianSelect(
                                                  technician.id,
                                                  technician.username
                                                )
                                              }
                                              className="px-3 py-2 cursor-pointer hover-bg-light"
                                              style={{ cursor: "pointer" }}
                                            >
                                              <div className="d-flex align-items-center">
                                                {technician.username}
                                              </div>
                                            </li>
                                          )
                                        )}
                                      </ul>
                                    ) : (
                                      <div className="px-3 py-2 text-muted">
                                        {technicianSearchTerm
                                          ? "No matching technician found"
                                          : "No technician available"}
                                      </div>
                                    )}
                                  </div>
                                </div>
                              )}
                            </div>
                          )}
                        </FormGroup>
                      </Col>
                      
                    </Row> */}
                    <FormGroup>
                      <Label for="reported_issue" className="text-muted">
                        Reported Issues *
                      </Label>
                      <Input
                        type="textarea"
                        name="reported_issues"
                        id="reported_issues"
                        rows={3}
                        value={formData.reported_issues}
                        onChange={handleFormChange}
                        placeholder="Describe the issue reported by the customer..."
                        required
                      />
                    </FormGroup>
                  </div>

                  {/* Submit Buttons */}
                  <div className="d-flex gap-2">
                    <Button
                      type="submit"
                      color="primary"
                      size="lg"
                      disabled={submitting}
                    >
                      {submitting ? (
                        <>
                          <Spinner size="sm" className="me-2" />
                          {isEditMode ? "Updating..." : "Creating..."}
                        </>
                      ) : (
                        <>
                          <i className="fa fa-save me-2"></i>
                          {isEditMode ? "Update Job Card" : "Create Job Card"}
                        </>
                      )}
                    </Button>
                    <Button
                      type="button"
                      color="secondary"
                      size="lg"
                      onClick={() =>
                        router.push(
                          isEditMode
                            ? `/admin/jobcards/${jobCardId}`
                            : "/admin/jobcards"
                        )
                      }
                      disabled={submitting}
                    >
                      Cancel
                    </Button>
                    {/* <Button
                      type="button"
                      color="info"
                      size="lg"
                      onClick={() => window.print()}
                      disabled={submitting}
                    >
                      <i className="fa fa-print me-2"></i>
                      Print Preview
                    </Button> */}
                  </div>
                </Form>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Container>

      {/* <style jsx>{`
        .cursor-pointer {
          cursor: pointer;
        }

        .text-truncate {
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        .hover-bg-light:hover {
          background-color: #f8f9fa;
        }
      `}</style> */}

      <style jsx>{`
        .form-control:disabled {
          background-color: #e9ecef;
          opacity: 1;
        }

        .text-muted {
          font-size: 0.875rem;
        }

        .cursor-pointer {
          cursor: pointer;
        }

        .text-truncate {
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        /* Dark mode styles for dropdowns */
        :global(.dark-mode) .dropdown-menu {
          background-color: #2a3042 !important;
          border-color: #404656 !important;
          color: #e0e0e0 !important;
        }

        :global(.dark-mode) .dropdown-item {
          color: #e0e0e0 !important;
        }

        :global(.dark-mode) .dropdown-item:hover {
          background-color: #3a4054 !important;
          color: #ffffff !important;
        }

        :global(.dark-mode) .text-muted {
          color: #a0a0a0 !important;
        }

        :global(.dark-mode) .border-bottom {
          border-color: #404656 !important;
        }

        :global(.dark-mode) .form-control {
          background-color: #2a3042 !important;
          border-color: #404656 !important;
          color: #e0e0e0 !important;
        }

        :global(.dark-mode) .form-control::placeholder {
          color: #a0a0a0 !important;
        }

        /* Make dropdown trigger adapt to dark mode */
        :global(.dark-mode) .dropdown-toggle {
          background-color: #2a3042 !important;
          border-color: #404656 !important;
          color: #e0e0e0 !important;
        }
      `}</style>
    </div>
  );
}

export default CreateJobCardPage;
