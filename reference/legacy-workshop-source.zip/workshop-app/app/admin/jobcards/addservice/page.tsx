// "use client";

// import {
//   Card,
//   CardBody,
//   Row,
//   Col,
//   Label,
//   Input,
//   Button,
//   Table,
//   Spinner,
//   Container,
// } from "reactstrap";
// import React, { useState, useEffect, useRef } from "react";
// import { toast } from "react-toastify";
// import { useAuth } from "@/helper/AuthContext";
// import Breadcrumbs from "@/CommonElements/Breadcrumbs";
// import { Currency } from "@/utils/Utils";
// import { useSearchParams, useRouter } from "next/navigation";
// import Link from "next/link";

// interface Part {
//   id: string;
//   name: string;
//   sku: string;
//   unit_cost: string | number;
//   quantity: number;
// }

// interface JobItem {
//   id: number;
//   description: string;
//   labor_hours: number;
//   labor_rate: number;
//   total: number;
// }

// interface PartUsed {
//   id: number;
//   part_id: string;
//   part_name: string;
//   quantity: number;
//   unit_cost: number;
//   total: number;
// }

// function AddServicePage() {
//   const { state } = useAuth();
//   const router = useRouter();
//   const searchParams = useSearchParams();
//   const jobCardId = searchParams.get("id") || "";

//   const [loading, setLoading] = useState(false);
//   const [submitting, setSubmitting] = useState(false);
//   const [parts, setParts] = useState<Part[]>([]);
//   const [jobItems, setJobItems] = useState<JobItem[]>([]);
//   const [partsUsed, setPartsUsed] = useState<PartUsed[]>([]);
//   const [existingJobItems, setExistingJobItems] = useState<JobItem[]>([]);
//   const [existingPartsUsed, setExistingPartsUsed] = useState<PartUsed[]>([]);

//   const [partsSearchTerm, setPartsSearchTerm] = useState("");
//   const [isPartsDropdownOpen, setIsPartsDropdownOpen] = useState(false);
//   const [selectedPartsName, setSelectedPartsName] = useState("");
//   const partsDropdownRef = useRef<HTMLDivElement | null>(null);

//   const [newJobItem, setNewJobItem] = useState({
//     description: "",
//     labor_hours: 0,
//     labor_rate: 75,
//   });

//   const [selectedPart, setSelectedPart] = useState({
//     part_id: "",
//     quantity: 1,
//   });

//   useEffect(() => {
//     if (!jobCardId) {
//       toast.error("No job card ID provided");
//       router.push("/admin/jobcards");
//       return;
//     }

//     fetchParts();
//     fetchExistingJobCardData();
//   }, [jobCardId]);

//   const fetchExistingJobCardData = async () => {
//     try {
//       const token = state?.accessToken || localStorage.getItem("token");

//       const response = await fetch(`/api/jobcards/${jobCardId}`, {
//         headers: { Authorization: `Bearer ${token}` },
//       });

//       if (response.ok) {
//         const jobCardData = await response.json();

//         if (jobCardData.data) {
//           const jobCard = jobCardData.data;

//           // Set existing job items
//           if (jobCard.items && jobCard.items.length > 0) {
//             const items = jobCard.items.map((item: any, index: number) => ({
//               id: index + 1,
//               description: item.description || "",
//               labor_hours: parseFloat(item.labor_hours) || 0,
//               labor_rate: parseFloat(item.labor_rate) || 0,
//               total: parseFloat(item.amount) || 0,
//             }));
//             setExistingJobItems(items);
//           }

//           // Set existing parts used
//           if (jobCard.parts && jobCard.parts.length > 0) {
//             const parts = jobCard.parts.map((part: any, index: number) => ({
//               id: index + 1,
//               part_id: part.part_id || "",
//               part_name: part.part_name || "",
//               quantity: parseFloat(part.quantity) || 0,
//               unit_cost: parseFloat(part.unit_price) || 0,
//               total: parseFloat(part.amount) || 0,
//             }));
//             setExistingPartsUsed(parts);
//           }
//         }
//       }
//     } catch (error: any) {
//       console.error("Error fetching job card data:", error);
//     }
//   };

//   const fetchParts = async () => {
//     try {
//       setLoading(true);
//       const token = state?.accessToken || localStorage.getItem("token");

//       const partsRes = await fetch("/api/parts_list", {
//         headers: { Authorization: `Bearer ${token}` },
//       });
//       if (partsRes.ok) {
//         const partsData = await partsRes.json();
//         setParts(partsData.data || []);
//       } else {
//         toast.error("Failed to load parts");
//       }
//     } catch (error: any) {
//       console.error("Error fetching parts:", error);
//       toast.error("Failed to load parts");
//     } finally {
//       setLoading(false);
//     }
//   };

//   const handleAddJobItem = () => {
//     if (newJobItem.description && newJobItem.labor_hours > 0) {
//       const total = newJobItem.labor_hours * newJobItem.labor_rate;
//       setJobItems([
//         ...jobItems,
//         {
//           id: Date.now(),
//           ...newJobItem,
//           total,
//         },
//       ]);
//       setNewJobItem({
//         description: "",
//         labor_hours: 0,
//         labor_rate: 75,
//       });
//     } else {
//       toast.error("Please enter description and valid hours");
//     }
//   };

//   const handleRemoveJobItem = (id: number) => {
//     setJobItems(jobItems.filter((item) => item.id !== id));
//   };

//   const handleAddPart = () => {
//     if (selectedPart.part_id) {
//       const part = parts.find((p) => p.id === selectedPart.part_id);
//       if (part && selectedPart.quantity > 0) {
//         const unitCost =
//           typeof part.unit_cost === "string"
//             ? parseFloat(part.unit_cost)
//             : part.unit_cost;

//         if (selectedPart.quantity > part.quantity) {
//           toast.error(`Only ${part.quantity} units available in stock`);
//           return;
//         }

//         const total = unitCost * selectedPart.quantity;
//         setPartsUsed([
//           ...partsUsed,
//           {
//             id: Date.now(),
//             part_id: part.id,
//             part_name: part.name,
//             quantity: selectedPart.quantity,
//             unit_cost: unitCost,
//             total,
//           },
//         ]);
//         setSelectedPart({ part_id: "", quantity: 1 });
//       } else {
//         toast.error("Please select a valid part and quantity");
//       }
//     } else {
//       toast.error("Please select a part");
//     }
//   };

//   const handleRemovePart = (id: number) => {
//     setPartsUsed(partsUsed.filter((part) => part.id !== id));
//   };

//   const handleDeletePart = async (id: string) => {
//     if (!confirm("Are you sure you want to delete this part?")) {
//       return;
//     }

//     try {
//       const token = localStorage.getItem("token");

//       const response = await fetch(`/api/jobcards/remove_parts/${id}`, {
//         method: "PUT",
//         headers: {
//           Authorization: `Bearer ${token}`,
//           "Content-Type": "application/json",
//         },
//       });

//       if (response.ok) {
//         toast.success("Customer deleted successfully");
//         // Refresh the customers list
//         // fetchCustomers();
//       } else {
//         const errorData = await response.json();
//         toast.error(errorData.message || "Failed to delete customer");
//       }
//     } catch (error: any) {
//       console.error("Error deleting customer:", error);
//       toast.error(`Failed to delete customer: ${error.message}`);
//     }
//   };

//   const calculateEstimates = () => {
//     // Calculate new items totals
//     const newLabourTotal = jobItems.reduce((sum, item) => sum + item.total, 0);
//     const newPartsTotal = partsUsed.reduce((sum, part) => sum + part.total, 0);

//     // Calculate existing items totals
//     const existingLabourTotal = existingJobItems.reduce(
//       (sum, item) => sum + item.total,
//       0
//     );
//     const existingPartsTotal = existingPartsUsed.reduce(
//       (sum, part) => sum + part.total,
//       0
//     );

//     // Calculate combined totals
//     const labourEstimate = newLabourTotal + existingLabourTotal;
//     const partsEstimate = newPartsTotal + existingPartsTotal;
//     const totalEstimate = labourEstimate + partsEstimate;

//     return {
//       labour_estimate: labourEstimate,
//       parts_estimate: partsEstimate,
//       total_estimate: totalEstimate,
//     };
//   };

//   // const handleSubmit = async () => {
//   //   if (!jobCardId) {
//   //     toast.error("Job card ID is required");
//   //     return;
//   //   }

//   //   if (jobItems.length === 0 && partsUsed.length === 0) {
//   //     toast.error("Please add at least one job item or part");
//   //     return;
//   //   }

//   //   try {
//   //     setSubmitting(true);
//   //     const token = state?.accessToken || localStorage.getItem("token");

//   //     // Calculate estimates (including existing items)
//   //     const estimates = calculateEstimates();

//   //     // Combine existing and new items
//   //     const allItems = [
//   //       ...existingJobItems.map((item) => ({
//   //         description: item.description,
//   //         labor_hours: Number(item.labor_hours),
//   //         labor_rate: Number(item.labor_rate),
//   //         amount: Number(item.total),
//   //       })),
//   //       ...jobItems.map((item) => ({
//   //         description: item.description,
//   //         labor_hours: Number(item.labor_hours),
//   //         labor_rate: Number(item.labor_rate),
//   //         amount: Number(item.total),
//   //       })),
//   //     ];

//   //     // Combine existing and new parts
//   //     const allParts = [
//   //       ...existingPartsUsed.map((part) => ({
//   //         part_id: Number(part.part_id),
//   //         part_name: part.part_name,
//   //         quantity: Number(part.quantity),
//   //         unit_price: Number(part.unit_cost),
//   //         amount: Number(part.total),
//   //       })),
//   //       ...partsUsed.map((part) => ({
//   //         part_id: Number(part.part_id),
//   //         part_name: part.part_name,
//   //         quantity: Number(part.quantity),
//   //         unit_price: Number(part.unit_cost),
//   //         amount: Number(part.total),
//   //       })),
//   //     ];

//   //     // Prepare the complete request body
//   //     const requestBody = {
//   //       labour_estimate: estimates.labour_estimate,
//   //       parts_estimate: estimates.parts_estimate,
//   //       total_estimate: estimates.total_estimate,
//   //       items: allItems,
//   //       parts: allParts,
//   //     };

//   //     console.log("Submitting data:", requestBody);

//   //     // Use PUT method as specified
//   //     const response = await fetch(`/api/jobcards/items_add/${jobCardId}`, {
//   //       method: "PUT",
//   //       headers: {
//   //         "Content-Type": "application/json",
//   //         Authorization: `Bearer ${token}`,
//   //       },
//   //       body: JSON.stringify(requestBody),
//   //     });

//   //     const responseData = await response.json();

//   //     if (!response.ok) {
//   //       throw new Error(
//   //         responseData.message || "Failed to update service items"
//   //       );
//   //     }

//   //     toast.success("Service items updated successfully!");

//   //     // Clear new items after successful submission
//   //     setJobItems([]);
//   //     setPartsUsed([]);

//   //     // Refresh existing data to show updated state
//   //     fetchExistingJobCardData();
//   //   } catch (error: any) {
//   //     console.error("Error updating service items:", error);
//   //     toast.error(error.message || "Failed to update service items");
//   //   } finally {
//   //     setSubmitting(false);
//   //   }
//   // };

//   const handleSubmit = async () => {
//     if (!jobCardId) {
//       toast.error("Job card ID is required");
//       return;
//     }

//     if (jobItems.length === 0 && partsUsed.length === 0) {
//       toast.error("Please add at least one new job item or part");
//       return;
//     }

//     try {
//       setSubmitting(true);
//       const token = state?.accessToken || localStorage.getItem("token");

//       // Calculate estimates for NEW items only (existing items are already in the job card)
//       const newLabourTotal = jobItems.reduce(
//         (sum, item) => sum + item.total,
//         0
//       );
//       const newPartsTotal = partsUsed.reduce(
//         (sum, part) => sum + part.total,
//         0
//       );

//       // Get current totals from the server to calculate new totals
//       const currentTotals = calculateEstimates();
//       const newLabourEstimate = currentTotals.labour_estimate + newLabourTotal;
//       const newPartsEstimate = currentTotals.parts_estimate + newPartsTotal;
//       const newTotalEstimate =
//         currentTotals.total_estimate + newLabourTotal + newPartsTotal;

//       // Prepare ONLY NEW items (existing items should not be sent again)
//       const newItems = jobItems.map((item) => ({
//         description: item.description,
//         labor_hours: Number(item.labor_hours),
//         labor_rate: Number(item.labor_rate),
//         amount: Number(item.total),
//       }));

//       // Prepare ONLY NEW parts (existing parts should not be sent again)
//       const newParts = partsUsed.map((part) => ({
//         part_id: Number(part.part_id),
//         part_name: part.part_name,
//         quantity: Number(part.quantity),
//         unit_price: Number(part.unit_cost),
//         amount: Number(part.total),
//       }));

//       // Prepare the request body with only NEW items and updated totals
//       const requestBody = {
//         labour_estimate: newLabourEstimate,
//         parts_estimate: newPartsEstimate,
//         total_estimate: newTotalEstimate,
//         items: newItems,
//         parts: newParts,
//       };

//       console.log("Submitting NEW data only:", requestBody);

//       // Use PUT method to add new items
//       const response = await fetch(`/api/jobcards/items_add/${jobCardId}`, {
//         method: "PUT",
//         headers: {
//           "Content-Type": "application/json",
//           Authorization: `Bearer ${token}`,
//         },
//         body: JSON.stringify(requestBody),
//       });

//       const responseData = await response.json();

//       if (!response.ok) {
//         throw new Error(
//           responseData.message || "Failed to update service items"
//         );
//       }

//       toast.success("Service items added successfully!");

//       // Move new items to existing items and clear
//       if (jobItems.length > 0) {
//         const newExistingItems = jobItems.map((item, index) => ({
//           ...item,
//           id: existingJobItems.length + index + 1,
//         }));
//         setExistingJobItems([...existingJobItems, ...newExistingItems]);
//       }

//       if (partsUsed.length > 0) {
//         const newExistingParts = partsUsed.map((part, index) => ({
//           ...part,
//           id: existingPartsUsed.length + index + 1,
//         }));
//         setExistingPartsUsed([...existingPartsUsed, ...newExistingParts]);
//       }

//       // Clear new items
//       setJobItems([]);
//       setPartsUsed([]);
//       setSelectedPart({ part_id: "", quantity: 1 });
//       setSelectedPartsName("");

//       // Refresh data from server to ensure consistency
//       fetchExistingJobCardData();
//     } catch (error: any) {
//       console.error("Error updating service items:", error);
//       toast.error(error.message || "Failed to update service items");
//     } finally {
//       setSubmitting(false);
//     }
//   };

//   const handleComplete = () => {
//     router.push(`/admin/jobcards/${jobCardId}`);
//   };

//   // Calculate totals for display
//   const labourTotal = jobItems.reduce((sum, item) => sum + item.total, 0);
//   const partsTotal = partsUsed.reduce((sum, part) => sum + part.total, 0);
//   const existingLabourTotal = existingJobItems.reduce(
//     (sum, item) => sum + item.total,
//     0
//   );
//   const existingPartsTotal = existingPartsUsed.reduce(
//     (sum, part) => sum + part.total,
//     0
//   );
//   const grandTotal =
//     labourTotal + partsTotal + existingLabourTotal + existingPartsTotal;

//   if (!jobCardId) {
//     return (
//       <div className="page-body">
//         <Container fluid>
//           <Row>
//             <Col lg={12}>
//               <Card>
//                 <CardBody className="text-center py-5">
//                   <Spinner color="primary" />
//                   <p className="mt-3">Loading...</p>
//                 </CardBody>
//               </Card>
//             </Col>
//           </Row>
//         </Container>
//       </div>
//     );
//   }

//   // Close dropdown when clicking outside
//   useEffect(() => {
//     const handleClickOutside = (event: MouseEvent) => {
//       if (
//         partsDropdownRef.current &&
//         !partsDropdownRef.current.contains(event.target as Node)
//       ) {
//         setIsPartsDropdownOpen(false);
//       }
//     };

//     document.addEventListener("mousedown", handleClickOutside);
//     return () => {
//       document.removeEventListener("mousedown", handleClickOutside);
//     };
//   }, []);

//   const filteredParts = parts.filter((parts) =>
//     parts.name.toLowerCase().includes(partsSearchTerm.toLowerCase())
//   );

//   const handlePartsSelect = (partId: string, partName: string) => {
//     setSelectedPart((prev) => ({
//       ...prev,
//       part_id: partId,
//     }));

//     setSelectedPartsName(partName);
//     setIsPartsDropdownOpen(false);
//     setPartsSearchTerm("");
//   };

//   return (
//     <div className="page-body">
//       <Breadcrumbs
//         title="Add Service Items"
//         mainTitle="Add Service Items"
//         parent="Job Card Management"
//       />

//       <Container fluid>
//         <Row>
//           <Col lg={12}>
//             <div className="mb-4">
//               <h4>Add Service Items to Job Card</h4>
//               <p className="text-muted">
//                 Job Card ID: <strong>{jobCardId}</strong>
//               </p>
//               <Link
//                 href={`/admin/jobcards/${jobCardId}`}
//                 className="btn btn-outline-primary btn-sm"
//               >
//                 <i className="fa fa-eye me-2"></i>
//                 View Job Card
//               </Link>
//             </div>

//             {/* Existing Items Display */}
//             {existingJobItems.length > 0 && (
//               <Card className="mb-4">
//                 <CardBody>
//                   <h6 className="mb-3 text-muted">Existing Job Items</h6>
//                   <div className="table-responsive">
//                     <Table size="sm" bordered>
//                       <thead>
//                         <tr>
//                           <th>Description</th>
//                           <th>Hours</th>
//                           <th>Rate</th>
//                           <th>Total</th>
//                         </tr>
//                       </thead>
//                       <tbody>
//                         {existingJobItems.map((item, index) => (
//                           <tr key={index}>
//                             <td>{item.description}</td>
//                             <td>{item.labor_hours}</td>
//                             <td>
//                               {Currency}
//                               {item.labor_rate.toFixed(2)}
//                             </td>
//                             <td>
//                               {Currency}
//                               {item.total.toFixed(2)}
//                             </td>
//                           </tr>
//                         ))}
//                       </tbody>
//                     </Table>
//                   </div>
//                 </CardBody>
//               </Card>
//             )}

//             {/* Existing Parts Display */}
//             {existingPartsUsed.length > 0 && (
//               <Card className="mb-4">
//                 <CardBody>
//                   <h6 className="mb-3 text-muted">Existing Parts Used</h6>
//                   <div className="table-responsive">
//                     <Table size="sm" bordered>
//                       <thead>
//                         <tr>
//                           <th>Part Name</th>
//                           <th>Qty</th>
//                           <th>Unit Price</th>
//                           <th>Total</th>
//                           <th>Action</th>
//                         </tr>
//                       </thead>
//                       <tbody>
//                         {existingPartsUsed.map((part, index) => (
//                           <tr key={index}>
//                             <td>{part.part_name || `Part ${part.part_id}`}</td>
//                             <td>{part.quantity}</td>
//                             <td>
//                               {Currency}
//                               {part.unit_cost.toFixed(2)}
//                             </td>
//                             <td>
//                               {Currency}
//                               {part.total.toFixed(2)}
//                             </td>
//                             <td>
//                               <button
//                                 className="action-btn text-white border btn-danger"
//                                 onClick={() => handleDeletePart(part.part_id)}
//                                 title="Delete"
//                               >
//                                 <i className="fa fa-trash"></i>
//                               </button>
//                             </td>
//                           </tr>
//                         ))}
//                       </tbody>
//                     </Table>
//                   </div>
//                 </CardBody>
//               </Card>
//             )}

//             {/* New Job Items Section */}
//             <Card className="mb-4">
//               <CardBody>
//                 <h6 className="mb-3 text-muted">
//                   Add New Job Items / Labour Tasks
//                 </h6>
//                 <Row className="mb-3">
//                   <Col md={5} className="mb-3 mb-md-0">
//                     <Label className="text-muted">Description *</Label>
//                     <Input
//                       type="text"
//                       placeholder="Task description"
//                       value={newJobItem.description}
//                       onChange={(e) =>
//                         setNewJobItem({
//                           ...newJobItem,
//                           description: e.target.value,
//                         })
//                       }
//                       disabled={submitting}
//                     />
//                   </Col>

//                   <Col md={2} className="mb-3 mb-md-0">
//                     <Label className="text-muted">Hours</Label>
//                     <Input
//                       type="number"
//                       placeholder="Hours"
//                       value={newJobItem.labor_hours}
//                       onChange={(e) =>
//                         setNewJobItem({
//                           ...newJobItem,
//                           labor_hours: parseFloat(e.target.value) || 0,
//                         })
//                       }
//                       disabled={submitting}
//                     />
//                   </Col>

//                   <Col md={2} className="mb-3 mb-md-0">
//                     <Label className="text-muted">Rate ({Currency})</Label>
//                     <Input
//                       type="number"
//                       step="0.01"
//                       placeholder="Rate"
//                       value={newJobItem.labor_rate}
//                       onChange={(e) =>
//                         setNewJobItem({
//                           ...newJobItem,
//                           labor_rate: parseFloat(e.target.value) || 0,
//                         })
//                       }
//                       min="0"
//                       disabled={submitting}
//                     />
//                   </Col>

//                   <Col md={2} className="mb-3 mt-4 mb-md-0">
//                     <Button
//                       color="primary"
//                       onClick={handleAddJobItem}
//                       className="w-100"
//                       disabled={submitting}
//                     >
//                       Add Task
//                     </Button>
//                   </Col>
//                 </Row>

//                 {jobItems.length > 0 && (
//                   <div className="table-responsive">
//                     <Table size="sm" bordered>
//                       <thead>
//                         <tr>
//                           <th>Description</th>
//                           <th>Hours</th>
//                           <th>Rate</th>
//                           <th>Total</th>
//                           <th>Action</th>
//                         </tr>
//                       </thead>
//                       <tbody>
//                         {jobItems.map((item) => (
//                           <tr key={item.id}>
//                             <td>{item.description}</td>
//                             <td>{item.labor_hours}</td>
//                             <td>
//                               {Currency}
//                               {item.labor_rate.toFixed(2)}
//                             </td>
//                             <td>
//                               {Currency}
//                               {item.total.toFixed(2)}
//                             </td>
//                             <td>
//                               <Button
//                                 color="danger"
//                                 size="sm"
//                                 onClick={() => handleRemoveJobItem(item.id)}
//                                 disabled={submitting}
//                               >
//                                 <i className="icofont icofont-ui-delete"></i>
//                               </Button>
//                             </td>
//                           </tr>
//                         ))}
//                       </tbody>
//                     </Table>
//                   </div>
//                 )}
//               </CardBody>
//             </Card>

//             {/* Parts Used Section */}
//             <Card className="mb-4">
//               <CardBody>
//                 <h6 className="mb-3 text-muted">Add Parts Used</h6>
//                 <Row className="mb-3">
//                   <Col md={5} className="mb-3 mb-md-0">
//                     <Label className="text-muted">Select Parts</Label>
//                     {loading ? (
//                       <div className="d-flex align-items-center">
//                         <Spinner size="sm" className="me-2" />
//                         Loading Parts...
//                       </div>
//                     ) : parts.length === 0 ? (
//                       <div className="text-danger">
//                         No Parts found. Please add a Parts first.
//                       </div>
//                     ) : (
//                       <div className="position-relative" ref={partsDropdownRef}>
//                         {/* Dropdown trigger */}
//                         <div
//                           onClick={() =>
//                             setIsPartsDropdownOpen(!isPartsDropdownOpen)
//                           }
//                           className="d-flex w-100 align-items-center justify-content-between cursor-pointer form-select border"
//                           style={{
//                             minHeight: "38px",
//                             padding: "0.375rem 0.75rem",
//                             cursor: "pointer",
//                           }}
//                         >
//                           <span
//                             className="text-truncate"
//                             style={{ maxWidth: "calc(100% - 20px)" }}
//                           >
//                             {selectedPartsName || "Select part"}
//                           </span>
//                         </div>

//                         {/* Dropdown menu */}
//                         {isPartsDropdownOpen && (
//                           <div
//                             className="position-absolute w-100 mt-1 border rounded shadow dropdown-menu show"
//                             style={{
//                               maxHeight: "300px",
//                               overflow: "auto",
//                               zIndex: 1050,
//                             }}
//                           >
//                             {/* Search input */}
//                             <div className="p-2 border-bottom">
//                               <Input
//                                 type="text"
//                                 value={partsSearchTerm}
//                                 onChange={(e) => {
//                                   setPartsSearchTerm(e.target.value);
//                                 }}
//                                 placeholder="Search parts..."
//                                 className="form-control form-control-sm"
//                                 autoFocus
//                                 onClick={(e) => e.stopPropagation()}
//                               />
//                             </div>

//                             {/* Customer list */}
//                             <div
//                               style={{
//                                 maxHeight: "200px",
//                                 overflowY: "auto",
//                               }}
//                             >
//                               {filteredParts.length > 0 ? (
//                                 <ul className="list-unstyled mb-0">
//                                   {filteredParts.map((parts) => (
//                                     <li
//                                       key={parts.id}
//                                       onClick={() =>
//                                         parts.quantity > 0 &&
//                                         handlePartsSelect(parts.id, parts.name)
//                                       }
//                                       className={`px-3 py-2 ${
//                                         parts.quantity === 0
//                                           ? "text-muted"
//                                           : "cursor-pointer hover-bg-light"
//                                       }`}
//                                       style={{
//                                         cursor:
//                                           parts.quantity === 0
//                                             ? "not-allowed"
//                                             : "pointer",
//                                       }}
//                                     >
//                                       <div className="d-flex align-items-center">
//                                         {parts.name} – {Currency}
//                                         {(typeof parts.unit_cost === "string"
//                                           ? parseFloat(parts.unit_cost)
//                                           : parts.unit_cost
//                                         ).toFixed(2)}{" "}
//                                         | Stock: {parts.quantity}
//                                       </div>
//                                     </li>
//                                   ))}
//                                 </ul>
//                               ) : (
//                                 <div className="px-3 py-2 text-muted">
//                                   {partsSearchTerm
//                                     ? "No matching part found"
//                                     : "No part available"}
//                                 </div>
//                               )}
//                             </div>
//                           </div>
//                         )}
//                       </div>
//                     )}
//                   </Col>
//                   <Col md={2} className="mb-3 mb-md-0">
//                     <Label className="text-muted">Quantity</Label>
//                     <Input
//                       type="number"
//                       placeholder="Qty"
//                       value={selectedPart.quantity}
//                       onChange={(e) =>
//                         setSelectedPart({
//                           ...selectedPart,
//                           quantity: parseInt(e.target.value) || 1,
//                         })
//                       }
//                       min="1"
//                       disabled={submitting}
//                     />
//                   </Col>
//                   <Col md={2} className="mb-3 mt-4 mb-md-0">
//                     <Button
//                       color="primary"
//                       onClick={handleAddPart}
//                       className="w-100"
//                       disabled={submitting || !selectedPart.part_id}
//                     >
//                       Add Part
//                     </Button>
//                   </Col>
//                 </Row>

//                 {partsUsed.length > 0 && (
//                   <div className="table-responsive">
//                     <Table size="sm" bordered>
//                       <thead>
//                         <tr>
//                           <th>Part Name</th>
//                           <th>Qty</th>
//                           <th>Unit Price</th>
//                           <th>Total</th>
//                           <th>Action</th>
//                         </tr>
//                       </thead>
//                       <tbody>
//                         {partsUsed.map((part) => (
//                           <tr key={part.id}>
//                             <td>{part.part_name}</td>
//                             <td>{part.quantity}</td>
//                             <td>
//                               {Currency}
//                               {part.unit_cost.toFixed(2)}
//                             </td>
//                             <td>
//                               {Currency}
//                               {part.total.toFixed(2)}
//                             </td>
//                             <td>
//                               <Button
//                                 color="danger"
//                                 size="sm"
//                                 onClick={() => handleRemovePart(part.id)}
//                                 disabled={submitting}
//                               >
//                                 <i className="icofont icofont-ui-delete"></i>
//                               </Button>
//                             </td>
//                           </tr>
//                         ))}
//                       </tbody>
//                     </Table>
//                   </div>
//                 )}
//               </CardBody>
//             </Card>

//             {/* Summary Section */}
//             <Card className="mb-4">
//               <CardBody>
//                 <h6 className="mb-3 text-muted">Cost Summary</h6>
//                 <Row>
//                   <Col md={6}>
//                     {existingLabourTotal > 0 && (
//                       <div className="d-flex justify-content-between mb-2 text-muted">
//                         <span>Existing Labour:</span>
//                         <strong>
//                           {Currency}
//                           {existingLabourTotal.toFixed(2)}
//                         </strong>
//                       </div>
//                     )}
//                     {labourTotal > 0 && (
//                       <div className="d-flex justify-content-between mb-2 text-muted">
//                         <span>New Labour:</span>
//                         <strong>
//                           {Currency}
//                           {labourTotal.toFixed(2)}
//                         </strong>
//                       </div>
//                     )}
//                     {existingPartsTotal > 0 && (
//                       <div className="d-flex justify-content-between mb-2 text-muted">
//                         <span>Existing Parts:</span>
//                         <strong>
//                           {Currency}
//                           {existingPartsTotal.toFixed(2)}
//                         </strong>
//                       </div>
//                     )}
//                     {partsTotal > 0 && (
//                       <div className="d-flex justify-content-between mb-2 text-muted">
//                         <span>New Parts:</span>
//                         <strong>
//                           {Currency}
//                           {partsTotal.toFixed(2)}
//                         </strong>
//                       </div>
//                     )}
//                     <hr />
//                     <div className="d-flex justify-content-between text-muted">
//                       <span>
//                         <strong>Grand Total:</strong>
//                       </span>
//                       <strong className="text-primary">
//                         {Currency}
//                         {grandTotal.toFixed(2)}
//                       </strong>
//                     </div>
//                   </Col>
//                 </Row>
//               </CardBody>
//             </Card>

//             {/* Submit Buttons */}
//             <div className="d-flex gap-2">
//               <Button
//                 color="primary"
//                 size="lg"
//                 onClick={handleSubmit}
//                 disabled={
//                   submitting ||
//                   (jobItems.length === 0 && partsUsed.length === 0)
//                 }
//               >
//                 {submitting ? (
//                   <>
//                     <Spinner size="sm" className="me-2" />
//                     Saving...
//                   </>
//                 ) : (
//                   <>
//                     <i className="fa fa-save me-2"></i>
//                     Save All
//                   </>
//                 )}
//               </Button>
//               <Button
//                 color="success"
//                 size="lg"
//                 onClick={handleComplete}
//                 disabled={submitting}
//               >
//                 <i className="fa fa-check me-2"></i>
//                 Complete & View Job Card
//               </Button>
//               <Button
//                 color="secondary"
//                 size="lg"
//                 onClick={() => router.push("/admin/jobcards")}
//                 disabled={submitting}
//               >
//                 <i className="fa fa-times me-2"></i>
//                 Cancel
//               </Button>
//             </div>
//           </Col>
//         </Row>
//       </Container>
//     </div>
//   );
// }

// export default AddServicePage;

"use client";

import {
  Card,
  CardBody,
  Row,
  Col,
  Label,
  Input,
  Button,
  Table,
  Spinner,
  Container,
} from "reactstrap";
import React, { useState, useEffect, useRef } from "react";
import { toast } from "react-toastify";
import { useAuth } from "@/helper/AuthContext";
import Breadcrumbs from "@/CommonElements/Breadcrumbs";
import { Currency } from "@/utils/Utils";
import { useSearchParams, useRouter } from "next/navigation";
import Link from "next/link";

interface Part {
  id: string;
  name: string;
  sku: string;
  unit_cost: string | number;
  quantity: number;
}

interface JobItem {
  id: number;
  description: string;
  labor_hours: number;
  labor_rate: number;
  total: number;
}

interface PartUsed {
  id: number;
  part_id: string;
  part_name: string;
  quantity: number;
  unit_cost: number;
  total: number;
  job_card_part_id?: number;
}

function AddServicePage() {
  const { state } = useAuth();
  const router = useRouter();
  const searchParams = useSearchParams();
  const jobCardId = searchParams.get("id") || "";

  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [parts, setParts] = useState<Part[]>([]);
  const [jobItems, setJobItems] = useState<JobItem[]>([]);
  const [partsUsed, setPartsUsed] = useState<PartUsed[]>([]);
  const [existingJobItems, setExistingJobItems] = useState<JobItem[]>([]);
  const [existingPartsUsed, setExistingPartsUsed] = useState<PartUsed[]>([]);

  const [partsSearchTerm, setPartsSearchTerm] = useState("");
  const [isPartsDropdownOpen, setIsPartsDropdownOpen] = useState(false);
  const [selectedPartsName, setSelectedPartsName] = useState("");
  const partsDropdownRef = useRef<HTMLDivElement | null>(null);

  const [newJobItem, setNewJobItem] = useState({
    description: "",
    labor_hours: 0,
    labor_rate: 75,
  });

  const [selectedPart, setSelectedPart] = useState({
    part_id: "",
    quantity: 1,
  });

  useEffect(() => {
    if (!jobCardId) {
      toast.error("No job card ID provided");
      router.push("/admin/jobcards");
      return;
    }

    fetchParts();
    fetchExistingJobCardData();
  }, [jobCardId]);

  const fetchExistingJobCardData = async () => {
    try {
      const token = state?.accessToken || localStorage.getItem("token");

      const response = await fetch(`/api/jobcards/${jobCardId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (response.ok) {
        const jobCardData = await response.json();

        if (jobCardData.data) {
          const jobCard = jobCardData.data;

          // Set existing job items
          if (jobCard.items && jobCard.items.length > 0) {
            const items = jobCard.items.map((item: any, index: number) => ({
              id: index + 1,
              description: item.description || "",
              labor_hours: parseFloat(item.labor_hours) || 0,
              labor_rate: parseFloat(item.labor_rate) || 0,
              total: parseFloat(item.amount) || 0,
            }));
            setExistingJobItems(items);
          }

          // Set existing parts used
          if (jobCard.parts && jobCard.parts.length > 0) {
            const parts = jobCard.parts.map((part: any, index: number) => ({
              id: index + 1,
              // part_id: part.part_id || "",
              job_card_part_id: part.id,
              part_name: part.part_name || "",
              quantity: parseFloat(part.quantity) || 0,
              unit_cost: parseFloat(part.unit_price) || 0,
              total: parseFloat(part.amount) || 0,
            }));
            setExistingPartsUsed(parts);
          }
        }
      }
    } catch (error: any) {
      console.error("Error fetching job card data:", error);
    }
  };

  const fetchParts = async () => {
    try {
      setLoading(true);
      const token = state?.accessToken || localStorage.getItem("token");

      const partsRes = await fetch("/api/parts_list", {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (partsRes.ok) {
        const partsData = await partsRes.json();
        setParts(partsData.data || []);
      } else {
        toast.error("Failed to load parts");
      }
    } catch (error: any) {
      console.error("Error fetching parts:", error);
      toast.error("Failed to load parts");
    } finally {
      setLoading(false);
    }
  };

  const refreshData = () => {
    fetchExistingJobCardData();
    fetchParts(); // Refresh parts list in case stock changed
  };

  const handleAddJobItem = () => {
    if (newJobItem.description && newJobItem.labor_hours > 0) {
      const total = newJobItem.labor_hours * newJobItem.labor_rate;
      setJobItems([
        ...jobItems,
        {
          id: Date.now(),
          ...newJobItem,
          total,
        },
      ]);
      setNewJobItem({
        description: "",
        labor_hours: 0,
        labor_rate: 75,
      });
    } else {
      toast.error("Please enter description and valid hours");
    }
  };

  const handleRemoveJobItem = (id: number) => {
    setJobItems(jobItems.filter((item) => item.id !== id));
  };

  // const handleAddPart = () => {
  //   if (selectedPart.part_id) {
  //     const part = parts.find((p) => p.id === selectedPart.part_id);
  //     if (part && selectedPart.quantity > 0) {
  //       const unitCost =
  //         typeof part.unit_cost === "string"
  //           ? parseFloat(part.unit_cost)
  //           : part.unit_cost;

  //       if (selectedPart.quantity > part.quantity) {
  //         toast.error(`Only ${part.quantity} units available in stock`);
  //         return;
  //       }

  //       const total = unitCost * selectedPart.quantity;
  //       setPartsUsed([
  //         ...partsUsed,
  //         {
  //           id: Date.now(),
  //           part_id: part.id,
  //           part_name: part.name,
  //           quantity: selectedPart.quantity,
  //           unit_cost: unitCost,
  //           total,
  //         },
  //       ]);
  //       setSelectedPart({ part_id: "", quantity: 1 });
  //     } else {
  //       toast.error("Please select a valid part and quantity");
  //     }
  //   } else {
  //     toast.error("Please select a part");
  //   }
  // };
  // const handleAddPart = () => {
  //   if (selectedPart.part_id) {
  //     const part = parts.find((p) => p.id === selectedPart.part_id);
  //     if (part && selectedPart.quantity > 0) {
  //       const unitCost =
  //         typeof part.unit_cost === "string"
  //           ? parseFloat(part.unit_cost)
  //           : part.unit_cost;

  //       // Check stock availability
  //       if (selectedPart.quantity > part.quantity) {
  //         toast.error(`Only ${part.quantity} units available in stock`);
  //         return;
  //       }

  //       // Check if this part is already in the NEW partsUsed list
  //       const existingInNewList = partsUsed.find((p) => p.part_id === part.id);
  //       if (existingInNewList) {
  //         const newTotalQuantity =
  //           existingInNewList.quantity + selectedPart.quantity;
  //         if (newTotalQuantity > part.quantity) {
  //           toast.error(
  //             `Cannot add ${selectedPart.quantity} more units. Only ${
  //               part.quantity - existingInNewList.quantity
  //             } available.`
  //           );
  //           return;
  //         }

  //         // Update existing part quantity in new list
  //         setPartsUsed(
  //           partsUsed.map((p) =>
  //             p.part_id === part.id
  //               ? {
  //                   ...p,
  //                   quantity: p.quantity + selectedPart.quantity,
  //                   total: (p.quantity + selectedPart.quantity) * p.unit_cost,
  //                 }
  //               : p
  //           )
  //         );
  //         toast.info(
  //           `Updated quantity of ${part.name} to ${
  //             existingInNewList.quantity + selectedPart.quantity
  //           }`
  //         );
  //       } else {
  //         // Check if part is already in existing parts (from server)
  //         const existingInServerList = existingPartsUsed.find(
  //           (p) => p.part_id === part.id
  //         );
  //         if (existingInServerList) {
  //           toast.info(
  //             `Part "${part.name}" is already in the job card. You can update the quantity.`
  //           );
  //           return;
  //         }

  //         // Add as new part
  //         const total = unitCost * selectedPart.quantity;
  //         setPartsUsed([
  //           ...partsUsed,
  //           {
  //             id: Date.now(),
  //             part_id: part.id,
  //             part_name: part.name,
  //             quantity: selectedPart.quantity,
  //             unit_cost: unitCost,
  //             total,
  //           },
  //         ]);
  //       }

  //       // Reset selection
  //       setSelectedPart({ part_id: "", quantity: 1 });
  //       setSelectedPartsName("");
  //     } else {
  //       toast.error("Please select a valid part and quantity");
  //     }
  //   } else {
  //     toast.error("Please select a part");
  //   }
  // };

  const handleAddPart = () => {
    if (selectedPart.part_id) {
      const part = parts.find((p) => p.id === selectedPart.part_id);
      if (part && selectedPart.quantity > 0) {
        const unitCost =
          typeof part.unit_cost === "string"
            ? parseFloat(part.unit_cost)
            : part.unit_cost;

        // Check stock availability
        if (selectedPart.quantity > part.quantity) {
          toast.error(`Only ${part.quantity} units available in stock`);
          return;
        }

        // Check if this part is already in the NEW partsUsed list
        const existingInNewList = partsUsed.find((p) => p.part_id === part.id);
        if (existingInNewList) {
          const newTotalQuantity =
            existingInNewList.quantity + selectedPart.quantity;
          if (newTotalQuantity > part.quantity) {
            toast.error(
              `Cannot add ${selectedPart.quantity} more units. Only ${
                part.quantity - existingInNewList.quantity
              } available.`
            );
            return;
          }

          // Update existing part quantity in new list
          setPartsUsed(
            partsUsed.map((p) =>
              p.part_id === part.id
                ? {
                    ...p,
                    quantity: p.quantity + selectedPart.quantity,
                    total: (p.quantity + selectedPart.quantity) * p.unit_cost,
                  }
                : p
            )
          );
          toast.info(
            `Updated quantity of ${part.name} to ${
              existingInNewList.quantity + selectedPart.quantity
            }`
          );

          // Reset selection
          setSelectedPart({ part_id: "", quantity: 1 });
          setSelectedPartsName("");
          return;
        }

        // Check if part is already in existing parts (from server)
        const existingInServerList = existingPartsUsed.find(
          (p) => p.part_id === part.id
        );
        if (existingInServerList) {
          toast.warning(
            `Part "${part.name}" is already in the job card. Remove it first if you want to add it again.`
          );
          return;
        }

        // Add as new part
        const total = unitCost * selectedPart.quantity;
        setPartsUsed([
          ...partsUsed,
          {
            id: Date.now(),
            part_id: part.id,
            part_name: part.name,
            quantity: selectedPart.quantity,
            unit_cost: unitCost,
            total,
          },
        ]);

        // Reset selection
        setSelectedPart({ part_id: "", quantity: 1 });
        setSelectedPartsName("");
      } else {
        toast.error("Please select a valid part and quantity");
      }
    } else {
      toast.error("Please select a part");
    }
  };
  const handleRemovePart = (id: number) => {
    setPartsUsed(partsUsed.filter((part) => part.id !== id));
  };

  // const handleDeletePart = async (id: string) => {
  //   if (!confirm("Are you sure you want to delete this part?")) {
  //     return;
  //   }

  //   try {
  //     const token = localStorage.getItem("token");

  //     const response = await fetch(`/api/jobcards/remove_parts/${id}`, {
  //       method: "PUT",
  //       headers: {
  //         Authorization: `Bearer ${token}`,
  //         "Content-Type": "application/json",
  //       },
  //     });

  //     if (response.ok) {
  //       toast.success("Customer deleted successfully");
  //       // Refresh the customers list
  //       // fetchCustomers();
  //     } else {
  //       const errorData = await response.json();
  //       toast.error(errorData.message || "Failed to delete customer");
  //     }
  //   } catch (error: any) {
  //     console.error("Error deleting customer:", error);
  //     toast.error(`Failed to delete customer: ${error.message}`);
  //   }
  // };
  const handleDeletePart = async (jobCardPartId: number) => {
    if (
      !confirm("Are you sure you want to remove this part from the job card?")
    ) {
      return;
    }

    try {
      const token = state?.accessToken || localStorage.getItem("token");

      // Use the job card part ID (not part_id)
      const response = await fetch(
        `/api/jobcards/remove_parts/${jobCardPartId}`,
        {
          method: "PUT",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        }
      );

      if (response.ok) {
        toast.success("Part removed successfully");

        // Update local state immediately
        setExistingPartsUsed(
          existingPartsUsed.filter(
            (part) => part.job_card_part_id !== jobCardPartId
          )
        );

        // Refresh data from server
        fetchExistingJobCardData();
      } else {
        const errorData = await response.json();
        toast.error(errorData.message || "Failed to remove part");
      }
    } catch (error: any) {
      console.error("Error removing part:", error);
      toast.error(`Failed to remove part: ${error.message}`);
    }
  };
  const calculateEstimates = () => {
    // Calculate new items totals
    const newLabourTotal = jobItems.reduce((sum, item) => sum + item.total, 0);
    const newPartsTotal = partsUsed.reduce((sum, part) => sum + part.total, 0);

    // Calculate existing items totals
    const existingLabourTotal = existingJobItems.reduce(
      (sum, item) => sum + item.total,
      0
    );
    const existingPartsTotal = existingPartsUsed.reduce(
      (sum, part) => sum + part.total,
      0
    );

    // Calculate combined totals
    const labourEstimate = newLabourTotal + existingLabourTotal;
    const partsEstimate = newPartsTotal + existingPartsTotal;
    const totalEstimate = labourEstimate + partsEstimate;

    return {
      labour_estimate: labourEstimate,
      parts_estimate: partsEstimate,
      total_estimate: totalEstimate,
    };
  };

  // const handleSubmit = async () => {
  //   if (!jobCardId) {
  //     toast.error("Job card ID is required");
  //     return;
  //   }

  //   if (jobItems.length === 0 && partsUsed.length === 0) {
  //     toast.error("Please add at least one new job item or part");
  //     return;
  //   }

  //   try {
  //     setSubmitting(true);
  //     const token = state?.accessToken || localStorage.getItem("token");

  //     // Calculate estimates for NEW items only (existing items are already in the job card)
  //     const newLabourTotal = jobItems.reduce(
  //       (sum, item) => sum + item.total,
  //       0
  //     );
  //     const newPartsTotal = partsUsed.reduce(
  //       (sum, part) => sum + part.total,
  //       0
  //     );

  //     // Get current totals from the server to calculate new totals
  //     const currentTotals = calculateEstimates();
  //     const newLabourEstimate = currentTotals.labour_estimate + newLabourTotal;
  //     const newPartsEstimate = currentTotals.parts_estimate + newPartsTotal;
  //     const newTotalEstimate =
  //       currentTotals.total_estimate + newLabourTotal + newPartsTotal;

  //     // Prepare ONLY NEW items (existing items should not be sent again)
  //     const newItems = jobItems.map((item) => ({
  //       description: item.description,
  //       labor_hours: Number(item.labor_hours),
  //       labor_rate: Number(item.labor_rate),
  //       amount: Number(item.total),
  //     }));

  //     // Prepare ONLY NEW parts (existing parts should not be sent again)
  //     const newParts = partsUsed.map((part) => ({
  //       part_id: Number(part.part_id),
  //       part_name: part.part_name,
  //       quantity: Number(part.quantity),
  //       unit_price: Number(part.unit_cost),
  //       amount: Number(part.total),
  //     }));

  //     // Prepare the request body with only NEW items and updated totals
  //     const requestBody = {
  //       labour_estimate: newLabourEstimate,
  //       parts_estimate: newPartsEstimate,
  //       total_estimate: newTotalEstimate,
  //       items: newItems,
  //       parts: newParts,
  //     };

  //     console.log("Submitting NEW data only:", requestBody);

  //     // Use PUT method to add new items
  //     const response = await fetch(`/api/jobcards/items_add/${jobCardId}`, {
  //       method: "PUT",
  //       headers: {
  //         "Content-Type": "application/json",
  //         Authorization: `Bearer ${token}`,
  //       },
  //       body: JSON.stringify(requestBody),
  //     });

  //     const responseData = await response.json();

  //     if (!response.ok) {
  //       throw new Error(
  //         responseData.message || "Failed to update service items"
  //       );
  //     }

  //     toast.success("Service items added successfully!");

  //     // Move new items to existing items and clear
  //     if (jobItems.length > 0) {
  //       const newExistingItems = jobItems.map((item, index) => ({
  //         ...item,
  //         id: existingJobItems.length + index + 1,
  //       }));
  //       setExistingJobItems([...existingJobItems, ...newExistingItems]);
  //     }

  //     if (partsUsed.length > 0) {
  //       const newExistingParts = partsUsed.map((part, index) => ({
  //         ...part,
  //         id: existingPartsUsed.length + index + 1,
  //       }));
  //       setExistingPartsUsed([...existingPartsUsed, ...newExistingParts]);
  //     }

  //     // Clear new items
  //     setJobItems([]);
  //     setPartsUsed([]);
  //     setSelectedPart({ part_id: "", quantity: 1 });
  //     setSelectedPartsName("");

  //     // Refresh data from server to ensure consistency
  //     fetchExistingJobCardData();
  //   } catch (error: any) {
  //     console.error("Error updating service items:", error);
  //     toast.error(error.message || "Failed to update service items");
  //   } finally {
  //     setSubmitting(false);
  //   }
  // };
  const handleSubmit = async () => {
    if (!jobCardId) {
      toast.error("Job card ID is required");
      return;
    }

    if (jobItems.length === 0 && partsUsed.length === 0) {
      toast.error("Please add at least one new job item or part");
      return;
    }

    try {
      setSubmitting(true);
      const token = state?.accessToken || localStorage.getItem("token");

      // Calculate estimates for NEW items only
      const newLabourTotal = jobItems.reduce(
        (sum, item) => sum + item.total,
        0
      );
      const newPartsTotal = partsUsed.reduce(
        (sum, part) => sum + part.total,
        0
      );

      // Get current job card data to calculate correct totals
      const jobCardResponse = await fetch(`/api/jobcards/${jobCardId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (!jobCardResponse.ok) {
        throw new Error("Failed to fetch current job card data");
      }

      const jobCardData = await jobCardResponse.json();
      const currentJobCard = jobCardData.data;

      // Get current totals from the job card
      const currentLabourEstimate =
        parseFloat(currentJobCard.labor_estimate) || 0;
      const currentPartsEstimate =
        parseFloat(currentJobCard.parts_estimate) || 0;
      const currentTotalEstimate =
        parseFloat(currentJobCard.total_estimate) || 0;

      // Calculate new totals
      const newLabourEstimate = currentLabourEstimate + newLabourTotal;
      const newPartsEstimate = currentPartsEstimate + newPartsTotal;
      const newTotalEstimate =
        currentTotalEstimate + newLabourTotal + newPartsTotal;

      // Prepare ONLY NEW items
      const newItems = jobItems.map((item) => ({
        description: item.description,
        labor_hours: Number(item.labor_hours),
        labor_rate: Number(item.labor_rate),
        amount: Number(item.total),
      }));

      // Prepare ONLY NEW parts
      const newParts = partsUsed.map((part) => ({
        part_id: Number(part.part_id),
        part_name: part.part_name,
        quantity: Number(part.quantity),
        unit_price: Number(part.unit_cost),
        amount: Number(part.total),
      }));

      // Prepare the request body
      const requestBody = {
        labour_estimate: newLabourEstimate,
        parts_estimate: newPartsEstimate,
        total_estimate: newTotalEstimate,
        items: newItems,
        parts: newParts,
      };

      console.log("Submitting NEW data only:", requestBody);

      // Use PUT method to add new items
      const response = await fetch(`/api/jobcards/items_add/${jobCardId}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(requestBody),
      });

      const responseData = await response.json();

      if (!response.ok) {
        throw new Error(
          responseData.message || "Failed to update service items"
        );
      }

      toast.success("Service items added successfully!");

      // Clear new items only
      setJobItems([]);
      setPartsUsed([]);
      setSelectedPart({ part_id: "", quantity: 1 });
      setSelectedPartsName("");

      // Refresh data from server to show updated state
      fetchExistingJobCardData();
    } catch (error: any) {
      console.error("Error updating service items:", error);
      toast.error(error.message || "Failed to update service items");
    } finally {
      setSubmitting(false);
    }
  };
  const handleComplete = () => {
    router.push(`/admin/jobcards/${jobCardId}`);
  };

  // Calculate totals for display
  const labourTotal = jobItems.reduce((sum, item) => sum + item.total, 0);
  const partsTotal = partsUsed.reduce((sum, part) => sum + part.total, 0);
  const existingLabourTotal = existingJobItems.reduce(
    (sum, item) => sum + item.total,
    0
  );
  const existingPartsTotal = existingPartsUsed.reduce(
    (sum, part) => sum + part.total,
    0
  );
  const grandTotal =
    labourTotal + partsTotal + existingLabourTotal + existingPartsTotal;

  if (!jobCardId) {
    return (
      <div className="page-body">
        <Container fluid>
          <Row>
            <Col lg={12}>
              <Card>
                <CardBody className="text-center py-5">
                  <Spinner color="primary" />
                  <p className="mt-3">Loading...</p>
                </CardBody>
              </Card>
            </Col>
          </Row>
        </Container>
      </div>
    );
  }

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        partsDropdownRef.current &&
        !partsDropdownRef.current.contains(event.target as Node)
      ) {
        setIsPartsDropdownOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const filteredParts = parts.filter((parts) =>
    parts.name.toLowerCase().includes(partsSearchTerm.toLowerCase())
  );

  const handlePartsSelect = (partId: string, partName: string) => {
    setSelectedPart((prev) => ({
      ...prev,
      part_id: partId,
    }));

    setSelectedPartsName(partName);
    setIsPartsDropdownOpen(false);
    setPartsSearchTerm("");
  };

  return (
    <div className="page-body">
      <Breadcrumbs
        title="Add Service Items"
        mainTitle="Add Service Items"
        parent="Job Card Management"
      />

      <Container fluid>
        <Row>
          <Col lg={12}>
            <div className="mb-4">
              <h4>Add Service Items to Job Card</h4>
              <p className="text-muted">
                Job Card ID: <strong>{jobCardId}</strong>
              </p>
              <Link
                href={`/admin/jobcards/${jobCardId}`}
                className="btn btn-outline-primary btn-sm"
              >
                <i className="fa fa-eye me-2"></i>
                View Job Card
              </Link>
            </div>

            {/* Existing Items Display */}
            {existingJobItems.length > 0 && (
              <Card className="mb-4">
                <CardBody>
                  <h6 className="mb-3 text-muted">Existing Job Items</h6>
                  <div className="table-responsive">
                    <Table size="sm" bordered>
                      <thead>
                        <tr>
                          <th>Description</th>
                          <th>Hours</th>
                          <th>Rate</th>
                          <th>Total</th>
                        </tr>
                      </thead>
                      <tbody>
                        {existingJobItems.map((item, index) => (
                          <tr key={index}>
                            <td>{item.description}</td>
                            <td>{item.labor_hours}</td>
                            <td>
                              {Currency}
                              {item.labor_rate.toFixed(2)}
                            </td>
                            <td>
                              {Currency}
                              {item.total.toFixed(2)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </Table>
                  </div>
                </CardBody>
              </Card>
            )}

            {/* Existing Parts Display */}
            {existingPartsUsed.length > 0 && (
              <Card className="mb-4">
                <CardBody>
                  <h6 className="mb-3 text-muted">Existing Parts Used</h6>
                  <div className="table-responsive">
                    <Table size="sm" bordered>
                      <thead>
                        <tr>
                          <th>Part Name</th>
                          <th>Qty</th>
                          <th>Unit Price</th>
                          <th>Total</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        {existingPartsUsed.map((part, index) => (
                          <tr key={index}>
                            <td>{part.part_name || `Part ${part.part_id}`}</td>
                            <td>{part.quantity}</td>
                            <td>
                              {Currency}
                              {part.unit_cost.toFixed(2)}
                            </td>
                            <td>
                              {Currency}
                              {part.total.toFixed(2)}
                            </td>
                            {/* <td>
                              <button
                                className="action-btn text-white border btn-danger"
                                onClick={() => handleDeletePart(part.part_id)}
                                title="Delete"
                              >
                                <i className="fa fa-trash"></i>
                              </button>
                            </td> */}
                            <td>
                              <button
                                className="action-btn text-white border btn-danger"
                                onClick={() =>
                                  handleDeletePart(part.job_card_part_id!)
                                }
                                title="Delete"
                                disabled={submitting || !part.job_card_part_id}
                              >
                                <i className="fa fa-trash"></i>
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </Table>
                  </div>
                </CardBody>
              </Card>
            )}

            {/* New Job Items Section */}
            <Card className="mb-4">
              <CardBody>
                <h6 className="mb-3 text-muted">
                  Add New Job Items / Labour Tasks
                </h6>
                <Row className="mb-3">
                  <Col md={5} className="mb-3 mb-md-0">
                    <Label className="text-muted">Description *</Label>
                    <Input
                      type="text"
                      placeholder="Task description"
                      value={newJobItem.description}
                      onChange={(e) =>
                        setNewJobItem({
                          ...newJobItem,
                          description: e.target.value,
                        })
                      }
                      disabled={submitting}
                    />
                  </Col>

                  <Col md={2} className="mb-3 mb-md-0">
                    <Label className="text-muted">Hours</Label>
                    <Input
                      type="number"
                      placeholder="Hours"
                      value={newJobItem.labor_hours}
                      onChange={(e) =>
                        setNewJobItem({
                          ...newJobItem,
                          labor_hours: parseFloat(e.target.value) || 0,
                        })
                      }
                      disabled={submitting}
                    />
                  </Col>

                  <Col md={2} className="mb-3 mb-md-0">
                    <Label className="text-muted">Rate ({Currency})</Label>
                    <Input
                      type="number"
                      step="0.01"
                      placeholder="Rate"
                      value={newJobItem.labor_rate}
                      onChange={(e) =>
                        setNewJobItem({
                          ...newJobItem,
                          labor_rate: parseFloat(e.target.value) || 0,
                        })
                      }
                      min="0"
                      disabled={submitting}
                    />
                  </Col>

                  <Col md={2} className="mb-3 mt-4 mb-md-0">
                    <Button
                      color="primary"
                      onClick={handleAddJobItem}
                      className="w-100"
                      disabled={submitting}
                    >
                      Add Task
                    </Button>
                  </Col>
                </Row>

                {jobItems.length > 0 && (
                  <div className="table-responsive">
                    <Table size="sm" bordered>
                      <thead>
                        <tr>
                          <th>Description</th>
                          <th>Hours</th>
                          <th>Rate</th>
                          <th>Total</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        {jobItems.map((item) => (
                          <tr key={item.id}>
                            <td>{item.description}</td>
                            <td>{item.labor_hours}</td>
                            <td>
                              {Currency}
                              {item.labor_rate.toFixed(2)}
                            </td>
                            <td>
                              {Currency}
                              {item.total.toFixed(2)}
                            </td>
                            <td>
                              <Button
                                color="danger"
                                size="sm"
                                onClick={() => handleRemoveJobItem(item.id)}
                                disabled={submitting}
                              >
                                <i className="icofont icofont-ui-delete"></i>
                              </Button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </Table>
                  </div>
                )}
              </CardBody>
            </Card>

            {/* Parts Used Section */}
            <Card className="mb-4">
              <CardBody>
                <h6 className="mb-3 text-muted">Add Parts Used</h6>
                <Row className="mb-3">
                  <Col md={5} className="mb-3 mb-md-0">
                    <Label className="text-muted">Select Parts</Label>
                    {loading ? (
                      <div className="d-flex align-items-center">
                        <Spinner size="sm" className="me-2" />
                        Loading Parts...
                      </div>
                    ) : parts.length === 0 ? (
                      <div className="text-danger">
                        No Parts found. Please add a Parts first.
                      </div>
                    ) : (
                      <div className="position-relative" ref={partsDropdownRef}>
                        {/* Dropdown trigger */}
                        <div
                          onClick={() =>
                            setIsPartsDropdownOpen(!isPartsDropdownOpen)
                          }
                          className="d-flex w-100 align-items-center justify-content-between cursor-pointer form-select border"
                          style={{
                            minHeight: "38px",
                            padding: "0.375rem 0.75rem",
                            cursor: "pointer",
                          }}
                        >
                          <span
                            className="text-truncate"
                            style={{ maxWidth: "calc(100% - 20px)" }}
                          >
                            {selectedPartsName || "Select part"}
                          </span>
                        </div>

                        {/* Dropdown menu */}
                        {isPartsDropdownOpen && (
                          <div
                            className="position-absolute w-100 mt-1 border rounded shadow dropdown-menu show"
                            style={{
                              maxHeight: "300px",
                              overflow: "auto",
                              zIndex: 1050,
                            }}
                          >
                            {/* Search input */}
                            <div className="p-2 border-bottom">
                              <Input
                                type="text"
                                value={partsSearchTerm}
                                onChange={(e) => {
                                  setPartsSearchTerm(e.target.value);
                                }}
                                placeholder="Search parts..."
                                className="form-control form-control-sm"
                                autoFocus
                                onClick={(e) => e.stopPropagation()}
                              />
                            </div>

                            {/* Customer list */}
                            <div
                              style={{
                                maxHeight: "200px",
                                overflowY: "auto",
                              }}
                            >
                              {filteredParts.length > 0 ? (
                                <ul className="list-unstyled mb-0">
                                  {filteredParts.map((parts) => (
                                    <li
                                      key={parts.id}
                                      onClick={() =>
                                        parts.quantity > 0 &&
                                        handlePartsSelect(parts.id, parts.name)
                                      }
                                      className={`px-3 py-2 ${
                                        parts.quantity === 0
                                          ? "text-muted"
                                          : "cursor-pointer hover-bg-light"
                                      }`}
                                      style={{
                                        cursor:
                                          parts.quantity === 0
                                            ? "not-allowed"
                                            : "pointer",
                                      }}
                                    >
                                      <div className="d-flex align-items-center">
                                        {parts.name} – {Currency}
                                        {(typeof parts.unit_cost === "string"
                                          ? parseFloat(parts.unit_cost)
                                          : parts.unit_cost
                                        ).toFixed(2)}{" "}
                                        | Stock: {parts.quantity}
                                      </div>
                                    </li>
                                  ))}
                                </ul>
                              ) : (
                                <div className="px-3 py-2 text-muted">
                                  {partsSearchTerm
                                    ? "No matching part found"
                                    : "No part available"}
                                </div>
                              )}
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </Col>
                  <Col md={2} className="mb-3 mb-md-0">
                    <Label className="text-muted">Quantity</Label>
                    <Input
                      type="number"
                      placeholder="Qty"
                      value={selectedPart.quantity}
                      onChange={(e) =>
                        setSelectedPart({
                          ...selectedPart,
                          quantity: parseInt(e.target.value) || 1,
                        })
                      }
                      min="1"
                      disabled={submitting}
                    />
                  </Col>
                  <Col md={2} className="mb-3 mt-4 mb-md-0">
                    <Button
                      color="primary"
                      onClick={handleAddPart}
                      className="w-100"
                      disabled={submitting || !selectedPart.part_id}
                    >
                      Add Part
                    </Button>
                  </Col>
                </Row>

                {partsUsed.length > 0 && (
                  <div className="table-responsive">
                    <Table size="sm" bordered>
                      <thead>
                        <tr>
                          <th>Part Name</th>
                          <th>Qty</th>
                          <th>Unit Price</th>
                          <th>Total</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        {partsUsed.map((part) => (
                          <tr key={part.id}>
                            <td>{part.part_name}</td>
                            <td>{part.quantity}</td>
                            <td>
                              {Currency}
                              {part.unit_cost.toFixed(2)}
                            </td>
                            <td>
                              {Currency}
                              {part.total.toFixed(2)}
                            </td>
                            <td>
                              <Button
                                color="danger"
                                size="sm"
                                onClick={() => handleRemovePart(part.id)}
                                disabled={submitting}
                              >
                                <i className="icofont icofont-ui-delete"></i>
                              </Button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </Table>
                  </div>
                )}
              </CardBody>
            </Card>

            {/* Summary Section */}
            <Card className="mb-4">
              <CardBody>
                <h6 className="mb-3 text-muted">Cost Summary</h6>
                <Row>
                  <Col md={6}>
                    {existingLabourTotal > 0 && (
                      <div className="d-flex justify-content-between mb-2 text-muted">
                        <span>Existing Labour:</span>
                        <strong>
                          {Currency}
                          {existingLabourTotal.toFixed(2)}
                        </strong>
                      </div>
                    )}
                    {labourTotal > 0 && (
                      <div className="d-flex justify-content-between mb-2 text-muted">
                        <span>New Labour:</span>
                        <strong>
                          {Currency}
                          {labourTotal.toFixed(2)}
                        </strong>
                      </div>
                    )}
                    {existingPartsTotal > 0 && (
                      <div className="d-flex justify-content-between mb-2 text-muted">
                        <span>Existing Parts:</span>
                        <strong>
                          {Currency}
                          {existingPartsTotal.toFixed(2)}
                        </strong>
                      </div>
                    )}
                    {partsTotal > 0 && (
                      <div className="d-flex justify-content-between mb-2 text-muted">
                        <span>New Parts:</span>
                        <strong>
                          {Currency}
                          {partsTotal.toFixed(2)}
                        </strong>
                      </div>
                    )}
                    <hr />
                    <div className="d-flex justify-content-between text-muted">
                      <span>
                        <strong>Grand Total:</strong>
                      </span>
                      <strong className="text-primary">
                        {Currency}
                        {grandTotal.toFixed(2)}
                      </strong>
                    </div>
                  </Col>
                </Row>
              </CardBody>
            </Card>

            {/* Submit Buttons */}
            <div className="d-flex gap-2 mb-4">
              <Button
                color="primary"
                size="md"
                onClick={handleSubmit}
                disabled={
                  submitting ||
                  (jobItems.length === 0 && partsUsed.length === 0)
                }
              >
                {submitting ? (
                  <>
                    <Spinner size="sm" className="me-2" />
                    Saving...
                  </>
                ) : (
                  <>
                    <i className="fa fa-save me-2"></i>
                    Save All
                  </>
                )}
              </Button>
              <Button
                color="success"
                size="md"
                onClick={handleComplete}
                disabled={submitting}
              >
                <i className="fa fa-check me-2"></i>
                Complete & View Job Card
              </Button>
              <Button
                color="secondary"
                size="md"
                onClick={() => router.push("/admin/jobcards")}
                disabled={submitting}
              >
                <i className="fa fa-times me-2"></i>
                Cancel
              </Button>
              {/* <Button
                type="button"
                color="info"
                size="md"
                onClick={() => window.print()}
                disabled={submitting}
              >
                <i className="fa fa-print me-2"></i>
                Print Preview
              </Button> */}
            </div>
          </Col>
        </Row>
      </Container>
    </div>
  );
}

export default AddServicePage;
