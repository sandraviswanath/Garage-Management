// "use client";
// import Breadcrumbs from "@/CommonElements/Breadcrumbs";
// import CustomPagination from "@/CommonElements/Pagination";
// import {
//   Container,
//   Row,
//   Col,
//   Card,
//   CardBody,
//   Input,
//   Button,
//   Table,
//   Badge,
//   Dropdown,
//   DropdownToggle,
//   DropdownMenu,
//   DropdownItem,
// } from "reactstrap";
// import React, { useEffect, useState } from "react";
// import Link from "next/link";
// import { useRouter } from "next/navigation";
// import { toast } from "react-toastify";
// import { useAuth } from "@/helper/AuthContext";
// import withAuth from "@/helper/WithAuth";
// import AssignTechnician from "./AssignTechnician";

// // Types
// interface JobCard {
//   id: number;
//   job_number: string;
//   customer_name: string;
//   registration_number: string;
//   vehicleModel: string;
//   jobType: "repair" | "service" | "inspection" | "custom";
//   status: "open" | "in-progress" | "completed" | "cancelled";
//   reported_issue: string;
//   created_by_user: string;
//   assigned_to_user: string;
//   total_estimate: number;
//   labor_estimate: number;
//   parts_estimate: number;
//   actualCost?: number;
//   created_at: string;
//   updated_at: string;
//   estimatedCompletion: string;
// }
// interface Technician {
//   id: string;
//   username: string;
//   // Add other technician properties as needed
// }

// function JobCardsPage() {
//   const { state } = useAuth();
//   const router = useRouter();
//   const [currentPage, setCurrentPage] = useState(1);

//   const [loading, setLoading] = useState(true);
//   const [jobCards, setJobCards] = useState<JobCard[]>([]);
//   const [searchTerm, setSearchTerm] = useState("");
//   const [statusFilter, setStatusFilter] = useState("all");
//   const [jobTypeFilter, setJobTypeFilter] = useState("all");
//   const [modalOpen, setModalOpen] = useState(false);
//   const [selectedCard, setSelectedCard] = useState<{
//     id: string;
//     name: string;
//   } | null>(null);
//   const itemsPerPage = 10;

//   useEffect(() => {
//     fetchJobCards();
//   }, []);

//   const fetchJobCards = async () => {
//     try {
//       setLoading(true);
//       const token = localStorage.getItem("token");

//       if (!token) {
//         toast.error("Authentication required. Please login again.");
//         router.push("/login");
//         return;
//       }

//       const response = await fetch("/api/jobcards", {
//         method: "GET",
//         headers: {
//           Authorization: `Bearer ${
//             state?.accessToken || localStorage.getItem("token")
//           }`,
//           "Content-Type": "application/json",
//         },
//       });

//       if (!response.ok) {
//         throw new Error(`API error: ${response.status}`);
//       }

//       const data = await response.json();

//       if (data.data && Array.isArray(data.data)) {
//         setJobCards(data.data);
//       } else {
//         toast.error("Invalid data format received from API");
//         setJobCards([]);
//       }
//     } catch (error: any) {
//       console.error("Error fetching customers:", error);
//       toast.error(`Failed to load customers: ${error.message}`);
//       setJobCards([]);
//     } finally {
//       setLoading(false);
//     }
//   };

//   // Filter job cards
//   const filteredJobCards = jobCards.filter((jobCard) => {
//     const matchesSearch =
//       jobCard.job_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
//       jobCard.customer_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
//       jobCard.registration_number
//         .toLowerCase()
//         .includes(searchTerm.toLowerCase());

//     const matchesStatus =
//       statusFilter === "all" || jobCard.status === statusFilter;
//     const matchesJobType =
//       jobTypeFilter === "all" || jobCard.jobType === jobTypeFilter;

//     return matchesSearch && matchesStatus && matchesJobType;
//   });

//   // Pagination
//   const totalPages = Math.ceil(filteredJobCards.length / itemsPerPage);
//   const paginatedJobCards = filteredJobCards.slice(
//     (currentPage - 1) * itemsPerPage,
//     currentPage * itemsPerPage
//   );

//   // Status badge render function
//   // const renderStatusBadge = (status: string) => {
//   //   const statusConfig = {
//   //     open: { class: "bg-primary", label: "Open" },
//   //     "in-progress": { class: "bg-warning", label: "In Progress" },
//   //     completed: { class: "bg-success", label: "Completed" },
//   //     cancelled: { class: "bg-danger", label: "Cancelled" },
//   //   };

//   //   const config = statusConfig[status as keyof typeof statusConfig] || {
//   //     class: "bg-secondary",
//   //     label: status,
//   //   };

//   //   return <Badge className={config.class}>{config.label}</Badge>;
//   // };
//   const renderStatusBadge = (status: string) => {
//     const statusConfig: Record<string, { class: string; label: string }> = {
//       open: { class: "badge-light-warning", label: "open" },
//       in_progress: { class: "badge-light-primary", label: "In Progress" },
//       completed: { class: "badge-light-success", label: "Completed" },
//       closed: { class: "badge-light-success", label: "Closed" },
//       cancelled: { class: "badge-light-danger", label: "Cancelled" },
//     };

//     const config = statusConfig[status] || {
//       class: "badge-light-secondary",
//       label: status,
//     };

//     return <span className={`badge ${config.class}`}>{config.label}</span>;
//   };

//   // Job type badge render function
//   const renderJobTypeBadge = (jobType: string) => {
//     const typeConfig = {
//       repair: { class: "bg-danger", label: "Repair" },
//       service: { class: "bg-info", label: "Service" },
//       inspection: { class: "bg-secondary", label: "Inspection" },
//       custom: { class: "bg-dark", label: "Custom" },
//     };

//     const config = typeConfig[jobType as keyof typeof typeConfig] || {
//       class: "bg-secondary",
//       label: jobType,
//     };

//     return <Badge className={config.class}>{config.label}</Badge>;
//   };

//   const handleDeleteJobCard = (id: number) => {
//     if (confirm("Are you sure you want to delete this job card?")) {
//       setJobCards(jobCards.filter((jobCard) => jobCard.id !== id));
//     }
//   };

//   const handleStatusChange = (
//     jobCardId: number,
//     newStatus: JobCard["status"]
//   ) => {
//     setJobCards(
//       jobCards.map((jobCard) =>
//         jobCard.id === jobCardId ? { ...jobCard, status: newStatus } : jobCard
//       )
//     );
//   };

//   const resetFilters = () => {
//     setSearchTerm("");
//     setStatusFilter("all");
//     setJobTypeFilter("all");
//     setCurrentPage(1);
//   };
//   const handleTechnicianAdded = () => {
//     fetchJobCards(); // Refresh all data
//   };

//   const handleAssignTechnician = (jobCard: JobCard) => {
//     setSelectedCard({
//       id: jobCard.id.toString(),
//       name: jobCard.job_number || jobCard.customer_name,
//     });
//     setModalOpen(true);
//   };
//   return (
//     <div className="page-body">
//       <Breadcrumbs
//         title="Job Card Management"
//         mainTitle="Job Card Management"
//         parent="Dashboard"
//       />

//       <Container fluid>
//         <Row>
//           <Col sm={12}>
//             <Card className="job-card">
//               <CardBody>
//                 {/* Header with Search and Create Button */}
//                 <div className="row align-items-center mb-4 g-3">
//                   {/* Search Bar */}
//                   <div className="col-12 col-md-3">
//                     <div className="position-relative">
//                       <Input
//                         type="search"
//                         placeholder="Search job cards..."
//                         value={searchTerm}
//                         onChange={(e) => setSearchTerm(e.target.value)}
//                         className="form-control"
//                       />

//                       {searchTerm.length === 0 && (
//                         <i
//                           className="fa fa-search position-absolute"
//                           style={{
//                             right: "10px",
//                             top: "50%",
//                             transform: "translateY(-50%)",
//                             color: "#aaa",
//                           }}
//                         ></i>
//                       )}
//                     </div>
//                   </div>

//                   {/* Status Filter */}
//                   <div className="col-12 col-md-2">
//                     <select
//                       className="form-select p-2 border"
//                       style={{ fontSize: "0.9rem" }}
//                       value={statusFilter}
//                       onChange={(e) => setStatusFilter(e.target.value)}
//                     >
//                       <option value="all">All Status</option>
//                       <option value="open">Open</option>
//                       <option value="in-progress">In Progress</option>
//                       <option value="completed">Completed</option>
//                       <option value="cancelled">Cancelled</option>
//                     </select>
//                   </div>

//                   {/* Job Type Filter */}
//                   {/* <div className="col-12 col-md-2">
//                     <select
//                       className="form-select p-2 border"
//                       style={{ fontSize: "0.9rem" }}
//                       value={jobTypeFilter}
//                       onChange={(e) => setJobTypeFilter(e.target.value)}
//                     >
//                       <option value="all">All Types</option>
//                       <option value="repair">Repair</option>
//                       <option value="service">Service</option>
//                       <option value="inspection">Inspection</option>
//                       <option value="custom">Custom</option>
//                     </select>
//                   </div> */}

//                   <Col md="2">
//                     <div>
//                       <Button color="outline-secondary" onClick={resetFilters}>
//                         Clear Filter
//                       </Button>
//                     </div>
//                   </Col>

//                   {/* Spacer */}
//                   <div className="d-none d-md-block col-md-1"></div>

//                   {/* Create Job Card Button */}
//                   <div className="col-12 col-md-2 d-flex justify-content-md-end">
//                     <Link
//                       href="/admin/jobcards/create"
//                       className="w-100 w-md-auto"
//                     >
//                       <Button color="primary" className="w-100 w-md-auto">
//                         <i className="fa fa-plus me-2"></i>
//                         {/* Create Job Card */}
//                         Create
//                       </Button>
//                     </Link>
//                   </div>
//                 </div>

//                 {/* Job Cards Table */}
//                 <div className="table-responsive">
//                   <Table hover className="job-cards-table mb-0">
//                     <thead>
//                       <tr>
//                         <th>Job Number</th>
//                         <th>Customer</th>
//                         <th>Vehicle</th>
//                         {/* <th>Job Type</th> */}
//                         <th>Reported Issue</th>
//                         <th>Created by</th>
//                         <th>Technician</th>
//                         <th>Labor Estimate</th>
//                         <th>Parts Estimate</th>
//                         <th>Total Estimate</th>
//                         <th>Status</th>
//                         <th>Created</th>
//                         <th>UPdated</th>
//                         <th>Actions</th>
//                       </tr>
//                     </thead>
//                     <tbody>
//                       {paginatedJobCards.length === 0 ? (
//                         <tr>
//                           <td colSpan={10} className="text-center py-4">
//                             No job cards found
//                           </td>
//                         </tr>
//                       ) : (
//                         paginatedJobCards.map((jobCard) => (
//                           <tr key={jobCard.id}>
//                             <td className="no-wrap">
//                               <strong
//                                 className="text-primary cursor-pointer"
//                                 onClick={() =>
//                                   router.push(`/admin/jobcards/${jobCard.id}`)
//                                 }
//                               >
//                                 {jobCard.job_number}
//                               </strong>
//                             </td>

//                             <td>{jobCard.customer_name}</td>
//                             <td>
//                               <div>
//                                 <div>{jobCard.registration_number}</div>
//                                 <small className="text-muted">
//                                   {jobCard.vehicleModel}
//                                 </small>
//                               </div>
//                             </td>
//                             {/* <td>{renderJobTypeBadge(jobCard.jobType)}</td> */}
//                             <td className="text-truncate">
//                               {/* <div
//                                 className="text-truncate"
//                                 style={{ maxWidth: "200px" }}
//                                 title={jobCard.reported_issue}
//                               >
//                                 {jobCard.reported_issue}
//                               </div> */}
//                               {jobCard.reported_issue}
//                             </td>

//                             <td>{jobCard.created_by_user}</td>
//                             <td>{jobCard.assigned_to_user}</td>
//                             <td>${jobCard.labor_estimate}</td>
//                             <td>${jobCard.parts_estimate}</td>
//                             <td>
//                               <strong>${jobCard.total_estimate}</strong>
//                             </td>

//                             <td>
//                               <Dropdown>
//                                 <DropdownToggle
//                                   tag="span"
//                                   className="cursor-pointer"
//                                   style={{ cursor: "pointer" }}
//                                 >
//                                   {renderStatusBadge(jobCard.status)}
//                                 </DropdownToggle>
//                                 <DropdownMenu>
//                                   <DropdownItem
//                                     onClick={() =>
//                                       handleStatusChange(jobCard.id, "open")
//                                     }
//                                   >
//                                     Mark as Open
//                                   </DropdownItem>
//                                   <DropdownItem
//                                     onClick={() =>
//                                       handleStatusChange(
//                                         jobCard.id,
//                                         "in-progress"
//                                       )
//                                     }
//                                   >
//                                     Mark as In Progress
//                                   </DropdownItem>
//                                   <DropdownItem
//                                     onClick={() =>
//                                       handleStatusChange(
//                                         jobCard.id,
//                                         "completed"
//                                       )
//                                     }
//                                   >
//                                     Mark as Approved
//                                   </DropdownItem>
//                                   <DropdownItem
//                                     onClick={() =>
//                                       handleStatusChange(
//                                         jobCard.id,
//                                         "cancelled"
//                                       )
//                                     }
//                                   >
//                                     Mark as Cancelled
//                                   </DropdownItem>
//                                 </DropdownMenu>
//                               </Dropdown>
//                             </td>
//                             <td>
//                               {new Date(
//                                 jobCard.created_at
//                               ).toLocaleDateString()}
//                             </td>

//                             <td>
//                               {new Date(
//                                 jobCard.updated_at
//                               ).toLocaleDateString()}
//                             </td>
//                             <td>
//                               <div className="d-flex gap-1 ">
//                                 <button
//                                   className="action-btn text-white border btn-success"
//                                   onClick={() =>
//                                     router.push(
//                                       // `/admin/jobcards/${jobCard.id}?edit=true`

//                                       `/admin/jobcards/addservice?id=${jobCard.id}`
//                                     )
//                                   }
//                                   title="Add service"
//                                   disabled={loading}
//                                 >
//                                   <i className="fa fa-plus"></i>
//                                 </button>
//                                 <button
//                                   color="primary"
//                                   className="action-btn text-white border btn-primary"
//                                   onClick={() =>
//                                     router.push(`/admin/jobcards/${jobCard.id}`)
//                                   }
//                                   title="View"
//                                 >
//                                   <i className="fa fa-eye"></i>
//                                 </button>
//                                 <button
//                                   color="warning"
//                                   className="action-btn text-white border btn-warning"
//                                   onClick={() =>
//                                     router.push(
//                                       // `/admin/jobcards/${jobCard.id}?edit=true`

//                                       `/admin/jobcards/create?id=${jobCard.id}`
//                                     )
//                                   }
//                                   title="Edit"
//                                 >
//                                   <i className="icofont icofont-pencil-alt-5"></i>
//                                 </button>

//                                 <button
//                                   className="action-btn text-white border btn-info"
//                                   onClick={() =>
//                                     handleAssignTechnician(jobCard)
//                                   }
//                                   title="Assign Technician"
//                                   disabled={loading}
//                                 >
//                                   <i className="fa fa-user-plus"></i>
//                                 </button>
//                                 {/* <button
//                                   color="info"
//                                   className="action-btn text-white border btn-info"
//                                   onClick={() => window.print()}
//                                   title="Print"
//                                 >
//                                   <i className="fa fa-print"></i>
//                                 </button> */}

//                                 {/* <button
//                                   color="danger"
//                                   className="action-btn text-white border btn-danger"
//                                   onClick={() =>
//                                     handleDeleteJobCard(jobCard.id)
//                                   }
//                                   title="Delete"
//                                 >
//                                   <i className="icofont icofont-ui-delete"></i>
//                                 </button> */}
//                               </div>
//                             </td>
//                           </tr>
//                         ))
//                       )}
//                     </tbody>
//                   </Table>
//                 </div>

//                 {/* Pagination and Info */}
//                 <div className="d-flex flex-column flex-md-row justify-content-between align-items-center gap-3 mt-4">
//                   <div className="text-center text-md-start text-muted">
//                     Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
//                     {Math.min(
//                       currentPage * itemsPerPage,
//                       filteredJobCards.length
//                     )}{" "}
//                     of {filteredJobCards.length} entries
//                   </div>
//                   <CustomPagination
//                     currentPage={currentPage}
//                     totalPages={totalPages}
//                     onPageChange={setCurrentPage}
//                     showFirstLast={true}
//                     maxVisiblePages={5}
//                     paginationType="primary"
//                     className="justify-content-center justify-content-md-end"
//                   />
//                 </div>
//               </CardBody>
//             </Card>
//           </Col>
//         </Row>
//       </Container>

//       {/* <style jsx>{`
//         .job-card {
//           box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
//           border: 1px solid rgba(0, 0, 0, 0.125);
//         }

//         .action-btn {
//           padding: 0.25rem 0.5rem;
//           font-size: 0.75rem;
//         }

//         .cursor-pointer {
//           cursor: pointer;
//         }

//         .job-cards-table {
//           font-size: 0.875rem;
//         }

//         .job-cards-table td {
//           vertical-align: middle;
//         }

//         @media (max-width: 768px) {
//           .table-responsive {
//             border: 1px solid #dee2e6;
//             border-radius: 0.375rem;
//           }

//           .job-cards-table {
//             min-width: 1000px;
//             margin-bottom: 0;
//           }
//         }

//         @media (max-width: 576px) {
//           .action-btn {
//             padding: 0.2rem 0.4rem;
//             font-size: 0.7rem;
//           }
//         }
//       `}</style> */}
//       <style jsx>{`
//         .job-card {
//           box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
//           border: 1px solid rgba(0, 0, 0, 0.125);
//         }

//         .action-btn {
//           padding: 0.25rem 0.5rem;
//           border-radius: 5px;
//           font-size: 0.75rem;
//         }

//         .job-table {
//           font-size: 0.875rem;
//         }

//         .job-table td {
//           vertical-align: middle;
//         }

//         @media (max-width: 768px) {
//           .job-card .card-body {
//             padding: 1rem;
//           }

//           .table-responsive {
//             border: 1px solid #dee2e6;
//             border-radius: 0.375rem;
//           }

//           .job-table {
//             min-width: 800px;
//           }
//         }
//       `}</style>

//       <AssignTechnician
//         isOpen={modalOpen}
//         toggle={() => setModalOpen(!modalOpen)}
//         jobId={selectedCard?.id || ""}
//         jobName={selectedCard?.name || ""}
//         onSuccess={handleTechnicianAdded}
//       />
//     </div>
//   );
// }

// // export default JobCardsPage;
// export default withAuth(JobCardsPage, ["admin"]);

"use client";
import Breadcrumbs from "@/CommonElements/Breadcrumbs";
import CustomPagination from "@/CommonElements/Pagination";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  Input,
  Button,
  Table,
  Badge,
  Dropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  Spinner,
} from "reactstrap";
import React, { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { toast } from "react-toastify";
import { useAuth } from "@/helper/AuthContext";
import withAuth from "@/helper/WithAuth";
import AssignTechnician from "./AssignTechnician";

// Types
interface JobCard {
  id: number;
  job_number: string;
  customer_name: string;
  registration_number: string;
  vehicleModel: string;
  jobType: "repair" | "service" | "inspection" | "custom";
  status: "open" | "in_progress" | "completed" | "closed" | "cancelled";
  reported_issue: string;
  created_by_user: string;
  assigned_to_user: string;
  total_estimate: number;
  labor_estimate: number;
  parts_estimate: number;
  actualCost?: number;
  created_at: string;
  updated_at: string;
  estimatedCompletion: string;
}

function JobCardsPage() {
  const { state } = useAuth();
  const router = useRouter();
  const [currentPage, setCurrentPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [updatingStatus, setUpdatingStatus] = useState<number | null>(null);
  const [jobCards, setJobCards] = useState<JobCard[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [jobTypeFilter, setJobTypeFilter] = useState("all");
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedCard, setSelectedCard] = useState<{
    id: string;
    name: string;
  } | null>(null);
  const itemsPerPage = 10;

  // State for dropdown open/close
  const [dropdownOpen, setDropdownOpen] = useState<{ [key: number]: boolean }>(
    {}
  );

  const toggleDropdown = (id: number) => {
    setDropdownOpen((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  useEffect(() => {
    fetchJobCards();
  }, []);

  const fetchJobCards = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem("token");

      if (!token) {
        toast.error("Authentication required. Please login again.");
        router.push("/login");
        return;
      }

      const response = await fetch("/api/jobcards", {
        method: "GET",
        headers: {
          Authorization: `Bearer ${
            state?.accessToken || localStorage.getItem("token")
          }`,
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }

      const data = await response.json();

      if (data.data && Array.isArray(data.data)) {
        setJobCards(data.data);
      } else {
        toast.error("Invalid data format received from API");
        setJobCards([]);
      }
    } catch (error: any) {
      console.error("Error fetching customers:", error);
      toast.error(`Failed to load customers: ${error.message}`);
      setJobCards([]);
    } finally {
      setLoading(false);
    }
  };

  // Filter job cards
  const filteredJobCards = jobCards.filter((jobCard) => {
    const matchesSearch =
      jobCard.job_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
      jobCard.customer_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      jobCard.registration_number
        .toLowerCase()
        .includes(searchTerm.toLowerCase());

    const matchesStatus =
      statusFilter === "all" || jobCard.status === statusFilter;
    const matchesJobType =
      jobTypeFilter === "all" || jobCard.jobType === jobTypeFilter;

    return matchesSearch && matchesStatus && matchesJobType;
  });

  // Pagination
  const totalPages = Math.ceil(filteredJobCards.length / itemsPerPage);
  const paginatedJobCards = filteredJobCards.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  // Status badge render function
  const renderStatusBadge = (status: string) => {
    const statusConfig: Record<string, { class: string; label: string }> = {
      open: { class: "badge-light-warning", label: "open" },
      in_progress: { class: "badge-light-primary", label: "In Progress" },
      completed: { class: "badge-light-success", label: "Completed" },
      // closed: { class: "badge-light-success", label: "Closed" },
      cancelled: { class: "badge-light-secondary", label: "Cancelled" },
    };

    const config = statusConfig[status] || {
      class: "badge-light-secondary",
      label: status,
    };

    return <span className={`badge ${config.class}`}>{config.label}</span>;
  };

  // Job type badge render function
  const renderJobTypeBadge = (jobType: string) => {
    const typeConfig = {
      repair: { class: "bg-danger", label: "Repair" },
      service: { class: "bg-info", label: "Service" },
      inspection: { class: "bg-secondary", label: "Inspection" },
      custom: { class: "bg-dark", label: "Custom" },
    };

    const config = typeConfig[jobType as keyof typeof typeConfig] || {
      class: "bg-secondary",
      label: jobType,
    };

    return <Badge className={config.class}>{config.label}</Badge>;
  };

  const handleDeleteJobCard = (id: number) => {
    if (confirm("Are you sure you want to delete this job card?")) {
      setJobCards(jobCards.filter((jobCard) => jobCard.id !== id));
    }
  };

  const handleStatusChange = async (jobCardId: number, newStatus: string) => {
    try {
      setUpdatingStatus(jobCardId);
      const token = state?.accessToken || localStorage.getItem("token");

      // Make API call to update status
      const response = await fetch(`/api/jobcards/${jobCardId}/status`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          status: newStatus,
        }),
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.message || "Failed to update status");
      }

      // Update local state
      setJobCards(
        jobCards.map((jobCard) =>
          jobCard.id === jobCardId
            ? {
                ...jobCard,
                status: newStatus as JobCard["status"],
                updated_at: new Date().toISOString(),
              }
            : jobCard
        )
      );

      // Close the dropdown
      setDropdownOpen((prev) => ({
        ...prev,
        [jobCardId]: false,
      }));

      toast.success("Status updated successfully!");
    } catch (error: any) {
      console.error("Error updating status:", error);
      toast.error(error.message || "Failed to update status");
    } finally {
      setUpdatingStatus(null);
    }
  };

  const resetFilters = () => {
    setSearchTerm("");
    setStatusFilter("all");
    setJobTypeFilter("all");
    setCurrentPage(1);
  };

  const handleTechnicianAdded = () => {
    fetchJobCards(); // Refresh all data
  };

  const handleAssignTechnician = (jobCard: JobCard) => {
    setSelectedCard({
      id: jobCard.id.toString(),
      name: jobCard.job_number || jobCard.customer_name,
    });
    setModalOpen(true);
  };

  return (
    <div className="page-body">
      <Breadcrumbs
        title="Job Card Management"
        mainTitle="Job Card Management"
        parent="Dashboard"
      />

      <Container fluid>
        <Row>
          <Col sm={12}>
            <Card className="job-card">
              <CardBody>
                {/* Header with Search and Create Button */}
                <div className="row align-items-center mb-4 g-3">
                  {/* Search Bar */}
                  <div className="col-12 col-md-3">
                    <div className="position-relative">
                      <Input
                        type="search"
                        placeholder="Search job cards..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="form-control"
                      />

                      {searchTerm.length === 0 && (
                        <i
                          className="fa fa-search position-absolute"
                          style={{
                            right: "10px",
                            top: "50%",
                            transform: "translateY(-50%)",
                            color: "#aaa",
                          }}
                        ></i>
                      )}
                    </div>
                  </div>

                  {/* Status Filter */}
                  <div className="col-12 col-md-2">
                    <select
                      className="form-select p-2 border"
                      style={{ fontSize: "0.9rem" }}
                      value={statusFilter}
                      onChange={(e) => setStatusFilter(e.target.value)}
                    >
                      <option value="all">All Status</option>
                      <option value="open">Open</option>
                      <option value="in_progress">In Progress</option>
                      <option value="completed">Completed</option>
                      <option value="cancelled">Cancelled</option>
                    </select>
                  </div>

                  {/* Job Type Filter */}
                  {/* <div className="col-12 col-md-2">
                    <select
                      className="form-select p-2 border"
                      style={{ fontSize: "0.9rem" }}
                      value={jobTypeFilter}
                      onChange={(e) => setJobTypeFilter(e.target.value)}
                    >
                      <option value="all">All Types</option>
                      <option value="repair">Repair</option>
                      <option value="service">Service</option>
                      <option value="inspection">Inspection</option>
                      <option value="custom">Custom</option>
                    </select>
                  </div> */}

                  <Col md="2">
                    <div>
                      <Button color="outline-secondary" onClick={resetFilters}>
                        Clear Filter
                      </Button>
                    </div>
                  </Col>

                  {/* Spacer */}
                  <div className="d-none d-md-block col-md-1"></div>

                  {/* Create Job Card Button */}
                  <div className="col-12 col-md-2 d-flex justify-content-md-end">
                    <Link
                      href="/admin/jobcards/create"
                      className="w-100 w-md-auto"
                    >
                      <Button color="primary" className="w-100 w-md-auto">
                        <i className="fa fa-plus me-2"></i>
                        Create
                      </Button>
                    </Link>
                  </div>
                </div>

                {/* Job Cards Table */}
                <div className="table-responsive">
                  <Table hover className="job-cards-table mb-0">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>Job Number</th>
                        <th>Customer</th>
                        <th>Vehicle</th>
                        <th>Reported Issue</th>
                        <th>Created by</th>
                        <th>Technician</th>
                        <th>Labor Estimate</th>
                        <th>Parts Estimate</th>
                        <th>Total Estimate</th>
                        <th>Status</th>
                        <th>Created</th>
                        <th>UPdated</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {loading ? (
                        <tr>
                          <td colSpan={13} className="text-center py-4">
                            <Spinner color="primary" />
                            <p className="mt-2">Loading job cards...</p>
                          </td>
                        </tr>
                      ) : paginatedJobCards.length === 0 ? (
                        <tr>
                          <td colSpan={13} className="text-center py-4">
                            No job cards found
                          </td>
                        </tr>
                      ) : (
                        paginatedJobCards.map((jobCard, index) => (
                          <tr key={jobCard.id}>
                            <td>
                              {(currentPage - 1) * itemsPerPage + index + 1}
                            </td>
                            <td className="no-wrap">
                              <strong
                                className="text-primary cursor-pointer"
                                onClick={() =>
                                  router.push(`/admin/jobcards/${jobCard.id}`)
                                }
                                style={{ cursor: "pointer" }}
                              >
                                {jobCard.job_number}
                              </strong>
                            </td>

                            <td>{jobCard.customer_name}</td>
                            <td>
                              <div>
                                <div>{jobCard.registration_number}</div>
                                <small className="text-muted">
                                  {jobCard.vehicleModel}
                                </small>
                              </div>
                            </td>
                            <td>{jobCard.reported_issue}</td>
                            <td>{jobCard.created_by_user}</td>
                            <td>{jobCard.assigned_to_user}</td>
                            <td>${jobCard.labor_estimate}</td>
                            <td>${jobCard.parts_estimate}</td>
                            <td>
                              <strong>${jobCard.total_estimate}</strong>
                            </td>

                            <td>
                              <Dropdown
                                isOpen={dropdownOpen[jobCard.id] || false}
                                toggle={() => toggleDropdown(jobCard.id)}
                              >
                                <DropdownToggle
                                  tag="div"
                                  style={{
                                    cursor: "pointer",
                                    display: "inline-block",
                                  }}
                                >
                                  {updatingStatus === jobCard.id ? (
                                    <Spinner size="sm" />
                                  ) : (
                                    renderStatusBadge(jobCard.status)
                                  )}
                                </DropdownToggle>
                                <DropdownMenu>
                                  {/* <DropdownItem
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      handleStatusChange(jobCard.id, "open");
                                    }}
                                    disabled={updatingStatus === jobCard.id}
                                  >
                                    {updatingStatus === jobCard.id ? (
                                      <Spinner size="sm" className="me-2" />
                                    ) : (
                                      <i className="fa fa-circle me-2 text-warning"></i>
                                    )}
                                    Mark as Open
                                  </DropdownItem> */}
                                  <DropdownItem
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      handleStatusChange(
                                        jobCard.id,
                                        "in_progress"
                                      );
                                    }}
                                    disabled={updatingStatus === jobCard.id}
                                  >
                                    {updatingStatus === jobCard.id ? (
                                      <Spinner size="sm" className="me-2" />
                                    ) : (
                                      <i className="fa fa-play me-2 text-primary"></i>
                                    )}
                                    Mark as In Progress
                                  </DropdownItem>
                                  <DropdownItem
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      handleStatusChange(
                                        jobCard.id,
                                        "completed"
                                      );
                                    }}
                                    disabled={updatingStatus === jobCard.id}
                                  >
                                    {updatingStatus === jobCard.id ? (
                                      <Spinner size="sm" className="me-2" />
                                    ) : (
                                      <i className="fa fa-check me-2 text-success"></i>
                                    )}
                                    Mark as Completed
                                  </DropdownItem>
                                  {/* <DropdownItem
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      handleStatusChange(jobCard.id, "closed");
                                    }}
                                    disabled={updatingStatus === jobCard.id}
                                  >
                                    {updatingStatus === jobCard.id ? (
                                      <Spinner size="sm" className="me-2" />
                                    ) : (
                                      <i className="fa fa-lock me-2 text-success"></i>
                                    )}
                                    Mark as Closed
                                  </DropdownItem> */}
                                  <DropdownItem
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      handleStatusChange(
                                        jobCard.id,
                                        "cancelled"
                                      );
                                    }}
                                    disabled={updatingStatus === jobCard.id}
                                  >
                                    {updatingStatus === jobCard.id ? (
                                      <Spinner size="sm" className="me-2" />
                                    ) : (
                                      <i className="fa fa-times me-2 text-danger"></i>
                                    )}
                                    Mark as Cancelled
                                  </DropdownItem>
                                </DropdownMenu>
                              </Dropdown>
                            </td>
                            <td>
                              {new Date(
                                jobCard.created_at
                              ).toLocaleDateString()}
                            </td>

                            <td>
                              {new Date(
                                jobCard.updated_at
                              ).toLocaleDateString()}
                            </td>
                            <td>
                              <div className="d-flex gap-1 ">
                                <button
                                  className="action-btn text-white border btn-success"
                                  onClick={() =>
                                    router.push(
                                      `/admin/jobcards/addservice?id=${jobCard.id}`
                                    )
                                  }
                                  title="Add service"
                                  disabled={updatingStatus === jobCard.id}
                                >
                                  <i className="fa fa-plus"></i>
                                </button>
                                <button
                                  className="action-btn text-white border btn-primary"
                                  onClick={() =>
                                    router.push(`/admin/jobcards/${jobCard.id}`)
                                  }
                                  title="View"
                                  disabled={updatingStatus === jobCard.id}
                                >
                                  <i className="fa fa-eye"></i>
                                </button>
                                <button
                                  className="action-btn text-white border btn-warning"
                                  onClick={() =>
                                    router.push(
                                      `/admin/jobcards/create?id=${jobCard.id}`
                                    )
                                  }
                                  title="Edit"
                                  disabled={updatingStatus === jobCard.id}
                                >
                                  <i className="icofont icofont-pencil-alt-5"></i>
                                </button>

                                <button
                                  className="action-btn text-white border btn-info"
                                  onClick={() =>
                                    handleAssignTechnician(jobCard)
                                  }
                                  title="Assign Technician"
                                  disabled={updatingStatus === jobCard.id}
                                >
                                  <i className="fa fa-user-plus"></i>
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </Table>
                </div>

                {/* Pagination and Info */}
                <div className="d-flex flex-column flex-md-row justify-content-between align-items-center gap-3 mt-4">
                  <div className="text-center text-md-start text-muted">
                    Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
                    {Math.min(
                      currentPage * itemsPerPage,
                      filteredJobCards.length
                    )}{" "}
                    of {filteredJobCards.length} entries
                  </div>
                  <CustomPagination
                    currentPage={currentPage}
                    totalPages={totalPages}
                    onPageChange={setCurrentPage}
                    showFirstLast={true}
                    maxVisiblePages={5}
                    paginationType="primary"
                    className="justify-content-center justify-content-md-end"
                  />
                </div>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Container>

      <style jsx>{`
        .job-card {
          box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
          border: 1px solid rgba(0, 0, 0, 0.125);
        }

        .action-btn {
          padding: 0.25rem 0.5rem;
          border-radius: 5px;
          font-size: 0.75rem;
        }

        .job-table {
          font-size: 0.875rem;
        }

        .job-table td {
          vertical-align: middle;
        }

        @media (max-width: 768px) {
          .job-card .card-body {
            padding: 1rem;
          }

          .table-responsive {
            border: 1px solid #dee2e6;
            border-radius: 0.375rem;
          }

          .job-table {
            min-width: 800px;
          }
        }
      `}</style>

      <AssignTechnician
        isOpen={modalOpen}
        toggle={() => setModalOpen(!modalOpen)}
        jobId={selectedCard?.id || ""}
        jobName={selectedCard?.name || ""}
        onSuccess={handleTechnicianAdded}
      />
    </div>
  );
}

export default withAuth(JobCardsPage, ["admin"]);
