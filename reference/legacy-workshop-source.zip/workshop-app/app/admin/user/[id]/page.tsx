"use client";
import Breadcrumbs from "@/CommonElements/Breadcrumbs";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  Badge,
  Button,
  TabContent,
  TabPane,
  Nav,
  NavItem,
  NavLink,
  Table,
} from "reactstrap";
import React, { useState } from "react";
import { useRouter } from "next/navigation";

// Mock data
const userData = {
  id: 1,
  name: "John Doe",
  email: "john@example.com",
  phone: "+1 234 567 890",
  role: "customer" as const,
  address: "123 Main St, New York, NY 10001",
  status: "active" as const,
  joinDate: "2023-01-15",
  lastLogin: "2024-01-20",
};

const activityHistory = [
  {
    id: 1,
    date: "2024-01-20",
    activity: "Login",
    description: "User logged into the system",
    ipAddress: "192.168.1.100",
  },
  {
    id: 2,
    date: "2024-01-19",
    activity: "Profile Update",
    description: "Updated contact information",
    ipAddress: "192.168.1.100",
  },
  {
    id: 3,
    date: "2024-01-18",
    activity: "Password Change",
    description: "User changed password",
    ipAddress: "192.168.1.150",
  },
  {
    id: 4,
    date: "2024-01-15",
    activity: "Login",
    description: "User logged into the system",
    ipAddress: "192.168.1.200",
  },
];

function UserProfilePage({ params }: { params: { id: string } }) {
  const router = useRouter();
  const [activeTab, setActiveTab] = useState("1");
  const user = userData;

  const renderStatusBadge = (status: string) => {
    const statusConfig = {
      active: { class: "bg-success", label: "Active" },
      inactive: { class: "bg-secondary", label: "Inactive" },
      pending: { class: "bg-warning", label: "Pending" },
    };

    const config = statusConfig[status as keyof typeof statusConfig] || {
      class: "bg-secondary",
      label: status,
    };

    return <Badge className={config.class}>{config.label}</Badge>;
  };

  const renderRoleBadge = (role: string) => {
    const roleConfig = {
      customer: { class: "bg-primary", label: "Customer" },
      technician: { class: "bg-info", label: "Technician" },
      accountant: { class: "bg-warning", label: "Accountant" },
      manager: { class: "bg-danger", label: "Manager" },
    };

    const config = roleConfig[role as keyof typeof roleConfig] || {
      class: "bg-secondary",
      label: role,
    };

    return <Badge className={config.class}>{config.label}</Badge>;
  };

  return (
    <div className="page-body">
      <Breadcrumbs
        title={`User - ${user.name}`}
        mainTitle="User Profile"
        parent="User Management"
      />

      <Container fluid>
        <Row>
          {/* User Info Card */}
          <Col md={4}>
            <Card>
              <CardBody>
                <div className="text-center mb-4">
                  <div className="avatar-lg mx-auto mb-3">
                    <div className="avatar-title bg-primary rounded-circle text-white display-4">
                      {user.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </div>
                  </div>
                  <h4 className="text-muted">{user.name}</h4>
                  <div className="mb-2 ">
                    {renderRoleBadge(user.role)}
                  </div>
                  <div>
                    {renderStatusBadge(user.status)}
                  </div>
                </div>

                <div className="mb-3 text-muted">
                  <strong>Contact Information</strong>
                  <div className="mt-2">
                    <div className="d-flex justify-content-between py-2 border-bottom">
                      <span>Email:</span>
                      <span>{user.email}</span>
                    </div>
                    <div className="d-flex justify-content-between py-2 border-bottom">
                      <span>Phone:</span>
                      <span>{user.phone}</span>
                    </div>
                    <div className="d-flex justify-content-between py-2 border-bottom">
                      <span>Member Since:</span>
                      <span>
                        {new Date(user.joinDate).toLocaleDateString()}
                      </span>
                    </div>
                    <div className="d-flex justify-content-between py-2">
                      <span>Last Login:</span>
                      <span>
                        {new Date(user.lastLogin).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="mb-3 text-muted">
                  <strong>Address</strong>
                  <div className="mt-2">
                    <p className="mb-0">{user.address}</p>
                  </div>
                </div>

                <div className="d-grid gap-2">
                  <Button
                    color="primary"
                    onClick={() =>
                      router.push(`/admin/user/${user.id}?edit=true`)
                    }
                  >
                    Edit User
                  </Button>
                  <Button
                    color="outline-primary"
                    onClick={() => router.push("/admin/user")}
                  >
                    Back to List
                  </Button>
                </div>
              </CardBody>
            </Card>
          </Col>

          {/* Stats and Activity History */}
          <Col md={8}>
            {/* Stats Cards */}
            <Row className="mb-4">
              <Col md={4}>
                <Card className="text-center bg-primary text-white">
                  <CardBody>
                    <h3 className="text-white">15</h3>
                    <p className="mb-0 text-white">Total Orders</p>
                  </CardBody>
                </Card>
              </Col>
              <Col md={4}>
                <Card className="text-center bg-success text-white">
                  <CardBody>
                    <h3 className="text-white">12</h3>
                    <p className="mb-0 text-white">Completed</p>
                  </CardBody>
                </Card>
              </Col>
              <Col md={4}>
                <Card className="text-center bg-info text-white">
                  <CardBody>
                    <h3 className="text-white">3</h3>
                    <p className="mb-0 text-white">Pending</p>
                  </CardBody>
                </Card>
              </Col>
            </Row>

            {/* Tabs */}
            <Card>
              <CardBody>
                <Nav tabs>
                  <NavItem>
                    <NavLink
                      className={activeTab === "1" ? "active" : ""}
                      onClick={() => setActiveTab("1")}
                    >
                      Activity History
                    </NavLink>
                  </NavItem>
                  <NavItem>
                    <NavLink
                      className={activeTab === "2" ? "active" : ""}
                      onClick={() => setActiveTab("2")}
                    >
                      Notes & Comments
                    </NavLink>
                  </NavItem>
                </Nav>

                <TabContent activeTab={activeTab} className="pt-3">
                  <TabPane tabId="1">
                    <div className="table-responsive">
                      <Table
                        hover
                        className="activity-history-table mb-0"
                      >
                        <thead>
                          <tr>
                            <th scope="col">Date</th>
                            <th scope="col">Activity</th>
                            <th scope="col">Description</th>
                            <th scope="col">IP Address</th>
                          </tr>
                        </thead>
                        <tbody>
                          {activityHistory.length === 0 ? (
                            <tr>
                              <td colSpan={4} className="text-center py-4">
                                No activity history found
                              </td>
                            </tr>
                          ) : (
                            activityHistory.map((activity) => (
                              <tr key={activity.id}>
                                <td>
                                  {new Date(activity.date).toLocaleDateString()}
                                </td>
                                <td>
                                  <strong>{activity.activity}</strong>
                                </td>
                                <td>{activity.description}</td>
                                <td>
                                  <code>{activity.ipAddress}</code>
                                </td>
                              </tr>
                            ))
                          )}
                        </tbody>
                      </Table>
                    </div>
                  </TabPane>
                  <TabPane tabId="2">
                    <div className="p-3 text-muted">
                      <h6>User Notes</h6>
                      <div className="border rounded p-3 mb-3">
                        <div className="d-flex justify-content-between align-items-center mb-2 text-muted">
                          <strong>Regular User</strong>
                          <small className="text-muted">2024-01-15</small>
                        </div>
                        <p className="mb-0">
                          User is active and regularly uses the system. Prefers email communication.
                        </p>
                      </div>

                      <div className="border rounded p-3">
                        <div className="d-flex justify-content-between align-items-center mb-2">
                          <strong>Account Verification</strong>
                          <small className="text-muted">2024-01-10</small>
                        </div>
                        <p className="mb-0">
                          User account has been verified. All documents are in order.
                        </p>
                      </div>

                      <div className="mt-3">
                        <Button color="primary" size="sm">
                          <i className="fa fa-plus me-2"></i>
                          Add New Note
                        </Button>
                      </div>
                    </div>
                  </TabPane>
                </TabContent>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Container>

      <style jsx>{`
        .avatar-lg {
          width: 80px;
          height: 80px;
        }

        .avatar-title {
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 1.5rem;
          font-weight: 600;
        }

        .action-btn {
          padding: 0.25rem 0.5rem;
          font-size: 0.75rem;
        }

        .activity-history-table {
          font-size: 0.875rem;
        }

        .activity-history-table td {
          vertical-align: middle;
        }

        @media (max-width: 768px) {
          .table-responsive {
            border: 1px solid #dee2e6;
            border-radius: 0.375rem;
          }

          .activity-history-table {
            min-width: 600px;
            margin-bottom: 0;
          }
        }

        @media (max-width: 576px) {
          .action-btn {
            padding: 0.2rem 0.4rem;
            font-size: 0.7rem;
          }

          .activity-history-table {
            font-size: 0.8rem;
          }

          .avatar-lg {
            width: 60px;
            height: 60px;
          }

          .avatar-title {
            font-size: 1.25rem;
          }
        }
      `}</style>
    </div>
  );
}

export default UserProfilePage;
