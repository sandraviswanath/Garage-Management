// "use client";
// import Breadcrumbs from "@/CommonElements/Breadcrumbs";
// import CustomPagination from "@/CommonElements/Pagination";
// import {
//   Container,
//   Row,
//   Col,
//   Card,
//   CardBody,
//   Input,
//   Button,
//   Table,
//   Dropdown,
//   DropdownToggle,
//   DropdownMenu,
//   DropdownItem,
// } from "reactstrap";
// import React, { useState } from "react";
// import Link from "next/link";
// import { useRouter } from "next/navigation";

// // Types
// interface User {
//   id: number;
//   name: string;
//   email: string;
//   phone: string;
//   role: "customer" | "technician" | "accountant" | "manager";
//   address: string;
//   status: "active" | "inactive" | "pending";
//   joinDate: string;
//   lastLogin: string;
// }

// // Mock data
// const UsersData: User[] = [
//   {
//     id: 1,
//     name: "John Doe",
//     email: "john@example.com",
//     phone: "+1 234 567 890",
//     role: "customer",
//     address: "123 Main St, New York, NY",
//     status: "active",
//     joinDate: "2023-01-15",
//     lastLogin: "2024-01-20",
//   },
//   {
//     id: 2,
//     name: "Jane Smith",
//     email: "jane@example.com",
//     phone: "+1 234 567 891",
//     role: "technician",
//     address: "456 Oak Ave, Los Angeles, CA",
//     status: "active",
//     joinDate: "2023-03-20",
//     lastLogin: "2024-01-20",
//   },
//   {
//     id: 3,
//     name: "Mike Johnson",
//     email: "mike@example.com",
//     phone: "+1 234 567 892",
//     role: "accountant",
//     address: "789 Pine Rd, Chicago, IL",
//     status: "inactive",
//     joinDate: "2023-02-10",
//     lastLogin: "2024-01-15",
//   },
//   {
//     id: 4,
//     name: "Sarah Wilson",
//     email: "sarah@example.com",
//     phone: "+1 234 567 893",
//     role: "manager",
//     address: "321 Elm St, Houston, TX",
//     status: "pending",
//     joinDate: "2023-04-05",
//     lastLogin: "2024-01-18",
//   },
//   {
//     id: 5,
//     name: "Robert Brown",
//     email: "robert@example.com",
//     phone: "+1 234 567 894",
//     role: "customer",
//     address: "654 Maple Dr, Phoenix, AZ",
//     status: "active",
//     joinDate: "2023-05-12",
//     lastLogin: "2024-01-19",
//   },
//   {
//     id: 6,
//     name: "Emily Davis",
//     email: "emily@example.com",
//     phone: "+1 234 567 895",
//     role: "technician",
//     address: "987 Cedar Ln, Philadelphia, PA",
//     status: "active",
//     joinDate: "2023-06-18",
//     lastLogin: "2024-01-20",
//   },
// ];

// function UserPage() {
//   const router = useRouter();
//   const [currentPage, setCurrentPage] = useState(1);
//   const [users, setUsers] = useState<User[]>(UsersData);
//   const [searchTerm, setSearchTerm] = useState("");
//   const [statusFilter, setStatusFilter] = useState("all");
//   const [roleFilter, setRoleFilter] = useState("all");
//   const [dropdownOpen, setDropdownOpen] = useState(false);
//   const [roleDropdownOpen, setRoleDropdownOpen] = useState(false);
//   const itemsPerPage = 5;

//   const toggleDropdown = () => setDropdownOpen((prevState) => !prevState);
//   const toggleRoleDropdown = () =>
//     setRoleDropdownOpen((prevState) => !prevState);

//   // Filter users based on search and filters
//   const filteredUsers = users.filter((user) => {
//     const matchesSearch =
//       user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
//       user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
//       user.phone.includes(searchTerm) ||
//       user.address.toLowerCase().includes(searchTerm.toLowerCase());

//     const matchesStatus =
//       statusFilter === "all" || user.status === statusFilter;

//     const matchesRole = roleFilter === "all" || user.role === roleFilter;

//     return matchesSearch && matchesStatus && matchesRole;
//   });

//   // Pagination
//   const totalPages = Math.ceil(filteredUsers.length / itemsPerPage);
//   const paginatedUsers = filteredUsers.slice(
//     (currentPage - 1) * itemsPerPage,
//     currentPage * itemsPerPage
//   );

//   // Status badge render function
//   const renderStatusBadge = (value: string) => {
//     const statusConfig = {
//       active: { class: "bg-success", label: "Active" },
//       inactive: { class: "bg-secondary", label: "Inactive" },
//       pending: { class: "bg-warning", label: "Pending" },
//     };

//     const config = statusConfig[value as keyof typeof statusConfig] || {
//       class: "bg-secondary",
//       label: value,
//     };

//     return (
//       <span className={`badge ${config.class} text-white`}>{config.label}</span>
//     );
//   };

//   // Role badge render function
//   const renderRoleBadge = (value: string) => {
//     const roleConfig = {
//       customer: { class: "bg-primary", label: "Customer" },
//       technician: { class: "bg-info", label: "Technician" },
//       accountant: { class: "bg-warning", label: "Accountant" },
//       manager: { class: "bg-danger", label: "Manager" },
//     };

//     const config = roleConfig[value as keyof typeof roleConfig] || {
//       class: "bg-secondary",
//       label: value,
//     };

//     return (
//       <span className={`badge ${config.class} text-white`}>{config.label}</span>
//     );
//   };

//   const handleDeleteUser = (id: number) => {
//     if (confirm("Are you sure you want to delete this user?")) {
//       setUsers(users.filter((user) => user.id !== id));
//     }
//   };

//   const resetFilters = () => {
//     setSearchTerm("");
//     setStatusFilter("all");
//     setRoleFilter("all");
//     setCurrentPage(1);
//   };

//   return (
//     <div className="page-body">
//       <Breadcrumbs
//         title="User Management"
//         mainTitle="User Management"
//         parent="Dashboard"
//       />

//       <Container fluid>
//         <Row>
//           <Col sm={12}>
//             <Card className="customer-card">
//               <CardBody>
//                 {/* Header with Search and Add Button */}
//                 <div className="row align-items-center mb-4 g-3">
//                   {/* Search Bar - Left */}
//                   <div className="col-12 col-md-3">
//                     <div className="position-relative">
//                       <Input
//                         type="search"
//                         placeholder="Search users..."
//                         value={searchTerm}
//                         onChange={(e) => setSearchTerm(e.target.value)}
//                         className="form-control"
//                       />
//                          {searchTerm.length === 0 && (
//                       <i
//                         className="fa fa-search position-absolute"
//                         style={{
//                           right: "10px",
//                           top: "50%",
//                           transform: "translateY(-50%)",
//                           color: "#aaa",
//                         }}
//                       ></i>
//                          )}
//                     </div>
//                   </div>

//                   <div className="col-12 col-md-2">
//                     <select
//                       className="form-select p-2 border"
//                       style={{ fontSize: "0.9rem" }}
//                       value={statusFilter}
//                       onChange={(e) => setStatusFilter(e.target.value)}
//                     >
//                       <option value="all">All Status</option>
//                       <option value="active">Active</option>
//                       <option value="inactive">Inactive</option>
//                       <option value="pending">Pending</option>
//                     </select>
//                   </div>

//                   <div className="col-12 col-md-2">
//                     <select
//                       className="form-select p-2 border"
//                       style={{ fontSize: "0.9rem" }}
//                       value={roleFilter}
//                       onChange={(e) => setRoleFilter(e.target.value)}
//                     >
//                       <option value="all">All Roles</option>
//                       <option value="customer">Customer</option>
//                       <option value="technician">Technician</option>
//                       <option value="accountant">Accountant</option>
//                       <option value="manager">Manager</option>
//                     </select>
//                   </div>
//                   <Col md="2">
//                     <div>
//                       <Button color="outline-secondary" onClick={resetFilters}>
//                         Clear Filter
//                       </Button>
//                     </div>
//                   </Col>

//                   {/* Spacer */}
//                   <div className="d-none d-md-block col-md-1"></div>

//                   {/* Add User Button - Right */}
//                   <div className="col-12 col-md-2 d-flex justify-content-md-end">
//                     <Link href="/admin/user/add" className="w-100 w-md-auto">
//                       <Button
//                         color="primary"
//                         className="w-100 w-md-auto p-2"
//                         style={{ fontSize: "13px" }}
//                       >
//                         <i className="fa fa-plus me-2"></i>
//                         Add User
//                       </Button>
//                     </Link>
//                   </div>
//                 </div>

//                 {/* User Table */}
//                 <div className="table-responsive">
//                   <Table hover className="customer-table mb-0">
//                     <thead>
//                       <tr>
//                         <th>ID</th>
//                         <th>User Name</th>
//                         <th>Email</th>
//                         <th>Phone</th>
//                         <th>Role</th>
//                         <th>Address</th>
//                         <th>Status</th>
//                         <th>Join Date</th>
//                         <th>Last Login</th>
//                         <th>Actions</th>
//                       </tr>
//                     </thead>
//                     <tbody>
//                       {paginatedUsers.length === 0 ? (
//                         <tr>
//                           <td colSpan={10} className="text-center py-4">
//                             No users found
//                           </td>
//                         </tr>
//                       ) : (
//                         paginatedUsers.map((user) => (
//                           <tr key={user.id}>
//                             <td>
//                               <strong>{user.id}</strong>
//                             </td>
//                             <td>
//                               <div
//                                 className="fw-bold text-primary cursor-pointer no-wrap"
//                                 onClick={() =>
//                                   router.push(`/admin/user/${user.id}`)
//                                 }
//                               >
//                                 {user.name}
//                               </div>
//                             </td>
//                             <td>{user.email}</td>
//                             <td className="no-wrap">{user.phone}</td>
//                             <td>{renderRoleBadge(user.role)}</td>
//                             <td>
//                               <span
//                                 className="text-truncate d-inline-block"
//                                 style={{ maxWidth: "150px" }}
//                                 title={user.address}
//                               >
//                                 {user.address}
//                               </span>
//                             </td>
//                             <td>{renderStatusBadge(user.status)}</td>
//                             <td>
//                               {new Date(user.joinDate).toLocaleDateString()}
//                             </td>
//                             <td>
//                               {new Date(user.lastLogin).toLocaleDateString()}
//                             </td>
//                             <td>
//                               <div className="d-flex gap-1">
//                                 <button
//                                   className="action-btn text-white border btn-primary"
//                                   onClick={() =>
//                                     router.push(`/admin/user/${user.id}`)
//                                   }
//                                   title="View"
//                                 >
//                                   <i className="fa fa-eye"></i>
//                                 </button>
//                                 <button
//                                   className="action-btn text-white border btn-warning"
//                                   onClick={() =>
//                                     router.push(
//                                       `/admin/user/${user.id}?edit=true`
//                                     )
//                                   }
//                                   title="Edit"
//                                 >
//                                   <i className="icofont icofont-pencil-alt-5"></i>
//                                 </button>
//                                 <button
//                                   className="action-btn text-white border btn-danger"
//                                   onClick={() => handleDeleteUser(user.id)}
//                                   title="Delete"
//                                 >
//                                   <i className="icofont icofont-ui-delete"></i>
//                                 </button>
//                               </div>
//                             </td>
//                           </tr>
//                         ))
//                       )}
//                     </tbody>
//                   </Table>
//                 </div>

//                 {/* Pagination and Info */}
//                 <div className="d-flex flex-column flex-md-row justify-content-between align-items-center gap-3 mt-4">
//                   <div className="text-center text-md-start text-muted">
//                     Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
//                     {Math.min(currentPage * itemsPerPage, filteredUsers.length)}{" "}
//                     of {filteredUsers.length} entries
//                   </div>
//                   <CustomPagination
//                     currentPage={currentPage}
//                     totalPages={totalPages}
//                     onPageChange={setCurrentPage}
//                     showFirstLast={true}
//                     maxVisiblePages={5}
//                     paginationType="primary"
//                     className="justify-content-center justify-content-md-end"
//                   />
//                 </div>
//               </CardBody>
//             </Card>
//           </Col>
//         </Row>
//       </Container>

//       <style jsx>{`
//         .customer-card {
//           box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
//           border: 1px solid rgba(0, 0, 0, 0.125);
//         }

//         .action-btn {
//           padding: 0.25rem 0.5rem;
//           border-radius: 5px;
//           font-size: 0.75rem;
//         }

//         .customer-table {
//           font-size: 0.875rem;
//           table-layout: auto;
//           white-space: nowrap;
//         }

//         .customer-table td {
//           vertical-align: middle;
//           white-space: nowrap;
//         }

//         .no-wrap {
//           white-space: nowrap;
//         }

//         @media (max-width: 768px) {
//           .customer-card .card-body {
//             padding: 1rem;
//           }

//           .table-responsive {
//             border: 1px solid #dee2e6;
//             border-radius: 0.375rem;
//           }

//           .customer-table {
//             min-width: 1000px;
//           }
//         }
//       `}</style>
//     </div>
//   );
// }

// export default UserPage;

"use client";
import Breadcrumbs from "@/CommonElements/Breadcrumbs";
import CustomPagination from "@/CommonElements/Pagination";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  Input,
  Button,
  Table,
} from "reactstrap";
import React, { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useAuth } from "@/helper/AuthContext";
import withAuth from "@/helper/WithAuth";

// Updated Types to match API response
interface ApiUser {
  id: string;
  display_name: string;
  email: string;
  role_id: string;
  is_active: string;
}

interface User {
  id: number;
  name: string;
  email: string;
  phone: string;
  role: "customer" | "technician" | "accountant" | "manager" | string;
  address: string;
  status: "active" | "inactive" | "pending";
  joinDate: string;
  lastLogin: string;
}

function UserPage() {
  const { state } = useAuth();
  const router = useRouter();
  const [currentPage, setCurrentPage] = useState(1);
  const [users, setUsers] = useState<User[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [roleFilter, setRoleFilter] = useState("all");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const itemsPerPage = 5;

  const roleMap: { [key: string]: string } = {
    "2": "admin",
    "3": "manager",
    "4": "receptionist",
    "5": "technician",
    "6": "accountant",
    "7": "customer",
  };

  // Map is_active to status
  const statusMap: { [key: string]: "active" | "inactive" | "pending" } = {
    "1": "active",
    "0": "inactive",
    "2": "pending",
  };

  // Transform API data to match User interface
  const transformApiData = (apiUsers: ApiUser[]): User[] => {
    return apiUsers.map((apiUser) => ({
      id: parseInt(apiUser.id),
      name: apiUser.display_name,
      email: apiUser.email,
      phone: "N/A", // Add phone field if available in API
      role: roleMap[apiUser.role_id] || "customer",
      address: "N/A", // Add address field if available in API
      status: statusMap[apiUser.is_active] || "pending",
      joinDate: new Date().toISOString().split("T")[0], // Use actual date from API if available
      lastLogin: new Date().toISOString().split("T")[0], // Use actual last login from API if available
    }));
  };

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        setLoading(true);
        setError(null);

        const token = state?.accessToken || localStorage.getItem("token");

        if (!token) {
          throw new Error("No authentication token found");
        }

        const response = await fetch("/api/users", {
          method: "GET",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        });

        if (!response.ok) {
          throw new Error(`Failed to fetch users: ${response.status}`);
        }

        const data = await response.json();

        // Assuming your API returns { data: ApiUser[] }
        if (data.data && Array.isArray(data.data)) {
          const transformedUsers = transformApiData(data.data);
          setUsers(transformedUsers);
        } else {
          throw new Error("Invalid data format received from API");
        }
      } catch (err) {
        console.error("Error fetching users:", err);
        setError(err instanceof Error ? err.message : "Failed to load users");
      } finally {
        setLoading(false);
      }
    };

    fetchUsers();
  }, [state?.accessToken]);

  // Filter users based on search and filters
  const filteredUsers = users.filter((user) => {
    const matchesSearch =
      user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.phone.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.address.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus =
      statusFilter === "all" || user.status === statusFilter;

    const matchesRole = roleFilter === "all" || user.role === roleFilter;

    return matchesSearch && matchesStatus && matchesRole;
  });

  // Pagination
  const totalPages = Math.ceil(filteredUsers.length / itemsPerPage);
  const paginatedUsers = filteredUsers.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  // Status badge render function
  const renderStatusBadge = (value: string) => {
    const statusConfig = {
      active: { class: "bg-success", label: "Active" },
      inactive: { class: "bg-secondary", label: "Inactive" },
      pending: { class: "bg-warning", label: "Pending" },
    };

    const config = statusConfig[value as keyof typeof statusConfig] || {
      class: "bg-secondary",
      label: value,
    };

    return (
      <span className={`badge ${config.class} text-white`}>{config.label}</span>
    );
  };

  // Role badge render function
  const renderRoleBadge = (value: string) => {
    const roleConfig = {
      admin: { class: "bg-dark", label: "Admin" },
      customer: { class: "bg-primary", label: "Customer" },
      technician: { class: "bg-info", label: "Technician" },
      accountant: { class: "bg-warning", label: "Accountant" },
      manager: { class: "bg-danger", label: "Manager" },
      receptionist: { class: "bg-primary", label: "Receptionist" },
    };

    const config = roleConfig[value as keyof typeof roleConfig] || {
      class: "bg-secondary",
      label: value,
    };

    return (
      <span className={`badge ${config.class} text-white`}>{config.label}</span>
    );
  };

  const handleDeleteUser = async (id: number) => {
    if (confirm("Are you sure you want to delete this user?")) {
      try {
        const token = state?.accessToken || localStorage.getItem("token");

        const response = await fetch(`/api/users/${id}`, {
          method: "DELETE",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        });

        if (response.ok) {
          // Remove user from state on successful deletion
          setUsers(users.filter((user) => user.id !== id));
        } else {
          throw new Error("Failed to delete user");
        }
      } catch (error) {
        console.error("Error deleting user:", error);
        alert("Failed to delete user. Please try again.");
      }
    }
  };

  const resetFilters = () => {
    setSearchTerm("");
    setStatusFilter("all");
    setRoleFilter("all");
    setCurrentPage(1);
  };

  // Loading state
  if (loading) {
    return (
      <div className="page-body">
        <Breadcrumbs
          title="User Management"
          mainTitle="User Management"
          parent="Dashboard"
        />
        <Container fluid>
          <Row>
            <Col sm={12}>
              <Card>
                <CardBody className="text-center py-5">
                  <div className="spinner-border text-primary" role="status">
                    <span className="visually-hidden">Loading...</span>
                  </div>
                  <p className="mt-3">Loading users...</p>
                </CardBody>
              </Card>
            </Col>
          </Row>
        </Container>
      </div>
    );
  }

  // Error state
  if (error) {
    return (
      <div className="page-body">
        <Breadcrumbs
          title="User Management"
          mainTitle="User Management"
          parent="Dashboard"
        />
        <Container fluid>
          <Row>
            <Col sm={12}>
              <Card>
                <CardBody className="text-center py-5">
                  <div className="text-danger mb-3">
                    <i className="fa fa-exclamation-triangle fa-2x"></i>
                  </div>
                  <h5>Error Loading Users</h5>
                  <p className="text-muted">{error}</p>
                  <Button
                    color="primary"
                    onClick={() => window.location.reload()}
                  >
                    Retry
                  </Button>
                </CardBody>
              </Card>
            </Col>
          </Row>
        </Container>
      </div>
    );
  }

  return (
    <div className="page-body">
      <Breadcrumbs
        title="User Management"
        mainTitle="User Management"
        parent="Dashboard"
      />

      <Container fluid>
        <Row>
          <Col sm={12}>
            <Card className="customer-card">
              <CardBody>
                {/* Header with Search and Add Button */}
                <div className="row align-items-center mb-4 g-3">
                  {/* Search Bar - Left */}
                  <div className="col-12 col-md-3">
                    <div className="position-relative">
                      <Input
                        type="search"
                        placeholder="Search users..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="form-control"
                      />
                      {searchTerm.length === 0 && (
                        <i
                          className="fa fa-search position-absolute"
                          style={{
                            right: "10px",
                            top: "50%",
                            transform: "translateY(-50%)",
                            color: "#aaa",
                          }}
                        ></i>
                      )}
                    </div>
                  </div>

                  <div className="col-12 col-md-2">
                    <select
                      className="form-select p-2 border"
                      style={{ fontSize: "0.9rem" }}
                      value={statusFilter}
                      onChange={(e) => setStatusFilter(e.target.value)}
                    >
                      <option value="all">All Status</option>
                      <option value="active">Active</option>
                      <option value="inactive">Inactive</option>
                      <option value="pending">Pending</option>
                    </select>
                  </div>

                  <div className="col-12 col-md-2">
                    <select
                      className="form-select p-2 border"
                      style={{ fontSize: "0.9rem" }}
                      value={roleFilter}
                      onChange={(e) => setRoleFilter(e.target.value)}
                    >
                      <option value="all">All Roles</option>
                      <option value="admin">Admin</option>
                      <option value="manager">Manager</option>
                      <option value="receptionist">Receptionist</option>
                      <option value="technician">Technician</option>
                      <option value="accountant">Accountant</option>
                      <option value="customer">Customer</option>
                    </select>
                  </div>
                  <Col md="2">
                    <div>
                      <Button color="outline-secondary" onClick={resetFilters}>
                        Clear Filter
                      </Button>
                    </div>
                  </Col>

                  {/* Spacer */}
                  <div className="d-none d-md-block col-md-1"></div>

                  {/* Add User Button - Right */}
                  <div className="col-12 col-md-2 d-flex justify-content-md-end">
                    <Link href="/admin/user/add" className="w-100 w-md-auto">
                      <Button
                        color="primary"
                        className="w-100 w-md-auto p-2"
                        style={{ fontSize: "13px" }}
                      >
                        <i className="fa fa-plus me-2"></i>
                        Add User
                      </Button>
                    </Link>
                  </div>
                </div>

                {/* User Table */}
                <div className="table-responsive">
                  <Table hover className="customer-table mb-0">
                    <thead>
                      <tr>
                        <th>Sl</th>
                        <th>User Name</th>
                        <th>Email</th>
                        {/* <th>Phone</th> */}
                        <th>Role</th>
                        {/* <th>Address</th> */}
                        <th>Status</th>
                        {/* <th>Join Date</th> */}
                        {/* <th>Last Login</th> */}
                        {/* <th>Actions</th> */}
                      </tr>
                    </thead>
                    <tbody>
                      {paginatedUsers.length === 0 ? (
                        <tr>
                          <td colSpan={10} className="text-center py-4">
                            {users.length === 0
                              ? "No users found"
                              : "No users match your filters"}
                          </td>
                        </tr>
                      ) : (
                        paginatedUsers.map((user, index) => (
                          <tr key={user.id}>
                            {/* <td>
                              <strong>{user.id}</strong>
                            </td> */}
                            <td>
                              <strong>{index + 1}</strong>
                            </td>
                            <td>
                              <div
                                className="fw-bold text-primary cursor-pointer no-wrap"
                                onClick={() =>
                                  router.push(`/admin/user/${user.id}`)
                                }
                                style={{ cursor: "pointer" }}
                              >
                                {user.name}
                              </div>
                            </td>
                            <td>{user.email}</td>
                            {/* <td className="no-wrap">{user.phone}</td> */}
                            <td>{renderRoleBadge(user.role)}</td>
                            {/* <td>
                              <span
                                className="text-truncate d-inline-block"
                                style={{ maxWidth: "150px" }}
                                title={user.address}
                              >
                                {user.address}
                              </span>
                            </td> */}
                            <td>{renderStatusBadge(user.status)}</td>
                            {/* <td>
                              {new Date(user.joinDate).toLocaleDateString()}
                            </td>
                            <td>
                              {new Date(user.lastLogin).toLocaleDateString()}
                            </td> */}
                            {/* <td>
                              <div className="d-flex gap-1">
                                <button
                                  className="action-btn text-white border btn-primary"
                                  onClick={() =>
                                    router.push(`/admin/user/${user.id}`)
                                  }
                                  title="View"
                                >
                                  <i className="fa fa-eye"></i>
                                </button>
                                <button
                                  className="action-btn text-white border btn-warning"
                                  onClick={() =>
                                    router.push(
                                      `/admin/user/${user.id}?edit=true`
                                    )
                                  }
                                  title="Edit"
                                >
                                  <i className="icofont icofont-pencil-alt-5"></i>
                                </button>
                                <button
                                  className="action-btn text-white border btn-danger"
                                  onClick={() => handleDeleteUser(user.id)}
                                  title="Delete"
                                >
                                  <i className="icofont icofont-ui-delete"></i>
                                </button>
                              </div>
                            </td> */}
                          </tr>
                        ))
                      )}
                    </tbody>
                  </Table>
                </div>

                {/* Pagination and Info */}
                <div className="d-flex flex-column flex-md-row justify-content-between align-items-center gap-3 mt-4">
                  <div className="text-center text-md-start text-muted">
                    Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
                    {Math.min(currentPage * itemsPerPage, filteredUsers.length)}{" "}
                    of {filteredUsers.length} entries
                  </div>
                  <CustomPagination
                    currentPage={currentPage}
                    totalPages={totalPages}
                    onPageChange={setCurrentPage}
                    showFirstLast={true}
                    maxVisiblePages={5}
                    paginationType="primary"
                    className="justify-content-center justify-content-md-end"
                  />
                </div>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Container>

      <style jsx>{`
        .customer-card {
          box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
          border: 1px solid rgba(0, 0, 0, 0.125);
        }

        .action-btn {
          padding: 0.25rem 0.5rem;
          border-radius: 5px;
          font-size: 0.75rem;
        }

        .customer-table {
          font-size: 0.875rem;
          table-layout: auto;
          white-space: nowrap;
        }

        .customer-table td {
          vertical-align: middle;
          white-space: nowrap;
        }

        .no-wrap {
          white-space: nowrap;
        }

        .cursor-pointer {
          cursor: pointer;
        }

        @media (max-width: 768px) {
          .customer-card .card-body {
            padding: 1rem;
          }

          .table-responsive {
            border: 1px solid #dee2e6;
            border-radius: 0.375rem;
          }

          .customer-table {
            min-width: 1000px;
          }
        }
      `}</style>
    </div>
  );
}

// export default UserPage;
export default withAuth(UserPage, ["admin"]);
