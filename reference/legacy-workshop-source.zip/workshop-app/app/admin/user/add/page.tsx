// "use client";
// import Breadcrumbs from "@/CommonElements/Breadcrumbs";
// import {
//   Container,
//   Row,
//   Col,
//   Card,
//   CardBody,
//   Form,
//   FormGroup,
//   Label,
//   Input,
//   Button,
//   Alert,
// } from "reactstrap";
// import React, { useState } from "react";
// import { useRouter } from "next/navigation";

// function AddUserPage() {
//   const router = useRouter();
//   const [formData, setFormData] = useState({
//     name: "",
//     email: "",
//     phone: "",
//     role: "customer",
//     address: "",
//     status: "active",
//   });
//   const [showAlert, setShowAlert] = useState(false);

//   const handleChange = (
//     e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
//   ) => {
//     const { name, value } = e.target;
//     setFormData((prev) => ({
//       ...prev,
//       [name]: value,
//     }));
//   };

//   const handleSubmit = (e: React.FormEvent) => {
//     e.preventDefault();

//     // Here you would typically make an API call
//     console.log("User data:", formData);

//     // Show success message
//     setShowAlert(true);

//     // Redirect after 2 seconds
//     setTimeout(() => {
//       router.push("/admin/user");
//     }, 2000);
//   };

//   return (
//     <div className="page-body">
//       <Breadcrumbs
//         title="Add New User"
//         mainTitle="Add New User"
//         parent="User Management"
//       />

//       <Container fluid>
//         <Row>
//           <Col sm={12}>
//             <Card>
//               <CardBody>
//                 {showAlert && (
//                   <Alert color="success" className="mb-3">
//                     User added successfully! Redirecting...
//                   </Alert>
//                 )}

//                 <Form onSubmit={handleSubmit} className="text-muted">
//                   <Row>
//                     <Col md={6}>
//                       <FormGroup>
//                         <Label for="name">Full Name *</Label>
//                         <Input
//                           type="text"
//                           name="name"
//                           id="name"
//                           value={formData.name}
//                           onChange={handleChange}
//                           required
//                         />
//                       </FormGroup>
//                     </Col>

//                     <Col md={6}>
//                       <FormGroup>
//                         <Label for="email">Email Address *</Label>
//                         <Input
//                           type="email"
//                           name="email"
//                           id="email"
//                           value={formData.email}
//                           onChange={handleChange}
//                           required
//                         />
//                       </FormGroup>
//                     </Col>
//                   </Row>

//                   <Row>
//                     <Col md={6}>
//                       <FormGroup>
//                         <Label for="phone">Contact Number *</Label>
//                         <Input
//                           type="tel"
//                           name="phone"
//                           id="phone"
//                           value={formData.phone}
//                           onChange={handleChange}
//                           required
//                         />
//                       </FormGroup>
//                     </Col>

//                     <Col md={6}>
//                       <FormGroup>
//                         <Label for="role">User Role *</Label>
//                         <select
//                           name="role"
//                           id="role"
//                              style={{fontSize:'0.9rem'}}
//                          className="form-select border p-2"
//                           value={formData.role}
//                           onChange={handleChange}
//                           required
//                         >
//                           <option value="customer">Customer</option>
//                           <option value="technician">Technician</option>
//                           <option value="accountant">Accountant</option>
//                           <option value="manager">Manager</option>
//                         </select>
//                       </FormGroup>
//                     </Col>
//                   </Row>

//                   <Row>
//                     <Col md={6}>
//                       <FormGroup>
//                         <Label for="status">Status</Label>
//                         <select
//                           name="status"
//                          style={{fontSize:'0.9rem'}}
//                           id="status"
//                           className="form-select border p-2"
//                           value={formData.status}
//                           onChange={handleChange}
//                         >
//                           <option value="active">Active</option>
//                           <option value="inactive">Inactive</option>
//                           <option value="pending">Pending</option>
//                         </select>
//                       </FormGroup>
//                     </Col>
//                   </Row>

//                   <FormGroup>
//                     <Label for="address">Address</Label>
//                     <Input
//                       type="textarea"
//                       name="address"
//                       id="address"
//                       value={formData.address}
//                       onChange={handleChange}
//                       rows={3}
//                     />
//                   </FormGroup>

//                   <div className="d-flex gap-2 mt-4">
//                     <Button type="submit" color="primary">
//                       Add User
//                     </Button>
//                     <Button
//                       type="button"
//                       color="secondary"
//                       onClick={() => router.push("/admin/user")}
//                     >
//                       Cancel
//                     </Button>
//                   </div>
//                 </Form>
//               </CardBody>
//             </Card>
//           </Col>
//         </Row>
//       </Container>
//     </div>
//   );
// }

// export default AddUserPage;

"use client";
import Breadcrumbs from "@/CommonElements/Breadcrumbs";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  Form,
  FormGroup,
  Label,
  Input,
  Button,
  Alert,
  Spinner,
} from "reactstrap";
import React, { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/helper/AuthContext";

// Types for form data - simplified to match API requirements
interface UserFormData {
  name: string;
  email: string;
  password: string;
  role_id: string;
}

const userRole = [
  { value: "3", label: "Manager" },
  { value: "4", label: "Receptionist" },
  { value: "5", label: "Technician" },
  { value: "6", label: "Accountant" },
];

function AddUserPage() {
  const router = useRouter();
  const { state } = useAuth();
  const [formData, setFormData] = useState<UserFormData>({
    name: "",
    email: "",
    password: "",
    role_id: "5", // Default to customer (5)
  });

  const [loading, setLoading] = useState(false);
  const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState("");
  const [alertType, setAlertType] = useState<"success" | "danger">("success");
  const [errors, setErrors] = useState<Record<string, string>>({});

  const [userRoleSearchTerm, setUserRoleSearchTerm] = useState("");
  const [isUserRoleDropdownOpen, setIsUserRoleDropdownOpen] = useState(false);
  const [selectedUserRoleLabel, setSelectedUserRoleLabel] = useState("");
  const userRoleDropdownRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        userRoleDropdownRef.current &&
        !userRoleDropdownRef.current.contains(event.target as Node)
      ) {
        setIsUserRoleDropdownOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!formData.name.trim()) {
      newErrors.name = "Name is required";
    }

    if (!formData.email.trim()) {
      newErrors.email = "Email is required";
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = "Email is invalid";
    }

    if (!formData.password) {
      newErrors.password = "Password is required";
    } else if (formData.password.length < 6) {
      newErrors.password = "Password must be at least 6 characters";
    }

    if (!formData.role_id) {
      newErrors.role_id = "Role is required";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));

    // Clear error when user starts typing
    if (errors[name]) {
      setErrors((prev) => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };

  const handleUserRoleSelect = (
    vehicleTypeValue: string,
    vehicleTypeLabel: string
  ) => {
    setFormData((prev) => ({
      ...prev,
      role_id: vehicleTypeValue,
    }));
    setSelectedUserRoleLabel(vehicleTypeLabel);
    setIsUserRoleDropdownOpen(false);
    setUserRoleSearchTerm("");
  };

  const filteredUserRoles = userRoleSearchTerm
    ? userRole.filter(
        (type) =>
          type.label.toLowerCase().includes(userRoleSearchTerm.toLowerCase()) ||
          type.value.toLowerCase().includes(userRoleSearchTerm.toLowerCase())
      )
    : userRole;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setLoading(true);
    setShowAlert(false);

    try {
      const token = state?.accessToken || localStorage.getItem("token");

      if (!token) {
        throw new Error("No authentication token found");
      }

      // Prepare data for API - exactly as required
      const apiData = {
        name: formData.name,
        email: formData.email,
        password: formData.password,
        role_id: formData.role_id,
      };

      const response = await fetch("/api/users", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(apiData),
      });

      const responseData = await response.json();

      if (!response.ok) {
        throw new Error(
          responseData.message || `Failed to create user: ${response.status}`
        );
      }

      // Show success message
      setAlertMessage("User added successfully! Redirecting...");
      setAlertType("success");
      setShowAlert(true);

      // Reset form
      setFormData({
        name: "",
        email: "",
        password: "",
        role_id: "5",
      });
      router.push("/admin/user");

      // setTimeout(() => {
      //   router.push("/admin/user");
      // }, 2000);
    } catch (error) {
      console.error("Error adding user:", error);

      setAlertMessage(
        error instanceof Error
          ? error.message
          : "Failed to add user. Please try again."
      );
      setAlertType("danger");
      setShowAlert(true);
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = () => {
    if (formData.name || formData.email || formData.password) {
      if (
        confirm("Are you sure you want to cancel? All changes will be lost.")
      ) {
        router.push("/admin/user");
      }
    } else {
      router.push("/admin/user");
    }
  };

  return (
    <div className="page-body">
      <Breadcrumbs
        title="Add New User"
        mainTitle="Add New User"
        parent="User Management"
      />

      <Container fluid>
        <Row>
          <Col sm={12}>
            <Card>
              <CardBody>
                {showAlert && (
                  <Alert
                    color={alertType}
                    className="mb-3"
                    toggle={() => setShowAlert(false)}
                  >
                    {alertMessage}
                  </Alert>
                )}

                <Form onSubmit={handleSubmit} className="text-muted">
                  <Row>
                    <Col md={6}>
                      <FormGroup>
                        <Label for="name">Name *</Label>
                        <Input
                          type="text"
                          name="name"
                          id="name"
                          placeholder="Enter name"
                          value={formData.name}
                          onChange={handleChange}
                          invalid={!!errors.name}
                          disabled={loading}
                        />
                        {errors.name && (
                          <div className="text-danger small mt-1">
                            {errors.name}
                          </div>
                        )}
                      </FormGroup>
                    </Col>

                    <Col md={6}>
                      <FormGroup>
                        <Label for="email">Email Address *</Label>
                        <Input
                          type="email"
                          name="email"
                          id="email"
                          placeholder="Enter email address"
                          value={formData.email}
                          onChange={handleChange}
                          invalid={!!errors.email}
                          disabled={loading}
                        />
                        {errors.email && (
                          <div className="text-danger small mt-1">
                            {errors.email}
                          </div>
                        )}
                      </FormGroup>
                    </Col>
                  </Row>

                  <Row>
                    <Col md={6}>
                      <FormGroup>
                        <Label for="password">Password *</Label>
                        <Input
                          type="password"
                          name="password"
                          id="password"
                          placeholder="Enter password (min. 6 characters)"
                          value={formData.password}
                          onChange={handleChange}
                          invalid={!!errors.password}
                          disabled={loading}
                        />
                        {errors.password && (
                          <div className="text-danger small mt-1">
                            {errors.password}
                          </div>
                        )}
                      </FormGroup>
                    </Col>

                    {/* <Col md={6}>
                      <FormGroup>
                        <Label for="role_id">User Role *</Label>
                        <select
                          name="role_id"
                          id="role_id"
                          style={{ fontSize: "0.9rem" }}
                          className={`form-select border p-2 ${
                            errors.role_id ? "is-invalid" : ""
                          }`}
                          value={formData.role_id}
                          onChange={handleChange}
                          disabled={loading}
                          required
                        >
                          <option value="">Select a role</option>
                          <option value="3">Manager</option>
                          <option value="4">Receptionist</option>
                          <option value="5">Technician</option>
                          <option value="6">Accountant</option>
                        </select>
                        {errors.role_id && (
                          <div className="text-danger small mt-1">
                            {errors.role_id}
                          </div>
                        )}
                      </FormGroup>
                    </Col> */}
                    <Col md="6">
                      <FormGroup>
                        <Label>User Role *</Label>
                        <div
                          className="position-relative"
                          ref={userRoleDropdownRef}
                        >
                          {/* Dropdown trigger */}
                          <div
                            onClick={() =>
                              setIsUserRoleDropdownOpen(!isUserRoleDropdownOpen)
                            }
                            className="d-flex w-100 align-items-center justify-content-between cursor-pointer form-select border"
                            style={{
                              minHeight: "38px",
                              padding: "0.375rem 0.75rem",
                              cursor: "pointer",
                            }}
                          >
                            <span
                              className="text-truncate"
                              style={{ maxWidth: "calc(100% - 20px)" }}
                            >
                              {selectedUserRoleLabel || "Select Role"}
                            </span>
                            {/* <span
                              className="ms-2 text-muted"
                              style={{ flexShrink: 0 }}
                            >
                              {isUserRoleDropdownOpen ? "▲" : "▼"}
                            </span> */}
                          </div>

                          {/* Dropdown menu */}
                          {isUserRoleDropdownOpen && (
                            // <div
                            //   className="position-absolute w-100 mt-1 bg-white border rounded shadow"
                            //   style={{
                            //     maxHeight: "300px",
                            //     overflow: "auto",
                            //     zIndex: 1050,
                            //   }}
                            // >
                            <div
                              className="position-absolute w-100 mt-1 border rounded shadow dropdown-menu show"
                              style={{
                                maxHeight: "300px",
                                overflow: "auto",
                                zIndex: 1050,
                              }}
                            >
                              <div className="p-2 border-bottom">
                                <Input
                                  type="text"
                                  value={userRoleSearchTerm}
                                  onChange={(e) => {
                                    setUserRoleSearchTerm(e.target.value);
                                  }}
                                  placeholder="Search roles..."
                                  className="form-control form-control-sm"
                                  autoFocus
                                  onClick={(e) => e.stopPropagation()}
                                />
                              </div>

                              <div
                                style={{
                                  maxHeight: "200px",
                                  overflowY: "auto",
                                }}
                              >
                                {filteredUserRoles.length > 0 ? (
                                  <ul className="list-unstyled mb-0">
                                    {filteredUserRoles.map((role) => (
                                      <li
                                        key={role.value}
                                        onClick={() =>
                                          handleUserRoleSelect(
                                            role.value,
                                            role.label
                                          )
                                        }
                                        className="px-3 py-2 cursor-pointer hover-bg-light"
                                        style={{ cursor: "pointer" }}
                                      >
                                        <div className="d-flex align-items-center justify-content-between">
                                          <span>{role.label}</span>
                                          {/* {formData.role_id === role.value && (
                                            <span className="ms-2 badge bg-primary">
                                              Selected
                                            </span>
                                          )} */}
                                        </div>
                                      </li>
                                    ))}
                                  </ul>
                                ) : (
                                  <div className="px-3 py-2 text-muted">
                                    {userRoleSearchTerm
                                      ? "No matching user roles found"
                                      : "No user roles available"}
                                  </div>
                                )}
                              </div>
                            </div>
                          )}

                          {/* Hidden input for form submission */}
                          <input
                            type="hidden"
                            name="role_id"
                            value={formData.role_id}
                            required
                          />
                        </div>
                      </FormGroup>
                    </Col>
                  </Row>

                  <div className="d-flex gap-2 mt-4">
                    <Button type="submit" color="primary" disabled={loading}>
                      {loading ? (
                        <>
                          <Spinner size="sm" className="me-2" />
                          Adding User...
                        </>
                      ) : (
                        "Add User"
                      )}
                    </Button>
                    <Button
                      type="button"
                      color="secondary"
                      onClick={handleCancel}
                      disabled={loading}
                    >
                      Cancel
                    </Button>
                  </div>
                </Form>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Container>
      <style jsx>{`
        .form-control:disabled {
          background-color: #e9ecef;
          opacity: 1;
        }

        .text-muted {
          font-size: 0.875rem;
        }

        .cursor-pointer {
          cursor: pointer;
        }

        .text-truncate {
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        /* Dark mode styles for dropdowns */
        :global(.dark-mode) .dropdown-menu {
          background-color: #2a3042 !important;
          border-color: #404656 !important;
          color: #e0e0e0 !important;
        }

        :global(.dark-mode) .dropdown-item {
          color: #e0e0e0 !important;
        }

        :global(.dark-mode) .dropdown-item:hover {
          background-color: #3a4054 !important;
          color: #ffffff !important;
        }

        :global(.dark-mode) .text-muted {
          color: #a0a0a0 !important;
        }

        :global(.dark-mode) .border-bottom {
          border-color: #404656 !important;
        }

        :global(.dark-mode) .form-control {
          background-color: #2a3042 !important;
          border-color: #404656 !important;
          color: #e0e0e0 !important;
        }

        :global(.dark-mode) .form-control::placeholder {
          color: #a0a0a0 !important;
        }

        /* Make dropdown trigger adapt to dark mode */
        :global(.dark-mode) .dropdown-toggle {
          background-color: #2a3042 !important;
          border-color: #404656 !important;
          color: #e0e0e0 !important;
        }
      `}</style>
    </div>
  );
}

export default AddUserPage;
