// filter dropdown fix in mobile

// "use client";
// import Breadcrumbs from "@/CommonElements/Breadcrumbs";
// import CustomPagination from "@/CommonElements/Pagination";
// import {
//   Container,
//   Row,
//   Col,
//   Card,
//   CardBody,
//   Input,
//   Button,
//   Table,
//   Badge,
// } from "reactstrap";
// import React, { useState, ChangeEvent, useEffect, useRef } from "react";
// import Link from "next/link";
// import { useRouter } from "next/navigation";
// import withAuth from "@/helper/WithAuth";

// // Types
// interface Technician {
//   id: number;
//   name: string;
//   email: string;
//   phone: string;
//   specialization: string[];
//   status: "available" | "busy" | "offline";
//   currentWorkload: number;
//   rating: number;
//   completedJobs: number;
// }

// interface WorkAssignment {
//   id: number;
//   jobCardId: string;
//   jobCardNumber: string;
//   vehicleNumber: string;
//   vehicleModel: string;
//   reportedIssue: string;
//   assignedTechnician: string;
//   technicianId: number;
//   assignedDate: string;
//   estimatedCompletion: string;
//   status: "pending" | "in-progress" | "completed" | "cancelled";
//   priority: "low" | "medium" | "high" | "urgent";
//   internalNotes: InternalNote[];
//   actualCompletionDate?: string;
// }

// interface InternalNote {
//   id: number;
//   author: string;
//   content: string;
//   timestamp: string;
//   type: "update" | "issue" | "resolution";
// }

// // Mock data
// const techniciansData: Technician[] = [
//   {
//     id: 1,
//     name: "Mike Smith",
//     email: "mike.smith@garage.com",
//     phone: "+1-555-0101",
//     specialization: ["Engine", "Transmission"],
//     status: "busy",
//     currentWorkload: 3,
//     rating: 4.8,
//     completedJobs: 156,
//   },
//   {
//     id: 2,
//     name: "Sarah Johnson",
//     email: "sarah.j@garage.com",
//     phone: "+1-555-0102",
//     specialization: ["Brakes", "Suspension"],
//     status: "available",
//     currentWorkload: 1,
//     rating: 4.9,
//     completedJobs: 89,
//   },
//   {
//     id: 3,
//     name: "David Wilson",
//     email: "david.w@garage.com",
//     phone: "+1-555-0103",
//     specialization: ["Electrical", "AC Systems"],
//     status: "available",
//     currentWorkload: 2,
//     rating: 4.7,
//     completedJobs: 203,
//   },
// ];

// const workAssignmentsData: WorkAssignment[] = [
//   {
//     id: 1,
//     jobCardId: "JC-2024-001",
//     jobCardNumber: "JC-2024-001",
//     vehicleNumber: "ABC123",
//     vehicleModel: "Toyota Camry 2022",
//     reportedIssue: "Regular maintenance service",
//     assignedTechnician: "Mike Smith",
//     technicianId: 1,
//     assignedDate: "2024-01-15",
//     estimatedCompletion: "2024-01-16",
//     status: "in-progress",
//     priority: "medium",
//     internalNotes: [
//       {
//         id: 1,
//         author: "Mike Smith",
//         content: "Started oil change and filter replacement",
//         timestamp: "2024-01-15 09:30",
//         type: "update",
//       },
//     ],
//   },
//   {
//     id: 2,
//     jobCardId: "JC-2024-002",
//     jobCardNumber: "JC-2024-002",
//     vehicleNumber: "XYZ789",
//     vehicleModel: "Honda Civic 2021",
//     reportedIssue: "Brake noise and vibration",
//     assignedTechnician: "Sarah Johnson",
//     technicianId: 2,
//     assignedDate: "2024-01-16",
//     estimatedCompletion: "2024-01-18",
//     status: "pending",
//     priority: "high",
//     internalNotes: [],
//   },
//   {
//     id: 3,
//     jobCardId: "JC-2024-003",
//     jobCardNumber: "JC-2024-003",
//     vehicleNumber: "DEF456",
//     vehicleModel: "Ford F-150 2023",
//     reportedIssue: "Pre-purchase inspection",
//     assignedTechnician: "David Wilson",
//     technicianId: 3,
//     assignedDate: "2024-01-14",
//     estimatedCompletion: "2024-01-15",
//     status: "completed",
//     priority: "low",
//     internalNotes: [
//       {
//         id: 2,
//         author: "David Wilson",
//         content: "Vehicle passed all inspections. Minor wear on tires noted.",
//         timestamp: "2024-01-15 14:20",
//         type: "resolution",
//       },
//     ],
//     actualCompletionDate: "2024-01-15",
//   },
//   {
//     id: 4,
//     jobCardId: "JC-2024-004",
//     jobCardNumber: "JC-2024-004",
//     vehicleNumber: "GHI789",
//     vehicleModel: "BMW X5 2022",
//     reportedIssue: "AC not cooling properly",
//     assignedTechnician: "Mike Smith",
//     technicianId: 1,
//     assignedDate: "2024-01-17",
//     estimatedCompletion: "2024-01-19",
//     status: "in-progress",
//     priority: "high",
//     internalNotes: [],
//   },
// ];

// function WorkAssignmentPage() {
//   const router = useRouter();
//   const [currentPage, setCurrentPage] = useState(1);
//   const [assignments, setAssignments] =
//     useState<WorkAssignment[]>(workAssignmentsData);
//   const [searchTerm, setSearchTerm] = useState("");
//   const [statusFilter, setStatusFilter] = useState("all");
//   const [technicianFilter, setTechnicianFilter] = useState("all");
//   const [priorityFilter, setPriorityFilter] = useState("all");
//   const [showFilterSidebar, setShowFilterSidebar] = useState(true);
//   const dropdownRef = useRef<HTMLDivElement>(null);
//   const itemsPerPage = 10;

//   const [showFilterDropdown, setShowFilterDropdown] = useState(false);

//   // Close dropdown when clicking outside
//   useEffect(() => {
//     const handleClickOutside = (event: MouseEvent) => {
//       if (
//         dropdownRef.current &&
//         !dropdownRef.current.contains(event.target as Node)
//       ) {
//         setShowFilterDropdown(false);
//       }
//     };

//     document.addEventListener("mousedown", handleClickOutside);
//     return () => {
//       document.removeEventListener("mousedown", handleClickOutside);
//     };
//   }, []);
//   // const fetchJobCards = async () => {
//   //   try {
//   //     setLoading(true);
//   //     const token = localStorage.getItem("token");

//   //     if (!token) {
//   //       toast.error("Authentication required. Please login again.");
//   //       router.push("/login");
//   //       return;
//   //     }

//   //     const response = await fetch("/api/jobcards", {
//   //       method: "GET",
//   //       headers: {
//   //         // Authorization: `Bearer ${token}`,
//   //         // authorizations: state?.accessToken ?? "",
//   //         Authorization: `Bearer ${
//   //           state?.accessToken || localStorage.getItem("token")
//   //         }`,
//   //         "Content-Type": "application/json",
//   //       },
//   //     });

//   //     if (!response.ok) {
//   //       throw new Error(`API error: ${response.status}`);
//   //     }

//   //     const data = await response.json();

//   //     if (data.data && Array.isArray(data.data)) {
//   //       setJobCards(data.data);
//   //     } else {
//   //       toast.error("Invalid data format received from API");
//   //       setJobCards([]);
//   //     }
//   //   } catch (error: any) {
//   //     console.error("Error fetching customers:", error);
//   //     toast.error(`Failed to load customers: ${error.message}`);
//   //     setJobCards([]);
//   //   } finally {
//   //     setLoading(false);
//   //   }
//   // };
//   // Toggle filter dropdown
//   const toggleFilterDropdown = () => {
//     setShowFilterDropdown(!showFilterDropdown);
//   };

//   // Filter assignments (keep your existing filter logic)
//   const filteredAssignments = assignments.filter((assignment) => {
//     const matchesSearch =
//       assignment.jobCardNumber
//         .toLowerCase()
//         .includes(searchTerm.toLowerCase()) ||
//       assignment.vehicleNumber
//         .toLowerCase()
//         .includes(searchTerm.toLowerCase()) ||
//       assignment.vehicleModel
//         .toLowerCase()
//         .includes(searchTerm.toLowerCase()) ||
//       assignment.reportedIssue.toLowerCase().includes(searchTerm.toLowerCase());

//     const matchesStatus =
//       statusFilter === "all" || assignment.status === statusFilter;
//     const matchesTechnician =
//       technicianFilter === "all" ||
//       assignment.technicianId.toString() === technicianFilter;
//     const matchesPriority =
//       priorityFilter === "all" || assignment.priority === priorityFilter;

//     return (
//       matchesSearch && matchesStatus && matchesTechnician && matchesPriority
//     );
//   });

//   // Pagination
//   const totalPages = Math.ceil(filteredAssignments.length / itemsPerPage);
//   const paginatedAssignments = filteredAssignments.slice(
//     (currentPage - 1) * itemsPerPage,
//     currentPage * itemsPerPage
//   );

//   // Status badge render function
//   const renderStatusBadge = (status: string) => {
//     const statusConfig = {
//       pending: { class: "badge-light-warning", label: "Pending" },
//       "in-progress": { class: "badge-light-primary", label: "In Progress" },
//       completed: { class: "badge-light-success", label: "Completed" },
//       cancelled: { class: "badge-light-secondary", label: "Cancelled" },
//     };

//     const config = statusConfig[status as keyof typeof statusConfig] || {
//       class: "badge-light-secondary",
//       label: status,
//     };

//     return <span className={`badge ${config.class}`}>{config.label}</span>;
//   };

//   // Priority badge render function
//   const renderPriorityBadge = (priority: string) => {
//     const priorityConfig = {
//       low: { class: "badge-light-primary", label: "Low" },
//       medium: { class: "badge-light-warning", label: "Medium" },
//       high: { class: "badge-light-danger", label: "High" },
//       urgent: { class: "badge-light-danger", label: "Urgent" },
//     };

//     const config = priorityConfig[priority as keyof typeof priorityConfig] || {
//       class: "badge-light-secondary",
//       label: priority,
//     };

//     return <button className={`btn ${config.class}`}>{config.label}</button>;
//   };

//   // Get technician avatar or initial
//   const getTechnicianDisplay = (technicianName: string) => {
//     const technician = techniciansData.find((t) => t.name === technicianName);
//     if (!technician) return null;

//     return (
//       <div
//         className="common-circle bg-lighter-primary"
//         data-bs-toggle="tooltip"
//         data-bs-placement="top"
//         data-bs-title={technicianName}
//       >
//         {technicianName.charAt(0)}
//       </div>
//     );
//   };

//   // Performance metrics
//   const getPerformanceMetrics = () => {
//     const totalAssignments = assignments.length;
//     const completedAssignments = assignments.filter(
//       (a) => a.status === "completed"
//     ).length;
//     const inProgressAssignments = assignments.filter(
//       (a) => a.status === "in-progress"
//     ).length;
//     const pendingAssignments = assignments.filter(
//       (a) => a.status === "pending"
//     ).length;

//     return {
//       totalAssignments,
//       completedAssignments,
//       inProgressAssignments,
//       pendingAssignments,
//     };
//   };

//   const metrics = getPerformanceMetrics();

//   const resetFilters = () => {
//     setSearchTerm("");
//     setStatusFilter("all");
//     // setJobTypeFilter("all");
//     setTechnicianFilter("all");
//     setPriorityFilter("all");
//     setCurrentPage(1);
//   };
//   return (
//     <div className="page-body">
//       {/* <div className="container-fluid">
//         <div className="page-title">
//           <div className="row">
//             <div className="col-sm-6">
//               <h3>Work Assignment</h3>
//             </div>
//             <div className="col-sm-6">
//               <ol className="breadcrumb">
//                 <li className="breadcrumb-item">
//                   <Link href="/admin">
//                     <svg className="stroke-icon">
//                       <use href="../assets/svg/icon-sprite.svg#stroke-home"></use>
//                     </svg>
//                   </Link>
//                 </li>
//                 <li className="breadcrumb-item">Dashboard</li>
//                 <li className="breadcrumb-item active">Work Assignment</li>
//               </ol>
//             </div>
//           </div>
//         </div>
//       </div> */}
//       <Breadcrumbs
//         title="Work Assignment"
//         mainTitle="Work Assignment"
//         parent="Dashboard"
//       />
//       <Container fluid>
//         <Row>
//           <Col sm={12}>
//             {/* <div className="container-fluid main-tasks"> */}
//             <div className="email-wrap bookmark-wrap">
//               <div className="row main-bookmark">
//                 {/* Filter Dropdown */}
//                 <div
//                   className="d-flex align-items-center justify-content-start gap-2 mb-3 position-relative"
//                   ref={dropdownRef}
//                 >
//                   <button
//                     className="btn btn-primary dropdown-toggle"
//                     onClick={toggleFilterDropdown}
//                     type="button"
//                   >
//                     <i className="fa fa-filter me-2"></i>
//                     Task Filter
//                   </button>

//                   {showFilterDropdown && (
//                     <div className="filter-dropdown-panel card shadow-sm p-3 position-absolute top-100 start-0 mt-2 z-3">
//                       <div className="email-left-aside">
//                         <div>
//                           {/* Technician info */}
//                           <div className="d-flex flex-column align-items-center mb-3 text-center">
//                             <div className="media-size-email mb-2">
//                               <img
//                                 className="rounded-circle"
//                                 src="../assets/images/user/user.png"
//                                 alt="Technician"
//                                 width={60}
//                                 height={60}
//                               />
//                             </div>
//                             <h6 className="mb-1 text-muted">
//                               TECHNICIAN MANAGER
//                             </h6>
//                             <p className="mb-0">manager@garage.com</p>
//                           </div>

//                           <div className="col-12 mb-3">
//                             <button className="new-task-btn w-100">
//                               <Link href="/admin/work/create">New Task</Link>
//                             </button>
//                           </div>

//                           {/* Filters */}
//                           <form
//                             className="row g-3 needs-validation text-muted"
//                             noValidate
//                             style={{ fontSize: "0.8rem" }}
//                           >
//                             <div className="col-12 text-muted">
//                               <label className="form-label">Task Status</label>
//                               <select
//                                 className="form-select p-2 border"
//                                 value={statusFilter}
//                                 onChange={(e) =>
//                                   setStatusFilter(e.target.value)
//                                 }
//                                 style={{ fontSize: "0.8rem" }}
//                               >
//                                 <option value="all">All Status</option>
//                                 <option value="pending">Pending</option>
//                                 <option value="in-progress">In Progress</option>
//                                 <option value="completed">Completed</option>
//                                 <option value="cancelled">Cancelled</option>
//                               </select>
//                             </div>

//                             <div className="col-12">
//                               <label className="form-label">
//                                 Task Importance
//                               </label>
//                               <select
//                                 className="form-select p-2 border"
//                                 style={{ fontSize: "0.8rem" }}
//                                 value={priorityFilter}
//                                 onChange={(e) =>
//                                   setPriorityFilter(e.target.value)
//                                 }
//                               >
//                                 <option value="all">All Priority</option>
//                                 <option value="low">Low</option>
//                                 <option value="medium">Medium</option>
//                                 <option value="high">High</option>
//                                 <option value="urgent">Urgent</option>
//                               </select>
//                             </div>

//                             <div className="col-12">
//                               <label className="form-label">
//                                 Assigned Technician
//                               </label>
//                               <select
//                                 className="form-select p-2 border"
//                                 style={{ fontSize: "0.8rem" }}
//                                 value={technicianFilter}
//                                 onChange={(e) =>
//                                   setTechnicianFilter(e.target.value)
//                                 }
//                               >
//                                 <option value="all">All Technicians</option>
//                                 {techniciansData.map((tech) => (
//                                   <option
//                                     key={tech.id}
//                                     value={tech.id.toString()}
//                                   >
//                                     {tech.name}
//                                   </option>
//                                 ))}
//                               </select>
//                             </div>
//                           </form>

//                           {/* Stats */}
//                           <div className="row task-stats gap-3 mt-3">
//                             <div className="col-12">
//                               <div className="common-align">
//                                 <div className="bg-primary me-2 p-2 rounded">
//                                   <i
//                                     className="icofont icofont-tasks-alt"
//                                     style={{ fontSize: "24px" }}
//                                   ></i>
//                                 </div>
//                                 <div>
//                                   <span className="c-o-light">
//                                     Today's Assignments
//                                   </span>
//                                   <h4 className="mb-0 text-muted">
//                                     {
//                                       assignments.filter(
//                                         (a) =>
//                                           new Date(
//                                             a.assignedDate
//                                           ).toDateString() ===
//                                           new Date().toDateString()
//                                       ).length
//                                     }
//                                   </h4>
//                                 </div>
//                               </div>
//                             </div>

//                             <div className="col-12">
//                               <div className="common-align">
//                                 <div className="bg-primary me-2 p-2 rounded">
//                                   <i
//                                     className="icofont icofont-hour-glass"
//                                     style={{ fontSize: "24px" }}
//                                   ></i>
//                                 </div>
//                                 <div>
//                                   <span className="c-o-light">In Progress</span>
//                                   <h4 className="mb-0 text-muted">
//                                     {metrics.inProgressAssignments}
//                                   </h4>
//                                 </div>
//                               </div>
//                             </div>

//                             <div className="col-12">
//                               <div className="common-align">
//                                 <div className="bg-primary me-2 p-2 rounded">
//                                   <i
//                                     className="icofont icofont-history"
//                                     style={{ fontSize: "24px" }}
//                                   ></i>
//                                 </div>
//                                 <div>
//                                   <span className="c-o-light">
//                                     Pending Review
//                                   </span>
//                                   <h4 className="mb-0 text-muted">
//                                     {metrics.pendingAssignments}
//                                   </h4>
//                                 </div>
//                               </div>
//                             </div>
//                           </div>
//                         </div>
//                       </div>
//                     </div>
//                   )}

//                   <div>
//                     <Button color="secondary" onClick={resetFilters}>
//                       <i className="fa fa-refresh me-2"></i>
//                       Reset Filters
//                     </Button>
//                   </div>
//                 </div>

//                 {/* Main Content */}
//                 <div className="col-xxl-12 col-md-12 box-col-12">
//                   <div className="card heading-space">
//                     <div className="card-header card-no-border">
//                       <div className="header-top">
//                         <h5 className="d-flex align-items-center justify-content-between">
//                           Work Assignments /Technician Management
//                         </h5>
//                       </div>
//                     </div>

//                     <div className="card-body px-0 pt-0 common-task-table">
//                       <div className="table-responsive custom-scrollbar">
//                         <Table hover className="table mb-0">
//                           <thead>
//                             <tr>
//                               <th>Job Card</th>
//                               <th>Vehicle</th>
//                               <th>Task Details</th>
//                               <th>Due Date</th>
//                               <th>Assign To</th>
//                               <th>Status</th>
//                               <th>Importance</th>
//                               <th>Actions</th>
//                             </tr>
//                           </thead>
//                           <tbody>
//                             {paginatedAssignments.length === 0 ? (
//                               <tr>
//                                 <td colSpan={8} className="text-center py-4">
//                                   No assignments found
//                                 </td>
//                               </tr>
//                             ) : (
//                               paginatedAssignments.map((assignment) => (
//                                 <tr key={assignment.id}>
//                                   <td className="no-wrap">
//                                     <strong className="text-primary">
//                                       {assignment.jobCardNumber}
//                                     </strong>
//                                   </td>
//                                   <td>
//                                     <div>
//                                       <div>{assignment.vehicleNumber}</div>
//                                       <small className="text-muted">
//                                         {assignment.vehicleModel}
//                                       </small>
//                                     </div>
//                                   </td>
//                                   <td>
//                                     <span>{assignment.reportedIssue}</span>
//                                   </td>
//                                   <td>
//                                     {new Date(
//                                       assignment.estimatedCompletion
//                                     ).toLocaleDateString()}
//                                   </td>
//                                   <td>
//                                     <ul className="common-f-start">
//                                       <li
//                                         data-bs-toggle="tooltip"
//                                         data-bs-placement="top"
//                                         data-bs-title={
//                                           assignment.assignedTechnician
//                                         }
//                                       >
//                                         {getTechnicianDisplay(
//                                           assignment.assignedTechnician
//                                         )}
//                                       </li>
//                                     </ul>
//                                   </td>
//                                   <td>
//                                     {renderStatusBadge(assignment.status)}
//                                   </td>
//                                   <td>
//                                     {renderPriorityBadge(assignment.priority)}
//                                   </td>
//                                   <td>
//                                     <div className="d-flex gap-1">
//                                       <button
//                                         color="primary"
//                                         className="action-btn text-white border btn-primary"
//                                         // onClick={() => router.push(`/admin/work/${assignment.id}`)}
//                                         title="View"
//                                       >
//                                         <i className="fa fa-eye"></i>
//                                       </button>
//                                       <button
//                                         color="warning"
//                                         className="action-btn text-white border btn-warning"
//                                         // onClick={() => router.push(`/admin/work/${assignment.id}/edit`)}
//                                         title="Edit"
//                                       >
//                                         <i className="fa fa-edit"></i>
//                                       </button>
//                                     </div>
//                                   </td>
//                                 </tr>
//                               ))
//                             )}
//                           </tbody>
//                         </Table>
//                       </div>

//                       {/* Pagination */}
//                       <div className="d-flex flex-column flex-md-row justify-content-between align-items-center gap-3 mt-4 px-3">
//                         <div className="text-center text-md-start text-muted">
//                           Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
//                           {Math.min(
//                             currentPage * itemsPerPage,
//                             filteredAssignments.length
//                           )}{" "}
//                           of {filteredAssignments.length} entries
//                         </div>
//                         <CustomPagination
//                           currentPage={currentPage}
//                           totalPages={totalPages}
//                           onPageChange={setCurrentPage}
//                           showFirstLast={true}
//                           maxVisiblePages={5}
//                           paginationType="primary"
//                           className="justify-content-center justify-content-md-end"
//                         />
//                       </div>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//             </div>
//             {/* </div> */}
//           </Col>
//         </Row>
//       </Container>
//       <style jsx global>{`
//         .main-tasks {
//           padding: 20px 0;
//         }

//         .new-task-btn {
//           display: inline-block;
//           padding: 0.5rem 1rem;
//           color: #5c5ff6;
//           border-color: transparent;
//           border-radius: 0.25rem;
//           text-decoration: none;
//           text-align: left;
//           background-color: #7366ff26;
//           transition: all 0.2s;
//         }

//         .new-task-btn:hover,
//         .new-task-btn:focus {
//           color: #5c5ff6;
//           border-color: #7366ff75;
//           background-color: #7366ff26;
//           text-decoration: none;
//         }

//         .email-left-aside .card {
//           border: 1px solid #e6edef;
//           box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
//         }

//         .task-sidebar .common-flex {
//           padding: 20px;
//           border-bottom: 1px solid #e6edef;
//         }

//         .media-size-email img {
//           width: 50px;
//           height: 50px;
//         }

//         .badge-light-primary {
//           background-color: rgba(92, 95, 246, 0.1);
//           color: #5c5ff6;
//         }

//         .btn-mail {
//           border: none;
//           padding: 10px 15px;
//           text-align: left;
//           width: 100%;
//         }

//         .common-align {
//           display: flex;
//           align-items: center;
//           gap: 15px;
//         }

//         .common-align .bg-primary {
//           width: 40px;
//           height: 40px;
//           border-radius: 50%;
//           display: flex;
//           align-items: center;
//           justify-content: center;
//           background-color: #5c5ff6 !important;
//           color: white;
//         }

//         .c-o-light {
//           color: #8c8c8c;
//           font-size: 12px;
//         }

//         .common-f-start {
//           display: flex;
//           gap: 5px;
//           padding: 0;
//           margin: 0;
//           list-style: none;
//         }

//         .common-circle {
//           width: 35px;
//           height: 35px;
//           border-radius: 50%;
//           display: flex;
//           align-items: center;
//           justify-content: center;
//           font-weight: bold;
//           color: white;
//         }

//         .bg-lighter-primary {
//           background-color: #5c5ff6;
//         }

//         /* Filter Dropdown Styles */
//         .filter-dropdown-panel {
//           width: 320px;
//           margin-left: 1rem;
//           max-height: 80vh;
//           overflow-y: auto;
//           z-index: 1000;
//           background: white;
//         }

//         /* Mobile responsive adjustments */
//         @media (max-width: 576px) {
//           .filter-dropdown-panel {
//             width: 280px;
//             left: 0 !important; /* keep it aligned to the left */
//             right: auto !important;
//           }
//         }

//         @media (max-width: 360px) {
//           .filter-dropdown-panel {
//             width: 260px;
//             left: 0 !important; /* keep it aligned to the left */
//             right: auto !important;
//           }
//         }

//         .heading-space .card-header {
//           padding: 20px;
//         }

//         .common-task-table .table {
//           margin-bottom: 0;
//         }

//         .common-task-table .table th {
//           border-top: none;
//           font-weight: 600;
//           color: #495057;
//         }

//         .z-3 {
//           z-index: 3;
//         }

//         @media (max-width: 768px) {
//           .main-bookmark {
//             flex-direction: column;
//           }

//           .box-col-6 {
//             margin-bottom: 20px;
//           }
//         }
//       `}</style>
//     </div>
//   );
// }

// // export default WorkAssignmentPage;
// export default withAuth(WorkAssignmentPage, ["admin"]);

"use client";
import Breadcrumbs from "@/CommonElements/Breadcrumbs";
import CustomPagination from "@/CommonElements/Pagination";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  Input,
  Button,
  Table,
  Badge,
  Spinner,
  Alert,
  Dropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  FormGroup,
  Label,
} from "reactstrap";
import React, { useState, ChangeEvent, useEffect, useRef } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import withAuth from "@/helper/WithAuth";
import { toast } from "react-toastify";
import { useAuth } from "@/helper/AuthContext";

interface Technician {
  id: string;
  username: string;
  fullName?: string;
  email?: string;
  specialization?: string;
  status?: "available" | "busy" | "offline";
}

interface InternalNote {
  id: number;
  author: string;
  content: string;
  timestamp: string;
  type: "update" | "issue" | "resolution";
}

interface JobCard {
  id: string;
  job_number: string;
  customer_id: string;
  vehicle_id: string;
  created_by: string;
  assigned_to: string | null;
  status: "open" | "in-progress" | "completed" | "closed" | "cancelled";
  reported_issue: string;
  diagnosis: string | null;
  labor_estimate: string;
  parts_estimate: string;
  total_estimate: string;
  priority: string;
  expected_completion: string;
  actual_completion: string | null;
  is_paid: string;
  meta: string;
  created_at: string;
  updated_at: string;
  customer_name: string;
  registration_number: string;
  created_by_user: string | null;
  assigned_to_user: string | null;
  model: string;
  vehicleModel?: string;
}

function WorkAssignmentPage() {
  const { state } = useAuth();
  const router = useRouter();
  const [currentPage, setCurrentPage] = useState(1);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [technicianFilter, setTechnicianFilter] = useState("all");
  const [priorityFilter, setPriorityFilter] = useState("all");
  const dropdownRef = useRef<HTMLDivElement>(null);
  const itemsPerPage = 10;
  const [jobCards, setJobCards] = useState<JobCard[]>([]);
  const [filteredJobs, setFilteredJobs] = useState<JobCard[]>([]);
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState<string | null>(null);
  const [showFilterDropdown, setShowFilterDropdown] = useState(false);
  const [technicians, setTechnicians] = useState<Technician[]>([]);
  const [workNotes, setWorkNotes] = useState<{ [key: string]: string }>({});
  const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState("");
  const [alertType, setAlertType] = useState<"success" | "danger">("success");

  const [technicianSearchTerm, setTechnicianSearchTerm] = useState("");
  const [isTechnicianDropdownOpen, setIsTechnicianDropdownOpen] =
    useState(false);
  const [selectedTechnicianId, setSelectedTechnicianId] = useState<string>("");
  const [selectedTechnicianName, setSelectedTechnicianName] = useState("");
  const technicianDropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node)
      ) {
        setShowFilterDropdown(false);
      }
      if (
        technicianDropdownRef.current &&
        !technicianDropdownRef.current.contains(event.target as Node)
      ) {
        setIsTechnicianDropdownOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  // Fetch job cards
  const fetchJobCards = async () => {
    try {
      setLoading(true);
      const token = state?.accessToken || localStorage.getItem("token");

      if (!token) {
        toast.error("Authentication required. Please login again.");
        router.push("/login");
        return;
      }

      const response = await fetch("/api/jobcards", {
        method: "GET",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }

      const data = await response.json();

      if (data.data && Array.isArray(data.data)) {
        const jobsWithTechnicians = data.data.filter(
          (job: any) =>
            job.assigned_to &&
            job.assigned_to !== null &&
            job.assigned_to !== ""
        );
        // setJobCards(data.data);
        setJobCards(jobsWithTechnicians);
        setFilteredJobs(jobsWithTechnicians);
      } else {
        toast.error("Invalid data format received from API");
        setJobCards([]);
        // setFilteredJobs([]);
      }
    } catch (error: any) {
      console.error("Error fetching job cards:", error);
      toast.error(`Failed to load job cards: ${error.message}`);
      setJobCards([]);
    } finally {
      setLoading(false);
    }
  };

  // Fetch technicians
  const fetchTechnicians = async () => {
    try {
      const token = state?.accessToken || localStorage.getItem("token");
      const response = await fetch("/api/technicians_list", {
        method: "GET",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error("Failed to fetch technicians");
      }

      const data = await response.json();
      setTechnicians(data.data || []);
    } catch (err: any) {
      console.error("Error fetching technicians:", err);
      toast.error("Failed to load technicians");
    }
  };

  useEffect(() => {
    fetchJobCards();
    fetchTechnicians();
  }, []);

  // Toggle filter dropdown
  const toggleFilterDropdown = () => {
    setShowFilterDropdown(!showFilterDropdown);
  };

  // Filter job cards
  const filteredAssignments = jobCards.filter((assignment) => {
    const matchesSearch =
      assignment.job_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
      assignment.registration_number
        .toLowerCase()
        .includes(searchTerm.toLowerCase()) ||
      assignment.customer_name
        .toLowerCase()
        .includes(searchTerm.toLowerCase()) ||
      assignment.reported_issue
        .toLowerCase()
        .includes(searchTerm.toLowerCase());

    const matchesStatus =
      statusFilter === "all" || assignment.status === statusFilter;

    const matchesTechnician =
      technicianFilter === "all" ||
      (technicianFilter === "unassigned" && !assignment.assigned_to) ||
      assignment.assigned_to === technicianFilter;

    const matchesPriority =
      priorityFilter === "all" ||
      (priorityFilter === "high" && ["1", "2"].includes(assignment.priority)) ||
      (priorityFilter === "medium" && assignment.priority === "3") ||
      (priorityFilter === "low" && ["4", "5"].includes(assignment.priority));

    return (
      matchesSearch && matchesStatus && matchesTechnician && matchesPriority
    );
  });

  const filteredTechnicians = technicians.filter((technician) =>
    technician.username
      .toLowerCase()
      .includes(technicianSearchTerm.toLowerCase())
  );

  const handleTechnicianSelect = (id: string, username: string) => {
    setSelectedTechnicianId(id);
    setSelectedTechnicianName(username);
    setIsTechnicianDropdownOpen(false);
    setTechnicianSearchTerm("");
  };

  // Pagination
  const totalPages = Math.ceil(filteredAssignments.length / itemsPerPage);
  const paginatedAssignments = filteredAssignments.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  // Status badge render function
  const renderStatusBadge = (status: string) => {
    const statusConfig: Record<string, { class: string; label: string }> = {
      open: { class: "badge-light-warning", label: "open" },
      in_progress: { class: "badge-light-primary", label: "In Progress" },
      completed: { class: "badge-light-success", label: "Completed" },
      // closed: { class: "badge-light-success", label: "Closed" },
      cancelled: { class: "badge-light-secondary", label: "Cancelled" },
    };

    const config = statusConfig[status] || {
      class: "badge-light-secondary",
      label: status,
    };

    return <span className={`badge ${config.class}`}>{config.label}</span>;
  };

  // Priority badge render function
  const renderPriorityBadge = (priority: string) => {
    const priorityConfig: Record<string, { class: string; label: string }> = {
      "1": { class: "badge-light-danger", label: "Urgent" },
      "2": { class: "badge-light-danger", label: "High" },
      "3": { class: "badge-light-warning", label: "Medium" },
      "4": { class: "badge-light-primary", label: "Low" },
      "5": { class: "badge-light-info", label: "Very Low" },
    };

    const config = priorityConfig[priority] || {
      class: "badge-light-secondary",
      label: `Priority ${priority}`,
    };

    return <span className={`badge ${config.class}`}>{config.label}</span>;
  };

  // Performance metrics
  const getPerformanceMetrics = () => {
    const totalAssignments = jobCards.length;
    const completedAssignments = jobCards.filter(
      (a) => a.status === "completed" || a.status === "closed"
    ).length;
    const inProgressAssignments = jobCards.filter(
      (a) => a.status === "in-progress"
    ).length;
    const pendingAssignments = jobCards.filter(
      (a) => a.status === "open"
    ).length;

    return {
      totalAssignments,
      completedAssignments,
      inProgressAssignments,
      pendingAssignments,
    };
  };

  const metrics = getPerformanceMetrics();

  const resetFilters = () => {
    setSearchTerm("");
    setStatusFilter("all");
    setTechnicianFilter("all");
    setPriorityFilter("all");
    setCurrentPage(1);
  };

  // Format date
  const formatDate = (dateString: string) => {
    if (!dateString || dateString === "0000-00-00 00:00:00") {
      return "Not set";
    }
    try {
      return new Date(dateString).toLocaleDateString();
    } catch {
      return "Invalid date";
    }
  };

  // Get today's assignments count
  const getTodaysAssignments = () => {
    const today = new Date().toDateString();
    return jobCards.filter(
      (a) => new Date(a.created_at).toDateString() === today
    ).length;
  };

  return (
    <div className="page-body">
      <Breadcrumbs
        title="Work Assignment"
        mainTitle="Work Assignment"
        parent="Dashboard"
      />
      <Container fluid>
        {/* Alert */}
        {showAlert && (
          <Row>
            <Col sm={12}>
              <Alert
                color={alertType}
                isOpen={showAlert}
                toggle={() => setShowAlert(false)}
                className="mb-3"
              >
                {alertMessage}
              </Alert>
            </Col>
          </Row>
        )}

        <Row>
          <Col sm={12}>
            <div className="email-wrap bookmark-wrap">
              <div className="row main-bookmark">
                {/* Filter Dropdown */}
                <div
                  className="d-flex align-items-center justify-content-start gap-2 mb-3 position-relative flex-wrap"
                  ref={dropdownRef}
                >
                  <div className="position-relative">
                    <button
                      className="btn btn-primary dropdown-toggle"
                      onClick={toggleFilterDropdown}
                      type="button"
                    >
                      <i className="fa fa-filter me-2"></i>
                      Work Filters
                    </button>

                    {showFilterDropdown && (
                      <div className="filter-dropdown-panel card shadow-sm p-3 position-absolute top-100 start-0 mt-2 z-3">
                        <div className="email-left-aside">
                          <div>
                            <div className="d-flex flex-column align-items-center mb-3 text-center">
                              <div className="media-size-email mb-2">
                                <div
                                  className="common-circle bg-primary text-white d-flex align-items-center justify-content-center"
                                  style={{
                                    width: "60px",
                                    height: "60px",
                                    fontSize: "24px",
                                    margin: "0 auto",
                                  }}
                                >
                                  <i className="fa fa-user-cog"></i>
                                </div>
                              </div>
                              <h6 className="mb-1 text-muted">WORK MANAGER</h6>
                              <p className="mb-0">manager@garage.com</p>
                            </div>

                            <div className="row task-stats gap-3 mb-3">
                              <div className="col-12">
                                <div className="common-align">
                                  <div className="bg-primary me-2 p-2 rounded">
                                    <i className="icofont icofont-tasks-alt"></i>
                                  </div>
                                  <div>
                                    <span className="c-o-light">
                                      Today's Assignments
                                    </span>
                                    <h4 className="mb-0 text-muted">
                                      {getTodaysAssignments()}
                                    </h4>
                                  </div>
                                </div>
                              </div>

                              <div className="col-12">
                                <div className="common-align">
                                  <div className="bg-primary me-2 p-2 rounded">
                                    <i className="icofont icofont-hour-glass"></i>
                                  </div>
                                  <div>
                                    <span className="c-o-light">
                                      In Progress
                                    </span>
                                    <h4 className="mb-0 text-muted">
                                      {metrics.inProgressAssignments}
                                    </h4>
                                  </div>
                                </div>
                              </div>

                              <div className="col-12">
                                <div className="common-align">
                                  <div className="bg-primary me-2 p-2 rounded">
                                    <i className="icofont icofont-history"></i>
                                  </div>
                                  <div>
                                    <span className="c-o-light">
                                      Pending Review
                                    </span>
                                    <h4 className="mb-0 text-muted">
                                      {metrics.pendingAssignments}
                                    </h4>
                                  </div>
                                </div>
                              </div>
                            </div>

                            <form
                              className="row g-3 needs-validation text-muted"
                              noValidate
                            >
                              <Col md="12">
                                <FormGroup>
                                  <Label>Technician</Label>
                                  {loading && technicians.length === 0 ? (
                                    <div className="d-flex align-items-center">
                                      <Spinner size="sm" className="me-2" />
                                      Loading technicians...
                                    </div>
                                  ) : technicians.length === 0 ? (
                                    <div className="text-danger">
                                      No technicians found.
                                    </div>
                                  ) : (
                                    <div
                                      className="position-relative"
                                      ref={technicianDropdownRef}
                                    >
                                      <div
                                        onClick={() =>
                                          setIsTechnicianDropdownOpen(
                                            !isTechnicianDropdownOpen
                                          )
                                        }
                                        className="d-flex w-100 align-items-center justify-content-between cursor-pointer form-control border"
                                        style={{
                                          minHeight: "38px",
                                          padding: "0.375rem 0.75rem",
                                          cursor: "pointer",
                                        }}
                                      >
                                        <span
                                          className="text-truncate"
                                          style={{
                                            maxWidth: "calc(100% - 20px)",
                                          }}
                                        >
                                          {selectedTechnicianName ||
                                            "Select Technician"}
                                        </span>
                                        <span
                                          className="ms-2 text-muted"
                                          style={{ flexShrink: 0 }}
                                        >
                                          {isTechnicianDropdownOpen ? "▲" : "▼"}
                                        </span>
                                      </div>

                                      {isTechnicianDropdownOpen && (
                                        <div
                                          className="position-absolute w-100 mt-1 bg-white border rounded shadow"
                                          style={{
                                            maxHeight: "300px",
                                            overflow: "auto",
                                            zIndex: 1050,
                                          }}
                                        >
                                          <div className="p-2 border-bottom">
                                            <Input
                                              type="text"
                                              value={technicianSearchTerm}
                                              onChange={(e) => {
                                                setTechnicianSearchTerm(
                                                  e.target.value
                                                );
                                              }}
                                              placeholder="Search technicians..."
                                              className="form-control form-control-sm"
                                              autoFocus
                                              onClick={(e) =>
                                                e.stopPropagation()
                                              }
                                            />
                                          </div>

                                          <div
                                            style={{
                                              maxHeight: "200px",
                                              overflowY: "auto",
                                            }}
                                          >
                                            {filteredTechnicians.length > 0 ? (
                                              <ul className="list-unstyled mb-0">
                                                {filteredTechnicians.map(
                                                  (technician) => (
                                                    <li
                                                      key={technician.id}
                                                      onClick={() =>
                                                        handleTechnicianSelect(
                                                          technician.id,
                                                          technician.username
                                                        )
                                                      }
                                                      className="px-3 py-2 cursor-pointer hover-bg-light"
                                                      style={{
                                                        cursor: "pointer",
                                                        backgroundColor:
                                                          selectedTechnicianId ===
                                                          technician.id
                                                            ? "#f8f9fa"
                                                            : "transparent",
                                                      }}
                                                    >
                                                      <div className="d-flex align-items-center">
                                                        {technician.username}
                                                        {technician.fullName && (
                                                          <small className="text-muted ms-2">
                                                            (
                                                            {
                                                              technician.fullName
                                                            }
                                                            )
                                                          </small>
                                                        )}
                                                      </div>
                                                    </li>
                                                  )
                                                )}
                                              </ul>
                                            ) : (
                                              <div className="px-3 py-2 text-muted">
                                                {technicianSearchTerm
                                                  ? "No matching technician found"
                                                  : "No technicians available"}
                                              </div>
                                            )}
                                          </div>
                                        </div>
                                      )}
                                    </div>
                                  )}
                                </FormGroup>
                              </Col>
                              <div className="col-12">
                                <label className="form-label">
                                  Task Status
                                </label>
                                <select
                                  className="form-select p-2 border"
                                  value={statusFilter}
                                  onChange={(e) =>
                                    setStatusFilter(e.target.value)
                                  }
                                >
                                  <option value="all">All Status</option>
                                  <option value="open">Pending</option>
                                  <option value="in-progress">
                                    In Progress
                                  </option>
                                  <option value="completed">Completed</option>
                                </select>
                              </div>
                            </form>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  <div>
                    <Button color="secondary" onClick={resetFilters}>
                      <i className="fa fa-refresh me-2"></i>
                      Reset Filters
                    </Button>
                  </div>

                  <div className="flex-grow-1 ms-md-auto mt-2 mt-md-0">
                    <div className="input-group" style={{ maxWidth: "400px" }}>
                      <Input
                        type="text"
                        placeholder="Search job cards..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                      />
                      <Button color="primary">
                        <i className="fa fa-search"></i>
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Main Content */}
                <div className="col-xxl-12 col-md-12 box-col-12">
                  <div className="card heading-space">
                    <div className="card-header card-no-border">
                      <div className="header-top">
                        <h5 className="d-flex align-items-center justify-content-between">
                          Work Assignments / Technician Management
                          <span className="badge bg-primary">
                            {/* {filteredAssignments.length} Jobs */}
                          </span>
                        </h5>
                      </div>
                    </div>

                    <div className="card-body px-0 pt-0 common-task-table">
                      {loading ? (
                        <div className="text-center py-5">
                          <Spinner color="primary" />
                          <p className="mt-2">Loading work assignments...</p>
                        </div>
                      ) : (
                        <>
                          <div className="table-responsive custom-scrollbar">
                            <Table hover className="table mb-0">
                              <thead>
                                <tr>
                                  <th>#</th>
                                  <th>Job Card</th>
                                  <th>Customer</th>
                                  <th>Vehicle</th>
                                  <th>Issue</th>
                                  <th>Due Date</th>
                                  <th>Assigned To</th>
                                  <th>Status</th>
                                  {/* <th>Priority</th> */}
                                  <th>Actions</th>
                                </tr>
                              </thead>
                              <tbody>
                                {paginatedAssignments.length === 0 ? (
                                  <tr>
                                    <td
                                      colSpan={9}
                                      className="text-center py-4"
                                    >
                                      <div className="text-muted">
                                        <i className="fa fa-tasks fa-2x mb-2"></i>
                                        <p>No work assignments found</p>
                                        {filteredAssignments.length === 0 &&
                                          jobCards.length > 0 && (
                                            <small className="text-info">
                                              Try changing your filter criteria
                                            </small>
                                          )}
                                      </div>
                                    </td>
                                  </tr>
                                ) : (
                                  paginatedAssignments.map(
                                    (assignment, index) => (
                                      <tr key={assignment.id}>
                                        <td>
                                          {(currentPage - 1) * itemsPerPage +
                                            index +
                                            1}
                                        </td>
                                        <td className="no-wrap">
                                          <strong
                                            className="text-primary cursor-pointer"
                                            onClick={() =>
                                              router.push(
                                                `/admin/jobcards/${assignment.id}`
                                              )
                                            }
                                          >
                                            {assignment.job_number}
                                          </strong>
                                        </td>
                                        <td>{assignment.customer_name}</td>
                                        <td>
                                          <div>
                                            <div>
                                              {assignment.registration_number}
                                            </div>
                                            <small className="text-muted">
                                              {assignment.model || "N/A"}
                                            </small>
                                          </div>
                                        </td>
                                        <td>
                                          <div
                                            className="text-truncate"
                                            style={{ maxWidth: "200px" }}
                                          >
                                            {assignment.reported_issue}
                                          </div>
                                        </td>
                                        <td>
                                          {formatDate(
                                            assignment.expected_completion
                                          )}
                                        </td>
                                        <td>
                                          <div className="d-flex align-items-center gap-2">
                                            {/* {getTechnicianDisplay( */}
                                            {/* {assignment.assigned_to}, */}
                                            {assignment.assigned_to_user}
                                            {/* )} */}
                                          </div>
                                        </td>
                                        <td>
                                          {/* <div className="d-flex flex-column gap-1">
                                          {renderStatusBadge(assignment.status)}
                                          <div className="d-flex gap-1">
                                            {assignment.status === "open" && (
                                              <button
                                                className="btn btn-sm btn-warning"
                                                onClick={() =>
                                                  updateWorkStatus(
                                                    assignment.id,
                                                    "in-progress"
                                                  )
                                                }
                                                disabled={
                                                  updating === assignment.id ||
                                                  !assignment.assigned_to
                                                }
                                                title={
                                                  !assignment.assigned_to
                                                    ? "Assign a technician first"
                                                    : "Start work"
                                                }
                                              >
                                                {updating === assignment.id ? (
                                                  <Spinner size="sm" />
                                                ) : (
                                                  "Start"
                                                )}
                                              </button>
                                            )}
                                            {assignment.status ===
                                              "in-progress" && (
                                              <button
                                                className="btn btn-sm btn-success"
                                                onClick={() =>
                                                  updateWorkStatus(
                                                    assignment.id,
                                                    "completed"
                                                  )
                                                }
                                                disabled={
                                                  updating === assignment.id
                                                }
                                              >
                                                {updating === assignment.id ? (
                                                  <Spinner size="sm" />
                                                ) : (
                                                  "Complete"
                                                )}
                                              </button>
                                            )}
                                          </div>
                                        </div> */}
                                          {renderStatusBadge(assignment.status)}
                                        </td>
                                        {/* <td>
                                        {renderPriorityBadge(
                                          assignment.priority
                                        )}
                                      </td> */}
                                        <td>
                                          <div className="d-flex gap-1">
                                            <button
                                              className="action-btn text-white border btn-primary"
                                              onClick={() =>
                                                router.push(
                                                  `/admin/work/${assignment.id}`
                                                )
                                              }
                                              title="View"
                                            >
                                              <i className="fa fa-eye"></i>
                                            </button>
                                            {/* <button
                                            className="action-btn text-white border btn-warning"
                                            onClick={() =>
                                              router.push(
                                                `/admin/jobcards/create?id=${assignment.id}`
                                              )
                                            }
                                            title="Edit"
                                          >
                                            <i className="fa fa-edit"></i>
                                          </button> */}
                                          </div>
                                        </td>
                                      </tr>
                                    )
                                  )
                                )}
                              </tbody>
                            </Table>
                          </div>

                          {/* Pagination */}
                          <div className="d-flex flex-column flex-md-row justify-content-between align-items-center gap-3 mt-4 px-3">
                            <div className="text-center text-md-start text-muted">
                              Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
                              {Math.min(
                                currentPage * itemsPerPage,
                                filteredAssignments.length
                              )}{" "}
                              of {filteredAssignments.length} entries
                            </div>
                            <CustomPagination
                              currentPage={currentPage}
                              totalPages={totalPages}
                              onPageChange={setCurrentPage}
                              showFirstLast={true}
                              maxVisiblePages={5}
                              paginationType="primary"
                              className="justify-content-center justify-content-md-end"
                            />
                          </div>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Col>
        </Row>
      </Container>
      <style jsx global>{`
        .main-tasks {
          padding: 20px 0;
        }

        .email-left-aside .card {
          border: 1px solid #e6edef;
          box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
        }

        .badge-light-primary {
          background-color: rgba(92, 95, 246, 0.1);
          color: #5c5ff6;
        }

        .badge-light-warning {
          background-color: rgba(255, 193, 7, 0.1);
          color: #ffc107;
        }

        .badge-light-success {
          background-color: rgba(40, 167, 69, 0.1);
          color: #28a745;
        }

        .badge-light-danger {
          background-color: rgba(220, 53, 69, 0.1);
          color: #dc3545;
        }

        .badge-light-secondary {
          background-color: rgba(108, 117, 125, 0.1);
          color: #6c757d;
        }

        .badge-light-info {
          background-color: rgba(23, 162, 184, 0.1);
          color: #17a2b8;
        }

        .common-align {
          display: flex;
          align-items: center;
          gap: 15px;
        }

        .common-align .bg-primary {
          width: 40px;
          height: 40px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          background-color: #5c5ff6 !important;
          color: white;
        }

        .c-o-light {
          color: #8c8c8c;
          font-size: 12px;
        }

        .common-circle {
          width: 35px;
          height: 35px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: bold;
          color: white;
        }

        .bg-lighter-primary {
          background-color: #5c5ff6;
        }

        /* Filter Dropdown Styles */
        .filter-dropdown-panel {
          width: 320px;
          margin-left: 1rem;
          max-height: 80vh;
          overflow-y: auto;
          z-index: 1050;
          background: white;
        }

        /* Mobile responsive adjustments */
        @media (max-width: 576px) {
          .filter-dropdown-panel {
            width: 280px;
            left: 0 !important;
            right: auto !important;
          }
        }

        @media (max-width: 360px) {
          .filter-dropdown-panel {
            width: 260px;
            left: 0 !important;
            right: auto !important;
          }
        }

        .heading-space .card-header {
          padding: 20px;
        }

        .common-task-table .table {
          margin-bottom: 0;
        }

        .common-task-table .table th {
          border-top: none;
          font-weight: 600;
          color: #495057;
        }

        .z-3 {
          z-index: 3;
        }

        @media (max-width: 768px) {
          .main-bookmark {
            flex-direction: column;
          }

          .box-col-6 {
            margin-bottom: 20px;
          }
        }

        .no-wrap {
          white-space: nowrap;
        }

        .text-truncate {
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        .cursor-pointer {
          cursor: pointer;
        }

        .action-btn {
          padding: 0.25rem 0.5rem;
          font-size: 0.875rem;
          border-radius: 0.25rem;
        }

        /* Custom scrollbar */
        .custom-scrollbar {
          max-height: 600px;
          overflow-y: auto;
        }

        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }

        .custom-scrollbar::-webkit-scrollbar-track {
          background: #f1f1f1;
        }

        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #888;
          border-radius: 3px;
        }

        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #555;
        }
      `}</style>
    </div>
  );
}

export default withAuth(WorkAssignmentPage, ["admin", "technician"]);
