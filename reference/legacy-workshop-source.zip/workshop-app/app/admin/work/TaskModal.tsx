// "use client";

// import React, { useState, useEffect } from "react";
// import {
//   Button,
//   Spinner,
//   Input,
//   Label,
//   Badge,
//   Row,
//   Col,
//   Modal,
//   ModalHeader,
//   ModalBody,
//   ModalFooter,
// } from "reactstrap";
// import { Close, SaveChanges } from "@/utils/Constant";

// // Types - Make sure this matches exactly with the interface in page.tsx
// interface JobCardItem {
//   id: string;
//   job_card_id: string;
//   sequence: string;
//   description: string;
//   labor_hours: string;
//   labor_rate: string;
//   amount: string;
//   status: string;
//   assigned_to: string | null;
//   notes: string | null;
//   created_at: string;
//   updated_at: string;
// }

// interface TaskModalProps {
//   isOpen: boolean;
//   toggle: () => void;
//   task: JobCardItem | null;
//   onUpdate: (taskId: string, status: string, notes: string) => Promise<void>;
//   loading?: boolean;
//   modalTitle?: string;
//   modalClass?: string;
//   modalSize?: string;
//   showFooter?: boolean;
// }

// const TaskModal: React.FC<TaskModalProps> = ({
//   isOpen,
//   toggle,
//   task,
//   onUpdate,
//   loading = false,
//   modalTitle,
//   modalClass,
//   modalSize = "md",
//   showFooter = true,
// }) => {
//   const [notes, setNotes] = useState<string>("");
//   const [selectedStatus, setSelectedStatus] = useState<string>("");
//   const [isSubmitting, setIsSubmitting] = useState(false);

//   // Reset form when task changes
//   useEffect(() => {
//     if (task) {
//       setNotes(task.notes || "");
//       setSelectedStatus(task.status);
//     }
//   }, [task]);

//   const handleSubmit = async () => {
//     if (!task || !selectedStatus) return;

//     setIsSubmitting(true);
//     try {
//       await onUpdate(task.id, selectedStatus, notes);
//       // Modal will close on successful update
//     } catch (error) {
//       console.error("Error updating task:", error);
//       // Don't close modal on error
//       setIsSubmitting(false);
//       return; // Keep modal open on error
//     }
//     setIsSubmitting(false);
//   };

//   const getStatusLabel = (status: string) => {
//     switch (status) {
//       case "pending":
//         return "Pending";
//       case "in_progress":
//         return "In Progress";
//       case "completed":
//         return "Completed";
//       default:
//         return status.charAt(0).toUpperCase() + status.slice(1);
//     }
//   };

//   const getStatusColor = (status: string) => {
//     switch (status) {
//       case "pending":
//         return "warning";
//       case "in_progress":
//         return "primary";
//       case "completed":
//         return "success";
//       default:
//         return "secondary";
//     }
//   };

//   const formatDateTime = (dateString?: string) => {
//     if (!dateString) return "N/A";
//     try {
//       return new Date(dateString).toLocaleString("en-US", {
//         year: "numeric",
//         month: "short",
//         day: "numeric",
//         hour: "2-digit",
//         minute: "2-digit",
//       });
//     } catch {
//       return "Invalid Date";
//     }
//   };

//   const formatCurrency = (amount?: string) => {
//     if (!amount) return "$0.00";
//     const num = parseFloat(amount);
//     return new Intl.NumberFormat("en-US", {
//       style: "currency",
//       currency: "USD",
//     }).format(num || 0);
//   };

//   if (!task) return null;

//   // Determine modal title
//   const title = modalTitle || (
//     <div className="d-flex align-items-center">
//       {/* <i className="fa fa-tasks me-2"></i> */}
//       Update Task
//       {task && (
//         <Badge color={getStatusColor(task.status)} className="ms-2">
//           {getStatusLabel(task.status)}
//         </Badge>
//       )}
//     </div>
//   );

//   // Determine button text
//   const buttonText = isSubmitting ? (
//     <>
//       <Spinner size="sm" className="me-2" />
//       Updating...
//     </>
//   ) : (
//     "Update Task"
//   );

//   return (
//     <Modal
//       className={modalClass}
//       isOpen={isOpen}
//       toggle={toggle}
//       size={modalSize}
//       centered
//     >
//       <ModalHeader toggle={toggle}>{title}</ModalHeader>
//       <ModalBody>
//         {/* <div className="modal-padding-space"> */}
//         {/* Task Header with badge */}
//         {/* <div className="d-flex justify-content-between align-items-center mb-4">
//             <div className="d-flex align-items-center">
//               <i className="fa fa-chevron-right me-2 text-primary"></i>
//               <div>
//                 <h6 className="mb-0">Task Details</h6>
//                 <p className="text-muted mb-1 small">
//                   Task #{task.sequence || "N/A"}
//                 </p>
//               </div>
//             </div>
//             <Badge color={getStatusColor(task.status)}>
//               {getStatusLabel(task.status)}
//             </Badge>
//           </div> */}

//         {/* Task Description */}
//         <div className="mb-4">
//           <Label className="text-muted small mb-2">Description</Label>
//           <div className="border rounded p-3 bg-light">
//             <p className="mb-0" style={{ color: "#8950fc" }}>
//               {task.description}
//             </p>
//           </div>
//         </div>

//         {/* Task Information Grid */}
//         <div className="mb-4">
//           <Label className="text-muted small mb-2">Task Information</Label>
//           <Row className="g-3">
//             <Col md={6}>
//               <div className="d-flex align-items-start mb-3">
//                 <div className="flex-shrink-0">
//                   <i className="fa fa-user text-primary me-2"></i>
//                 </div>
//                 <div className="flex-grow-1">
//                   <Label className="text-muted small mb-1">Assigned To</Label>
//                   <p className="mb-0">{task.assigned_to || "Not Assigned"}</p>
//                 </div>
//               </div>
//             </Col>
//             <Col md={6}>
//               <div className="d-flex align-items-start mb-3">
//                 <div className="flex-shrink-0">
//                   <i className="fa fa-calendar text-primary me-2"></i>
//                 </div>
//                 <div className="flex-grow-1">
//                   <Label className="text-muted small mb-1">Created</Label>
//                   <p className="mb-0">{formatDateTime(task.created_at)}</p>
//                 </div>
//               </div>
//             </Col>
//           </Row>

//           {/* Cost Information */}
//           <div className="border rounded p-3 mt-3">
//             <Label className="text-muted small mb-2">Cost Details</Label>
//             <Row className="g-3">
//               <Col xs={4}>
//                 <div className="text-center">
//                   <div className="text-muted small">Hours</div>
//                   <div className="h5 text-primary">
//                     {parseFloat(task.labor_hours).toFixed(1)}
//                   </div>
//                 </div>
//               </Col>
//               <Col xs={4}>
//                 <div className="text-center">
//                   <div className="text-muted small">Rate</div>
//                   <div className="h5 text-warning">
//                     {formatCurrency(task.labor_rate)}
//                   </div>
//                 </div>
//               </Col>
//               <Col xs={4}>
//                 <div className="text-center">
//                   <div className="text-muted small">Total</div>
//                   <div className="h5 text-success">
//                     {formatCurrency(task.amount)}
//                   </div>
//                 </div>
//               </Col>
//             </Row>
//           </div>
//         </div>

//         {/* Status Update Section */}
//         <div className="mb-4">
//           <Label className="text-muted small mb-1">Update Status</Label>
//           <div className="d-flex flex-wrap gap-2 mb-3">
//             {["pending", "in_progress", "completed"].map((status) => (
//               <Button
//                 key={status}
//                 color={
//                   selectedStatus === status
//                     ? getStatusColor(status)
//                     : "outline-secondary"
//                 }
//                 onClick={() => setSelectedStatus(status)}
//                 disabled={isSubmitting}
//                 className="d-flex align-items-center"
//               >
//                 {selectedStatus === status && isSubmitting ? (
//                   <Spinner size="sm" className="me-2" />
//                 ) : (
//                   <i
//                     className={`fa me-2 ${
//                       status === "pending"
//                         ? "fa-clock"
//                         : status === "in_progress"
//                         ? "fa-play"
//                         : "fa-check"
//                     }`}
//                   ></i>
//                 )}
//                 {getStatusLabel(status)}
//               </Button>
//             ))}
//           </div>
//         </div>

//         {/* Notes Section */}
//         <div className="mb-3">
//           <Label className="text-muted small mb-1">Task Notes</Label>
//           <div className="d-flex align-items-start">
//             <div className="flex-shrink-0">
//               <i className="fa fa-sticky-note text-primary me-2 mt-2"></i>
//             </div>
//             <div className="flex-grow-1">
//               <Input
//                 type="textarea"
//                 rows={4}
//                 placeholder="Add or update notes about this task..."
//                 value={notes}
//                 onChange={(e) => setNotes(e.target.value)}
//                 disabled={isSubmitting}
//               />
//               <div className="mt-2 d-flex justify-content-between align-items-center">
//                 <small className="text-muted">
//                   {task.notes && (
//                     <>
//                       <i className="fa fa-history me-1"></i>
//                       Last updated: {formatDateTime(task.updated_at)}
//                     </>
//                   )}
//                 </small>
//                 <small className="text-muted">
//                   {notes.length} character{notes.length !== 1 ? "s" : ""}
//                 </small>
//               </div>
//             </div>
//           </div>
//         </div>
//         {/* </div> */}
//       </ModalBody>

//       {showFooter && (
//         <ModalFooter>
//           <Button color="secondary" onClick={toggle} disabled={isSubmitting}>
//             {Close}
//           </Button>
//           <Button
//             color="primary"
//             onClick={handleSubmit}
//             // disabled={isSubmitting || !selectedStatus || notes === task.notes}
//             disabled={isSubmitting}
//           >
//             {buttonText}
//           </Button>
//         </ModalFooter>
//       )}
//     </Modal>
//   );
// };

// export default TaskModal;

"use client";

import React, { useState, useEffect } from "react";
import {
  Button,
  Spinner,
  Input,
  Label,
  Badge,
  Row,
  Col,
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
} from "reactstrap";
import { Close, SaveChanges } from "@/utils/Constant";

// Types - Make sure this matches exactly with the interface in page.tsx
interface JobCardItem {
  id: string;
  job_card_id: string;
  sequence: string;
  description: string;
  labor_hours: string;
  labor_rate: string;
  amount: string;
  status: string;
  assigned_to: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

interface TaskModalProps {
  isOpen: boolean;
  toggle: () => void;
  task: JobCardItem | null;
  onUpdate: (taskId: string, status: string, notes: string) => Promise<void>;
  loading?: boolean;
  modalTitle?: string;
  modalClass?: string;
  modalSize?: string;
  showFooter?: boolean;
  onSuccess?: () => void; // Add callback for successful update
}

const TaskModal: React.FC<TaskModalProps> = ({
  isOpen,
  toggle,
  task,
  onUpdate,
  loading = false,
  modalTitle,
  modalClass,
  modalSize = "md",
  showFooter = true,
  onSuccess, // Receive callback for success
}) => {
  const [notes, setNotes] = useState<string>("");
  const [selectedStatus, setSelectedStatus] = useState<string>("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Reset form when task changes
  useEffect(() => {
    if (task) {
      setNotes(task.notes || "");
      setSelectedStatus(task.status);
    }
  }, [task]);

  const handleSubmit = async () => {
    if (!task || !selectedStatus) return;

    setIsSubmitting(true);
    try {
      await onUpdate(task.id, selectedStatus, notes);

      // Call success callback if provided
      if (onSuccess) {
        onSuccess();
      }

      // Close modal on successful update
      toggle();
    } catch (error) {
      console.error("Error updating task:", error);
      setIsSubmitting(false);
      // Keep modal open on error - user can see the error and try again
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "pending":
        return "Pending";
      case "in_progress":
        return "In Progress";
      case "completed":
        return "Completed";
      default:
        return status.charAt(0).toUpperCase() + status.slice(1);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "warning";
      case "in_progress":
        return "primary";
      case "completed":
        return "success";
      default:
        return "secondary";
    }
  };

  const formatDateTime = (dateString?: string) => {
    if (!dateString) return "N/A";
    try {
      return new Date(dateString).toLocaleString("en-US", {
        year: "numeric",
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      });
    } catch {
      return "Invalid Date";
    }
  };

  const formatCurrency = (amount?: string) => {
    if (!amount) return "$0.00";
    const num = parseFloat(amount);
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(num || 0);
  };

  if (!task) return null;

  // Determine modal title
  const title = modalTitle || (
    <div className="d-flex align-items-center">
      Update Task
      {task && (
        <Badge color={getStatusColor(task.status)} className="ms-2">
          {getStatusLabel(task.status)}
        </Badge>
      )}
    </div>
  );

  // Determine button text
  const buttonText = isSubmitting ? (
    <>
      <Spinner size="sm" className="me-2" />
      Updating...
    </>
  ) : (
    "Update Task"
  );

  return (
    <Modal
      className={modalClass}
      isOpen={isOpen}
      toggle={toggle}
      size={modalSize}
      centered
      onClosed={() => {
        // Reset form state when modal closes
        setNotes("");
        setSelectedStatus("");
        setIsSubmitting(false);
      }}
    >
      <ModalHeader toggle={toggle}>{title}</ModalHeader>
      <ModalBody>
        {/* Task Description */}
        <div className="mb-4">
          <Label className="text-muted small mb-2">Description</Label>
          <div className="border rounded p-3 bg-light">
            <p className="mb-0" style={{ color: "#8950fc" }}>
              {task.description}
            </p>
          </div>
        </div>

        {/* Task Information Grid */}
        <div className="mb-4">
          <Label className="text-muted small mb-2">Task Information</Label>
          <Row className="g-3">
            <Col md={6}>
              <div className="d-flex align-items-start mb-3">
                <div className="flex-shrink-0">
                  <i className="fa fa-user text-primary me-2"></i>
                </div>
                <div className="flex-grow-1">
                  <Label className="text-muted small mb-1">Assigned To</Label>
                  <p className="mb-0">{task.assigned_to || "Not Assigned"}</p>
                </div>
              </div>
            </Col>
            <Col md={6}>
              <div className="d-flex align-items-start mb-3">
                <div className="flex-shrink-0">
                  <i className="fa fa-calendar text-primary me-2"></i>
                </div>
                <div className="flex-grow-1">
                  <Label className="text-muted small mb-1">Created</Label>
                  <p className="mb-0">{formatDateTime(task.created_at)}</p>
                </div>
              </div>
            </Col>
          </Row>

          {/* Cost Information */}
          <div className="border rounded p-3 mt-3">
            <Label className="text-muted small mb-2">Cost Details</Label>
            <Row className="g-3">
              <Col xs={4}>
                <div className="text-center">
                  <div className="text-muted small">Hours</div>
                  <div className="h5 text-primary">
                    {parseFloat(task.labor_hours).toFixed(1)}
                  </div>
                </div>
              </Col>
              <Col xs={4}>
                <div className="text-center">
                  <div className="text-muted small">Rate</div>
                  <div className="h5 text-warning">
                    {formatCurrency(task.labor_rate)}
                  </div>
                </div>
              </Col>
              <Col xs={4}>
                <div className="text-center">
                  <div className="text-muted small">Total</div>
                  <div className="h5 text-success">
                    {formatCurrency(task.amount)}
                  </div>
                </div>
              </Col>
            </Row>
          </div>
        </div>

        {/* Status Update Section */}
        <div className="mb-4">
          <Label className="text-muted small mb-1">Update Status</Label>
          <div className="d-flex flex-wrap gap-2 mb-3">
            {["pending", "in_progress", "completed"].map((status) => (
              <Button
                key={status}
                color={
                  selectedStatus === status
                    ? getStatusColor(status)
                    : "outline-secondary"
                }
                onClick={() => setSelectedStatus(status)}
                disabled={isSubmitting}
                className="d-flex align-items-center"
              >
                {selectedStatus === status && isSubmitting ? (
                  <Spinner size="sm" className="me-2" />
                ) : (
                  <i
                    className={`fa me-2 ${
                      status === "pending"
                        ? "fa-clock"
                        : status === "in_progress"
                        ? "fa-play"
                        : "fa-check"
                    }`}
                  ></i>
                )}
                {getStatusLabel(status)}
              </Button>
            ))}
          </div>
        </div>

        {/* Notes Section */}
        <div className="mb-3">
          <Label className="text-muted small mb-1">Task Notes</Label>
          <div className="d-flex align-items-start">
            <div className="flex-shrink-0">
              <i className="fa fa-sticky-note text-primary me-2 mt-2"></i>
            </div>
            <div className="flex-grow-1">
              <Input
                type="textarea"
                rows={4}
                placeholder="Add or update notes about this task..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                disabled={isSubmitting}
              />
              <div className="mt-2 d-flex justify-content-between align-items-center">
                <small className="text-muted">
                  {task.notes && (
                    <>
                      <i className="fa fa-history me-1"></i>
                      Last updated: {formatDateTime(task.updated_at)}
                    </>
                  )}
                </small>
                <small className="text-muted">
                  {notes.length} character{notes.length !== 1 ? "s" : ""}
                </small>
              </div>
            </div>
          </div>
        </div>
      </ModalBody>

      {showFooter && (
        <ModalFooter>
          <Button color="secondary" onClick={toggle} disabled={isSubmitting}>
            {Close}
          </Button>
          <Button
            color="primary"
            onClick={handleSubmit}
            disabled={
              isSubmitting ||
              !selectedStatus ||
              (selectedStatus === task.status && notes === task.notes)
            }
          >
            {buttonText}
          </Button>
        </ModalFooter>
      )}
    </Modal>
  );
};

export default TaskModal;
