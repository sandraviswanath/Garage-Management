"use client";
import Breadcrumbs from "@/CommonElements/Breadcrumbs";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  Badge,
  Button,
  TabContent,
  TabPane,
  Nav,
  NavItem,
  NavLink,
  Table,
  Progress,
  Input,
  Spinner,
  Alert,
  Media,
} from "reactstrap";
import React, { useState, useEffect, Fragment } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/helper/AuthContext";
import { toast } from "react-toastify";
import TaskModal from "../TaskModal";

// Types based on API response
interface JobCardItem {
  id: string;
  job_card_id: string;
  sequence: string;
  description: string;
  labor_hours: string;
  labor_rate: string;
  amount: string;
  status: string;
  assigned_to: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

interface JobCardPart {
  id: string;
  job_card_id: string;
  part_id: string;
  part_name: string;
  quantity: string;
  unit_price: string;
  amount: string;
  source: string;
  created_at: string;
  updated_at: string;
}

interface JobCardPayment {
  id: string;
  job_card_id: string;
  amount: string;
  payment_method: string;
  transaction_id: string | null;
  status: string;
  created_at: string;
  updated_at: string;
}

interface JobCardData {
  id: string;
  job_number: string;
  customer_id: string;
  vehicle_id: string;
  created_by: string;
  assigned_to: string;
  status: string;
  reported_issue: string;
  diagnosis: string | null;
  labor_estimate: string;
  parts_estimate: string;
  total_estimate: string;
  priority: string;
  expected_completion: string;
  actual_completion: string | null;
  is_paid: string;
  meta: string;
  created_at: string;
  updated_at: string;
  customer_name: string;
  registration_number: string;
  created_by_user: string;
  items: JobCardItem[];
  parts: JobCardPart[];
  payments: JobCardPayment[];
}

function WorkDetailPage({ params }: { params: { id: string } }) {
  const { state } = useAuth();
  const router = useRouter();
  const [activeTab, setActiveTab] = useState("1");
  const [jobCard, setJobCard] = useState<JobCardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [updating, setUpdating] = useState<string | null>(null);
  const [vehicleDetails, setVehicleDetails] = useState<any>(null);
  const [technicianDetails, setTechnicianDetails] = useState<any>(null);

  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [selectedTask, setSelectedTask] = useState<JobCardItem | null>(null);
  const [modalNotes, setModalNotes] = useState<string>("");

  const openTaskModal = (task: JobCardItem) => {
    setSelectedTask(task);
    setModalNotes(task.notes || "");
    setIsTaskModalOpen(true);
  };

  const toggleTaskModal = () => {
    setIsTaskModalOpen(!isTaskModalOpen);
    if (isTaskModalOpen) {
      setSelectedTask(null);
    }
  };
  useEffect(() => {
    fetchJobCard();
  }, []);
  // const handleTaskUpdate = async (
  //   taskId: string,
  //   status: string,
  //   notes: string
  // ) => {
  //   setLoading(true);
  //   try {
  //     // Make API call
  //     const response = await fetch(`/api/jobcards/jobitem_status/${taskId}`, {
  //       method: "PUT",
  //       headers: {
  //         "Content-Type": "application/json",
  //         Authorization: `Bearer ${localStorage.getItem("token")}`,
  //       },
  //       body: JSON.stringify({
  //         status: status,
  //         notes: notes,
  //       }),
  //     });

  //     if (!response.ok) {
  //       throw new Error("Failed to update task");
  //     }

  //     toast.success("Task updated successfully!");

  //     // Refresh task data or update local state
  //     // ... your refresh logic here
  //   } catch (error) {
  //     console.error("Error updating task:", error);
  //     toast.error("Failed to update task");
  //     throw error; // Re-throw to show error in modal
  //   } finally {
  //     setLoading(false);
  //   }
  // };

  // useEffect(() => {
  //   const fetchJobCard = async () => {
  //     try {
  //       setLoading(true);
  //       setError(null);

  //       const token = state?.accessToken || localStorage.getItem("token");
  //       const response = await fetch(`/api/jobcards/${params.id}`, {
  //         method: "GET",
  //         headers: {
  //           Authorization: `Bearer ${token}`,
  //           "Content-Type": "application/json",
  //         },
  //       });

  //       if (!response.ok) {
  //         const errorData = await response.json();
  //         throw new Error(errorData.message || "Failed to fetch job card");
  //       }

  //       const result = await response.json();

  //       if (result.data) {
  //         setJobCard(result.data);

  //         // Fetch additional vehicle details if needed
  //         if (result.data.vehicle_id) {
  //           fetchVehicleDetails(result.data.vehicle_id);
  //         }

  //         // Fetch technician details if needed
  //         if (result.data.assigned_to) {
  //           fetchTechnicianDetails(result.data.assigned_to);
  //         }
  //       } else {
  //         throw new Error("No data received");
  //       }
  //     } catch (err: any) {
  //       console.error("Error fetching job card:", err);
  //       setError(err.message || "An error occurred");
  //       toast.error("Failed to load job card details");
  //     } finally {
  //       setLoading(false);
  //     }
  //   };

  //   if (params.id) {
  //     fetchJobCard();
  //   }
  // }, [params.id]);

  // Update your fetchJobCard function to be accessible
  const fetchJobCard = async () => {
    try {
      setLoading(true);
      setError(null);

      const token = state?.accessToken || localStorage.getItem("token");
      const response = await fetch(`/api/jobcards/${params.id}`, {
        method: "GET",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to fetch job card");
      }

      const result = await response.json();

      if (result.data) {
        setJobCard(result.data);

        // Fetch additional vehicle details if needed
        if (result.data.vehicle_id) {
          fetchVehicleDetails(result.data.vehicle_id);
        }

        // Fetch technician details if needed
        if (result.data.assigned_to) {
          fetchTechnicianDetails(result.data.assigned_to);
        }
      } else {
        throw new Error("No data received");
      }
    } catch (err: any) {
      console.error("Error fetching job card:", err);
      setError(err.message || "An error occurred");
      toast.error("Failed to load job card details");
    } finally {
      setLoading(false);
    }
  };

  // Also update your handleTaskUpdate function to return the promise
  const handleTaskUpdate = async (
    taskId: string,
    status: string,
    notes: string
  ) => {
    try {
      // Make API call
      const response = await fetch(`/api/jobcards/jobitem_status/${taskId}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
        body: JSON.stringify({
          status: status,
          notes: notes,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to update task");
      }

      const result = await response.json();
      toast.success("Task updated successfully!");

      return result.data; // Return the updated data
    } catch (error) {
      console.error("Error updating task:", error);
      toast.error("Failed to update task");
      throw error; // Re-throw to show error in modal
    }
  };
  const fetchVehicleDetails = async (vehicleId: string) => {
    try {
      const token = state?.accessToken || localStorage.getItem("token");
      const response = await fetch(`/api/vehicles/${vehicleId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (response.ok) {
        const data = await response.json();
        setVehicleDetails(data.data);
      }
    } catch (err) {
      console.error("Error fetching vehicle details:", err);
    }
  };

  const fetchTechnicianDetails = async (technicianId: string) => {
    try {
      const token = state?.accessToken || localStorage.getItem("token");
      const response = await fetch(`/api/technicians/${technicianId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (response.ok) {
        const data = await response.json();
        setTechnicianDetails(data.data);
      }
    } catch (err) {
      console.error("Error fetching technician details:", err);
    }
  };

  const renderStatusBadge = (status: string) => {
    const statusConfig: Record<string, { color: string; label: string }> = {
      open: { color: "primary", label: "Open" },
      in_progress: { color: "warning", label: "In Progress" },
      completed: { color: "success", label: "Completed" },
      // closed: { color: "success", label: "Closed" },
      // cancelled: { color: "danger", label: "Cancelled" },
      pending: { color: "secondary", label: "Pending" },
    };

    const config = statusConfig[status.toLowerCase()] || {
      color: "secondary",
      label: status.charAt(0).toUpperCase() + status.slice(1),
    };

    return <Badge color={config.color}>{config.label}</Badge>;
  };

  const handleDeletePart = async (jobCardPartId: string) => {
    if (
      !confirm("Are you sure you want to remove this part from the job card?")
    ) {
      return;
    }

    try {
      setUpdating("delete-part");
      const token = state?.accessToken || localStorage.getItem("token");

      // Note: The API endpoint expects the job card part entry ID, not the part_id
      // From your API example: /api/jobcards/remove_parts/1 (where 1 is the job_card_part_id)
      const response = await fetch(
        `/api/jobcards/remove_parts/${jobCardPartId}`,
        {
          method: "PUT",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        }
      );

      if (response.ok) {
        toast.success("Part removed successfully");

        // Update local state immediately
        if (jobCard) {
          const updatedParts = jobCard.parts.filter(
            (part) => part.id !== jobCardPartId
          );
          setJobCard({ ...jobCard, parts: updatedParts });
        }

        // Optionally refresh data from server
        // await fetchJobCard(); // You might want to add a fetchJobCard function
      } else {
        const errorData = await response.json();
        toast.error(errorData.message || "Failed to remove part");
      }
    } catch (error: any) {
      console.error("Error removing part:", error);
      toast.error(`Failed to remove part: ${error.message}`);
    } finally {
      setUpdating(null);
    }
  };

  const handleStatusChange = async (newStatus: string) => {
    if (!jobCard) return;

    try {
      setUpdating("jobStatus");
      const token = state?.accessToken || localStorage.getItem("token");

      const response = await fetch(`/api/jobcards/${params.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ status: newStatus }),
      });

      if (response.ok) {
        setJobCard({ ...jobCard, status: newStatus });
        toast.success(`Job status updated to ${newStatus}`);
      } else {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to update status");
      }
    } catch (err: any) {
      console.error("Error updating status:", err);
      toast.error(err.message || "Failed to update status");
    } finally {
      setUpdating(null);
    }
  };

  const handleTaskStatusChange = async (taskId: string, newStatus: string) => {
    if (!jobCard) return;

    try {
      setUpdating(`task-${taskId}`);
      const token = state?.accessToken || localStorage.getItem("token");

      const response = await fetch(`/api/jobcard-items/${taskId}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ status: newStatus }),
      });

      if (response.ok) {
        const updatedItems = jobCard.items.map((item) =>
          item.id === taskId ? { ...item, status: newStatus } : item
        );
        setJobCard({ ...jobCard, items: updatedItems });
        toast.success("Task status updated");
      } else {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to update task");
      }
    } catch (err: any) {
      console.error("Error updating task status:", err);
      toast.error(err.message || "Failed to update task");
    } finally {
      setUpdating(null);
    }
  };

  const handleTaskNotesChange = async (
    taskId: string,
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    if (!jobCard) return;

    const updatedItems = jobCard.items.map((t) =>
      t.id === taskId ? { ...t, notes: e.target.value } : t
    );
    setJobCard({ ...jobCard, items: updatedItems });
  };

  const saveTaskNotes = async (taskId: string) => {
    if (!jobCard) return;

    const task = jobCard.items.find((item) => item.id === taskId);
    if (!task) return;

    try {
      const token = state?.accessToken || localStorage.getItem("token");
      await fetch(`/api/jobcard-items/${taskId}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ notes: task.notes }),
      });
      toast.success("Task notes saved");
    } catch (err: any) {
      console.error("Error saving task notes:", err);
      toast.error("Failed to save notes");
    }
  };

  const handleMarkAsPaid = async () => {
    if (!jobCard) return;

    try {
      setUpdating("payment");
      const token = state?.accessToken || localStorage.getItem("token");

      const response = await fetch(`/api/jobcards/${params.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ is_paid: "1" }),
      });

      if (response.ok) {
        setJobCard({ ...jobCard, is_paid: "1" });
        toast.success("Job marked as paid");
      } else {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to update payment status");
      }
    } catch (err: any) {
      console.error("Error marking as paid:", err);
      toast.error(err.message || "Failed to update payment");
    } finally {
      setUpdating(null);
    }
  };

  const handleMarkAsUnpaid = async () => {
    if (!jobCard) return;

    try {
      setUpdating("payment");
      const token = state?.accessToken || localStorage.getItem("token");

      const response = await fetch(`/api/jobcards/${params.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ is_paid: "0" }),
      });

      if (response.ok) {
        setJobCard({ ...jobCard, is_paid: "0" });
        toast.success("Job marked as unpaid");
      } else {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to update payment status");
      }
    } catch (err: any) {
      console.error("Error marking as unpaid:", err);
      toast.error(err.message || "Failed to update payment");
    } finally {
      setUpdating(null);
    }
  };

  // Calculate progress
  const calculateProgress = () => {
    if (!jobCard || !jobCard.items.length)
      return { percentage: 0, completed: 0, total: 0 };

    const completedTasks = jobCard.items.filter(
      (item) => item.status === "completed"
    ).length;
    const totalTasks = jobCard.items.length;
    const progressPercentage =
      totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;

    return {
      percentage: progressPercentage,
      completed: completedTasks,
      total: totalTasks,
    };
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString || dateString === "0000-00-00 00:00:00") return "Not set";
    try {
      return new Date(dateString).toLocaleDateString("en-US", {
        year: "numeric",
        month: "short",
        day: "numeric",
      });
    } catch {
      return "Invalid date";
    }
  };

  const formatDateTime = (dateString: string | null) => {
    if (!dateString || dateString === "0000-00-00 00:00:00") return "Not set";
    try {
      return new Date(dateString).toLocaleString("en-US", {
        year: "numeric",
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      });
    } catch {
      return "Invalid date";
    }
  };

  if (loading) {
    return (
      <div className="page-body">
        <Container fluid>
          <div className="text-center py-5">
            <Spinner color="primary" />
            <p className="mt-2">Loading job card details...</p>
          </div>
        </Container>
      </div>
    );
  }

  if (error || !jobCard) {
    return (
      <div className="page-body">
        <Breadcrumbs
          title="Error"
          mainTitle="Job Card Details"
          parent="Job Card Management"
        />
        <Container fluid>
          <Card>
            <CardBody className="text-center py-5">
              <i className="fa fa-exclamation-triangle fa-3x text-danger mb-3"></i>
              <h4>Error Loading Job Card</h4>
              <p className="text-muted">{error || "Job card not found"}</p>
              <Button
                color="primary"
                onClick={() => router.push("/admin/jobcards")}
              >
                Back to Job Cards
              </Button>
            </CardBody>
          </Card>
        </Container>
      </div>
    );
  }

  const {
    percentage: progressPercentage,
    completed: completedTasks,
    total: totalTasks,
  } = calculateProgress();

  const laborTotal = jobCard.items.reduce(
    (sum, item) => sum + parseFloat(item.amount),
    0
  );
  const partsTotal = jobCard.parts.reduce(
    (sum, part) => sum + parseFloat(part.amount),
    0
  );
  const actualTotal = laborTotal + partsTotal;

  return (
    <div className="page-body">
      <Breadcrumbs
        title={`Job Card - ${jobCard.job_number}`}
        mainTitle="Job Card Details"
        parent="Job Card Management"
      />

      <Container fluid>
        <Row>
          <Col lg={4}>
            <Card className="mb-4">
              <CardBody>
                <div className="text-center mb-4">
                  <h4 className="text-primary">{jobCard.job_number}</h4>
                  {renderStatusBadge(jobCard.status)}
                </div>

                <div className="mb-3">
                  <strong className="text-muted">Customer Information</strong>
                  <div className="mt-2">
                    <div className="d-flex justify-content-between py-2 border-bottom">
                      <span>Name:</span>
                      <span>{jobCard.customer_name || "N/A"}</span>
                    </div>
                    <div className="d-flex justify-content-between py-2 border-bottom">
                      <span>Customer ID:</span>
                      <span>{jobCard.customer_id}</span>
                    </div>
                  </div>
                </div>

                <div className="mb-3">
                  <strong>Vehicle Information</strong>
                  <div className="mt-2">
                    <div className="d-flex justify-content-between py-2 border-bottom">
                      <span>Registration No:</span>
                      <span>{jobCard.registration_number || "N/A"}</span>
                    </div>
                    <div className="d-flex justify-content-between py-2 border-bottom">
                      <span>Vehicle ID:</span>
                      <span>{jobCard.vehicle_id}</span>
                    </div>
                    {vehicleDetails && (
                      <>
                        <div className="d-flex justify-content-between py-2 border-bottom">
                          <span>Make/Model:</span>
                          <span>
                            {vehicleDetails.make || "N/A"}{" "}
                            {vehicleDetails.model || ""}
                          </span>
                        </div>
                        <div className="d-flex justify-content-between py-2">
                          <span>Year:</span>
                          <span>{vehicleDetails.year || "N/A"}</span>
                        </div>
                      </>
                    )}
                  </div>
                </div>

                <div className="mb-3">
                  <strong>Job Information</strong>
                  <div className="mt-2">
                    <div className="d-flex justify-content-between py-2 border-bottom">
                      <span>Created By:</span>
                      <span>
                        {jobCard.created_by_user ||
                          "User " + jobCard.created_by}
                      </span>
                    </div>
                    <div className="d-flex justify-content-between py-2 border-bottom">
                      <span>Assigned To:</span>
                      <span>
                        {technicianDetails?.name ||
                          `Technician ${jobCard.assigned_to}`}
                      </span>
                    </div>
                    <div className="d-flex justify-content-between py-2 border-bottom">
                      <span>Priority:</span>
                      <Badge
                        color={
                          jobCard.priority === "1"
                            ? "danger"
                            : jobCard.priority === "2"
                            ? "warning"
                            : "info"
                        }
                      >
                        {jobCard.priority === "1"
                          ? "High"
                          : jobCard.priority === "2"
                          ? "Medium"
                          : "Low"}
                      </Badge>
                    </div>
                    <div className="d-flex justify-content-between py-2 border-bottom">
                      <span>Created:</span>
                      <span>{formatDateTime(jobCard.created_at)}</span>
                    </div>
                    <div className="d-flex justify-content-between py-2 border-bottom">
                      <span>Expected Completion:</span>
                      <span>{formatDate(jobCard.expected_completion)}</span>
                    </div>
                  </div>
                </div>
              </CardBody>
            </Card>

            {/* Quick Actions Card */}
            {/* <Card>
              <CardBody>
                <h6 className="mb-3">Quick Actions</h6>
                <div className="d-grid gap-2">
                  {jobCard.status !== "completed" &&
                    jobCard.status !== "closed" && (
                      <Button
                        color="success"
                        onClick={() => handleStatusChange("completed")}
                        disabled={updating === "jobStatus"}
                      >
                        {updating === "jobStatus" ? (
                          <Spinner size="sm" className="me-2" />
                        ) : (
                          <i className="fa fa-check me-2"></i>
                        )}
                        Mark as Completed
                      </Button>
                    )}

                  {jobCard.status !== "in-progress" && (
                    <Button
                      color="warning"
                      onClick={() => handleStatusChange("in-progress")}
                      disabled={updating === "jobStatus"}
                    >
                      {updating === "jobStatus" ? (
                        <Spinner size="sm" className="me-2" />
                      ) : (
                        <i className="fa fa-play me-2"></i>
                      )}
                      Start Progress
                    </Button>
                  )}

                  <Button
                    color="primary"
                    onClick={() =>
                      router.push(
                        `/admin/invoices/create?job_card_id=${jobCard.id}`
                      )
                    }
                  >
                    <i className="fa fa-file-invoice me-2"></i>
                    Create Invoice
                  </Button>

                  <Button
                    color="info"
                    onClick={() => {
                      // TODO: Implement send update
                      toast.info("Send update feature coming soon");
                    }}
                  >
                    <i className="fa fa-envelope me-2"></i>
                    Send Update
                  </Button>
                </div>
              </CardBody>
            </Card> */}
          </Col>

          <Col lg={8}>
            {/* Progress Card */}
            <Card className="mb-4">
              <CardBody>
                <div className="d-flex justify-content-between align-items-center mb-2">
                  <h6 className="mb-0">Job Progress</h6>
                  <span>
                    {completedTasks}/{totalTasks} tasks completed
                  </span>
                </div>
                <Progress
                  value={progressPercentage}
                  color={
                    progressPercentage < 30
                      ? "danger"
                      : progressPercentage < 70
                      ? "warning"
                      : "success"
                  }
                  className="mb-2"
                />
                <small>{progressPercentage.toFixed(0)}% complete</small>
              </CardBody>
            </Card>

            {/* Tabs */}
            <Card>
              <CardBody>
                <Nav tabs>
                  <NavItem>
                    <NavLink
                      className={activeTab === "1" ? "active" : ""}
                      onClick={() => setActiveTab("1")}
                    >
                      <i className="fa fa-info-circle me-1"></i>
                      Overview
                    </NavLink>
                  </NavItem>
                  <NavItem>
                    <NavLink
                      className={activeTab === "2" ? "active" : ""}
                      onClick={() => setActiveTab("2")}
                    >
                      <i className="fa fa-tasks me-1"></i>
                      Tasks ({jobCard.items.length})
                    </NavLink>
                  </NavItem>
                  <NavItem>
                    <NavLink
                      className={activeTab === "3" ? "active" : ""}
                      onClick={() => setActiveTab("3")}
                    >
                      <i className="fa fa-cogs me-1"></i>
                      Parts ({jobCard.parts.length})
                    </NavLink>
                  </NavItem>
                  <NavItem>
                    <NavLink
                      className={activeTab === "4" ? "active" : ""}
                      onClick={() => setActiveTab("4")}
                    >
                      <i className="fa fa-credit-card me-1"></i>
                      Payments ({jobCard.payments.length})
                    </NavLink>
                  </NavItem>
                </Nav>

                <TabContent activeTab={activeTab} className="pt-3">
                  {/* Overview Tab */}
                  <TabPane tabId="1">
                    <div className="mb-4">
                      <h6>Reported Issue</h6>
                      <Card>
                        <CardBody>
                          <p className="mb-0">
                            {jobCard.reported_issue || "No issue reported"}
                          </p>
                        </CardBody>
                      </Card>
                    </div>

                    {jobCard.diagnosis && (
                      <div className="mb-4">
                        <h6>Diagnosis</h6>
                        <Card>
                          <CardBody>
                            <p className="mb-0 text-info">
                              {jobCard.diagnosis}
                            </p>
                          </CardBody>
                        </Card>
                      </div>
                    )}

                    {/* <div className="row text-center">
                      <div className="col-md-3 mb-3">
                        <Card
                          className={`border-${
                            actualTotal > parseFloat(jobCard.total_estimate)
                              ? "warning"
                              : "primary"
                          }`}
                        >
                          <CardBody>
                            <h4 className="text-primary">
                              ${actualTotal.toFixed(2)}
                            </h4>
                            <p className="mb-0">Actual Total</p>
                            <small className="text-muted">
                              Est: $
                              {parseFloat(jobCard.total_estimate).toFixed(2)}
                            </small>
                          </CardBody>
                        </Card>
                      </div>
                      <div className="col-md-3 mb-3">
                        <Card className="border-warning">
                          <CardBody>
                            <h4 className="text-warning">
                              ${laborTotal.toFixed(2)}
                            </h4>
                            <p className="mb-0">Labor Cost</p>
                            <small className="text-muted">
                              Est: $
                              {parseFloat(jobCard.labor_estimate).toFixed(2)}
                            </small>
                          </CardBody>
                        </Card>
                      </div>
                      <div className="col-md-3 mb-3">
                        <Card className="border-success">
                          <CardBody>
                            <h4 className="text-success">
                              ${partsTotal.toFixed(2)}
                            </h4>
                            <p className="mb-0">Parts Cost</p>
                            <small className="text-muted">
                              Est: $
                              {parseFloat(jobCard.parts_estimate).toFixed(2)}
                            </small>
                          </CardBody>
                        </Card>
                      </div>
                      <div className="col-md-3 mb-3">
                        <Card className="border-info">
                          <CardBody>
                            <h4 className="text-info">
                              {jobCard.items.length}
                            </h4>
                            <p className="mb-0">Total Tasks</p>
                            <small className="text-muted">
                              {completedTasks} completed
                            </small>
                          </CardBody>
                        </Card>
                      </div>
                    </div> */}
                  </TabPane>

                  {/* Tasks Tab */}

                  {/* dashoard card */}
                  {/* <TabPane tabId="2">
                    <div className="projects-wrapper">
                      <div className="row g-4">
                        {jobCard.items.length > 0 ? (
                          jobCard.items.map((task, index) => {
                            const getTaskTitle = (task) => {
                              if (task.title) return task.title;
                              if (task.name) return task.name;
                              return (
                                task.description?.split("\n")[0] ||
                                `Task #${task.sequence || index + 1}`
                              );
                            };

                            const getTaskSubtitle = (task) => {
                              if (task.description) {
                                const lines = task.description.split("\n");
                                return lines.length > 1
                                  ? lines.slice(1).join(" ")
                                  : task.description.length > 40
                                  ? `${task.description.substring(0, 40)}...`
                                  : task.description;
                              }
                              return "No description";
                            };

                            const getProgressPercentage = (task) => {
                              if (task.progress !== undefined)
                                return task.progress;
                              if (task.progress_percentage !== undefined)
                                return task.progress_percentage;

                              switch (task.status) {
                                case "pending":
                                  return 20;
                                case "in_progress":
                                  return 60;
                                case "completed":
                                  return 100;
                                default:
                                  return 0;
                              }
                            };

                            const getBudgetDisplay = (task) => {
                              if (task.amount)
                                return `$${parseFloat(task.amount).toFixed(2)}`;
                              if (task.budget)
                                return `$${parseFloat(task.budget).toFixed(2)}`;
                              if (task.labor_hours && task.labor_rate) {
                                const total =
                                  parseFloat(task.labor_hours) *
                                  parseFloat(task.labor_rate);
                                return `$${total.toFixed(2)}`;
                              }
                              return "N/A";
                            };

                            const getBadgeClass = (status) => {
                              switch (status) {
                                case "pending":
                                  return "badge-light-secondary";
                                case "in_progress":
                                  return "badge-light-warning";
                                case "completed":
                                  return "badge-light-success";
                                default:
                                  return "badge-light-secondary";
                              }
                            };

                            const getBadgeLabel = (status) => {
                              switch (status) {
                                case "pending":
                                  return "Pending";
                                case "in_progress":
                                  return "In Progress";
                                case "completed":
                                  return "Completed";
                                default:
                                  return status;
                              }
                            };

                            const getProgressBarClass = (status) => {
                              switch (status) {
                                case "pending":
                                  return "bg-secondary";
                                case "in_progress":
                                  return "bg-warning";
                                case "completed":
                                  return "bg-success";
                                default:
                                  return "bg-secondary";
                              }
                            };

                            const progressPercentage =
                              getProgressPercentage(task);
                            const badgeClass = getBadgeClass(task.status);
                            const badgeLabel = getBadgeLabel(task.status);
                            const progressBarClass = getProgressBarClass(
                              task.status
                            );

                            return (
                              <div
                                className="col-xxl-4 col-md-6"
                                key={task.id || index}
                              >
                                <div
                                  className="project-card clickable-card"
                                  onClick={() =>
                                    openTaskModal && openTaskModal(task)
                                  }
                                  style={{
                                    cursor: "pointer",
                                    border: "1px solid #e8e8e8",
                                    borderRadius: "12px",
                                    padding: "20px",
                                    backgroundColor: "#fff",
                                    height: "100%",
                                    transition: "all 0.3s ease",
                                  }}
                                >
                                  <div className="d-flex justify-content-between align-items-start mb-3">
                                    <div
                                      style={{ flex: 1, paddingRight: "10px" }}
                                    >
                                      <h6
                                        style={{
                                          fontSize: "16px",
                                          fontWeight: "600",
                                          color: "#333",
                                          marginBottom: "4px",
                                          lineHeight: "1.3",
                                        }}
                                      >
                                        {getTaskTitle(task)}
                                      </h6>
                                      <p
                                        style={{
                                          fontSize: "14px",
                                          color: "#666",
                                          marginBottom: "8px",
                                          lineHeight: "1.4",
                                        }}
                                      >
                                        {getTaskSubtitle(task)}
                                      </p>
                                    </div>
                                    <span
                                      className={`badge ${badgeClass}`}
                                      style={{
                                        padding: "4px 12px",
                                        borderRadius: "20px",
                                        fontSize: "12px",
                                        fontWeight: "500",
                                        whiteSpace: "nowrap",
                                      }}
                                    >
                                      {badgeLabel}
                                    </span>
                                  </div>

                                  <div className="mb-3">
                                    <p
                                      style={{
                                        fontSize: "12px",
                                        color: "#999",
                                        marginBottom: 0,
                                      }}
                                    >
                                      <i className="fa fa-calendar me-2"></i>
                                      {formatDate(
                                        task.created_at ||
                                          task.due_date ||
                                          task.start_date
                                      )}
                                    </p>
                                  </div>

                                  <div
                                    className="d-flex justify-content-between align-items-center mb-3"
                                    style={{
                                      paddingBottom: "12px",
                                      borderBottom: "1px solid #f0f0f0",
                                    }}
                                  >
                                    <span
                                      style={{
                                        fontSize: "14px",
                                        color: "#666",
                                      }}
                                    >
                                      Tasks
                                    </span>
                                    <span
                                      style={{
                                        fontSize: "14px",
                                        fontWeight: "600",
                                        color: "#1bc5bd",
                                      }}
                                    >
                                      {getBudgetDisplay(task)}
                                    </span>
                                  </div>

                                  <div className="mt-3">
                                    <div className="d-flex justify-content-between mb-1">
                                      <span
                                        style={{
                                          fontSize: "14px",
                                          color: "#666",
                                        }}
                                      >
                                        Progress
                                      </span>
                                      <span
                                        style={{
                                          fontSize: "14px",
                                          color: "#333",
                                          fontWeight: "500",
                                        }}
                                      >
                                        {progressPercentage}%
                                      </span>
                                    </div>
                                    <div
                                      className="progress"
                                      style={{
                                        height: "6px",
                                        borderRadius: "3px",
                                        backgroundColor: "#f5f5f5",
                                      }}
                                    >
                                      <div
                                        className={`progress-bar ${progressBarClass}`}
                                        style={{
                                          width: `${progressPercentage}%`,
                                          borderRadius: "3px",
                                        }}
                                      ></div>
                                    </div>
                                  </div>

                                  {task.assigned_to && (
                                    <div className="mt-3 pt-3 border-top">
                                      <small className="text-muted d-block">
                                        Assigned To
                                      </small>
                                      <strong style={{ fontSize: "13px" }}>
                                        {task.assigned_to}
                                      </strong>
                                    </div>
                                  )}
                                </div>
                              </div>
                            );
                          })
                        ) : (
                          <div className="col-12">
                            <div className="card">
                              <div className="card-body text-center py-5">
                                <i className="fa fa-tasks fa-3x text-muted mb-3"></i>
                                <h5>No Tasks Assigned</h5>
                                <p className="text-muted">
                                  No tasks have been added to this job card yet.
                                </p>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>

                      {jobCard.items.length > 0 && (
                        <div className="row g-4 mt-4">
                          <div className="col-xxl-3 col-md-6">
                            <div
                              className="summary-card"
                              style={{
                                border: "1px solid #e8e8e8",
                                borderRadius: "12px",
                                padding: "20px",
                                backgroundColor: "#fff",
                                height: "100%",
                              }}
                            >
                              <div className="d-flex align-items-center">
                                <div
                                  style={{
                                    width: "50px",
                                    height: "50px",
                                    backgroundColor: "rgba(27, 197, 189, 0.1)",
                                    borderRadius: "10px",
                                    display: "flex",
                                    alignItems: "center",
                                    justifyContent: "center",
                                    marginRight: "15px",
                                  }}
                                >
                                  <i
                                    className="fa fa-list-check"
                                    style={{
                                      fontSize: "1.5rem",
                                      color: "#1bc5bd",
                                    }}
                                  ></i>
                                </div>
                                <div>
                                  <h6
                                    style={{
                                      fontSize: "14px",
                                      color: "#666",
                                      marginBottom: "4px",
                                    }}
                                  >
                                    Total Tasks
                                  </h6>
                                  <h3
                                    style={{
                                      fontSize: "24px",
                                      fontWeight: "600",
                                      color: "#1bc5bd",
                                      marginBottom: "0",
                                    }}
                                  >
                                    {jobCard.items.length}
                                  </h3>
                                </div>
                              </div>
                              <p
                                style={{
                                  fontSize: "12px",
                                  color: "#999",
                                  marginTop: "8px",
                                  marginBottom: "0",
                                }}
                              >
                                All assigned tasks in this job
                              </p>
                            </div>
                          </div>

                          <div className="col-xxl-3 col-md-6">
                            <div
                              className="summary-card"
                              style={{
                                border: "1px solid #e8e8e8",
                                borderRadius: "12px",
                                padding: "20px",
                                backgroundColor: "#fff",
                                height: "100%",
                              }}
                            >
                              <div className="d-flex align-items-center">
                                <div
                                  style={{
                                    width: "50px",
                                    height: "50px",
                                    backgroundColor: "rgba(137, 80, 252, 0.1)",
                                    borderRadius: "10px",
                                    display: "flex",
                                    alignItems: "center",
                                    justifyContent: "center",
                                    marginRight: "15px",
                                  }}
                                >
                                  <i
                                    className="fa fa-clock"
                                    style={{
                                      fontSize: "1.5rem",
                                      color: "#8950fc",
                                    }}
                                  ></i>
                                </div>
                                <div>
                                  <h6
                                    style={{
                                      fontSize: "14px",
                                      color: "#666",
                                      marginBottom: "4px",
                                    }}
                                  >
                                    Pending Tasks
                                  </h6>
                                  <h3
                                    style={{
                                      fontSize: "24px",
                                      fontWeight: "600",
                                      color: "#8950fc",
                                      marginBottom: "0",
                                    }}
                                  >
                                    {
                                      jobCard.items.filter(
                                        (t) => t.status === "pending"
                                      ).length
                                    }
                                  </h3>
                                </div>
                              </div>
                              <p
                                style={{
                                  fontSize: "12px",
                                  color: "#999",
                                  marginTop: "8px",
                                  marginBottom: "0",
                                }}
                              >
                                Tasks not yet started
                              </p>
                            </div>
                          </div>

                          <div className="col-xxl-3 col-md-6">
                            <div
                              className="summary-card"
                              style={{
                                border: "1px solid #e8e8e8",
                                borderRadius: "12px",
                                padding: "20px",
                                backgroundColor: "#fff",
                                height: "100%",
                              }}
                            >
                              <div className="d-flex align-items-center">
                                <div
                                  style={{
                                    width: "50px",
                                    height: "50px",
                                    backgroundColor: "rgba(255, 168, 0, 0.1)",
                                    borderRadius: "10px",
                                    display: "flex",
                                    alignItems: "center",
                                    justifyContent: "center",
                                    marginRight: "15px",
                                  }}
                                >
                                  <i
                                    className="fa fa-spinner"
                                    style={{
                                      fontSize: "1.5rem",
                                      color: "#ffa800",
                                    }}
                                  ></i>
                                </div>
                                <div>
                                  <h6
                                    style={{
                                      fontSize: "14px",
                                      color: "#666",
                                      marginBottom: "4px",
                                    }}
                                  >
                                    In Progress
                                  </h6>
                                  <h3
                                    style={{
                                      fontSize: "24px",
                                      fontWeight: "600",
                                      color: "#ffa800",
                                      marginBottom: "0",
                                    }}
                                  >
                                    {
                                      jobCard.items.filter(
                                        (t) => t.status === "in_progress"
                                      ).length
                                    }
                                  </h3>
                                </div>
                              </div>
                              <p
                                style={{
                                  fontSize: "12px",
                                  color: "#999",
                                  marginTop: "8px",
                                  marginBottom: "0",
                                }}
                              >
                                Tasks currently being worked on
                              </p>
                            </div>
                          </div>

                          <div className="col-xxl-3 col-md-6">
                            <div
                              className="summary-card"
                              style={{
                                border: "1px solid #e8e8e8",
                                borderRadius: "12px",
                                padding: "20px",
                                backgroundColor: "#fff",
                                height: "100%",
                              }}
                            >
                              <div className="d-flex align-items-center">
                                <div
                                  style={{
                                    width: "50px",
                                    height: "50px",
                                    backgroundColor: "rgba(40, 167, 69, 0.1)",
                                    borderRadius: "10px",
                                    display: "flex",
                                    alignItems: "center",
                                    justifyContent: "center",
                                    marginRight: "15px",
                                  }}
                                >
                                  <i
                                    className="fa fa-check-circle"
                                    style={{
                                      fontSize: "1.5rem",
                                      color: "#28a745",
                                    }}
                                  ></i>
                                </div>
                                <div>
                                  <h6
                                    style={{
                                      fontSize: "14px",
                                      color: "#666",
                                      marginBottom: "4px",
                                    }}
                                  >
                                    Completed
                                  </h6>
                                  <h3
                                    style={{
                                      fontSize: "24px",
                                      fontWeight: "600",
                                      color: "#28a745",
                                      marginBottom: "0",
                                    }}
                                  >
                                    {
                                      jobCard.items.filter(
                                        (t) => t.status === "completed"
                                      ).length
                                    }
                                  </h3>
                                </div>
                              </div>
                              <p
                                style={{
                                  fontSize: "12px",
                                  color: "#999",
                                  marginTop: "8px",
                                  marginBottom: "0",
                                }}
                              >
                                Successfully finished tasks
                              </p>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </TabPane> */}
                  <TabPane tabId="2">
                    <div className="projects-wrapper">
                      <div className="row g-4">
                        {jobCard.items.length > 0 ? (
                          jobCard.items.map((task, index) => {
                            // Get task title from description
                            const getTaskTitle = (
                              task: JobCardItem
                            ): string => {
                              if (task.description) {
                                const lines = task.description.split("\n");
                                return (
                                  lines[0] ||
                                  `Task #${task.sequence || index + 1}`
                                );
                              }
                              return `Task #${task.sequence || index + 1}`;
                            };

                            const getTaskSubtitle = (
                              task: JobCardItem
                            ): string => {
                              if (task.description) {
                                const lines = task.description.split("\n");
                                if (lines.length > 1) {
                                  return lines.slice(1).join(" ");
                                }
                                // If description is long, truncate it for subtitle
                                if (task.description.length > 40) {
                                  return `${task.description.substring(
                                    0,
                                    40
                                  )}...`;
                                }
                                return task.description;
                              }
                              return "No description";
                            };

                            const getProgressPercentage = (
                              task: JobCardItem
                            ): number => {
                              // Check if task has notes as progress indicator
                              if (task.notes && task.notes.includes("%")) {
                                const match = task.notes.match(/(\d+)%/);
                                if (match) return parseInt(match[1]);
                              }

                              // Default based on status
                              switch (task.status) {
                                case "pending":
                                  return 20;
                                case "in_progress":
                                  return 60;
                                case "completed":
                                  return 100;
                                default:
                                  return 0;
                              }
                            };

                            const getBudgetDisplay = (
                              task: JobCardItem
                            ): string => {
                              // Show the task amount as budget
                              if (task.amount)
                                return `$${parseFloat(task.amount).toFixed(2)}`;

                              // Calculate from labor hours and rate if amount not available
                              if (task.labor_hours && task.labor_rate) {
                                const total =
                                  parseFloat(task.labor_hours) *
                                  parseFloat(task.labor_rate);
                                return `$${total.toFixed(2)}`;
                              }
                              return "N/A";
                            };

                            const getBadgeClass = (status: string): string => {
                              switch (status) {
                                case "pending":
                                  return "badge-light-secondary";
                                case "in_progress":
                                  return "badge-light-warning";
                                case "completed":
                                  return "badge-light-success";
                                default:
                                  return "badge-light-secondary";
                              }
                            };

                            const getBadgeLabel = (status: string): string => {
                              switch (status) {
                                case "pending":
                                  return "Pending";
                                case "in_progress":
                                  return "In Progress";
                                case "completed":
                                  return "Completed";
                                default:
                                  return (
                                    status.charAt(0).toUpperCase() +
                                    status.slice(1)
                                  );
                              }
                            };

                            const getProgressBarClass = (
                              status: string
                            ): string => {
                              switch (status) {
                                case "pending":
                                  return "bg-secondary";
                                case "in_progress":
                                  return "bg-warning";
                                case "completed":
                                  return "bg-success";
                                default:
                                  return "bg-secondary";
                              }
                            };

                            const progressPercentage =
                              getProgressPercentage(task);
                            const badgeClass = getBadgeClass(task.status);
                            const badgeLabel = getBadgeLabel(task.status);
                            const progressBarClass = getProgressBarClass(
                              task.status
                            );
                            const taskAmount = parseFloat(task.amount).toFixed(
                              2
                            );

                            return (
                              <div className="col-xxl-4 col-md-6" key={task.id}>
                                <div
                                  className="project-card clickable-card"
                                  onClick={() =>
                                    openTaskModal && openTaskModal(task)
                                  }
                                  style={{
                                    cursor: "pointer",
                                    border: "1px solid #e8e8e8",
                                    borderRadius: "12px",
                                    padding: "20px",
                                    backgroundColor: "#fff",
                                    height: "100%",
                                    transition: "all 0.3s ease",
                                  }}
                                >
                                  {/* Header with title and badge */}
                                  <div className="d-flex justify-content-between align-items-start mb-3">
                                    <div
                                      style={{ flex: 1, paddingRight: "10px" }}
                                    >
                                      <h6
                                        style={{
                                          fontSize: "16px",
                                          fontWeight: "600",
                                          color: "#333",
                                          marginBottom: "4px",
                                          lineHeight: "1.3",
                                        }}
                                      >
                                        {getTaskTitle(task)}
                                      </h6>
                                      <p
                                        style={{
                                          fontSize: "14px",
                                          color: "#666",
                                          marginBottom: "8px",
                                          lineHeight: "1.4",
                                        }}
                                      >
                                        {getTaskSubtitle(task)}
                                      </p>
                                    </div>
                                    <span
                                      className={`badge ${badgeClass}`}
                                      style={{
                                        padding: "4px 12px",
                                        borderRadius: "20px",
                                        fontSize: "12px",
                                        fontWeight: "500",
                                        whiteSpace: "nowrap",
                                      }}
                                    >
                                      {badgeLabel}
                                    </span>
                                  </div>

                                  {/* Date */}
                                  <div className="mb-3">
                                    <p
                                      style={{
                                        fontSize: "12px",
                                        color: "#999",
                                        marginBottom: 0,
                                      }}
                                    >
                                      <i className="fa fa-calendar me-2"></i>
                                      {formatDate(task.created_at)}
                                    </p>
                                  </div>

                                  {/* Tasks/Amount row */}
                                  <div
                                    className="d-flex justify-content-between align-items-center mb-3"
                                    style={{
                                      paddingBottom: "12px",
                                      borderBottom: "1px solid #f0f0f0",
                                    }}
                                  >
                                    <span
                                      style={{
                                        fontSize: "14px",
                                        color: "#666",
                                      }}
                                    >
                                      Amount
                                    </span>
                                    <span
                                      style={{
                                        fontSize: "14px",
                                        fontWeight: "600",
                                        color: "#1bc5bd",
                                      }}
                                    >
                                      ${taskAmount}
                                    </span>
                                  </div>

                                  {/* Labor info */}
                                  <div className="mb-3">
                                    <div className="row">
                                      <div className="col-6">
                                        <small className="text-muted d-block">
                                          Labor Hours
                                        </small>
                                        <strong style={{ fontSize: "13px" }}>
                                          {task.labor_hours} hrs
                                        </strong>
                                      </div>
                                      <div className="col-6 text-end">
                                        <small className="text-muted d-block">
                                          Rate
                                        </small>
                                        <strong style={{ fontSize: "13px" }}>
                                          $
                                          {parseFloat(task.labor_rate).toFixed(
                                            2
                                          )}
                                          /hr
                                        </strong>
                                      </div>
                                    </div>
                                  </div>

                                  {/* Progress bar */}
                                  <div className="mt-3">
                                    <div className="d-flex justify-content-between mb-1">
                                      <span
                                        style={{
                                          fontSize: "14px",
                                          color: "#666",
                                        }}
                                      >
                                        Progress
                                      </span>
                                      <span
                                        style={{
                                          fontSize: "14px",
                                          color: "#333",
                                          fontWeight: "500",
                                        }}
                                      >
                                        {progressPercentage}%
                                      </span>
                                    </div>
                                    <div
                                      className="progress"
                                      style={{
                                        height: "6px",
                                        borderRadius: "3px",
                                        backgroundColor: "#f5f5f5",
                                      }}
                                    >
                                      <div
                                        className={`progress-bar ${progressBarClass}`}
                                        style={{
                                          width: `${progressPercentage}%`,
                                          borderRadius: "3px",
                                        }}
                                      ></div>
                                    </div>
                                  </div>

                                  {/* Task sequence and notes preview */}
                                  <div className="mt-3 pt-3 border-top">
                                    <div className="d-flex justify-content-between">
                                      <div>
                                        <small className="text-muted d-block">
                                          Task ID
                                        </small>
                                        <strong style={{ fontSize: "12px" }}>
                                          #{task.sequence || task.id}
                                        </strong>
                                      </div>
                                      {task.notes && (
                                        <div className="text-end">
                                          <small className="text-muted d-block">
                                            Notes
                                          </small>
                                          <small
                                            className="text-truncate"
                                            style={{
                                              maxWidth: "100px",
                                              display: "inline-block",
                                            }}
                                          >
                                            {task.notes.length > 20
                                              ? `${task.notes.substring(
                                                  0,
                                                  20
                                                )}...`
                                              : task.notes}
                                          </small>
                                        </div>
                                      )}
                                    </div>
                                  </div>
                                </div>
                              </div>
                            );
                          })
                        ) : (
                          <div className="col-12">
                            <div className="card">
                              <div className="card-body text-center py-5">
                                <i className="fa fa-tasks fa-3x text-muted mb-3"></i>
                                <h5>No Tasks Assigned</h5>
                                <p className="text-muted">
                                  No tasks have been added to this job card yet.
                                </p>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Summary Cards */}
                      {jobCard.items.length > 0 && (
                        <div className="row g-4 mt-4">
                          <div className="col-xxl-3 col-md-6">
                            <div
                              className="summary-card"
                              style={{
                                border: "1px solid #e8e8e8",
                                borderRadius: "12px",
                                padding: "20px",
                                backgroundColor: "#fff",
                                height: "100%",
                              }}
                            >
                              <div className="d-flex align-items-center">
                                <div
                                  style={{
                                    width: "50px",
                                    height: "50px",
                                    backgroundColor: "rgba(27, 197, 189, 0.1)",
                                    borderRadius: "10px",
                                    display: "flex",
                                    alignItems: "center",
                                    justifyContent: "center",
                                    marginRight: "15px",
                                  }}
                                >
                                  <i
                                    className="fa fa-list-check"
                                    style={{
                                      fontSize: "1.5rem",
                                      color: "#1bc5bd",
                                    }}
                                  ></i>
                                </div>
                                <div>
                                  <h6
                                    style={{
                                      fontSize: "14px",
                                      color: "#666",
                                      marginBottom: "4px",
                                    }}
                                  >
                                    Total Tasks
                                  </h6>
                                  <h3
                                    style={{
                                      fontSize: "24px",
                                      fontWeight: "600",
                                      color: "#1bc5bd",
                                      marginBottom: "0",
                                    }}
                                  >
                                    {jobCard.items.length}
                                  </h3>
                                </div>
                              </div>
                              <p
                                style={{
                                  fontSize: "12px",
                                  color: "#999",
                                  marginTop: "8px",
                                  marginBottom: "0",
                                }}
                              >
                                {jobCard.items.length} tasks in this job
                              </p>
                            </div>
                          </div>

                          <div className="col-xxl-3 col-md-6">
                            <div
                              className="summary-card"
                              style={{
                                border: "1px solid #e8e8e8",
                                borderRadius: "12px",
                                padding: "20px",
                                backgroundColor: "#fff",
                                height: "100%",
                              }}
                            >
                              <div className="d-flex align-items-center">
                                <div
                                  style={{
                                    width: "50px",
                                    height: "50px",
                                    backgroundColor: "rgba(137, 80, 252, 0.1)",
                                    borderRadius: "10px",
                                    display: "flex",
                                    alignItems: "center",
                                    justifyContent: "center",
                                    marginRight: "15px",
                                  }}
                                >
                                  <i
                                    className="fa fa-clock"
                                    style={{
                                      fontSize: "1.5rem",
                                      color: "#8950fc",
                                    }}
                                  ></i>
                                </div>
                                <div>
                                  <h6
                                    style={{
                                      fontSize: "14px",
                                      color: "#666",
                                      marginBottom: "4px",
                                    }}
                                  >
                                    Pending Tasks
                                  </h6>
                                  <h3
                                    style={{
                                      fontSize: "24px",
                                      fontWeight: "600",
                                      color: "#8950fc",
                                      marginBottom: "0",
                                    }}
                                  >
                                    {
                                      jobCard.items.filter(
                                        (t) => t.status === "pending"
                                      ).length
                                    }
                                  </h3>
                                </div>
                              </div>
                              <p
                                style={{
                                  fontSize: "12px",
                                  color: "#999",
                                  marginTop: "8px",
                                  marginBottom: "0",
                                }}
                              >
                                Tasks not yet started
                              </p>
                            </div>
                          </div>

                          <div className="col-xxl-3 col-md-6">
                            <div
                              className="summary-card"
                              style={{
                                border: "1px solid #e8e8e8",
                                borderRadius: "12px",
                                padding: "20px",
                                backgroundColor: "#fff",
                                height: "100%",
                              }}
                            >
                              <div className="d-flex align-items-center">
                                <div
                                  style={{
                                    width: "50px",
                                    height: "50px",
                                    backgroundColor: "rgba(255, 168, 0, 0.1)",
                                    borderRadius: "10px",
                                    display: "flex",
                                    alignItems: "center",
                                    justifyContent: "center",
                                    marginRight: "15px",
                                  }}
                                >
                                  <i
                                    className="fa fa-spinner"
                                    style={{
                                      fontSize: "1.5rem",
                                      color: "#ffa800",
                                    }}
                                  ></i>
                                </div>
                                <div>
                                  <h6
                                    style={{
                                      fontSize: "14px",
                                      color: "#666",
                                      marginBottom: "4px",
                                    }}
                                  >
                                    In Progress
                                  </h6>
                                  <h3
                                    style={{
                                      fontSize: "24px",
                                      fontWeight: "600",
                                      color: "#ffa800",
                                      marginBottom: "0",
                                    }}
                                  >
                                    {
                                      jobCard.items.filter(
                                        (t) => t.status === "in_progress"
                                      ).length
                                    }
                                  </h3>
                                </div>
                              </div>
                              <p
                                style={{
                                  fontSize: "12px",
                                  color: "#999",
                                  marginTop: "8px",
                                  marginBottom: "0",
                                }}
                              >
                                Tasks currently being worked on
                              </p>
                            </div>
                          </div>

                          <div className="col-xxl-3 col-md-6">
                            <div
                              className="summary-card"
                              style={{
                                border: "1px solid #e8e8e8",
                                borderRadius: "12px",
                                padding: "20px",
                                backgroundColor: "#fff",
                                height: "100%",
                              }}
                            >
                              <div className="d-flex align-items-center">
                                <div
                                  style={{
                                    width: "50px",
                                    height: "50px",
                                    backgroundColor: "rgba(40, 167, 69, 0.1)",
                                    borderRadius: "10px",
                                    display: "flex",
                                    alignItems: "center",
                                    justifyContent: "center",
                                    marginRight: "15px",
                                  }}
                                >
                                  <i
                                    className="fa fa-check-circle"
                                    style={{
                                      fontSize: "1.5rem",
                                      color: "#28a745",
                                    }}
                                  ></i>
                                </div>
                                <div>
                                  <h6
                                    style={{
                                      fontSize: "14px",
                                      color: "#666",
                                      marginBottom: "4px",
                                    }}
                                  >
                                    Completed
                                  </h6>
                                  <h3
                                    style={{
                                      fontSize: "24px",
                                      fontWeight: "600",
                                      color: "#28a745",
                                      marginBottom: "0",
                                    }}
                                  >
                                    {
                                      jobCard.items.filter(
                                        (t) => t.status === "completed"
                                      ).length
                                    }
                                  </h3>
                                </div>
                              </div>
                              <p
                                style={{
                                  fontSize: "12px",
                                  color: "#999",
                                  marginTop: "8px",
                                  marginBottom: "0",
                                }}
                              >
                                Successfully finished tasks
                              </p>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </TabPane>
                  {/* Parts Used Tab */}
                  <TabPane tabId="3">
                    <div className="table-responsive">
                      <Table bordered hover>
                        <thead>
                          <tr>
                            <th>Part ID</th>
                            <th>Part Name</th>
                            <th>Quantity</th>
                            <th>Unit Price</th>
                            <th>Total</th>
                            <th>Source</th>
                            <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          {jobCard.parts.length > 0 ? (
                            jobCard.parts.map((part) => (
                              <tr key={part.id}>
                                <td>{part.part_id}</td>
                                <td>{part.part_name || "Unnamed Part"}</td>
                                <td>{part.quantity}</td>
                                <td>
                                  ${parseFloat(part.unit_price).toFixed(2)}
                                </td>
                                <td>${parseFloat(part.amount).toFixed(2)}</td>
                                <td>
                                  <Badge
                                    color={
                                      part.source === "stock"
                                        ? "success"
                                        : "info"
                                    }
                                  >
                                    {part.source}
                                  </Badge>
                                </td>
                                <td>
                                  <button
                                    className="action-btn text-white border btn-danger"
                                    onClick={() => handleDeletePart(part.id)} // Changed from part.part_id to part.id
                                    title="Delete"
                                    disabled={updating === "delete-part"}
                                  >
                                    {updating === "delete-part" ? (
                                      <Spinner size="sm" />
                                    ) : (
                                      <i className="fa fa-trash"></i>
                                    )}
                                  </button>
                                </td>
                              </tr>
                            ))
                          ) : (
                            <tr>
                              <td colSpan={6} className="text-center">
                                <div className="py-3 text-muted">
                                  <i className="fa fa-box fa-2x mb-2"></i>
                                  <p>No parts used in this job</p>
                                </div>
                              </td>
                            </tr>
                          )}
                          <tr className="table-primary">
                            <td colSpan={4} className="text-end">
                              <strong>Parts Total:</strong>
                            </td>
                            <td>
                              <strong>${partsTotal.toFixed(2)}</strong>
                            </td>
                            <td></td>
                            <td></td>
                          </tr>
                        </tbody>
                      </Table>
                    </div>
                  </TabPane>

                  {/* Payments Tab */}
                  <TabPane tabId="4">
                    <Table bordered hover>
                      <thead>
                        <tr>
                          <th>Date</th>
                          <th>Amount</th>
                          <th>Method</th>
                          <th>Transaction ID</th>
                          <th>Status</th>
                        </tr>
                      </thead>
                      <tbody>
                        {jobCard.payments.length > 0 ? (
                          jobCard.payments.map((payment) => (
                            <tr key={payment.id}>
                              <td>{formatDateTime(payment.created_at)}</td>
                              <td>${parseFloat(payment.amount).toFixed(2)}</td>
                              <td>{payment.payment_method || "-"}</td>
                              <td>{payment.transaction_id || "-"}</td>
                              <td>
                                <Badge
                                  color={
                                    payment.status === "completed"
                                      ? "success"
                                      : payment.status === "pending"
                                      ? "warning"
                                      : "danger"
                                  }
                                >
                                  {payment.status}
                                </Badge>
                              </td>
                            </tr>
                          ))
                        ) : (
                          <tr>
                            <td colSpan={5} className="text-center">
                              <div className="py-3 text-muted">
                                <i className="fa fa-credit-card fa-2x mb-2"></i>
                                <p>No payments recorded</p>
                                <Button
                                  color="primary"
                                  size="sm"
                                  onClick={() => {
                                    // TODO: Implement add payment
                                    toast.info(
                                      "Add payment feature coming soon"
                                    );
                                  }}
                                >
                                  Add Payment
                                </Button>
                              </div>
                            </td>
                          </tr>
                        )}
                        {jobCard.payments.length > 0 && (
                          <tr className="table-info">
                            <td colSpan={1} className="text-end">
                              <strong>Total Received:</strong>
                            </td>
                            <td>
                              <strong>
                                $
                                {jobCard.payments
                                  .reduce(
                                    (sum, payment) =>
                                      sum + parseFloat(payment.amount),
                                    0
                                  )
                                  .toFixed(2)}
                              </strong>
                            </td>
                            <td colSpan={3}></td>
                          </tr>
                        )}
                      </tbody>
                    </Table>
                  </TabPane>
                </TabContent>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Container>
      <style jsx>
        {`
          /* Task Cards */
          .task-card {
            transition: all 0.2s ease;
            border: 1px solid #e9ecef;
            height: 100%;
            border-radius: 10px;
          }

          .task-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            border-color: #007bff;
          }

          .clickable-card {
            cursor: pointer;
          }

          .clickable-card:active {
            transform: translateY(-1px);
          }

          .text-truncate-2 {
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
            text-overflow: ellipsis;
          }

          .text-truncate-3 {
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            overflow: hidden;
            text-overflow: ellipsis;
          }

          /* Status badges in cards */
          .task-card .badge {
            font-size: 0.7rem;
            padding: 0.25rem 0.5rem;
            border-radius: 20px;
          }

          /* Modal enhancements */
          .modal-header.bg-primary {
            background: linear-gradient(
              135deg,
              #667eea 0%,
              #764ba2 100%
            ) !important;
          }

          /* Card hover animation */
          @keyframes cardHover {
            0% {
              transform: translateY(0);
            }
            100% {
              transform: translateY(-3px);
            }
          }

          .task-card:hover {
            animation: cardHover 0.2s ease forwards;
          }

          /* Empty state */
          .empty-state {
            padding: 3rem 1rem;
            text-align: center;
            color: #6c757d;
          }

          .empty-state i {
            font-size: 4rem;
            margin-bottom: 1rem;
            opacity: 0.5;
          }

          /* Responsive adjustments */
          @media (max-width: 768px) {
            .task-card {
              margin-bottom: 1rem;
            }

            .task-card .col-4 {
              padding: 0 3px;
            }

            .task-card .text-center {
              font-size: 0.85rem;
            }
          }

          /* Summary cards */
          .summary-card {
            border: none;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
          }

          .summary-card .border {
            border-color: #dee2e6 !important;
          }

          .summary-card h4 {
            font-weight: 600;
          }

          // dashboard-card
          .project-card:hover {
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            transform: translateY(-2px);
          }

          .badge-light-secondary {
            background-color: #eef0fa !important;
            color: #8950fc !important;
          }

          .badge-light-warning {
            background-color: #fff4de !important;
            color: #ffa800 !important;
          }

          .badge-light-success {
            background-color: #e7f7ef !important;
            color: #1bc5bd !important;
          }

          .bg-secondary {
            background-color: #8950fc !important;
          }

          .bg-warning {
            background-color: #ffa800 !important;
          }

          .bg-success {
            background-color: #1bc5bd !important;
          }
        `}
      </style>
      {/* <TaskModal
        isOpen={isTaskModalOpen}
        toggle={toggleTaskModal}
        task={selectedTask}
        onStatusChange={handleModalStatusChange}
        onNotesSave={handleModalNotesSave}
        loading={updating !== null}
        loadingTaskId={
          updating?.startsWith("task-") ? selectedTask?.id || null : null
        }
        formatDateTime={formatDateTime}
      /> */}
      <TaskModal
        isOpen={isTaskModalOpen}
        toggle={toggleTaskModal}
        task={selectedTask}
        onUpdate={handleTaskUpdate}
        loading={loading}
        onSuccess={fetchJobCard}
      />
    </div>
  );
}

export default WorkDetailPage;
