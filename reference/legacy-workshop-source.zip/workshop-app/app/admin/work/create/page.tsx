"use client";
import Breadcrumbs from "@/CommonElements/Breadcrumbs";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  Form,
  FormGroup,
  Label,
  Input,
  Button,
} from "reactstrap";
import React, { useState, ChangeEvent } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";

function Page() {
  const router = useRouter();
  const [formData, setFormData] = useState({
    jobCardNumber: "",
    vehicleNumber: "",
    vehicleModel: "",
    reportedIssue: "",
    assignedTechnician: "",
    estimatedCompletion: "",
    priority: "medium",
    status: "pending",
  });

  const handleInputChange = (
    e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission logic here
    console.log("Form submitted:", formData);
    // Redirect back to work assignments page
    router.push("/admin/work");
  };

  const technicians = [
    { id: 1, name: "Mike Smith" },
    { id: 2, name: "Sarah Johnson" },
    { id: 3, name: "David Wilson" },
  ];

  return (
    <div className="page-body">
      <div className="container-fluid">
        <div className="page-title">
          <div className="row">
            <div className="col-sm-6">
              <h3>Create Work</h3>
            </div>
            <div className="col-sm-6">
              <ol className="breadcrumb">
                <li className="breadcrumb-item">
                  <Link href="/admin">
                    <svg className="stroke-icon">
                      <use href="../assets/svg/icon-sprite.svg#stroke-home"></use>
                    </svg>
                  </Link>
                </li>
                <li className="breadcrumb-item">
                  <Link href="/admin/work">Work</Link>
                </li>
                <li className="breadcrumb-item active">Create</li>
              </ol>
            </div>
          </div>
        </div>
      </div>

      <div className="container-fluid">
        <Row>
          <Col sm="12">
            <Card>
              <CardBody>
                <Form
                  className="form-bookmark needs-validation"
                  onSubmit={handleSubmit}
                >
                  <Row className="text-muted">
                    <Col md="6">
                      <FormGroup>
                        <Label>Job Card Number</Label>
                        <Input
                          type="text"
                          name="jobCardNumber"
                          value={formData.jobCardNumber}
                          onChange={handleInputChange}
                          required
                          placeholder="Enter job card number"
                        />
                      </FormGroup>
                    </Col>

                    <Col md="6">
                      <FormGroup>
                        <Label>Vehicle Number</Label>
                        <Input
                          type="text"
                          name="vehicleNumber"
                          value={formData.vehicleNumber}
                          onChange={handleInputChange}
                          required
                          placeholder="Enter vehicle number"
                        />
                      </FormGroup>
                    </Col>

                    <Col md="6">
                      <FormGroup>
                        <Label>Vehicle Model</Label>
                        <Input
                          type="text"
                          name="vehicleModel"
                          value={formData.vehicleModel}
                          onChange={handleInputChange}
                          required
                          placeholder="Enter vehicle model"
                        />
                      </FormGroup>
                    </Col>

                    <Col md="6">
                      <FormGroup>
                        <Label>Assigned Technician</Label>
                        <Input
                          type="select"
                          name="assignedTechnician"
                          value={formData.assignedTechnician}
                          onChange={handleInputChange}
                          required
                          style={{fontSize:'0.9rem'}}
                          className="border"
                        >
                          <option value="">Select Technician</option>
                          {technicians.map((tech) => (
                            <option key={tech.id} value={tech.name}>
                              {tech.name}
                            </option>
                          ))}
                        </Input>
                      </FormGroup>
                    </Col>

                    <Col md="6">
                      <FormGroup>
                        <Label>Estimated Completion</Label>
                        <Input
                          type="date"
                          name="estimatedCompletion"
                          value={formData.estimatedCompletion}
                          onChange={handleInputChange}
                          required
                        />
                      </FormGroup>
                    </Col>

                    <Col md="6">
                      <FormGroup>
                        <Label>Priority</Label>
                        <Input
                          type="select"
                          name="priority"
                          value={formData.priority}
                          onChange={handleInputChange}
                            style={{fontSize:'0.9rem'}}
                          className="border"
                          required
                        >
                          <option value="low">Low</option>
                          <option value="medium">Medium</option>
                          <option value="high">High</option>
                          <option value="urgent">Urgent</option>
                        </Input>
                      </FormGroup>
                    </Col>

                    <Col md="6">
                      <FormGroup>
                        <Label>Status</Label>
                        <Input
                          type="select"
                          name="status"
                          value={formData.status}
                          onChange={handleInputChange}
                            style={{fontSize:'0.9rem'}}
                          className="border"
                          required
                        >
                          <option value="pending">Pending</option>
                          <option value="in-progress">In Progress</option>
                          <option value="completed">Completed</option>
                          <option value="cancelled">Cancelled</option>
                        </Input>
                      </FormGroup>
                    </Col>

                    <Col md="12">
                      <FormGroup>
                        <Label>Reported Issue</Label>
                        <Input
                          type="textarea"
                          name="reportedIssue"
                          value={formData.reportedIssue}
                          onChange={handleInputChange}
                          rows={4}
                          required
                          placeholder="Describe the reported issue..."
                        />
                      </FormGroup>
                    </Col>
                  </Row>

                  <div className="d-flex gap-2 mt-3">
                    <Button color="primary" type="submit">
                      Create Assignment
                    </Button>
                    <Link href="/admin/work">
                      <Button color="secondary" type="button">
                        Cancel
                      </Button>
                    </Link>
                  </div>
                </Form>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </div>
    </div>
  );
}

export default Page;
