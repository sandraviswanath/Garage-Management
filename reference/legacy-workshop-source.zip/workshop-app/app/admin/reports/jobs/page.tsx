"use client";
import Breadcrumbs from "@/CommonElements/Breadcrumbs";
import CustomPagination from "@/CommonElements/Pagination";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  Input,
  Button,
  Table,
  Badge,
  Form,
  FormGroup,
  Label,
  Spinner,
  Alert,
} from "reactstrap";
import React, { useState, ChangeEvent, useEffect, useRef } from "react";
import { useAuth } from "@/helper/AuthContext";
import { toast } from "react-toastify";
import Link from "next/link";
import * as XLSX from "xlsx";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import withAuth from "@/helper/WithAuth";

// API Response Types
interface ApiJobSummary {
  id: string;
  job_number: string;
  customer_id: string;
  vehicle_id: string;
  created_by: string;
  assigned_to: string;
  status: string;
  reported_issue: string;
  diagnosis: string | null;
  labor_estimate: string;
  parts_estimate: string;
  total_estimate: string;
  priority: string;
  expected_completion: string;
  actual_completion: string | null;
  is_paid: string;
  meta: string;
  created_at: string;
  updated_at: string;
  name: string; // Customer name
}

interface Technician {
  id: string;
  username: string;
}

function JobSummaryReport() {
  const { state } = useAuth();
  const [currentPage, setCurrentPage] = useState(1);
  const [jobs, setJobs] = useState<ApiJobSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingTechnicians, setLoadingTechnicians] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [technicians, setTechnicians] = useState<Technician[]>([]);
  const [technicianSearchTerm, setTechnicianSearchTerm] = useState("");
  const [isTechnicianDropdownOpen, setIsTechnicianDropdownOpen] =
    useState(false);
  const [selectedTechnicianName, setSelectedTechnicianName] = useState("");

  const [serviceSearchTerm, setServiceSearchTerm] = useState("");
  const [isServiceDropdownOpen, setIsServiceDropdownOpen] = useState(false);
  const [selectedServiceName, setSelectedServiceName] = useState("");
  const serviceDropdownRef = useRef<HTMLDivElement | null>(null);

  const [filters, setFilters] = useState({
    dateFrom: "",
    dateTo: "",
    status: "all",
    technician: "all",
    serviceType: "all",
  });
  const itemsPerPage = 10;

  const technicianDropdownRef = useRef<HTMLDivElement | null>(null);

  // Fetch job summary data from API
  useEffect(() => {
    fetchJobSummaryData();
    fetchTechniciansList();
  }, []);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        technicianDropdownRef.current &&
        !technicianDropdownRef.current.contains(event.target as Node)
      ) {
        setIsTechnicianDropdownOpen(false);
      }
      if (
        serviceDropdownRef.current &&
        !serviceDropdownRef.current.contains(event.target as Node)
      ) {
        setIsServiceDropdownOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const fetchJobSummaryData = async () => {
    try {
      setLoading(true);
      setError(null);
      const token = state?.accessToken || localStorage.getItem("token");

      if (!token) {
        throw new Error("No authentication token found");
      }

      const response = await fetch("/api/reports/job_summary", {
        method: "GET",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch job summary: ${response.status}`);
      }

      const data = await response.json();
      setJobs(data.data || []);
    } catch (err) {
      console.error("Error fetching job summary:", err);
      setError(
        err instanceof Error ? err.message : "Failed to load job summary data"
      );
      setJobs([]);
    } finally {
      setLoading(false);
    }
  };

  const fetchTechniciansList = async () => {
    try {
      setLoadingTechnicians(true);
      const token = state?.accessToken || localStorage.getItem("token");

      if (!token) {
        throw new Error("No authentication token found");
      }

      const response = await fetch("/api/technicians_list", {
        method: "GET",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch technicians: ${response.status}`);
      }

      const data = await response.json();
      setTechnicians(data.data || []);
    } catch (err) {
      console.error("Error fetching technicians:", err);
      toast.error("Failed to load technicians list");
      setTechnicians([]);
    } finally {
      setLoadingTechnicians(false);
    }
  };

  // Helper function to parse meta data
  const parseMetaData = (metaString: string) => {
    try {
      return JSON.parse(metaString || "{}");
    } catch {
      return {};
    }
  };

  // Get technician name by ID
  const getTechnicianName = (technicianId: string) => {
    const technician = technicians.find((tech) => tech.id === technicianId);
    return technician ? technician.username : `Tech ID: ${technicianId}`;
  };
  // Get service type for display
  const getServiceType = (job: ApiJobSummary) => {
    return (
      job.reported_issue || (job.diagnosis ? job.diagnosis : "General Service")
    );
  };

  // Get unique service types from API data
  const getAllServiceTypes = () => {
    const serviceTypes = jobs.map(
      (job) =>
        job.reported_issue ||
        (job.diagnosis ? job.diagnosis : "General Service")
    );
    return [...new Set(serviceTypes)].filter(
      (type) => type && type.trim() !== ""
    );
  };
  // Filter jobs
  const filteredJobs = jobs.filter((job) => {
    const jobDate = job.created_at.split(" ")[0]; // Extract date part from datetime
    const matchesDate =
      (!filters.dateFrom || jobDate >= filters.dateFrom) &&
      (!filters.dateTo || jobDate <= filters.dateTo);

    const matchesStatus =
      filters.status === "all" || job.status.toLowerCase() === filters.status;

    // Get technician name
    const technicianName = getTechnicianName(job.assigned_to);
    const matchesTechnician =
      filters.technician === "all" || job.assigned_to === filters.technician;

    // Get service type from reported_issue or diagnosis
    const serviceType =
      job.reported_issue || (job.diagnosis ? job.diagnosis : "General Service");
    const matchesServiceType =
      filters.serviceType === "all" || serviceType === filters.serviceType;

    return (
      matchesDate && matchesStatus && matchesTechnician && matchesServiceType
    );
  });

  // Calculate summary metrics directly from API data
  const calculateMetrics = () => {
    const totalJobs = filteredJobs.length;

    // Count completed jobs (assuming 'completed' status)
    const completedJobs = filteredJobs.filter(
      (job) => job.status.toLowerCase() === "completed"
    ).length;

    // Calculate total revenue from completed jobs
    const totalRevenue = filteredJobs
      .filter((job) => job.status.toLowerCase() === "completed")
      .reduce(
        (sum: number, job: ApiJobSummary) =>
          sum + parseFloat(job.total_estimate || "0"),
        0
      );

    // Calculate average completion time
    const completedJobsData = filteredJobs.filter(
      (job) => job.status.toLowerCase() === "completed"
    );
    const totalDuration = completedJobsData.reduce(
      (sum: number, job: ApiJobSummary) => {
        if (job.created_at && job.actual_completion) {
          const start = new Date(job.created_at);
          const end = new Date(job.actual_completion);
          const durationHours = Math.round(
            (end.getTime() - start.getTime()) / (1000 * 60 * 60)
          );
          return sum + durationHours;
        }
        return sum;
      },
      0
    );

    const avgCompletionTime =
      completedJobs > 0 ? totalDuration / completedJobs : 0;

    return {
      totalJobs,
      completedJobs,
      totalRevenue,
      avgCompletionTime: Math.round(avgCompletionTime * 10) / 10,
      completionRate:
        totalJobs > 0 ? Math.round((completedJobs / totalJobs) * 100) : 0,
    };
  };

  const metrics = calculateMetrics();

  // Filter technicians based on search
  const filteredTechnicians = technicians.filter((tech) =>
    tech.username.toLowerCase().includes(technicianSearchTerm.toLowerCase())
  );

  // Filter service types based on search
  const allServiceTypes = getAllServiceTypes();
  const filteredServiceTypes = allServiceTypes.filter((service) =>
    service.toLowerCase().includes(serviceSearchTerm.toLowerCase())
  );

  // Get unique values for other filters from API data
  const serviceTypes = [
    ...new Set(
      jobs.map((job) => {
        return (
          job.reported_issue ||
          (job.diagnosis ? job.diagnosis : "General Service")
        );
      })
    ),
  ];

  // Get status options from API data
  const statusOptions = [
    ...new Set(jobs.map((job) => job.status.toLowerCase())),
  ];

  // Pagination
  const totalPages = Math.ceil(filteredJobs.length / itemsPerPage);
  const paginatedJobs = filteredJobs.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const flattenData = () =>
    filteredJobs.map((item, idx) => ({
      // SNo: idx + 1,
      JobNumber: item.job_number,
      Customer: item.name || "N/A",
      Issue: item.reported_issue,
      LaborEstimate: item.labor_estimate,
      PartsEstimate: item.parts_estimate,
      TotalEstimate: item.total_estimate,

      // Amount: item.total_estimate,
      CreatedDate: new Date(item.created_at).toLocaleDateString(),
    }));

  const exportToExcel = () => {
    const ws = XLSX.utils.json_to_sheet(flattenData());
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Job Summary Report");
    XLSX.writeFile(wb, "job_summary_report.xlsx");
  };

  const exportToPDF = () => {
    const doc = new jsPDF();
    doc.text("Job Summary Report", 14, 10);
    autoTable(doc, {
      head: [
        [
          "Job Number",
          "Customer",
          "Reported issue",
          "Labor Estimate",
          "Parts Estimate",
          "Total Estimate",
          // "Amount",
          "Date",
        ],
      ],
      body: flattenData().map((d) => [
        d.JobNumber,
        d.Customer,
        d.Issue,
        d.LaborEstimate,
        d.PartsEstimate,
        d.TotalEstimate,

        // d.Amount,
        d.CreatedDate,
      ]),
      startY: 20,
      styles: { fontSize: 8, cellWidth: "wrap" },
      theme: "grid",
    });

    doc.save("job_summary_report.pdf");
  };

  // Status badge renderer
  const renderStatusBadge = (status: string) => {
    const statusLower = status.toLowerCase();
    const statusConfig: Record<string, { class: string; label: string }> = {
      completed: { class: "bg-success", label: "Completed" },
      "in-progress": { class: "bg-primary", label: "In Progress" },
      open: { class: "bg-info", label: "Open" },
      pending: { class: "bg-warning", label: "Pending" },
      cancelled: { class: "bg-danger", label: "Cancelled" },
    };

    const config = statusConfig[statusLower] || {
      class: "bg-secondary",
      label: status,
    };

    return <Badge className={config.class}>{config.label}</Badge>;
  };

  // Get service type
  // const getServiceType = (job: ApiJobSummary) => {
  //   return (
  //     job.reported_issue || (job.diagnosis ? job.diagnosis : "General Service")
  //   );
  // };

  // Format date for display
  const formatDate = (dateString: string | null) => {
    if (!dateString || dateString === "0000-00-00 00:00:00") {
      return "-";
    }
    const date = new Date(dateString);
    return date.toLocaleDateString();
  };

  const handleFilterChange = (field: string, value: string) => {
    setFilters((prev) => ({
      ...prev,
      [field]: value,
    }));
    setCurrentPage(1); // Reset to first page when filters change
  };

  const handleTechnicianSelect = (
    technicianId: string,
    technicianName: string
  ) => {
    handleFilterChange("technician", technicianId);
    setSelectedTechnicianName(technicianName);
    setIsTechnicianDropdownOpen(false);
    setTechnicianSearchTerm("");
  };

  const clearTechnicianFilter = () => {
    handleFilterChange("technician", "all");
    setSelectedTechnicianName("");
    setTechnicianSearchTerm("");
  };

  const handleExport = (format: "pdf" | "excel") => {
    // In a real application, this would generate and download the file
    console.log(`Exporting to ${format} with filters:`, filters);

    // You can create an API endpoint for exporting
    const exportUrl = `/api/reports/export/job_summary?format=${format}&${new URLSearchParams(
      filters as any
    ).toString()}`;
    window.open(exportUrl, "_blank");

    alert(`Exporting job summary report to ${format.toUpperCase()}`);
  };

  const resetFilters = () => {
    setFilters({
      dateFrom: "",
      dateTo: "",
      status: "all",
      technician: "all",
      serviceType: "all",
    });
    setSelectedTechnicianName("");
    setTechnicianSearchTerm("");
  };

  // Refresh data
  const refreshData = () => {
    fetchJobSummaryData();
    fetchTechniciansList();
  };

  if (loading) {
    return (
      <div className="page-body">
        <Breadcrumbs
          title="Job Summary Report"
          mainTitle="Job Cards Analysis"
          parent="Reports"
        />
        <Container fluid>
          <Row className="justify-content-center mt-5">
            <Col className="text-center">
              <Spinner color="primary" />
              <p className="mt-3">Loading job summary data...</p>
            </Col>
          </Row>
        </Container>
      </div>
    );
  }

  if (error) {
    return (
      <div className="page-body">
        <Breadcrumbs
          title="Job Summary Report"
          mainTitle="Job Cards Analysis"
          parent="Reports"
        />
        <Container fluid>
          <Row>
            <Col sm="12">
              <Card>
                <CardBody className="text-center py-5">
                  <h5 className="text-danger">Error Loading Data</h5>
                  <p className="text-muted">{error}</p>
                  <Button color="primary" onClick={refreshData}>
                    <i className="fa fa-refresh me-2"></i>
                    Try Again
                  </Button>
                </CardBody>
              </Card>
            </Col>
          </Row>
        </Container>
      </div>
    );
  }

  return (
    <div className="page-body">
      <Breadcrumbs
        title="Job Summary Report"
        mainTitle="Job Cards Analysis"
        parent="Reports"
      />

      <Container fluid>
        <Row>
          <Col sm="12">
            <Card>
              <CardBody>
                {/* Header with refresh button */}
                <div className="d-flex justify-content-between align-items-center mb-4">
                  <h5 className="card-title mb-0">Job Summary Report</h5>
                  <div className="d-flex gap-2">
                    <Button color="outline-primary" onClick={refreshData}>
                      <i className="fa fa-refresh me-2"></i>
                      Refresh
                    </Button>
                    <Button color="outline-primary" onClick={exportToExcel}>
                      <i className="fa fa-file-excel me-2"></i>
                      Export Excel
                    </Button>
                    <Button color="outline-danger" onClick={exportToPDF}>
                      <i className="fa fa-file-pdf me-2"></i>
                      Export PDF
                    </Button>
                  </div>
                </div>

                {/* Filters */}
                <Card className="bg-light mb-4">
                  <CardBody>
                    <h6 className="mb-3 text-muted">Filter Report</h6>
                    <Form>
                      <Row>
                        <Col md="3">
                          <FormGroup className="text-muted">
                            <Label>Date From</Label>
                            <Input
                              type="date"
                              value={filters.dateFrom}
                              onChange={(e: ChangeEvent<HTMLInputElement>) =>
                                handleFilterChange("dateFrom", e.target.value)
                              }
                            />
                          </FormGroup>
                        </Col>
                        <Col md="3">
                          <FormGroup className="text-muted">
                            <Label>Date To</Label>
                            <Input
                              type="date"
                              value={filters.dateTo}
                              onChange={(e: ChangeEvent<HTMLInputElement>) =>
                                handleFilterChange("dateTo", e.target.value)
                              }
                            />
                          </FormGroup>
                        </Col>
                        <Col md="3">
                          <FormGroup className="text-muted">
                            <Label>Status</Label>
                            <Input
                              type="select"
                              className="border"
                              value={filters.status}
                              onChange={(e: ChangeEvent<HTMLInputElement>) =>
                                handleFilterChange("status", e.target.value)
                              }
                            >
                              <option value="all">All Status</option>
                              {statusOptions.map((status) => (
                                <option key={status} value={status}>
                                  {status.charAt(0).toUpperCase() +
                                    status.slice(1)}
                                </option>
                              ))}
                            </Input>
                          </FormGroup>
                        </Col>

                        <Col md="3">
                          <FormGroup className="text-muted">
                            <Label>Technician</Label>
                            {loading ? (
                              <div className="d-flex align-items-center">
                                <Spinner size="sm" className="me-2" />
                                Loading customers...
                              </div>
                            ) : technicians.length === 0 ? (
                              <div className="text-danger">
                                No technician found. Please add a customer
                                first.
                              </div>
                            ) : (
                              <div
                                className="position-relative"
                                ref={technicianDropdownRef}
                              >
                                {/* Dropdown trigger */}
                                <div
                                  onClick={() =>
                                    setIsTechnicianDropdownOpen(
                                      !isTechnicianDropdownOpen
                                    )
                                  }
                                  className="d-flex w-100 align-items-center justify-content-between cursor-pointer form-select border"
                                  style={{
                                    minHeight: "38px",
                                    padding: "0.375rem 0.75rem",
                                    cursor: "pointer",
                                  }}
                                >
                                  <span
                                    className="text-truncate"
                                    style={{ maxWidth: "calc(100% - 20px)" }}
                                  >
                                    {selectedTechnicianName ||
                                      "Select Technician"}
                                  </span>
                                  {/* <span
                                    className="ms-2 text-muted"
                                    style={{ flexShrink: 0 }}
                                  >
                                    {isTechnicianDropdownOpen ? "▲" : "▼"}
                                  </span> */}
                                </div>

                                {/* Dropdown menu */}
                                {isTechnicianDropdownOpen && (
                                  <div
                                    // className="position-absolute w-100 mt-1 bg-white border rounded shadow"
                                    className="position-absolute w-100 mt-1 border rounded shadow dropdown-menu show"
                                    style={{
                                      maxHeight: "300px",
                                      overflow: "auto",
                                      zIndex: 1050,
                                    }}
                                  >
                                    {/* Search input */}
                                    <div className="p-2 border-bottom">
                                      <Input
                                        type="text"
                                        value={technicianSearchTerm}
                                        onChange={(e) => {
                                          setTechnicianSearchTerm(
                                            e.target.value
                                          );
                                        }}
                                        placeholder="Search technicians..."
                                        className="form-control form-control-sm"
                                        autoFocus
                                        onClick={(e) => e.stopPropagation()}
                                      />
                                    </div>

                                    {/* Customer list */}
                                    <div
                                      style={{
                                        maxHeight: "200px",
                                        overflowY: "auto",
                                      }}
                                    >
                                      {filteredTechnicians.length > 0 ? (
                                        <ul className="list-unstyled mb-0">
                                          {filteredTechnicians.map(
                                            (technician) => (
                                              <li
                                                key={technician.id}
                                                onClick={() =>
                                                  handleTechnicianSelect(
                                                    technician.id,
                                                    technician.username
                                                  )
                                                }
                                                // className="px-3 py-2 cursor-pointer hover-bg-light"
                                                // style={{ cursor: "pointer" }}
                                                className="px-3 py-2 cursor-pointer dropdown-item"
                                              >
                                                <div className="d-flex align-items-center">
                                                  {technician.username}
                                                </div>
                                              </li>
                                            )
                                          )}
                                        </ul>
                                      ) : (
                                        <div className="px-3 py-2 text-muted">
                                          {technicianSearchTerm
                                            ? "No matching technician found"
                                            : "No technician available"}
                                        </div>
                                      )}
                                    </div>
                                  </div>
                                )}
                              </div>
                            )}
                          </FormGroup>
                        </Col>
                        {/* <Col md="3">
                          <FormGroup className="text-muted">
                            <Label>Service Type</Label>
                            <Input
                              type="select"
                              className="border"
                              value={filters.serviceType}
                              onChange={(e: ChangeEvent<HTMLInputElement>) =>
                                handleFilterChange(
                                  "serviceType",
                                  e.target.value
                                )
                              }
                            >
                              <option value="all">All Services</option>
                              {serviceTypes.map((service) => (
                                <option key={service} value={service}>
                                  {service}
                                </option>
                              ))}
                            </Input>
                          </FormGroup>
                        </Col> */}
                        {/* <Col md="3">
                          <FormGroup className="text-muted">
                            <Label>Service Type</Label>
                            {loading ? (
                              <div className="d-flex align-items-center">
                                <Spinner size="sm" className="me-2" />
                                Loading services...
                              </div>
                            ) : technicians.length === 0 ? (
                              <div className="text-danger">
                                No service found.
                              </div>
                            ) : (
                              <div
                                className="position-relative"
                                ref={serviceDropdownRef}
                              >
                                <div
                                  onClick={() =>
                                    setIsServiceDropdownOpen(
                                      !isServiceDropdownOpen
                                    )
                                  }
                                  className="d-flex w-100 align-items-center justify-content-between cursor-pointer form-control border"
                                  style={{
                                    minHeight: "38px",
                                    padding: "0.375rem 0.75rem",
                                    cursor: "pointer",
                                  }}
                                >
                                  <span
                                    className="text-truncate"
                                    style={{ maxWidth: "calc(100% - 20px)" }}
                                  >
                                    {selectedServiceName || "Select Technician"}
                                  </span>
                                  <span
                                    className="ms-2 text-muted"
                                    style={{ flexShrink: 0 }}
                                  >
                                    {isServiceDropdownOpen ? "▲" : "▼"}
                                  </span>
                                </div>

                                {isServiceDropdownOpen && (
                                  <div
                                    className="position-absolute w-100 mt-1 bg-white border rounded shadow"
                                    style={{
                                      maxHeight: "300px",
                                      overflow: "auto",
                                      zIndex: 1050,
                                    }}
                                  >
                                    <div className="p-2 border-bottom">
                                      <Input
                                        type="text"
                                        value={serviceSearchTerm}
                                        onChange={(e) => {
                                          setServiceSearchTerm(e.target.value);
                                        }}
                                        placeholder="Search services..."
                                        className="form-control form-control-sm"
                                        autoFocus
                                        onClick={(e) => e.stopPropagation()}
                                      />
                                    </div>

                                    <div
                                      style={{
                                        maxHeight: "200px",
                                        overflowY: "auto",
                                      }}
                                    >
                                      {filteredServiceTypes.length > 0 ? (
                                        <ul className="list-unstyled mb-0">
                                          {filteredServiceTypes.map(
                                            (serviceType) => (
                                              <li
                                                key={serviceType.id}
                                                onClick={() =>
                                                  handleTechnicianSelect(
                                                    serviceType.id,
                                                    serviceType.username
                                                  )
                                                }
                                                className="px-3 py-2 cursor-pointer hover-bg-light"
                                                style={{ cursor: "pointer" }}
                                              >
                                                <div className="d-flex align-items-center">
                                                  {technician.username}
                                                </div>
                                              </li>
                                            )
                                          )}
                                        </ul>
                                      ) : (
                                        <div className="px-3 py-2 text-muted">
                                          {technicianSearchTerm
                                            ? "No matching technician found"
                                            : "No technician available"}
                                        </div>
                                      )}
                                    </div>
                                  </div>
                                )}
                              </div>
                            )}
                          </FormGroup>
                        </Col> */}
                        <Col md="3">
                          <Button
                            color="secondary"
                            className="mt-4 py-2"
                            onClick={resetFilters}
                          >
                            <i className="fa fa-refresh me-2"></i>
                            Reset Filters
                          </Button>
                        </Col>
                      </Row>
                    </Form>
                  </CardBody>
                </Card>

                {/* Jobs Table */}
                <div className="table-responsive">
                  <Table hover>
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>Job Number</th>
                        <th>Customer</th>
                        <th>Vehicle</th>
                        <th>Service Type</th>
                        <th>Technician</th>
                        <th>Status</th>
                        <th>Estimated Cost</th>
                        <th>Labor Estimate</th>
                        <th>Parts Estimate</th>
                        <th>Start Date</th>
                        <th>Completion Date</th>
                      </tr>
                    </thead>
                    <tbody>
                      {paginatedJobs.length === 0 ? (
                        <tr>
                          <td colSpan={11} className="text-center py-4">
                            No jobs found matching the selected filters
                          </td>
                        </tr>
                      ) : (
                        paginatedJobs.map((job, index) => (
                          <tr key={job.id}>
                            <td>
                              {(currentPage - 1) * itemsPerPage + index + 1}
                            </td>
                            <td>
                              <strong className="text-primary no-wrap">
                                {job.job_number}
                              </strong>
                            </td>
                            <td>{job.name || `Customer ${job.customer_id}`}</td>
                            <td>{job.vehicle_id}</td>
                            <td>
                              <Badge color="light" className="text-muted">
                                {getServiceType(job)}
                              </Badge>
                            </td>
                            <td>{getTechnicianName(job.assigned_to)}</td>
                            <td>{renderStatusBadge(job.status)}</td>
                            <td>${job.total_estimate}</td>
                            <td>
                              $
                              {parseFloat(job.labor_estimate || "0").toFixed(2)}
                            </td>
                            <td>${job.parts_estimate}</td>
                            <td>{formatDate(job.created_at)}</td>
                            <td>{formatDate(job.actual_completion)}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </Table>
                </div>

                {/* Pagination */}
                <div className="d-flex flex-column flex-md-row justify-content-between align-items-center gap-3 mt-4">
                  <div className="text-center text-md-start text-muted">
                    Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
                    {Math.min(currentPage * itemsPerPage, filteredJobs.length)}{" "}
                    of {filteredJobs.length} entries
                  </div>
                  <CustomPagination
                    currentPage={currentPage}
                    totalPages={totalPages}
                    onPageChange={setCurrentPage}
                    showFirstLast={true}
                    maxVisiblePages={5}
                    paginationType="primary"
                    className="justify-content-center justify-content-md-end"
                  />
                </div>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Container>

      {/* <style jsx global>{`
        .no-wrap {
          white-space: nowrap;
        }

        .cursor-pointer {
          cursor: pointer;
        }

        .text-truncate {
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        .hover-bg-light:hover {
          background-color: #f8f9fa !important;
        }

        .bg-primary.text-white:hover {
          background-color: #5c5ff6 !important;
        }

        .form-control.border {
          min-height: 38px;
        }
      `}</style> */}
      <style jsx>{`
        .form-control:disabled {
          background-color: #e9ecef;
          opacity: 1;
        }

        .text-muted {
          font-size: 0.875rem;
        }

        .cursor-pointer {
          cursor: pointer;
        }

        .text-truncate {
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        /* Dark mode styles for dropdowns */
        :global(.dark-mode) .dropdown-menu {
          background-color: #2a3042 !important;
          border-color: #404656 !important;
          color: #e0e0e0 !important;
        }

        :global(.dark-mode) .dropdown-item {
          color: #e0e0e0 !important;
        }

        :global(.dark-mode) .dropdown-item:hover {
          background-color: #3a4054 !important;
          color: #ffffff !important;
        }

        :global(.dark-mode) .text-muted {
          color: #a0a0a0 !important;
        }

        :global(.dark-mode) .border-bottom {
          border-color: #404656 !important;
        }

        :global(.dark-mode) .form-control {
          background-color: #2a3042 !important;
          border-color: #404656 !important;
          color: #e0e0e0 !important;
        }

        :global(.dark-mode) .form-control::placeholder {
          color: #a0a0a0 !important;
        }

        /* Make dropdown trigger adapt to dark mode */
        :global(.dark-mode) .dropdown-toggle {
          background-color: #2a3042 !important;
          border-color: #404656 !important;
          color: #e0e0e0 !important;
        }
      `}</style>
    </div>
  );
}

// export default JobSummaryReport;
export default withAuth(JobSummaryReport, ["admin"]);

// "use client";
// import Breadcrumbs from "@/CommonElements/Breadcrumbs";
// import CustomPagination from "@/CommonElements/Pagination";
// import {
//   Container,
//   Row,
//   Col,
//   Card,
//   CardBody,
//   Input,
//   Button,
//   Table,
//   Badge,
//   Form,
//   FormGroup,
//   Label,
// } from "reactstrap";
// import React, { useState, ChangeEvent } from "react";
// import Link from "next/link";

// // Types
// interface JobSummary {
//   id: string;
//   jobNumber: string;
//   customerName: string;
//   vehicle: string;
//   serviceType: string;
//   technician: string;
//   status: "completed" | "in-progress" | "pending" | "cancelled";
//   estimatedCost: number;
//   actualCost: number;
//   startDate: string;
//   completionDate: string;
//   duration: number; // in hours
// }

// // Mock data
// const jobSummaryData: JobSummary[] = [
//   {
//     id: "1",
//     jobNumber: "JC-2024-001",
//     customerName: "John Doe",
//     vehicle: "Toyota Camry (ABC123)",
//     serviceType: "Regular Maintenance",
//     technician: "Mike Smith",
//     status: "completed",
//     estimatedCost: 250.0,
//     actualCost: 245.5,
//     startDate: "2024-01-15",
//     completionDate: "2024-01-16",
//     duration: 5,
//   },
//   {
//     id: "2",
//     jobNumber: "JC-2024-002",
//     customerName: "Jane Smith",
//     vehicle: "Honda Civic (XYZ789)",
//     serviceType: "Brake Repair",
//     technician: "Sarah Johnson",
//     status: "in-progress",
//     estimatedCost: 450.0,
//     actualCost: 0,
//     startDate: "2024-01-16",
//     completionDate: "",
//     duration: 3,
//   },
//   {
//     id: "3",
//     jobNumber: "JC-2024-003",
//     customerName: "Mike Johnson",
//     vehicle: "Ford F-150 (DEF456)",
//     serviceType: "Inspection",
//     technician: "David Wilson",
//     status: "completed",
//     estimatedCost: 120.0,
//     actualCost: 120.0,
//     startDate: "2024-01-14",
//     completionDate: "2024-01-15",
//     duration: 2,
//   },
//   {
//     id: "4",
//     jobNumber: "JC-2024-004",
//     customerName: "Sarah Wilson",
//     vehicle: "BMW X5 (GHI789)",
//     serviceType: "AC Repair",
//     technician: "Mike Smith",
//     status: "pending",
//     estimatedCost: 350.0,
//     actualCost: 0,
//     startDate: "2024-01-17",
//     completionDate: "",
//     duration: 0,
//   },
//   {
//     id: "5",
//     jobNumber: "JC-2024-005",
//     customerName: "Robert Brown",
//     vehicle: "Mercedes C-Class (JKL012)",
//     serviceType: "Engine Repair",
//     technician: "David Wilson",
//     status: "completed",
//     estimatedCost: 800.0,
//     actualCost: 750.0,
//     startDate: "2024-01-12",
//     completionDate: "2024-01-14",
//     duration: 12,
//   },
// ];

// function JobSummaryReport() {
//   const [currentPage, setCurrentPage] = useState(1);
//   const [jobs, setJobs] = useState<JobSummary[]>(jobSummaryData);
//   const [filters, setFilters] = useState({
//     dateFrom: "",
//     dateTo: "",
//     status: "all",
//     technician: "all",
//     serviceType: "all",
//   });
//   const itemsPerPage = 10;

//   // Filter jobs
//   const filteredJobs = jobs.filter((job) => {
//     const matchesDate =
//       (!filters.dateFrom || job.startDate >= filters.dateFrom) &&
//       (!filters.dateTo || job.startDate <= filters.dateTo);
//     const matchesStatus =
//       filters.status === "all" || job.status === filters.status;
//     const matchesTechnician =
//       filters.technician === "all" || job.technician === filters.technician;
//     const matchesServiceType =
//       filters.serviceType === "all" || job.serviceType === filters.serviceType;

//     return (
//       matchesDate && matchesStatus && matchesTechnician && matchesServiceType
//     );
//   });

//   // Calculate summary metrics
//   const calculateMetrics = () => {
//     const totalJobs = filteredJobs.length;
//     const completedJobs = filteredJobs.filter(
//       (job) => job.status === "completed"
//     ).length;
//     const totalRevenue = filteredJobs
//       .filter((job) => job.status === "completed")
//       .reduce((sum: number, job: JobSummary) => sum + job.actualCost, 0);
//     const avgCompletionTime =
//       completedJobs > 0
//         ? filteredJobs
//             .filter((job) => job.status === "completed")
//             .reduce((sum: number, job: JobSummary) => sum + job.duration, 0) /
//           completedJobs
//         : 0;

//     return {
//       totalJobs,
//       completedJobs,
//       totalRevenue,
//       avgCompletionTime: Math.round(avgCompletionTime * 10) / 10,
//       completionRate:
//         totalJobs > 0 ? Math.round((completedJobs / totalJobs) * 100) : 0,
//     };
//   };

//   const metrics = calculateMetrics();

//   // Get unique values for filters
//   const technicians = [...new Set(jobs.map((job) => job.technician))];
//   const serviceTypes = [...new Set(jobs.map((job) => job.serviceType))];

//   // Pagination
//   const totalPages = Math.ceil(filteredJobs.length / itemsPerPage);
//   const paginatedJobs = filteredJobs.slice(
//     (currentPage - 1) * itemsPerPage,
//     currentPage * itemsPerPage
//   );

//   // Status badge renderer
//   const renderStatusBadge = (status: string) => {
//     const statusConfig = {
//       completed: { class: "bg-success", label: "Completed" },
//       "in-progress": { class: "bg-primary", label: "In Progress" },
//       pending: { class: "bg-warning", label: "Pending" },
//       cancelled: { class: "bg-danger", label: "Cancelled" },
//     };

//     const config = statusConfig[status as keyof typeof statusConfig] || {
//       class: "bg-secondary",
//       label: status,
//     };

//     return <Badge className={config.class}>{config.label}</Badge>;
//   };

//   const handleFilterChange = (field: string, value: string) => {
//     setFilters((prev) => ({
//       ...prev,
//       [field]: value,
//     }));
//     setCurrentPage(1); // Reset to first page when filters change
//   };

//   const handleExport = (format: "pdf" | "excel") => {
//     // In a real application, this would generate and download the file
//     console.log(`Exporting to ${format} with filters:`, filters);
//     alert(`Exporting job summary report to ${format.toUpperCase()}`);
//   };

//   const resetFilters = () => {
//     setFilters({
//       dateFrom: "",
//       dateTo: "",
//       status: "all",
//       technician: "all",
//       serviceType: "all",
//     });
//   };

//   return (
//     <div className="page-body">
//       <Breadcrumbs
//         title="Job Summary Report"
//         mainTitle="Job Cards Analysis"
//         parent="Reports"
//       />

//       <Container fluid>
//         {/* Summary Metrics */}
//         {/* <Row className="mb-4">
//           <Col xl="3" md="6">
//             <Card className="card-stats">
//               <CardBody>
//                 <div className="d-flex align-items-center">
//                   <div className="flex-grow-1">
//                     <h4 className="mb-0">{metrics.totalJobs}</h4>
//                     <span className="text-muted">Total Jobs</span>
//                   </div>
//                   <div className="flex-shrink-0">
//                     <div className="bg-primary rounded-circle p-3">
//                       <i className="fa fa-list-check text-white fs-4"></i>
//                     </div>
//                   </div>
//                 </div>
//               </CardBody>
//             </Card>
//           </Col>

//           <Col xl="3" md="6">
//             <Card className="card-stats">
//               <CardBody>
//                 <div className="d-flex align-items-center">
//                   <div className="flex-grow-1">
//                     <h4 className="mb-0">{metrics.completionRate}%</h4>
//                     <span className="text-muted">Completion Rate</span>
//                   </div>
//                   <div className="flex-shrink-0">
//                     <div className="bg-success rounded-circle p-3">
//                       <i className="fa fa-chart-pie text-white fs-4"></i>
//                     </div>
//                   </div>
//                 </div>
//               </CardBody>
//             </Card>
//           </Col>

//           <Col xl="3" md="6">
//             <Card className="card-stats">
//               <CardBody>
//                 <div className="d-flex align-items-center">
//                   <div className="flex-grow-1">
//                     <h4 className="mb-0">${metrics.totalRevenue.toFixed(2)}</h4>
//                     <span className="text-muted">Total Revenue</span>
//                   </div>
//                   <div className="flex-shrink-0">
//                     <div className="bg-info rounded-circle p-3">
//                       <i className="fa fa-dollar-sign text-white fs-4"></i>
//                     </div>
//                   </div>
//                 </div>
//               </CardBody>
//             </Card>
//           </Col>

//           <Col xl="3" md="6">
//             <Card className="card-stats">
//               <CardBody>
//                 <div className="d-flex align-items-center">
//                   <div className="flex-grow-1">
//                     <h4 className="mb-0">{metrics.avgCompletionTime}h</h4>
//                     <span className="text-muted">Avg. Completion Time</span>
//                   </div>
//                   <div className="flex-shrink-0">
//                     <div className="bg-warning rounded-circle p-3">
//                       <i className="fa fa-clock text-white fs-4"></i>
//                     </div>
//                   </div>
//                 </div>
//               </CardBody>
//             </Card>
//           </Col>
//         </Row> */}

//         <Row>
//           <Col sm="12">
//             <Card>
//               <CardBody>
//                 {/* Filters */}
//                 <Card className="bg-light mb-4">
//                   <CardBody>
//                     <h6 className="mb-3 text-muted">Filter Report</h6>
//                     <Form>
//                       <Row>
//                         <Col md="3">
//                           <FormGroup className="text-muted">
//                             <Label>Date From</Label>
//                             <Input
//                               type="date"
//                               value={filters.dateFrom}
//                               onChange={(e: ChangeEvent<HTMLInputElement>) =>
//                                 handleFilterChange("dateFrom", e.target.value)
//                               }
//                             />
//                           </FormGroup>
//                         </Col>
//                         <Col md="3">
//                           <FormGroup className="text-muted">
//                             <Label>Date To</Label>
//                             <Input
//                               type="date"
//                               value={filters.dateTo}
//                               onChange={(e: ChangeEvent<HTMLInputElement>) =>
//                                 handleFilterChange("dateTo", e.target.value)
//                               }
//                             />
//                           </FormGroup>
//                         </Col>
//                         <Col md="3">
//                           <FormGroup className="text-muted">
//                             <Label>Status</Label>
//                             <Input
//                               type="select"
//                               className="border"
//                               value={filters.status}
//                               onChange={(e: ChangeEvent<HTMLInputElement>) =>
//                                 handleFilterChange("status", e.target.value)
//                               }
//                             >
//                               <option value="all">All Status</option>
//                               <option value="completed">Completed</option>
//                               <option value="in-progress">In Progress</option>
//                               <option value="pending">Pending</option>
//                               <option value="cancelled">Cancelled</option>
//                             </Input>
//                           </FormGroup>
//                         </Col>
//                         <Col md="3">
//                           <FormGroup className="text-muted">
//                             <Label>Technician</Label>
//                             <Input
//                               type="select"
//                               className="border"
//                               value={filters.technician}
//                               onChange={(e: ChangeEvent<HTMLInputElement>) =>
//                                 handleFilterChange("technician", e.target.value)
//                               }
//                             >
//                               <option value="all">All Technicians</option>
//                               {technicians.map((tech) => (
//                                 <option key={tech} value={tech}>
//                                   {tech}
//                                 </option>
//                               ))}
//                             </Input>
//                           </FormGroup>
//                         </Col>
//                         <Col md="3">
//                           <FormGroup className="text-muted">
//                             <Label>Service Type</Label>
//                             <Input
//                               type="select"
//                               className="border"
//                               value={filters.serviceType}
//                               onChange={(e: ChangeEvent<HTMLInputElement>) =>
//                                 handleFilterChange(
//                                   "serviceType",
//                                   e.target.value
//                                 )
//                               }
//                             >
//                               <option value="all">All Services</option>
//                               {serviceTypes.map((service) => (
//                                 <option key={service} value={service}>
//                                   {service}
//                                 </option>
//                               ))}
//                             </Input>
//                           </FormGroup>
//                         </Col>
//                         <Col md="3">
//                           {/* <div className="d-flex justify-content-end"> */}
//                           <Button
//                             color="secondary"
//                             className="mt-4 py-2"
//                             onClick={resetFilters}
//                           >
//                             <i className="fa fa-refresh me-2"></i>
//                             Reset Filters
//                           </Button>
//                           {/* </div> */}
//                         </Col>
//                       </Row>
//                       {/* <div className="d-flex justify-content-end">
//                         <Button color="secondary" onClick={resetFilters}>
//                           <i className="fa fa-refresh me-2"></i>
//                           Reset Filters
//                         </Button>
//                       </div> */}
//                     </Form>
//                   </CardBody>
//                 </Card>
//                 {/* Report Header with Filters */}
//                 <div className="d-flex justify-content-between align-items-center mb-4">
//                   <h5 className="card-title mb-0 text-muted">
//                     Job Summary Report
//                   </h5>
//                   <div className="d-flex gap-2">
//                     <Button
//                       color="outline-primary"
//                       onClick={() => handleExport("excel")}
//                     >
//                       <i className="fa fa-file-excel me-2"></i>
//                       Export Excel
//                     </Button>
//                     <Button
//                       color="outline-danger"
//                       onClick={() => handleExport("pdf")}
//                     >
//                       <i className="fa fa-file-pdf me-2"></i>
//                       Export PDF
//                     </Button>
//                   </div>
//                 </div>
//                 {/* Jobs Table */}
//                 <div className="table-responsive">
//                   <Table hover>
//                     <thead>
//                       <tr>
//                         <th>Job Number</th>
//                         <th>Customer</th>
//                         <th>Vehicle</th>
//                         <th>Service Type</th>
//                         <th>Technician</th>
//                         <th>Status</th>
//                         <th>Estimated Cost</th>
//                         <th>Actual Cost</th>
//                         <th>Start Date</th>
//                         <th>Completion Date</th>
//                         <th>Duration (h)</th>
//                       </tr>
//                     </thead>
//                     <tbody>
//                       {paginatedJobs.length === 0 ? (
//                         <tr>
//                           <td colSpan={11} className="text-center py-4">
//                             No jobs found matching the selected filters
//                           </td>
//                         </tr>
//                       ) : (
//                         paginatedJobs.map((job) => (
//                           <tr key={job.id}>
//                             <td>
//                               <strong className="text-primary no-wrap">
//                                 {job.jobNumber}
//                               </strong>
//                             </td>
//                             <td>{job.customerName}</td>
//                             <td>{job.vehicle}</td>
//                             <td>
//                               <Badge color="light" className="text-muted">
//                                 {job.serviceType}
//                               </Badge>
//                             </td>
//                             <td>{job.technician}</td>
//                             <td>{renderStatusBadge(job.status)}</td>
//                             <td>${job.estimatedCost.toFixed(2)}</td>
//                             <td>
//                               <strong
//                                 className={
//                                   job.actualCost > job.estimatedCost
//                                     ? "text-danger"
//                                     : job.actualCost < job.estimatedCost
//                                     ? "text-success"
//                                     : "text-muted"
//                                 }
//                               >
//                                 $
//                                 {job.actualCost > 0
//                                   ? job.actualCost.toFixed(2)
//                                   : "0.00"}
//                               </strong>
//                             </td>
//                             <td>
//                               {new Date(job.startDate).toLocaleDateString()}
//                             </td>
//                             <td>
//                               {job.completionDate ? (
//                                 new Date(
//                                   job.completionDate
//                                 ).toLocaleDateString()
//                               ) : (
//                                 <span className="text-muted">-</span>
//                               )}
//                             </td>
//                             <td>{job.duration}</td>
//                           </tr>
//                         ))
//                       )}
//                     </tbody>
//                   </Table>
//                 </div>

//                 {/* Pagination */}
//                 <div className="d-flex flex-column flex-md-row justify-content-between align-items-center gap-3 mt-4">
//                   <div className="text-center text-md-start text-muted">
//                     Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
//                     {Math.min(currentPage * itemsPerPage, filteredJobs.length)}{" "}
//                     of {filteredJobs.length} entries
//                   </div>
//                   <CustomPagination
//                     currentPage={currentPage}
//                     totalPages={totalPages}
//                     onPageChange={setCurrentPage}
//                     showFirstLast={true}
//                     maxVisiblePages={5}
//                     paginationType="primary"
//                     className="justify-content-center justify-content-md-end"
//                   />
//                 </div>
//               </CardBody>
//             </Card>
//           </Col>
//         </Row>
//       </Container>

//       <style jsx global>{`
//         .card-stats {
//           border: 1px solid #e6edef;
//           box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
//         }

//         .card-stats .bg-primary {
//           background-color: #5c5ff6 !important;
//         }
//         .card-stats .bg-success {
//           background-color: #28a745 !important;
//         }
//         .card-stats .bg-info {
//           background-color: #17a2b8 !important;
//         }
//         .card-stats .bg-warning {
//           background-color: #f8d62b !important;
//         }
//       `}</style>
//     </div>
//   );
// }

// export default JobSummaryReport;

// "use client";
// import Breadcrumbs from "@/CommonElements/Breadcrumbs";
// import CustomPagination from "@/CommonElements/Pagination";
// import {
//   Container,
//   Row,
//   Col,
//   Card,
//   CardBody,
//   Input,
//   Button,
//   Table,
//   Badge,
//   Form,
//   FormGroup,
//   Label,
//   Spinner,
// } from "reactstrap";
// import React, { useState, ChangeEvent, useEffect } from "react";
// import { useAuth } from "@/helper/AuthContext";

// // API Response Type
// interface ApiJobSummary {
//   id: string;
//   job_number: string;
//   customer_id: string;
//   vehicle_id: string;
//   created_by: string;
//   assigned_to: string;
//   status: string;
//   reported_issue: string;
//   diagnosis: string | null;
//   labor_estimate: string;
//   parts_estimate: string;
//   total_estimate: string;
//   priority: string;
//   expected_completion: string;
//   actual_completion: string | null;
//   is_paid: string;
//   meta: string;
//   created_at: string;
//   updated_at: string;
//   name: string; // Customer name
// }

// function JobSummaryReport() {
//   const { state } = useAuth();
//   const [currentPage, setCurrentPage] = useState(1);
//   const [jobs, setJobs] = useState<ApiJobSummary[]>([]);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState<string | null>(null);
//   const [filters, setFilters] = useState({
//     dateFrom: "",
//     dateTo: "",
//     status: "all",
//     technician: "all",
//     serviceType: "all",
//   });
//   const itemsPerPage = 10;

//   // Fetch job summary data from API
//   useEffect(() => {
//     fetchJobSummaryData();
//   }, []);

//   const fetchJobSummaryData = async () => {
//     try {
//       setLoading(true);
//       setError(null);
//        const token = state?.accessToken || localStorage.getItem("token");

//         if (!token) {
//           throw new Error("No authentication token found");
//         }

//         const response = await fetch("/api/reports/job_summary", {
//           method: "GET",
//           headers: {
//             Authorization: `Bearer ${token}`,
//             "Content-Type": "application/json",
//           },
//         });
//       // const response = await fetch('/api/reports/job_summary');

//       if (!response.ok) {
//         throw new Error(`Failed to fetch job summary: ${response.status}`);
//       }

//       const data = await response.json();
//       setJobs(data.data || []);
//     } catch (err) {
//       console.error('Error fetching job summary:', err);
//       setError(err instanceof Error ? err.message : 'Failed to load job summary data');
//       setJobs([]);
//     } finally {
//       setLoading(false);
//     }
//   };

//   // Helper function to parse meta data
//   const parseMetaData = (metaString: string) => {
//     try {
//       return JSON.parse(metaString || '{}');
//     } catch {
//       return {};
//     }
//   };

//   // Filter jobs
//   const filteredJobs = jobs.filter((job) => {
//     const jobDate = job.created_at.split(' ')[0]; // Extract date part from datetime
//     const matchesDate =
//       (!filters.dateFrom || jobDate >= filters.dateFrom) &&
//       (!filters.dateTo || jobDate <= filters.dateTo);

//     const matchesStatus =
//       filters.status === "all" || job.status.toLowerCase() === filters.status;

//     // Get technician from meta or use assigned_to ID
//     const meta = parseMetaData(job.meta);
//     const technicianName = meta.technician_name || `Tech ID: ${job.assigned_to}`;
//     const matchesTechnician =
//       filters.technician === "all" || technicianName === filters.technician;

//     // Get service type from reported_issue or diagnosis
//     const serviceType = job.reported_issue || (job.diagnosis ? job.diagnosis : 'General Service');
//     const matchesServiceType =
//       filters.serviceType === "all" || serviceType === filters.serviceType;

//     return (
//       matchesDate && matchesStatus && matchesTechnician && matchesServiceType
//     );
//   });

//   // Calculate summary metrics directly from API data
//   const calculateMetrics = () => {
//     const totalJobs = filteredJobs.length;

//     // Count completed jobs (assuming 'completed' status)
//     const completedJobs = filteredJobs.filter(
//       (job) => job.status.toLowerCase() === 'completed'
//     ).length;

//     // Calculate total revenue from completed jobs
//     const totalRevenue = filteredJobs
//       .filter((job) => job.status.toLowerCase() === 'completed')
//       .reduce((sum: number, job: ApiJobSummary) => sum + parseFloat(job.total_estimate || '0'), 0);

//     // Calculate average completion time
//     const completedJobsData = filteredJobs.filter((job) => job.status.toLowerCase() === 'completed');
//     const totalDuration = completedJobsData.reduce((sum: number, job: ApiJobSummary) => {
//       if (job.created_at && job.actual_completion) {
//         const start = new Date(job.created_at);
//         const end = new Date(job.actual_completion);
//         const durationHours = Math.round((end.getTime() - start.getTime()) / (1000 * 60 * 60));
//         return sum + durationHours;
//       }
//       return sum;
//     }, 0);

//     const avgCompletionTime = completedJobs > 0 ? totalDuration / completedJobs : 0;

//     return {
//       totalJobs,
//       completedJobs,
//       totalRevenue,
//       avgCompletionTime: Math.round(avgCompletionTime * 10) / 10,
//       completionRate:
//         totalJobs > 0 ? Math.round((completedJobs / totalJobs) * 100) : 0,
//     };
//   };

//   const metrics = calculateMetrics();

//   // Get unique values for filters from API data
//   const technicians = [...new Set(jobs.map((job) => {
//     const meta = parseMetaData(job.meta);
//     return meta.technician_name || `Tech ID: ${job.assigned_to}`;
//   }))];

//   const serviceTypes = [...new Set(jobs.map((job) => {
//     return job.reported_issue || (job.diagnosis ? job.diagnosis : 'General Service');
//   }))];

//   // Get status options from API data
//   const statusOptions = [...new Set(jobs.map((job) => job.status.toLowerCase()))];

//   // Pagination
//   const totalPages = Math.ceil(filteredJobs.length / itemsPerPage);
//   const paginatedJobs = filteredJobs.slice(
//     (currentPage - 1) * itemsPerPage,
//     currentPage * itemsPerPage
//   );

//   // Status badge renderer
//   const renderStatusBadge = (status: string) => {
//     const statusLower = status.toLowerCase();
//     const statusConfig: Record<string, { class: string; label: string }> = {
//       completed: { class: "bg-success", label: "Completed" },
//       "in-progress": { class: "bg-primary", label: "In Progress" },
//       open: { class: "bg-info", label: "Open" },
//       pending: { class: "bg-warning", label: "Pending" },
//       cancelled: { class: "bg-danger", label: "Cancelled" },
//     };

//     const config = statusConfig[statusLower] || {
//       class: "bg-secondary",
//       label: status,
//     };

//     return <Badge className={config.class}>{config.label}</Badge>;
//   };

//   // Get service type
//   const getServiceType = (job: ApiJobSummary) => {
//     return job.reported_issue || (job.diagnosis ? job.diagnosis : 'General Service');
//   };

//   // Format date for display
//   const formatDate = (dateString: string | null) => {
//     if (!dateString || dateString === '0000-00-00 00:00:00') {
//       return '-';
//     }
//     const date = new Date(dateString);
//     return date.toLocaleDateString();
//   };

//   // Calculate duration in hours

//   const handleFilterChange = (field: string, value: string) => {
//     setFilters((prev) => ({
//       ...prev,
//       [field]: value,
//     }));
//     setCurrentPage(1); // Reset to first page when filters change
//   };

//   const handleExport = (format: "pdf" | "excel") => {
//     // In a real application, this would generate and download the file
//     console.log(`Exporting to ${format} with filters:`, filters);

//     // You can create an API endpoint for exporting
//     const exportUrl = `/api/reports/export/job_summary?format=${format}&${new URLSearchParams(filters as any).toString()}`;
//     window.open(exportUrl, '_blank');

//     alert(`Exporting job summary report to ${format.toUpperCase()}`);
//   };

//   const resetFilters = () => {
//     setFilters({
//       dateFrom: "",
//       dateTo: "",
//       status: "all",
//       technician: "all",
//       serviceType: "all",
//     });
//   };

//   // Refresh data
//   const refreshData = () => {
//     fetchJobSummaryData();
//   };

//   if (loading) {
//     return (
//       <div className="page-body">
//         <Breadcrumbs
//           title="Job Summary Report"
//           mainTitle="Job Cards Analysis"
//           parent="Reports"
//         />
//         <Container fluid>
//           <Row className="justify-content-center mt-5">
//             <Col className="text-center">
//               <Spinner color="primary" />
//               <p className="mt-3">Loading job summary data...</p>
//             </Col>
//           </Row>
//         </Container>
//       </div>
//     );
//   }

//   if (error) {
//     return (
//       <div className="page-body">
//         <Breadcrumbs
//           title="Job Summary Report"
//           mainTitle="Job Cards Analysis"
//           parent="Reports"
//         />
//         <Container fluid>
//           <Row>
//             <Col sm="12">
//               <Card>
//                 <CardBody className="text-center py-5">
//                   <h5 className="text-danger">Error Loading Data</h5>
//                   <p className="text-muted">{error}</p>
//                   <Button color="primary" onClick={refreshData}>
//                     <i className="fa fa-refresh me-2"></i>
//                     Try Again
//                   </Button>
//                 </CardBody>
//               </Card>
//             </Col>
//           </Row>
//         </Container>
//       </div>
//     );
//   }

//   return (
//     <div className="page-body">
//       <Breadcrumbs
//         title="Job Summary Report"
//         mainTitle="Job Cards Analysis"
//         parent="Reports"
//       />

//       <Container fluid>
//         {/* Summary Metrics */}

//         <Row>
//           <Col sm="12">
//             <Card>
//               <CardBody>
//                 {/* Header with refresh button */}

//                 {/* Filters */}
//                 <Card className="bg-light mb-4">
//                   <CardBody>
//                     <h6 className="mb-3 text-muted">Filter Report</h6>
//                     <Form>
//                       <Row>
//                         <Col md="3">
//                           <FormGroup className="text-muted">
//                             <Label>Date From</Label>
//                             <Input
//                               type="date"
//                               value={filters.dateFrom}
//                               onChange={(e: ChangeEvent<HTMLInputElement>) =>
//                                 handleFilterChange("dateFrom", e.target.value)
//                               }
//                             />
//                           </FormGroup>
//                         </Col>
//                         <Col md="3">
//                           <FormGroup className="text-muted">
//                             <Label>Date To</Label>
//                             <Input
//                               type="date"
//                               value={filters.dateTo}
//                               onChange={(e: ChangeEvent<HTMLInputElement>) =>
//                                 handleFilterChange("dateTo", e.target.value)
//                               }
//                             />
//                           </FormGroup>
//                         </Col>
//                         <Col md="3">
//                           <FormGroup className="text-muted">
//                             <Label>Status</Label>
//                             <Input
//                               type="select"
//                               className="border"
//                               value={filters.status}
//                               onChange={(e: ChangeEvent<HTMLInputElement>) =>
//                                 handleFilterChange("status", e.target.value)
//                               }
//                             >
//                               <option value="all">All Status</option>
//                               {statusOptions.map((status) => (
//                                 <option key={status} value={status}>
//                                   {status.charAt(0).toUpperCase() + status.slice(1)}
//                                 </option>
//                               ))}
//                             </Input>
//                           </FormGroup>
//                         </Col>
//                         <Col md="3">
//                           <FormGroup className="text-muted">
//                             <Label>Technician</Label>
//                             <Input
//                               type="select"
//                               className="border"
//                               value={filters.technician}
//                               onChange={(e: ChangeEvent<HTMLInputElement>) =>
//                                 handleFilterChange("technician", e.target.value)
//                               }
//                             >
//                               <option value="all">All Technicians</option>
//                               {technicians.map((tech) => (
//                                 <option key={tech} value={tech}>
//                                   {tech}
//                                 </option>
//                               ))}
//                             </Input>
//                           </FormGroup>
//                         </Col>
//                         <Col md="3">
//                           <FormGroup className="text-muted">
//                             <Label>Service Type</Label>
//                             <Input
//                               type="select"
//                               className="border"
//                               value={filters.serviceType}
//                               onChange={(e: ChangeEvent<HTMLInputElement>) =>
//                                 handleFilterChange(
//                                   "serviceType",
//                                   e.target.value
//                                 )
//                               }
//                             >
//                               <option value="all">All Services</option>
//                               {serviceTypes.map((service) => (
//                                 <option key={service} value={service}>
//                                   {service}
//                                 </option>
//                               ))}
//                             </Input>
//                           </FormGroup>
//                         </Col>
//                         <Col md="3">
//                           <Button
//                             color="secondary"
//                             className="mt-4 py-2"
//                             onClick={resetFilters}
//                           >
//                             <i className="fa fa-refresh me-2"></i>
//                             Reset Filters
//                           </Button>
//                         </Col>
//                       </Row>
//                     </Form>
//                   </CardBody>
//                 </Card>
//   <div className="d-flex justify-content-between align-items-center mb-4">
//                   <h5 className="card-title mb-0">Job Summary Report</h5>
//                   <div className="d-flex gap-2">

//                     <Button
//                       color="outline-primary"
//                       onClick={() => handleExport("excel")}
//                     >
//                       <i className="fa fa-file-excel me-2"></i>
//                       Export Excel
//                     </Button>
//                     <Button
//                       color="outline-danger"
//                       onClick={() => handleExport("pdf")}
//                     >
//                       <i className="fa fa-file-pdf me-2"></i>
//                       Export PDF
//                     </Button>
//                   </div>
//                 </div>
//                 {/* Jobs Table */}
//                 <div className="table-responsive">
//                   <Table hover>
//                     <thead>
//                       <tr>
//                         <th>Job Number</th>
//                         <th>Customer</th>
//                         <th>Vehicle</th>
//                         <th>Service Type</th>
//                         <th>Technician</th>
//                         <th>Status</th>
//                         <th>Estimated Cost</th>
//                         <th>Labor Estimate</th>
//                         <th>Parts Estimate</th>
//                         <th>Start Date</th>
//                         <th>Completion Date</th>
//                         {/* <th>Duration (h)</th> */}
//                       </tr>
//                     </thead>
//                     <tbody>
//                       {paginatedJobs.length === 0 ? (
//                         <tr>
//                           <td colSpan={12} className="text-center py-4">
//                             No jobs found matching the selected filters
//                           </td>
//                         </tr>
//                       ) : (
//                         paginatedJobs.map((job) => (
//                           <tr key={job.id}>
//                             <td>
//                               <strong className="text-primary no-wrap">
//                                 {job.job_number}
//                               </strong>
//                             </td>
//                             <td>{job.name || `Customer ${job.customer_id}`}</td>
//                             <td>{job.vehicle_id}</td>
//                             <td>
//                               <Badge color="light" className="text-muted">
//                                 {getServiceType(job)}
//                               </Badge>
//                             </td>
//                             <td>{job.assigned_to}</td>
//                             <td>{renderStatusBadge(job.status)}</td>
//                             <td>${job.total_estimate}</td>
//                             <td>${parseFloat(job.labor_estimate || '0').toFixed(2)}</td>
//                             <td>${job.parts_estimate }</td>
//                             <td>{formatDate(job.created_at)}</td>
//                             <td>{formatDate(job.actual_completion)}</td>
//                             {/* <td>{calculateDuration(job)}</td> */}
//                           </tr>
//                         ))
//                       )}
//                     </tbody>
//                   </Table>
//                 </div>

//                 {/* Pagination */}
//                 <div className="d-flex flex-column flex-md-row justify-content-between align-items-center gap-3 mt-4">
//                   <div className="text-center text-md-start text-muted">
//                     Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
//                     {Math.min(currentPage * itemsPerPage, filteredJobs.length)}{" "}
//                     of {filteredJobs.length} entries
//                   </div>
//                   <CustomPagination
//                     currentPage={currentPage}
//                     totalPages={totalPages}
//                     onPageChange={setCurrentPage}
//                     showFirstLast={true}
//                     maxVisiblePages={5}
//                     paginationType="primary"
//                     className="justify-content-center justify-content-md-end"
//                   />
//                 </div>
//               </CardBody>
//             </Card>
//           </Col>
//         </Row>
//       </Container>

//       <style jsx global>{`
//         .card-stats {
//           border: 1px solid #e6edef;
//           box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
//         }

//         .card-stats .bg-primary {
//           background-color: #5c5ff6 !important;
//         }
//         .card-stats .bg-success {
//           background-color: #28a745 !important;
//         }
//         .card-stats .bg-info {
//           background-color: #17a2b8 !important;
//         }
//         .card-stats .bg-warning {
//           background-color: #f8d62b !important;
//         }
//       `}</style>
//     </div>
//   );
// }

// export default JobSummaryReport;
