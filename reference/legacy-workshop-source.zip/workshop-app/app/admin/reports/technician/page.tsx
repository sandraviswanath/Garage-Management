// "use client";
// import Breadcrumbs from "@/CommonElements/Breadcrumbs";
// import {
//   Container,
//   Row,
//   Col,
//   Card,
//   CardBody,
//   Table,
//   Badge,
//   Progress,
//   Form,
//   FormGroup,
//   Label,
//   Input,
//   Button,
// } from "reactstrap";
// import React, { useState, ChangeEvent } from "react";
// import CustomPagination from "@/CommonElements/Pagination";

// // Types
// interface TechnicianPerformance {
//   id: number;
//   name: string;
//   totalJobs: number;
//   completedJobs: number;
//   inProgressJobs: number;
//   efficiency: number;
//   qualityRating: number;
//   avgCompletionTime: number;
//   revenueGenerated: number;
//   specialization: string[];
// }

// // Mock data
// const technicianData: TechnicianPerformance[] = [
//   {
//     id: 1,
//     name: "Mike Smith",
//     totalJobs: 45,
//     completedJobs: 42,
//     inProgressJobs: 3,
//     efficiency: 94,
//     qualityRating: 4.8,
//     avgCompletionTime: 4.2,
//     revenueGenerated: 12500.0,
//     specialization: ["Engine", "Transmission"],
//   },
//   {
//     id: 2,
//     name: "Sarah Johnson",
//     totalJobs: 38,
//     completedJobs: 35,
//     inProgressJobs: 3,
//     efficiency: 92,
//     qualityRating: 4.9,
//     avgCompletionTime: 3.8,
//     revenueGenerated: 9800.0,
//     specialization: ["Brakes", "Suspension"],
//   },
//   {
//     id: 3,
//     name: "David Wilson",
//     totalJobs: 52,
//     completedJobs: 48,
//     inProgressJobs: 4,
//     efficiency: 92,
//     qualityRating: 4.7,
//     avgCompletionTime: 5.1,
//     revenueGenerated: 15600.0,
//     specialization: ["Electrical", "AC Systems"],
//   },
//   {
//     id: 4,
//     name: "Emily Chen",
//     totalJobs: 28,
//     completedJobs: 25,
//     inProgressJobs: 3,
//     efficiency: 89,
//     qualityRating: 4.6,
//     avgCompletionTime: 4.8,
//     revenueGenerated: 7200.0,
//     specialization: ["Diagnostics", "Hybrid Systems"],
//   },
// ];

// function TechnicianPerformanceReport() {
//   const [currentPage, setCurrentPage] = useState(1);
//   const [dateFrom, setDateFrom] = useState("");
//   const [dateTo, setDateTo] = useState("");

//   const itemsPerPage = 10;
//   // Calculate overall metrics
//   const calculateOverallMetrics = () => {
//     const totalTechnicians = technicianData.length;
//     const avgEfficiency =
//       technicianData.reduce((sum, tech) => sum + tech.efficiency, 0) /
//       totalTechnicians;
//     const avgQuality =
//       technicianData.reduce((sum, tech) => sum + tech.qualityRating, 0) /
//       totalTechnicians;
//     const totalRevenue = technicianData.reduce(
//       (sum, tech) => sum + tech.revenueGenerated,
//       0
//     );

//     return {
//       totalTechnicians,
//       avgEfficiency: Math.round(avgEfficiency),
//       avgQuality: Math.round(avgQuality * 10) / 10,
//       totalRevenue,
//     };
//   };

//   const overallMetrics = calculateOverallMetrics();

//   const renderEfficiencyBar = (efficiency: number) => {
//     let color = "success";
//     if (efficiency < 85) color = "danger";
//     else if (efficiency < 90) color = "warning";

//     return (
//       <div className="d-flex align-items-center">
//         <div className="flex-grow-1 me-3">
//           <Progress
//             value={efficiency}
//             color={color}
//             style={{ height: "8px" }}
//           />
//         </div>
//         <small className="text-muted">{efficiency}%</small>
//       </div>
//     );
//   };

//   const renderQualityStars = (rating: number) => {
//     return (
//       <div className="d-flex align-items-center">
//         <span className="text-warning">
//           {"★".repeat(Math.floor(rating))}
//           {"☆".repeat(5 - Math.floor(rating))}
//         </span>
//         <small className="text-muted ms-2">({rating})</small>
//       </div>
//     );
//   };

//   const handleExport = (format: "pdf" | "excel") => {
//     console.log(`Exporting technician performance to ${format}`);
//     alert(`Exporting technician performance report to ${format.toUpperCase()}`);
//   };

//   return (
//     <div className="page-body">
//       <Breadcrumbs
//         title="Technician Performance"
//         mainTitle="Performance Analytics"
//         parent="Reports"
//       />

//       <Container fluid>
//         {/* Overall Metrics */}
//         {/* <Row className="mb-4">
//           <Col xl="3" md="6">
//             <Card className="card-stats">
//               <CardBody>
//                 <div className="d-flex align-items-center">
//                   <div className="flex-grow-1">
//                     <h4 className="mb-0">{overallMetrics.totalTechnicians}</h4>
//                     <span className="text-muted">Total Technicians</span>
//                   </div>
//                   <div className="flex-shrink-0">
//                     <div className="bg-primary rounded-circle p-3">
//                       <i className="fa fa-users text-white fs-4"></i>
//                     </div>
//                   </div>
//                 </div>
//               </CardBody>
//             </Card>
//           </Col>

//           <Col xl="3" md="6">
//             <Card className="card-stats">
//               <CardBody>
//                 <div className="d-flex align-items-center">
//                   <div className="flex-grow-1">
//                     <h4 className="mb-0">{overallMetrics.avgEfficiency}%</h4>
//                     <span className="text-muted">Avg. Efficiency</span>
//                   </div>
//                   <div className="flex-shrink-0">
//                     <div className="bg-success rounded-circle p-3">
//                       <i className="fa fa-chart-line text-white fs-4"></i>
//                     </div>
//                   </div>
//                 </div>
//               </CardBody>
//             </Card>
//           </Col>

//           <Col xl="3" md="6">
//             <Card className="card-stats">
//               <CardBody>
//                 <div className="d-flex align-items-center">
//                   <div className="flex-grow-1">
//                     <h4 className="mb-0">{overallMetrics.avgQuality}/5</h4>
//                     <span className="text-muted">Avg. Quality Rating</span>
//                   </div>
//                   <div className="flex-shrink-0">
//                     <div className="bg-warning rounded-circle p-3">
//                       <i className="fa fa-star text-white fs-4"></i>
//                     </div>
//                   </div>
//                 </div>
//               </CardBody>
//             </Card>
//           </Col>

//           <Col xl="3" md="6">
//             <Card className="card-stats">
//               <CardBody>
//                 <div className="d-flex align-items-center">
//                   <div className="flex-grow-1">
//                     <h4 className="mb-0">
//                       ${overallMetrics.totalRevenue.toFixed(2)}
//                     </h4>
//                     <span className="text-muted">Total Revenue</span>
//                   </div>
//                   <div className="flex-shrink-0">
//                     <div className="bg-info rounded-circle p-3">
//                       <i className="fa fa-dollar-sign text-white fs-4"></i>
//                     </div>
//                   </div>
//                 </div>
//               </CardBody>
//             </Card>
//           </Col>
//         </Row> */}

//         <Row>
//           <Col sm="12">
//             <Card>
//               <CardBody>
//                 {/* Date Filters */}
//                 <Card className="bg-light mb-4">
//                   <CardBody>
//                     <h6 className="mb-3 text-muted">Filter by Date Range</h6>
//                     <Form>
//                       <Row>
//                         <Col md="3">
//                           <FormGroup className="text-muted">
//                             <Label>Date From</Label>
//                             <Input
//                               type="date"
//                               value={dateFrom}
//                               onChange={(e: ChangeEvent<HTMLInputElement>) =>
//                                 setDateFrom(e.target.value)
//                               }
//                             />
//                           </FormGroup>
//                         </Col>
//                         <Col md="3">
//                           <FormGroup className="text-muted">
//                             <Label>Date To</Label>
//                             <Input
//                               type="date"
//                               value={dateTo}
//                               onChange={(e: ChangeEvent<HTMLInputElement>) =>
//                                 setDateTo(e.target.value)
//                               }
//                             />
//                           </FormGroup>
//                         </Col>
//                         <Col md="3">
//                           <Button color="secondary" className="mt-4 py-2">
//                             <i className="fa fa-filter me-2"></i>
//                             Apply Filters
//                           </Button>
//                         </Col>
//                       </Row>
//                     </Form>
//                   </CardBody>
//                 </Card>

//                 {/* Report Header */}
//                 <div className="d-flex justify-content-between align-items-center mb-4">
//                   <h5 className="card-title mb-0 text-muted">
//                     Technician Performance Report
//                   </h5>
//                   <div className="d-flex gap-2">
//                     <Button
//                       color="outline-primary"
//                       onClick={() => handleExport("excel")}
//                     >
//                       <i className="fa fa-file-excel me-2"></i>
//                       Export Excel
//                     </Button>
//                     <Button
//                       color="outline-danger"
//                       onClick={() => handleExport("pdf")}
//                     >
//                       <i className="fa fa-file-pdf me-2"></i>
//                       Export PDF
//                     </Button>
//                   </div>
//                 </div>
//                 {/* Performance Table */}
//                 <div className="table-responsive">
//                   <Table hover>
//                     <thead>
//                       <tr>
//                         <th>Technician</th>
//                         <th>Specialization</th>
//                         <th>Total Jobs</th>
//                         <th>Completed</th>
//                         <th>In Progress</th>
//                         <th>Efficiency</th>
//                         <th>Quality Rating</th>
//                         <th>Avg. Completion (h)</th>
//                         <th>Revenue Generated</th>
//                         <th>Performance</th>
//                       </tr>
//                     </thead>
//                     <tbody>
//                       {technicianData.map((tech) => (
//                         <tr key={tech.id}>
//                           <td>
//                             <div className="fw-bold">{tech.name}</div>
//                             <small className="text-muted">ID: {tech.id}</small>
//                           </td>
//                           <td>
//                             <div>
//                               {tech.specialization.map((spec) => (
//                                 <Badge
//                                   key={spec}
//                                   color="light"
//                                   className="text-muted me-1 mb-1"
//                                 >
//                                   {spec}
//                                 </Badge>
//                               ))}
//                             </div>
//                           </td>
//                           <td>
//                             <strong>{tech.totalJobs}</strong>
//                           </td>
//                           <td>
//                             <Badge color="success">{tech.completedJobs}</Badge>
//                           </td>
//                           <td>
//                             <Badge color="primary">{tech.inProgressJobs}</Badge>
//                           </td>
//                           <td>{renderEfficiencyBar(tech.efficiency)}</td>
//                           <td>{renderQualityStars(tech.qualityRating)}</td>
//                           <td>{tech.avgCompletionTime}h</td>
//                           <td>
//                             <strong className="text-success">
//                               ${tech.revenueGenerated.toFixed(2)}
//                             </strong>
//                           </td>
//                           <td>
//                             <Badge
//                               color={
//                                 tech.efficiency >= 90
//                                   ? "success"
//                                   : tech.efficiency >= 85
//                                   ? "warning"
//                                   : "danger"
//                               }
//                             >
//                               {tech.efficiency >= 90
//                                 ? "Excellent"
//                                 : tech.efficiency >= 85
//                                 ? "Good"
//                                 : "Needs Improvement"}
//                             </Badge>
//                           </td>
//                         </tr>
//                       ))}
//                     </tbody>
//                   </Table>
//                 </div>
//                 {/* <div className="d-flex flex-column flex-md-row justify-content-between align-items-center gap-3 mt-4">
//                   <div className="text-center text-md-start text-muted">
//                     Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
//                     {Math.min(
//                       currentPage * itemsPerPage,
//                       filteredRevenue.length
//                     )}{" "}
//                     of {filteredRevenue.length} entries
//                   </div>
//                   <CustomPagination
//                     currentPage={currentPage}
//                     totalPages={totalPages}
//                     onPageChange={setCurrentPage}
//                     showFirstLast={true}
//                     maxVisiblePages={5}
//                     paginationType="primary"
//                     className="justify-content-center justify-content-md-end"
//                   />
//                 </div> */}
//                 {/* Performance Summary */}
//                 <Card className="mt-4 bg-light">
//                   <CardBody>
//                     <h6 className="mb-3 text-muted">Performance Summary</h6>
//                     <Row>
//                       <Col md="4">
//                         <div className="mb-2">
//                           <small className="text-muted">Top Performer</small>
//                           <div className="fw-bold text-muted">
//                             {
//                               technicianData.reduce((prev, current) =>
//                                 prev.efficiency > current.efficiency
//                                   ? prev
//                                   : current
//                               ).name
//                             }
//                           </div>
//                         </div>
//                       </Col>
//                       <Col md="4">
//                         <div className="mb-2">
//                           <small className="text-muted">Highest Revenue</small>
//                           <div className="fw-bold text-muted">
//                             {
//                               technicianData.reduce((prev, current) =>
//                                 prev.revenueGenerated > current.revenueGenerated
//                                   ? prev
//                                   : current
//                               ).name
//                             }
//                           </div>
//                         </div>
//                       </Col>
//                       <Col md="4">
//                         <div className="mb-2">
//                           <small className="text-muted">Best Quality</small>
//                           <div className="fw-bold text-muted">
//                             {
//                               technicianData.reduce((prev, current) =>
//                                 prev.qualityRating > current.qualityRating
//                                   ? prev
//                                   : current
//                               ).name
//                             }
//                           </div>
//                         </div>
//                       </Col>
//                     </Row>
//                   </CardBody>
//                 </Card>
//               </CardBody>
//             </Card>
//           </Col>
//         </Row>
//       </Container>

//       <style jsx global>{`
//         .card-stats {
//           border: 1px solid #e6edef;
//           box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
//         }

//         .card-stats .bg-primary {
//           background-color: #5c5ff6 !important;
//         }
//         .card-stats .bg-success {
//           background-color: #28a745 !important;
//         }
//         .card-stats .bg-warning {
//           background-color: #f8d62b !important;
//         }
//         .card-stats .bg-info {
//           background-color: #17a2b8 !important;
//         }
//       `}</style>
//     </div>
//   );
// }

// export default TechnicianPerformanceReport;

"use client";
import Breadcrumbs from "@/CommonElements/Breadcrumbs";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  Table,
  Badge,
  Progress,
  Form,
  FormGroup,
  Label,
  Input,
  Button,
} from "reactstrap";
import React, { useState, ChangeEvent, useEffect } from "react";
import CustomPagination from "@/CommonElements/Pagination";

// Types
interface TechnicianPerformance {
  id: number;
  name: string;
  totalJobs: number;
  completedJobs: number;
  inProgressJobs: number;
  efficiency: number;
  qualityRating: number;
  avgCompletionTime: number;
  revenueGenerated: number;
  specialization: string[];
}

// Mock data
const technicianData: TechnicianPerformance[] = [
  {
    id: 1,
    name: "Mike Smith",
    totalJobs: 45,
    completedJobs: 42,
    inProgressJobs: 3,
    efficiency: 94,
    qualityRating: 4.8,
    avgCompletionTime: 4.2,
    revenueGenerated: 12500.0,
    specialization: ["Engine", "Transmission"],
  },
  {
    id: 2,
    name: "Sarah Johnson",
    totalJobs: 38,
    completedJobs: 35,
    inProgressJobs: 3,
    efficiency: 92,
    qualityRating: 4.9,
    avgCompletionTime: 3.8,
    revenueGenerated: 9800.0,
    specialization: ["Brakes", "Suspension"],
  },
  {
    id: 3,
    name: "David Wilson",
    totalJobs: 52,
    completedJobs: 48,
    inProgressJobs: 4,
    efficiency: 92,
    qualityRating: 4.7,
    avgCompletionTime: 5.1,
    revenueGenerated: 15600.0,
    specialization: ["Electrical", "AC Systems"],
  },
  {
    id: 4,
    name: "Emily Chen",
    totalJobs: 28,
    completedJobs: 25,
    inProgressJobs: 3,
    efficiency: 89,
    qualityRating: 4.6,
    avgCompletionTime: 4.8,
    revenueGenerated: 7200.0,
    specialization: ["Diagnostics", "Hybrid Systems"],
  },
  {
    id: 5,
    name: "John Davis",
    totalJobs: 60,
    completedJobs: 55,
    inProgressJobs: 5,
    efficiency: 91,
    qualityRating: 4.5,
    avgCompletionTime: 4.5,
    revenueGenerated: 18200.0,
    specialization: ["Engine", "Brakes"],
  },
  {
    id: 6,
    name: "Lisa Brown",
    totalJobs: 32,
    completedJobs: 30,
    inProgressJobs: 2,
    efficiency: 93,
    qualityRating: 4.8,
    avgCompletionTime: 3.9,
    revenueGenerated: 8900.0,
    specialization: ["Suspension", "AC Systems"],
  },
  {
    id: 7,
    name: "Robert Taylor",
    totalJobs: 41,
    completedJobs: 38,
    inProgressJobs: 3,
    efficiency: 88,
    qualityRating: 4.4,
    avgCompletionTime: 5.2,
    revenueGenerated: 11200.0,
    specialization: ["Transmission", "Electrical"],
  },
  {
    id: 8,
    name: "Maria Garcia",
    totalJobs: 35,
    completedJobs: 33,
    inProgressJobs: 2,
    efficiency: 95,
    qualityRating: 4.9,
    avgCompletionTime: 3.7,
    revenueGenerated: 9500.0,
    specialization: ["Diagnostics", "Hybrid Systems"],
  },
];

function TechnicianPerformanceReport() {
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(5);

  // Enhanced filters state
  const [filters, setFilters] = useState({
    dateFrom: "",
    dateTo: "",
    name: "all",
    qualityRating: "all",
    specialization: "all",
  });

  // Reset to first page when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [filters]);

  // Filter technician data
  const filteredTechnicians = technicianData.filter((tech) => {
    // const matchesEfficiency =
    //   filters.efficiency === "all" ||
    //   (filters.efficiency === "excellent" && tech.efficiency >= 90) ||
    //   (filters.efficiency === "good" &&
    //     tech.efficiency >= 85 &&
    //     tech.efficiency < 90) ||
    //   (filters.efficiency === "needs_improvement" && tech.efficiency < 85);

    const matchesQuality =
      filters.qualityRating === "all" ||
      (filters.qualityRating === "excellent" && tech.qualityRating >= 4.5) ||
      (filters.qualityRating === "good" &&
        tech.qualityRating >= 4.0 &&
        tech.qualityRating < 4.5) ||
      (filters.qualityRating === "average" && tech.qualityRating < 4.0);

    const matchesSpecialization =
      filters.specialization === "all" ||
      tech.specialization.includes(filters.specialization);
    const matchesTechnician =
      filters.name === "all" || tech.name.includes(filters.name);

    return matchesQuality && matchesSpecialization && matchesTechnician;
  });

  const technicians = [...new Set(technicianData.map((tech) => tech.name))];

  // Calculate pagination
  const totalPages = Math.ceil(filteredTechnicians.length / itemsPerPage);
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = filteredTechnicians.slice(
    indexOfFirstItem,
    indexOfLastItem
  );

  // Calculate overall metrics (based on filtered data)
  const calculateOverallMetrics = () => {
    const totalTechnicians = filteredTechnicians.length;
    const avgEfficiency =
      filteredTechnicians.reduce((sum, tech) => sum + tech.efficiency, 0) /
      (totalTechnicians || 1);
    const avgQuality =
      filteredTechnicians.reduce((sum, tech) => sum + tech.qualityRating, 0) /
      (totalTechnicians || 1);
    const totalRevenue = filteredTechnicians.reduce(
      (sum, tech) => sum + tech.revenueGenerated,
      0
    );
    const totalJobs = filteredTechnicians.reduce(
      (sum, tech) => sum + tech.totalJobs,
      0
    );

    return {
      totalTechnicians,
      avgEfficiency: Math.round(avgEfficiency),
      avgQuality: Math.round(avgQuality * 10) / 10,
      totalRevenue,
      totalJobs,
    };
  };

  const overallMetrics = calculateOverallMetrics();

  const handleFilterChange = (field: string, value: string) => {
    setFilters((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const renderEfficiencyBar = (efficiency: number) => {
    let color = "success";
    if (efficiency < 85) color = "danger";
    else if (efficiency < 90) color = "warning";

    return (
      <div className="d-flex align-items-center">
        <div className="flex-grow-1 me-3">
          <Progress
            value={efficiency}
            color={color}
            style={{ height: "8px" }}
          />
        </div>
        <small className="text-muted">{efficiency}%</small>
      </div>
    );
  };

  const renderQualityStars = (rating: number) => {
    return (
      <div className="d-flex align-items-center">
        <span className="text-warning">
          {"★".repeat(Math.floor(rating))}
          {"☆".repeat(5 - Math.floor(rating))}
        </span>
        <small className="text-muted ms-2">({rating.toFixed(1)})</small>
      </div>
    );
  };

  const handleExport = (format: "pdf" | "excel") => {
    console.log(`Exporting technician performance to ${format}`);
    alert(`Exporting technician performance report to ${format.toUpperCase()}`);
  };

  // Get unique specializations for filter dropdown
  const allSpecializations = Array.from(
    new Set(technicianData.flatMap((tech) => tech.specialization))
  );

  const resetFilters = () => {
    setFilters({
      dateFrom: "",
      dateTo: "",
      // paymentStatus: "all",
      specialization: "all",
      qualityRating: "all",
      name: "all",
    });
  };

  return (
    <div className="page-body">
      <Breadcrumbs
        title="Technician Performance"
        mainTitle="Performance Analytics"
        parent="Reports"
      />

      <Container fluid>
        <Row>
          <Col sm="12">
            <Card>
              <CardBody>
                {/* Enhanced Filters */}
                <Card className="bg-light mb-4">
                  <CardBody>
                    <h6 className="mb-3 text-muted">Filter Report</h6>
                    <Form>
                      <Row>
                        <Col md="3">
                          <FormGroup className="text-muted">
                            <Label>Date From</Label>
                            <Input
                              type="date"
                              value={filters.dateFrom}
                              onChange={(e: ChangeEvent<HTMLInputElement>) =>
                                handleFilterChange("dateFrom", e.target.value)
                              }
                            />
                          </FormGroup>
                        </Col>
                        <Col md="3">
                          <FormGroup className="text-muted">
                            <Label>Date To</Label>
                            <Input
                              type="date"
                              value={filters.dateTo}
                              onChange={(e: ChangeEvent<HTMLInputElement>) =>
                                handleFilterChange("dateTo", e.target.value)
                              }
                            />
                          </FormGroup>
                        </Col>
                        {/* <Col md="2">
                          <FormGroup className="text-muted">
                            <Label>Efficiency</Label>
                            <Input
                              type="select"
                              className="border"
                              value={filters.efficiency}
                              onChange={(e: ChangeEvent<HTMLInputElement>) =>
                                handleFilterChange("efficiency", e.target.value)
                              }
                            >
                              <option value="all">All Efficiency</option>
                              <option value="excellent">
                                Excellent (90%+)
                              </option>
                              <option value="good">Good (85-89%)</option>
                              <option value="needs_improvement">
                                Needs Improvement (&lt;85%)
                              </option>
                            </Input>
                          </FormGroup>
                        </Col> */}
                        <Col md="3">
                          <FormGroup className="text-muted">
                            <Label>Technician</Label>
                            <Input
                              type="select"
                              className="border"
                              value={filters.name}
                              onChange={(e: ChangeEvent<HTMLInputElement>) =>
                                handleFilterChange("technician", e.target.value)
                              }
                            >
                              <option value="all">All Technicians</option>
                              {technicians.map((tech) => (
                                <option key={tech} value={tech}>
                                  {tech}
                                </option>
                              ))}
                            </Input>
                          </FormGroup>
                        </Col>
                        <Col md="3">
                          <FormGroup className="text-muted">
                            <Label>Quality Rating</Label>
                            <Input
                              type="select"
                              className="border"
                              value={filters.qualityRating}
                              onChange={(e: ChangeEvent<HTMLInputElement>) =>
                                handleFilterChange(
                                  "qualityRating",
                                  e.target.value
                                )
                              }
                            >
                              <option value="all">All Ratings</option>
                              <option value="excellent">
                                Excellent (4.5+)
                              </option>
                              <option value="good">Good (4.0-4.4)</option>
                              <option value="average">Average (&lt;4.0)</option>
                            </Input>
                          </FormGroup>
                        </Col>
                        <Col md="3">
                          <FormGroup className="text-muted">
                            <Label>Specialization</Label>
                            <Input
                              type="select"
                              className="border"
                              value={filters.specialization}
                              onChange={(e: ChangeEvent<HTMLInputElement>) =>
                                handleFilterChange(
                                  "specialization",
                                  e.target.value
                                )
                              }
                            >
                              <option value="all">All Specializations</option>
                              {allSpecializations.map((spec) => (
                                <option key={spec} value={spec}>
                                  {spec}
                                </option>
                              ))}
                            </Input>
                          </FormGroup>
                        </Col>
                        <Col md="3">
                          {/* <div className="d-flex justify-content-end"> */}
                          <Button
                            color="secondary"
                            className="mt-4 py-2"
                            onClick={resetFilters}
                          >
                            <i className="fa fa-refresh me-2"></i>
                            Reset Filters
                          </Button>
                          {/* </div> */}
                        </Col>
                      </Row>
                    </Form>
                  </CardBody>
                </Card>

                {/* Report Header */}
                <div className="d-flex justify-content-between align-items-center mb-4">
                  <h5 className="card-title mb-0 text-muted">
                    Technician Performance Report
                  </h5>
                  <div className="d-flex gap-2">
                    <Button
                      color="outline-primary"
                      onClick={() => handleExport("excel")}
                    >
                      <i className="fa fa-file-excel me-2"></i>
                      Export Excel
                    </Button>
                    <Button
                      color="outline-danger"
                      onClick={() => handleExport("pdf")}
                    >
                      <i className="fa fa-file-pdf me-2"></i>
                      Export PDF
                    </Button>
                  </div>
                </div>

                {/* Performance Table */}
                <div className="table-responsive">
                  <Table hover>
                    <thead>
                      <tr>
                        <th>Technician</th>
                        <th>Specialization</th>
                        <th>Total Jobs</th>
                        <th>Completed</th>
                        <th>In Progress</th>
                        <th>Efficiency</th>
                        <th>Quality Rating</th>
                        <th>Avg. Completion (h)</th>
                        <th>Revenue Generated</th>
                        <th>Performance</th>
                      </tr>
                    </thead>
                    <tbody>
                      {currentItems.map((tech) => (
                        <tr key={tech.id}>
                          <td>
                            <div className="fw-bold no-wrap">{tech.name}</div>
                            <small className="text-muted">ID: {tech.id}</small>
                          </td>
                          <td>
                            <div>
                              {tech.specialization.map((spec) => (
                                <Badge
                                  key={spec}
                                  color="light"
                                  className="text-muted me-1 mb-1 no-wrap"
                                >
                                  {spec}
                                </Badge>
                              ))}
                            </div>
                          </td>
                          <td>
                            <strong>{tech.totalJobs}</strong>
                          </td>
                          <td>
                            <Badge color="success">{tech.completedJobs}</Badge>
                          </td>
                          <td>
                            <Badge color="primary">{tech.inProgressJobs}</Badge>
                          </td>
                          <td>{renderEfficiencyBar(tech.efficiency)}</td>
                          <td>{renderQualityStars(tech.qualityRating)}</td>
                          <td>{tech.avgCompletionTime}h</td>
                          <td>
                            <strong className="text-success">
                              ${tech.revenueGenerated.toFixed(2)}
                            </strong>
                          </td>
                          <td>
                            <Badge
                              color={
                                tech.efficiency >= 90
                                  ? "success"
                                  : tech.efficiency >= 85
                                  ? "warning"
                                  : "danger"
                              }
                            >
                              {tech.efficiency >= 90
                                ? "Excellent"
                                : tech.efficiency >= 85
                                ? "Good"
                                : "Needs Improvement"}
                            </Badge>
                          </td>
                        </tr>
                      ))}
                      {currentItems.length === 0 && (
                        <tr>
                          <td colSpan={10} className="text-center py-4">
                            <div className="text-muted">
                              No technicians found matching your filters.
                            </div>
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </Table>
                </div>

                {/* Pagination */}
                {filteredTechnicians.length > 0 && (
                  <div className="d-flex flex-column flex-md-row justify-content-between align-items-center gap-3 mt-4">
                    <div className="text-center text-md-start text-muted">
                      Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
                      {Math.min(
                        currentPage * itemsPerPage,
                        filteredTechnicians.length
                      )}{" "}
                      of {filteredTechnicians.length} entries
                    </div>
                    <CustomPagination
                      currentPage={currentPage}
                      totalPages={totalPages}
                      onPageChange={setCurrentPage}
                      showFirstLast={true}
                      maxVisiblePages={5}
                      paginationType="primary"
                      className="justify-content-center justify-content-md-end"
                    />
                  </div>
                )}

                {/* Performance Summary */}
                <Card className="mt-4 bg-light">
                  <CardBody>
                    <h6 className="mb-3 text-muted">Performance Summary</h6>
                    <Row>
                      <Col md="3">
                        <div className="mb-2">
                          <small className="text-muted">
                            Total Technicians
                          </small>
                          <div className="fw-bold text-muted">
                            {overallMetrics.totalTechnicians}
                          </div>
                        </div>
                      </Col>
                      <Col md="3">
                        <div className="mb-2">
                          <small className="text-muted">
                            Average Efficiency
                          </small>
                          <div className="fw-bold text-muted">
                            {overallMetrics.avgEfficiency}%
                          </div>
                        </div>
                      </Col>
                      <Col md="3">
                        <div className="mb-2">
                          <small className="text-muted">Average Quality</small>
                          <div className="fw-bold text-muted">
                            {overallMetrics.avgQuality}/5
                          </div>
                        </div>
                      </Col>
                      <Col md="3">
                        <div className="mb-2">
                          <small className="text-muted">Total Revenue</small>
                          <div className="fw-bold text-muted">
                            ${overallMetrics.totalRevenue.toFixed(2)}
                          </div>
                        </div>
                      </Col>
                    </Row>
                    <Row className="mt-3">
                      <Col md="4">
                        <div className="mb-2">
                          <small className="text-muted">Top Performer</small>
                          <div className="fw-bold text-success">
                            {filteredTechnicians.length > 0
                              ? filteredTechnicians.reduce((prev, current) =>
                                  prev.efficiency > current.efficiency
                                    ? prev
                                    : current
                                ).name
                              : "N/A"}
                          </div>
                        </div>
                      </Col>
                      <Col md="4">
                        <div className="mb-2">
                          <small className="text-muted">Highest Revenue</small>
                          <div className="fw-bold text-primary">
                            {filteredTechnicians.length > 0
                              ? filteredTechnicians.reduce((prev, current) =>
                                  prev.revenueGenerated >
                                  current.revenueGenerated
                                    ? prev
                                    : current
                                ).name
                              : "N/A"}
                          </div>
                        </div>
                      </Col>
                      <Col md="4">
                        <div className="mb-2">
                          <small className="text-muted">Best Quality</small>
                          <div className="fw-bold text-warning">
                            {filteredTechnicians.length > 0
                              ? filteredTechnicians.reduce((prev, current) =>
                                  prev.qualityRating > current.qualityRating
                                    ? prev
                                    : current
                                ).name
                              : "N/A"}
                          </div>
                        </div>
                      </Col>
                    </Row>
                  </CardBody>
                </Card>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Container>

      <style jsx global>{`
        .card-stats {
          border: 1px solid #e6edef;
          box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
        }

        .card-stats .bg-primary {
          background-color: #5c5ff6 !important;
        }
        .card-stats .bg-success {
          background-color: #28a745 !important;
        }
        .card-stats .bg-warning {
          background-color: #f8d62b !important;
        }
        .card-stats .bg-info {
          background-color: #17a2b8 !important;
        }
      `}</style>
    </div>
  );
}

export default TechnicianPerformanceReport;
