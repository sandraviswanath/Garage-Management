"use client";
import Breadcrumbs from "@/CommonElements/Breadcrumbs";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  Table,
  Badge,
  Form,
  FormGroup,
  Label,
  Input,
  Button,
  Alert,
} from "reactstrap";
import React, { useState, ChangeEvent, useEffect } from "react";
import CustomPagination from "@/CommonElements/Pagination";
import { useAuth } from "@/helper/AuthContext";
import * as XLSX from "xlsx";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import withAuth from "@/helper/WithAuth";
// Types based on your API response
interface RevenueData {
  date: string;
  job_number: string | null;
  amount: string;
  method: string;
  invoice_number: string;
  name: string | null;
  labor_estimate: string | null;
  parts_estimate: string | null;
  total_estimate: string | null;
  status: string | null;
}

interface RevenueMetrics {
  totalRevenue: number;
  paidRevenue: number;
  pendingRevenue: number;
  overdueRevenue: number;
  laborRevenue: number;
  partsRevenue: number;
  collectionRate: number;
}

function RevenueReport() {
  const { state } = useAuth();
  const [currentPage, setCurrentPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [revenueData, setRevenueData] = useState<RevenueData[]>([]);
  const [filters, setFilters] = useState({
    dateFrom: "",
    dateTo: "",
    paymentStatus: "all",
    serviceType: "all",
    paymentMethod: "all",
  });

  const itemsPerPage = 10;

  // Fetch revenue data from API
  useEffect(() => {
    fetchRevenueData();
  }, []);

  const fetchRevenueData = async () => {
    try {
      setLoading(true);
      setError(null);

      const response = await fetch("/api/reports/revenue", {
        headers: {
          Authorization: `Bearer ${
            state?.accessToken || localStorage.getItem("token")
          }`,
        },
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch revenue data: ${response.status}`);
      }

      const result = await response.json();
      setRevenueData(result.data || []);
    } catch (err: any) {
      console.error("Error fetching revenue data:", err);
      setError(err.message || "Failed to load revenue data");
    } finally {
      setLoading(false);
    }
  };

  // Filter revenue data
  const filteredRevenue = revenueData.filter((item) => {
    // Date filter
    const itemDate = item.date !== "0000-00-00" ? item.date : "";
    const matchesDate =
      (!filters.dateFrom || itemDate >= filters.dateFrom) &&
      (!filters.dateTo || itemDate <= filters.dateTo);

    // Payment status filter
    const paymentStatus = item.status || "pending";
    const matchesPaymentStatus =
      filters.paymentStatus === "all" ||
      paymentStatus === filters.paymentStatus;

    // Payment method filter
    const matchesPaymentMethod =
      filters.paymentMethod === "all" || item.method === filters.paymentMethod;

    return matchesDate && matchesPaymentStatus && matchesPaymentMethod;
  });

  // Get unique payment methods
  const paymentMethods = [
    ...new Set(revenueData.map((item) => item.method).filter(Boolean)),
  ];

  // Calculate revenue metrics
  const calculateMetrics = (): RevenueMetrics => {
    const totalRevenue = filteredRevenue.reduce(
      (sum, item) => sum + parseFloat(item.amount || "0"),
      0
    );

    // Determine paid/pending/overdue based on status field
    const paidRevenue = filteredRevenue
      .filter((item) => (item.status || "").toLowerCase() === "paid")
      .reduce((sum, item) => sum + parseFloat(item.amount || "0"), 0);

    const pendingRevenue = filteredRevenue
      .filter((item) => {
        const status = (item.status || "").toLowerCase();
        return status === "pending" || status === "unpaid" || !status;
      })
      .reduce((sum, item) => sum + parseFloat(item.amount || "0"), 0);

    const overdueRevenue = filteredRevenue
      .filter((item) => (item.status || "").toLowerCase() === "overdue")
      .reduce((sum, item) => sum + parseFloat(item.amount || "0"), 0);

    const laborRevenue = filteredRevenue.reduce(
      (sum, item) => sum + parseFloat(item.labor_estimate || "0"),
      0
    );

    const partsRevenue = filteredRevenue.reduce(
      (sum, item) => sum + parseFloat(item.parts_estimate || "0"),
      0
    );

    const collectionRate =
      totalRevenue > 0 ? (paidRevenue / totalRevenue) * 100 : 0;

    return {
      totalRevenue,
      paidRevenue,
      pendingRevenue,
      overdueRevenue,
      laborRevenue,
      partsRevenue,
      collectionRate,
    };
  };

  const metrics = calculateMetrics();

  const handleFilterChange = (field: string, value: string) => {
    setFilters((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const totalPages = Math.ceil(filteredRevenue.length / itemsPerPage);
  const paginatedRevenue = filteredRevenue.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const flattenData = () =>
    filteredRevenue.map((item, idx) => ({
      // SNo: idx + 1,
      InvoiceNumber: item.invoice_number,
      JobNumber: item.job_number,
      LaborEstimate: item.labor_estimate,
      PartsEstimate: item.parts_estimate,
      TotalEstimate: item.total_estimate,
      Customer: item.name || "N/A",
      Type: item.method,
      Amount: item.amount,
      Date: new Date(item.date).toLocaleDateString(),
    }));

  const exportToExcel = () => {
    const ws = XLSX.utils.json_to_sheet(flattenData());
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Revenue Report");
    XLSX.writeFile(wb, "revenue_report.xlsx");
  };

  const exportToPDF = () => {
    const doc = new jsPDF();
    doc.text("Revenue Report", 14, 10);
    autoTable(doc, {
      head: [
        [
          // "#",
          "Invoice Number",
          "Job Number",
          "Labor Estimate",
          "Parts Estimate",
          "Total Estimate",
          "Customer",
          "Type",
          "Amount",
          "Date",
        ],
      ],
      body: flattenData().map((d) => [
        // d.SNo,
        d.InvoiceNumber,
        d.JobNumber,
        d.LaborEstimate,
        d.PartsEstimate,
        d.TotalEstimate,
        d.Customer,
        d.Type,

        d.Amount,
        d.Date,
      ]),
      startY: 20,
      styles: { fontSize: 8, cellWidth: "wrap" },
      theme: "grid",
    });

    doc.save("Revenue_report.pdf");
  };
  const renderPaymentStatus = (status: string | null) => {
    const statusValue = (status || "pending").toLowerCase();
    const statusConfig = {
      paid: { class: "bg-success", label: "Paid" },
      pending: { class: "bg-warning", label: "Pending" },
      overdue: { class: "bg-danger", label: "Overdue" },
      unpaid: { class: "bg-warning", label: "Unpaid" },
    };

    const config = statusConfig[statusValue as keyof typeof statusConfig] || {
      class: "bg-secondary",
      label: statusValue,
    };

    return <Badge className={config.class}>{config.label}</Badge>;
  };

  const renderPaymentMethod = (method: string) => {
    const methodConfig: Record<string, string> = {
      cash: "Cash",
      card: "Credit Card",
      credit: "Credit",
      transfer: "Bank Transfer",
      check: "Check",
      online: "Online Payment",
    };

    return <Badge color="info">{methodConfig[method] || method}</Badge>;
  };

  const resetFilters = () => {
    setFilters({
      dateFrom: "",
      dateTo: "",
      paymentStatus: "all",
      serviceType: "all",
      paymentMethod: "all",
    });
  };

  const formatDate = (dateString: string) => {
    if (!dateString || dateString === "0000-00-00") {
      return "N/A";
    }
    return new Date(dateString).toLocaleDateString();
  };

  const refreshData = () => {
    fetchRevenueData();
  };

  if (loading && revenueData.length === 0) {
    return (
      <div className="page-body">
        <Breadcrumbs
          title="Revenue Report"
          mainTitle="Financial Analysis"
          parent="Reports"
        />
        <Container fluid>
          <Row>
            <Col sm="12">
              <Card>
                <CardBody className="text-center py-5">
                  <div className="spinner-border text-primary" role="status">
                    <span className="visually-hidden">Loading...</span>
                  </div>
                  <p className="mt-3 mb-0">Loading revenue data...</p>
                </CardBody>
              </Card>
            </Col>
          </Row>
        </Container>
      </div>
    );
  }

  return (
    <div className="page-body">
      <Breadcrumbs
        title="Revenue Report"
        mainTitle="Financial Analysis"
        parent="Reports"
      />

      <Container fluid>
        {/* Error and refresh button */}
        <div className="d-flex justify-content-between align-items-center mb-3">
          {error && (
            <Alert color="danger" className="mb-0 flex-grow-1 me-3">
              <i className="fa fa-exclamation-circle me-2"></i>
              {error}
            </Alert>
          )}
        </div>

        <Row>
          <Col sm="12">
            <Card>
              <CardBody>
                {/* Filters */}
                <Card className="bg-light mb-4">
                  <CardBody>
                    <h6 className="mb-3 text-muted">Filter Report</h6>
                    <Form>
                      <Row>
                        <Col md="3">
                          <FormGroup className="text-muted">
                            <Label>Date From</Label>
                            <Input
                              type="date"
                              value={filters.dateFrom}
                              onChange={(e: ChangeEvent<HTMLInputElement>) =>
                                handleFilterChange("dateFrom", e.target.value)
                              }
                              disabled={loading}
                            />
                          </FormGroup>
                        </Col>
                        <Col md="3">
                          <FormGroup className="text-muted">
                            <Label>Date To</Label>
                            <Input
                              type="date"
                              value={filters.dateTo}
                              onChange={(e: ChangeEvent<HTMLInputElement>) =>
                                handleFilterChange("dateTo", e.target.value)
                              }
                              disabled={loading}
                            />
                          </FormGroup>
                        </Col>
                        <Col md="3">
                          <FormGroup className="text-muted">
                            <Label>Payment Status</Label>
                            <Input
                              type="select"
                              className="border"
                              value={filters.paymentStatus}
                              onChange={(e: ChangeEvent<HTMLInputElement>) =>
                                handleFilterChange(
                                  "paymentStatus",
                                  e.target.value
                                )
                              }
                              disabled={loading}
                            >
                              <option value="all">All Status</option>
                              <option value="paid">Paid</option>
                              <option value="pending">Pending</option>
                              <option value="overdue">Overdue</option>
                              <option value="unpaid">Unpaid</option>
                            </Input>
                          </FormGroup>
                        </Col>
                        <Col md="3">
                          <FormGroup className="text-muted">
                            <Label>Payment Method</Label>
                            <Input
                              type="select"
                              className="border"
                              value={filters.paymentMethod}
                              onChange={(e: ChangeEvent<HTMLInputElement>) =>
                                handleFilterChange(
                                  "paymentMethod",
                                  e.target.value
                                )
                              }
                              disabled={loading}
                            >
                              <option value="all">All Methods</option>
                              {paymentMethods.map((method) => (
                                <option key={method} value={method}>
                                  {method.charAt(0).toUpperCase() +
                                    method.slice(1)}
                                </option>
                              ))}
                            </Input>
                          </FormGroup>
                        </Col>
                        <Col md="3">
                          <Button
                            color="secondary"
                            className="mt-4 py-2"
                            onClick={resetFilters}
                          >
                            <i className="fa fa-refresh me-2"></i>
                            Reset Filters
                          </Button>
                        </Col>
                      </Row>
                    </Form>
                  </CardBody>
                </Card>

                {/* Report Header */}
                <div className="d-flex justify-content-between align-items-center mb-4">
                  <h5 className="card-title mb-0 text-muted">Revenue Report</h5>
                  <div className="d-flex gap-2">
                    <Button
                      color="outline-primary"
                      onClick={exportToExcel}
                      disabled={loading || filteredRevenue.length === 0}
                    >
                      <i className="fa fa-file-excel me-2"></i>
                      Export Excel
                    </Button>
                    <Button
                      color="outline-danger"
                      onClick={exportToPDF}
                      disabled={loading || filteredRevenue.length === 0}
                    >
                      <i className="fa fa-file-pdf me-2"></i>
                      Export PDF
                    </Button>
                  </div>
                </div>

                {/* Loading indicator */}
                {loading && (
                  <div className="text-center mb-3">
                    <div
                      className="spinner-border spinner-border-sm text-primary me-2"
                      role="status"
                    >
                      <span className="visually-hidden">Loading...</span>
                    </div>
                    <span className="text-muted">Updating data...</span>
                  </div>
                )}

                {/* Revenue Table */}
                <div className="table-responsive">
                  <Table hover>
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>Date</th>
                        <th>Invoice Number</th>
                        <th>Customer</th>
                        <th>Job Number</th>
                        <th>Labor Estimate</th>
                        <th>Parts Estimate</th>
                        <th>Total Estimate</th>
                        <th>Amount</th>
                        <th>Payment Status</th>
                        <th>Payment Method</th>
                      </tr>
                    </thead>
                    <tbody>
                      {paginatedRevenue.length === 0 ? (
                        <tr>
                          <td colSpan={10} className="text-center py-4">
                            {loading
                              ? "Loading..."
                              : "No revenue records found"}
                          </td>
                        </tr>
                      ) : (
                        paginatedRevenue.map((item, index) => (
                          <tr key={`${item.invoice_number}-${index}`}>
                            <td>
                              {(currentPage - 1) * itemsPerPage + index + 1}
                            </td>
                            <td>{formatDate(item.date)}</td>
                            <td>
                              <strong className="text-primary">
                                {item.invoice_number || "N/A"}
                              </strong>
                            </td>
                            <td>{item.name || "N/A"}</td>
                            <td>
                              <Badge color="light" className="text-muted">
                                {item.job_number || "N/A"}
                              </Badge>
                            </td>
                            <td>
                              $
                              {parseFloat(item.labor_estimate || "0").toFixed(
                                2
                              )}
                            </td>
                            <td>
                              $
                              {parseFloat(item.parts_estimate || "0").toFixed(
                                2
                              )}
                            </td>
                            <td>
                              $
                              {parseFloat(item.total_estimate || "0").toFixed(
                                2
                              )}
                            </td>
                            <td>
                              <strong className="text-success">
                                ${parseFloat(item.amount || "0").toFixed(2)}
                              </strong>
                            </td>
                            <td>{renderPaymentStatus(item.status)}</td>
                            <td>{renderPaymentMethod(item.method)}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </Table>
                </div>

                {/* Pagination */}
                <div className="d-flex flex-column flex-md-row justify-content-between align-items-center gap-3 mt-4">
                  <div className="text-center text-md-start text-muted">
                    Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
                    {Math.min(
                      currentPage * itemsPerPage,
                      filteredRevenue.length
                    )}{" "}
                    of {filteredRevenue.length} entries
                  </div>
                  {totalPages > 1 && (
                    <CustomPagination
                      currentPage={currentPage}
                      totalPages={totalPages}
                      onPageChange={setCurrentPage}
                      showFirstLast={true}
                      maxVisiblePages={5}
                      paginationType="primary"
                      className="justify-content-center justify-content-md-end"
                    />
                  )}
                </div>

                {/* Summary Section */}
                <Card className="mt-4 bg-light">
                  <CardBody>
                    <h6 className="mb-3 text-muted">Revenue Summary</h6>
                    <Row>
                      <Col md="3">
                        <div className="mb-2">
                          <small className="text-muted">Total Revenue</small>
                          <div className="fw-bold text-primary">
                            ${metrics.totalRevenue.toFixed(2)}
                          </div>
                        </div>
                      </Col>
                      <Col md="3">
                        <div className="mb-2">
                          <small className="text-muted">Collection Rate</small>
                          <div className="fw-bold text-success">
                            {metrics.collectionRate.toFixed(1)}%
                          </div>
                        </div>
                      </Col>
                      <Col md="3">
                        <div className="mb-2">
                          <small className="text-muted">
                            Average Transaction
                          </small>
                          <div className="fw-bold text-muted">
                            $
                            {filteredRevenue.length > 0
                              ? (
                                  metrics.totalRevenue / filteredRevenue.length
                                ).toFixed(2)
                              : "0.00"}
                          </div>
                        </div>
                      </Col>
                      <Col md="3">
                        <div className="mb-2">
                          <small className="text-muted">Labor vs Parts</small>
                          <div className="fw-bold text-muted">
                            {metrics.totalRevenue > 0
                              ? `${(
                                  (metrics.laborRevenue /
                                    metrics.totalRevenue) *
                                  100
                                ).toFixed(1)}% Labor / 
                              ${(
                                (metrics.partsRevenue / metrics.totalRevenue) *
                                100
                              ).toFixed(1)}% Parts`
                              : "N/A"}
                          </div>
                        </div>
                      </Col>
                    </Row>
                  </CardBody>
                </Card>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Container>
    </div>
  );
}

// export default RevenueReport;
export default withAuth(RevenueReport, ["admin"]);
// "use client";
// import Breadcrumbs from "@/CommonElements/Breadcrumbs";
// import {
//   Container,
//   Row,
//   Col,
//   Card,
//   CardBody,
//   Table,
//   Badge,
//   Form,
//   FormGroup,
//   Label,
//   Input,
//   Button,
// } from "reactstrap";
// import React, { useState, ChangeEvent } from "react";
// import CustomPagination from "@/CommonElements/Pagination";

// // Types
// interface RevenueData {
//   id: number;
//   date: string;
//   jobNumber: string;
//   customer: string;
//   serviceType: string;
//   laborCost: number;
//   partsCost: number;
//   totalCost: number;
//   paymentStatus: "paid" | "pending" | "overdue";
//   paymentMethod: string;
// }

// // Mock data
// const revenueData: RevenueData[] = [
//   {
//     id: 1,
//     date: "2024-01-15",
//     jobNumber: "JC-2024-001",
//     customer: "John Doe",
//     serviceType: "Regular Maintenance",
//     laborCost: 150.0,
//     partsCost: 95.5,
//     totalCost: 245.5,
//     paymentStatus: "paid",
//     paymentMethod: "Credit Card",
//   },
//   {
//     id: 2,
//     date: "2024-01-16",
//     jobNumber: "JC-2024-002",
//     customer: "Jane Smith",
//     serviceType: "Brake Repair",
//     laborCost: 200.0,
//     partsCost: 250.0,
//     totalCost: 450.0,
//     paymentStatus: "pending",
//     paymentMethod: "Cash",
//   },
//   {
//     id: 3,
//     date: "2024-01-14",
//     jobNumber: "JC-2024-003",
//     customer: "Mike Johnson",
//     serviceType: "Inspection",
//     laborCost: 80.0,
//     partsCost: 40.0,
//     totalCost: 120.0,
//     paymentStatus: "paid",
//     paymentMethod: "Bank Transfer",
//   },
//   {
//     id: 4,
//     date: "2024-01-17",
//     jobNumber: "JC-2024-004",
//     customer: "Sarah Wilson",
//     serviceType: "AC Repair",
//     laborCost: 180.0,
//     partsCost: 170.0,
//     totalCost: 350.0,
//     paymentStatus: "overdue",
//     paymentMethod: "Credit Card",
//   },
//   {
//     id: 5,
//     date: "2024-01-12",
//     jobNumber: "JC-2024-005",
//     customer: "Robert Brown",
//     serviceType: "Engine Repair",
//     laborCost: 400.0,
//     partsCost: 350.0,
//     totalCost: 750.0,
//     paymentStatus: "paid",
//     paymentMethod: "Cash",
//   },
// ];

// function RevenueReport() {
//   const [currentPage, setCurrentPage] = useState(1);
//   const [filters, setFilters] = useState({
//     dateFrom: "",
//     dateTo: "",
//     paymentStatus: "all",
//     serviceType: "all",
//   });
//   const itemsPerPage = 10;

//   // Filter revenue data
//   const filteredRevenue = revenueData.filter((item) => {
//     const matchesDate =
//       (!filters.dateFrom || item.date >= filters.dateFrom) &&
//       (!filters.dateTo || item.date <= filters.dateTo);
//     const matchesPaymentStatus =
//       filters.paymentStatus === "all" ||
//       item.paymentStatus === filters.paymentStatus;
//     const matchesServiceType =
//       filters.serviceType === "all" || item.serviceType === filters.serviceType;

//     return matchesDate && matchesPaymentStatus && matchesServiceType;
//   });

//   // Calculate revenue metrics
//   const calculateMetrics = () => {
//     const totalRevenue = filteredRevenue.reduce(
//       (sum, item) => sum + item.totalCost,
//       0
//     );
//     const paidRevenue = filteredRevenue
//       .filter((item) => item.paymentStatus === "paid")
//       .reduce((sum, item) => sum + item.totalCost, 0);
//     const pendingRevenue = filteredRevenue
//       .filter((item) => item.paymentStatus === "pending")
//       .reduce((sum, item) => sum + item.totalCost, 0);
//     const overdueRevenue = filteredRevenue
//       .filter((item) => item.paymentStatus === "overdue")
//       .reduce((sum, item) => sum + item.totalCost, 0);
//     const laborRevenue = filteredRevenue.reduce(
//       (sum, item) => sum + item.laborCost,
//       0
//     );
//     const partsRevenue = filteredRevenue.reduce(
//       (sum, item) => sum + item.partsCost,
//       0
//     );

//     return {
//       totalRevenue,
//       paidRevenue,
//       pendingRevenue,
//       overdueRevenue,
//       laborRevenue,
//       partsRevenue,
//       collectionRate: totalRevenue > 0 ? (paidRevenue / totalRevenue) * 100 : 0,
//     };
//   };

//   const metrics = calculateMetrics();

//   const handleFilterChange = (field: string, value: string) => {
//     setFilters((prev) => ({
//       ...prev,
//       [field]: value,
//     }));
//   };

//   const totalPages = Math.ceil(filteredRevenue.length / itemsPerPage);
//   const paginatedRevenue = filteredRevenue.slice(
//     (currentPage - 1) * itemsPerPage,
//     currentPage * itemsPerPage
//   );

//   const handleExport = (format: "pdf" | "excel") => {
//     console.log(`Exporting revenue report to ${format}`);
//     alert(`Exporting revenue report to ${format.toUpperCase()}`);
//   };

//   const renderPaymentStatus = (status: string) => {
//     const statusConfig = {
//       paid: { class: "bg-success", label: "Paid" },
//       pending: { class: "bg-warning", label: "Pending" },
//       overdue: { class: "bg-danger", label: "Overdue" },
//     };

//     const config = statusConfig[status as keyof typeof statusConfig] || {
//       class: "bg-secondary",
//       label: status,
//     };

//     return <Badge className={config.class}>{config.label}</Badge>;
//   };

//   const resetFilters = () => {
//     setFilters({
//       dateFrom: "",
//       dateTo: "",
//       paymentStatus: "all",
//       // technician: "all",
//       serviceType: "all",
//     });
//   };

//   return (
//     <div className="page-body">
//       <Breadcrumbs
//         title="Revenue Report"
//         mainTitle="Financial Analysis"
//         parent="Reports"
//       />

//       <Container fluid>
//         {/* Revenue Metrics */}
//         {/* <Row className="mb-4">
//           <Col xl="2" md="4">
//             <Card className="card-stats">
//               <CardBody>
//                 <div className="text-center">
//                   <h4 className="mb-0">${metrics.totalRevenue.toFixed(2)}</h4>
//                   <span className="text-muted">Total Revenue</span>
//                 </div>
//               </CardBody>
//             </Card>
//           </Col>

//           <Col xl="2" md="4">
//             <Card className="card-stats">
//               <CardBody>
//                 <div className="text-center">
//                   <h4 className="mb-0 text-success">
//                     ${metrics.paidRevenue.toFixed(2)}
//                   </h4>
//                   <span className="text-muted">Paid</span>
//                 </div>
//               </CardBody>
//             </Card>
//           </Col>

//           <Col xl="2" md="4">
//             <Card className="card-stats">
//               <CardBody>
//                 <div className="text-center">
//                   <h4 className="mb-0 text-warning">
//                     ${metrics.pendingRevenue.toFixed(2)}
//                   </h4>
//                   <span className="text-muted">Pending</span>
//                 </div>
//               </CardBody>
//             </Card>
//           </Col>

//           <Col xl="2" md="4">
//             <Card className="card-stats">
//               <CardBody>
//                 <div className="text-center">
//                   <h4 className="mb-0 text-danger">
//                     ${metrics.overdueRevenue.toFixed(2)}
//                   </h4>
//                   <span className="text-muted">Overdue</span>
//                 </div>
//               </CardBody>
//             </Card>
//           </Col>

//           <Col xl="2" md="4">
//             <Card className="card-stats">
//               <CardBody>
//                 <div className="text-center">
//                   <h4 className="mb-0">${metrics.laborRevenue.toFixed(2)}</h4>
//                   <span className="text-muted">Labor</span>
//                 </div>
//               </CardBody>
//             </Card>
//           </Col>

//           <Col xl="2" md="4">
//             <Card className="card-stats">
//               <CardBody>
//                 <div className="text-center">
//                   <h4 className="mb-0">${metrics.partsRevenue.toFixed(2)}</h4>
//                   <span className="text-muted">Parts</span>
//                 </div>
//               </CardBody>
//             </Card>
//           </Col>
//         </Row> */}

//         <Row>
//           <Col sm="12">
//             <Card>
//               <CardBody>
//                 {/* Filters */}
//                 <Card className="bg-light mb-4">
//                   <CardBody>
//                     <h6 className="mb-3 text-muted">Filter Report</h6>
//                     <Form>
//                       <Row>
//                         <Col md="3">
//                           <FormGroup className="text-muted">
//                             <Label>Date From</Label>
//                             <Input
//                               type="date"
//                               value={filters.dateFrom}
//                               onChange={(e: ChangeEvent<HTMLInputElement>) =>
//                                 handleFilterChange("dateFrom", e.target.value)
//                               }
//                             />
//                           </FormGroup>
//                         </Col>
//                         <Col md="3">
//                           <FormGroup className="text-muted">
//                             <Label>Date To</Label>
//                             <Input
//                               type="date"
//                               value={filters.dateTo}
//                               onChange={(e: ChangeEvent<HTMLInputElement>) =>
//                                 handleFilterChange("dateTo", e.target.value)
//                               }
//                             />
//                           </FormGroup>
//                         </Col>
//                         <Col md="3">
//                           <FormGroup className="text-muted">
//                             <Label>Payment Status</Label>
//                             <Input
//                               type="select"
//                               className="border"
//                               value={filters.paymentStatus}
//                               onChange={(e: ChangeEvent<HTMLInputElement>) =>
//                                 handleFilterChange(
//                                   "paymentStatus",
//                                   e.target.value
//                                 )
//                               }
//                             >
//                               <option value="all">All Status</option>
//                               <option value="paid">Paid</option>
//                               <option value="pending">Pending</option>
//                               <option value="overdue">Overdue</option>
//                             </Input>
//                           </FormGroup>
//                         </Col>
//                         <Col md="3">
//                           <FormGroup className="text-muted">
//                             <Label>Service Type</Label>
//                             <Input
//                               type="select"
//                               className="border"
//                               value={filters.serviceType}
//                               onChange={(e: ChangeEvent<HTMLInputElement>) =>
//                                 handleFilterChange(
//                                   "serviceType",
//                                   e.target.value
//                                 )
//                               }
//                             >
//                               <option value="all">All Services</option>
//                               <option value="Regular Maintenance">
//                                 Regular Maintenance
//                               </option>
//                               <option value="Brake Repair">Brake Repair</option>
//                               <option value="Inspection">Inspection</option>
//                               <option value="AC Repair">AC Repair</option>
//                               <option value="Engine Repair">
//                                 Engine Repair
//                               </option>
//                             </Input>
//                           </FormGroup>
//                         </Col>

//                         <Col md="3">
//                           {/* <div className="d-flex justify-content-end"> */}
//                           <Button
//                             color="secondary"
//                             className="mt-4 py-2"
//                             onClick={resetFilters}
//                           >
//                             <i className="fa fa-refresh me-2"></i>
//                             Reset Filters
//                           </Button>
//                           {/* </div> */}
//                         </Col>
//                       </Row>
//                     </Form>
//                   </CardBody>
//                 </Card>
//                 {/* Report Header */}
//                 <div className="d-flex justify-content-between align-items-center mb-4">
//                   <h5 className="card-title mb-0 text-muted">Revenue Report</h5>
//                   <div className="d-flex gap-2">
//                     <Button
//                       color="outline-primary"
//                       onClick={() => handleExport("excel")}
//                     >
//                       <i className="fa fa-file-excel me-2"></i>
//                       Export Excel
//                     </Button>
//                     <Button
//                       color="outline-danger"
//                       onClick={() => handleExport("pdf")}
//                     >
//                       <i className="fa fa-file-pdf me-2"></i>
//                       Export PDF
//                     </Button>
//                   </div>
//                 </div>
//                 {/* Revenue Table */}
//                 <div className="table-responsive">
//                   <Table hover>
//                     <thead>
//                       <tr>
//                         <th>Date</th>
//                         <th>Job Number</th>
//                         <th>Customer</th>
//                         <th>Service Type</th>
//                         <th>Labor Cost</th>
//                         <th>Parts Cost</th>
//                         <th>Total Cost</th>
//                         <th>Payment Status</th>
//                         <th>Payment Method</th>
//                       </tr>
//                     </thead>
//                     <tbody>
//                       {paginatedRevenue.map((item) => (
//                         <tr key={item.id}>
//                           <td>{new Date(item.date).toLocaleDateString()}</td>
//                           <td>
//                             <strong className="text-primary no-wrap">
//                               {item.jobNumber}
//                             </strong>
//                           </td>
//                           <td>{item.customer}</td>
//                           <td>
//                             <Badge color="light" className="text-muted">
//                               {item.serviceType}
//                             </Badge>
//                           </td>
//                           <td>${item.laborCost.toFixed(2)}</td>
//                           <td>${item.partsCost.toFixed(2)}</td>
//                           <td>
//                             <strong className="text-success">
//                               ${item.totalCost.toFixed(2)}
//                             </strong>
//                           </td>
//                           <td>{renderPaymentStatus(item.paymentStatus)}</td>
//                           <td>
//                             <Badge color="info">{item.paymentMethod}</Badge>
//                           </td>
//                         </tr>
//                       ))}
//                     </tbody>
//                   </Table>
//                 </div>
//                 <div className="d-flex flex-column flex-md-row justify-content-between align-items-center gap-3 mt-4">
//                   <div className="text-center text-md-start text-muted">
//                     Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
//                     {Math.min(
//                       currentPage * itemsPerPage,
//                       filteredRevenue.length
//                     )}{" "}
//                     of {filteredRevenue.length} entries
//                   </div>
//                   <CustomPagination
//                     currentPage={currentPage}
//                     totalPages={totalPages}
//                     onPageChange={setCurrentPage}
//                     showFirstLast={true}
//                     maxVisiblePages={5}
//                     paginationType="primary"
//                     className="justify-content-center justify-content-md-end"
//                   />
//                 </div>
//                 {/* Summary Section */}
//                 <Card className="mt-4 bg-light">
//                   <CardBody>
//                     <h6 className="mb-3 text-muted">Revenue Summary</h6>
//                     <Row>
//                       <Col md="4">
//                         <div className="mb-2">
//                           <small className="text-muted">Collection Rate</small>
//                           <div className="fw-bold text-success">
//                             {metrics.collectionRate.toFixed(1)}%
//                           </div>
//                         </div>
//                       </Col>
//                       <Col md="4">
//                         <div className="mb-2">
//                           <small className="text-muted">
//                             Average Transaction
//                           </small>
//                           <div className="fw-bold text-muted">
//                             $
//                             {filteredRevenue.length > 0
//                               ? (
//                                   metrics.totalRevenue / filteredRevenue.length
//                                 ).toFixed(2)
//                               : "0.00"}
//                           </div>
//                         </div>
//                       </Col>
//                       <Col md="4">
//                         <div className="mb-2">
//                           <small className="text-muted">
//                             Labor vs Parts Ratio
//                           </small>
//                           <div className="fw-bold text-muted">
//                             {metrics.totalRevenue > 0
//                               ? `${(
//                                   (metrics.laborRevenue /
//                                     metrics.totalRevenue) *
//                                   100
//                                 ).toFixed(1)}% Labor /
//                               ${(
//                                 (metrics.partsRevenue / metrics.totalRevenue) *
//                                 100
//                               ).toFixed(1)}% Parts`
//                               : "N/A"}
//                           </div>
//                         </div>
//                       </Col>
//                     </Row>
//                   </CardBody>
//                 </Card>
//               </CardBody>
//             </Card>
//           </Col>
//         </Row>
//       </Container>

//       <style jsx global>{`
//         .card-stats {
//           border: 1px solid #e6edef;
//           box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
//         }
//       `}</style>
//     </div>
//   );
// }

// export default RevenueReport;
