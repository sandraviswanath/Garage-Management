// "use client";
// // import CommonLogo from "@/components/Others/authentication/common/CommonLogo";
// import { Col, Container, Row } from "reactstrap";
// import Link from "next/link";
// import { ChangeEvent, FormEvent, useState } from "react";
// import { Facebook, Linkedin, Twitter } from "react-feather";
// import { Button, FormGroup, Input, Label } from "reactstrap";
// import {
//   CreateAccount,
//   DoNotAccount,
//   EmailAddress,
//   EnterEmailPasswordLogin,
//   FacebookHeading,
//   ForgotPassword,
//   Password,
//   RememberPassword,
//   SignIn,
//   SignInAccount,
//   SignInWith,
//   TwitterHeading,
//   linkedInHeading,
// } from "@/utils/Constant";
// import { toast } from "react-toastify";
// import Cookies from "js-cookie";
// import { useRouter } from "next/navigation";
// import CommonLogo from "@/components/common/CommonLogo";
// // import { useRouter } from "next/router";

// const Login = () => {
//   const [showPassWord, setShowPassWord] = useState(false);
//   const [formValues, setFormValues] = useState({
//     email: "Test@gmail.com",
//     password: "Test@123",
//   });
//   const { email, password } = formValues;
//   const router = useRouter();
//   const handleUserValue = (event: ChangeEvent<HTMLInputElement>) => {
//     setFormValues({ ...formValues, [event.target.name]: event.target.value });
//   };
//   const formSubmitHandle = (event: FormEvent) => {
//     event.preventDefault();
//     if (email === "Test@gmail.com" && password === "Test@123") {
//       Cookies.set("token", JSON.stringify(true));
//       router.push("/dashboard/default");
//       toast.success("login successful");
//     } else {
//       toast.error("wrong");
//     }
//   };

//   return (
//     <Container fluid className="p-0">
//       <Row className="m-0">
//         <Col xs={12} className="p-0">
//           <div className="login-card login-dark">
//             <div>
//               <div>
//                 <CommonLogo />
//               </div>
//               <div className="login-main">
//                 <form className="theme-form" onSubmit={formSubmitHandle}>
//                   <h4>{SignInAccount}</h4>
//                   <p>{EnterEmailPasswordLogin}</p>
//                   <FormGroup>
//                     <Label className="col-form-label">{EmailAddress}</Label>
//                     <Input
//                       type="email"
//                       required
//                       placeholder="Test@gmail.com"
//                       value={email}
//                       name="email"
//                       onChange={handleUserValue}
//                     />
//                   </FormGroup>
//                   <FormGroup>
//                     <Label className="col-form-label">{Password}</Label>
//                     <div className="form-input position-relative">
//                       <Input
//                         type={showPassWord ? "text" : "password"}
//                         placeholder="*********"
//                         onChange={handleUserValue}
//                         value={password}
//                         name="password"
//                       />
//                       <div className="show-hide">
//                         <span
//                           onClick={() => setShowPassWord(!showPassWord)}
//                           className={!showPassWord ? "show" : ""}
//                         />
//                       </div>
//                     </div>
//                   </FormGroup>
//                   <FormGroup className="mb-0 form-group">
//                     <div className="checkbox p-0">
//                       <Input id="checkbox1" type="checkbox" />
//                       <Label className="text-muted" htmlFor="checkbox1">
//                         {RememberPassword}
//                       </Label>
//                     </div>
//                     <Link
//                       className="link"
//                       href="/pages/authentication/forget-pwd"
//                     >
//                       {ForgotPassword}
//                     </Link>
//                     <div className="text-end mt-3">
//                       <Button
//                         color="primary"
//                         className="btn-block w-100"
//                         type="submit"
//                       >
//                         {SignIn}
//                       </Button>
//                     </div>
//                   </FormGroup>
//                   <h6 className="text-muted mt-4 or">{SignInWith}</h6>
//                   <div className="social mt-4">
//                     <div className="btn-showcase">
//                       <a
//                         className="btn btn-light"
//                         href="https://www.linkedin.com/login"
//                         target="_blank"
//                         rel="noreferrer"
//                       >
//                         {" "}
//                         <Linkedin className="txt-linkedin" /> {linkedInHeading}
//                       </a>
//                       <a
//                         className="btn btn-light"
//                         href="https://twitter.com/login?lang=en"
//                         target="_blank"
//                         rel="noreferrer"
//                       >
//                         <Twitter className="txt-twitter" />
//                         {TwitterHeading}
//                       </a>
//                       <a
//                         className="btn btn-light"
//                         href="https://www.facebook.com/"
//                         target="_blank"
//                         rel="noreferrer"
//                       >
//                         <Facebook className="txt-fb" />
//                         {FacebookHeading}
//                       </a>
//                     </div>
//                   </div>
//                   <p className="mt-4 mb-0 text-center">
//                     {DoNotAccount}
//                     <Link
//                       className="ms-2"
//                       href="/pages/authentication/register-simple"
//                     >
//                       {CreateAccount}
//                     </Link>
//                   </p>
//                 </form>
//               </div>
//             </div>
//           </div>
//         </Col>
//       </Row>
//     </Container>
//   );
// };

// export default Login;

"use client";
import { Col, Container, Row } from "reactstrap";
import Link from "next/link";
import { ChangeEvent, FormEvent, useEffect, useState } from "react";
import { Facebook, Linkedin, Twitter } from "react-feather";
import { Button, FormGroup, Input, Label } from "reactstrap";
import {
  CreateAccount,
  DoNotAccount,
  EmailAddress,
  EnterEmailPasswordLogin,
  FacebookHeading,
  ForgotPassword,
  Password,
  RememberPassword,
  SignIn,
  SignInAccount,
  SignInWith,
  TwitterHeading,
  linkedInHeading,
} from "@/utils/Constant";
import { toast } from "react-toastify";
import Cookies from "js-cookie";
import { useRouter } from "next/navigation";
import CommonLogo from "@/components/common/CommonLogo";
import { FiEye, FiEyeOff } from "react-icons/fi";
import { useAuth } from "@/helper/AuthContext";

const Login = () => {
  const { state, setAuthData, isAuthenticated } = useAuth();
  const [showPassWord, setShowPassWord] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formValues, setFormValues] = useState({
    email: "",
    password: "",
  });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const { email, password } = formValues;
  const router = useRouter();

  // Check if user is already logged in
  useEffect(() => {
    const token = localStorage.getItem("token");
    const role = localStorage.getItem("role");
    if (token) {
      const rolePaths = {
        admin: "/admin",
        receptionist: "/receptionist",
        technician: "/technician",
        manager: "/manager",
        accountant: "/accountant",
      };
      router.push(rolePaths[role as keyof typeof rolePaths] || "/unauthorized");
    }
  }, [router]);

  const handleUserValue = (event: ChangeEvent<HTMLInputElement>) => {
    setFormValues({ ...formValues, [event.target.name]: event.target.value });
    // Clear error when user starts typing
    if (error) setError("");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, password, user_type: "staff" }),
      });
      const data = await response.json();

      if (response.ok && data?.user) {
        // Changed from data?.data to data?.user
        const { api_token: token, role_name: role } = data.user;

        sessionStorage.removeItem("hasVisitedAdmin");
        localStorage.setItem("token", token);
        localStorage.setItem("role", role);

        // Properly call setAuthData with the expected structure
        setAuthData({
          user: data.user,
          name: data.user.display_name,
          accessToken: token,
          username: data.user.username,
          refreshToken: token, // Use token as refreshToken if separate isn't provided
          photo: data.user.photo, // Uncomment if you have photo in user data
        });

        toast.success(data.msg || "Successfully logged in");

        // Redirect based on role
        const rolePaths = {
          admin: "/admin",
          receptionist: "/receptionist",
          technician: "/technician",
          manager: "/manager",
          accountant: "/accountant",
          staff: "/user/dashboard", // Added staff redirect
        };

        await router.push(
          rolePaths[role as keyof typeof rolePaths] || "/unauthorized"
        );
      } else {
        const errorMessage = data?.msg || "Login failed";
        setError(errorMessage);
      }
    } catch (err) {
      setError("An error occurred during login. Please try again.");
      console.error("Login error:", err);
    } finally {
      setLoading(false);
    }
  };
  return (
    <Container fluid className="p-0">
      <Row className="m-0">
        <Col xs={12} className="p-0">
          <div className="login-card login-dark">
            <div>
              <div>
                <CommonLogo />
              </div>
              <div className="login-main">
                <form className="theme-form" onSubmit={handleSubmit}>
                  <h4>{SignInAccount}</h4>
                  <p>{EnterEmailPasswordLogin}</p>

                  {/* Error Message */}
                  {error && (
                    <div className="mb-3 text-center text-danger">{error}</div>
                  )}

                  <FormGroup>
                    <Label className="col-form-label">{EmailAddress}</Label>
                    <Input
                      type="email"
                      required
                      placeholder="Enter your email"
                      value={email}
                      name="email"
                      onChange={handleUserValue}
                      disabled={isSubmitting}
                      className={error ? "border-danger" : ""}
                    />
                  </FormGroup>
                  <FormGroup>
                    <Label className="col-form-label">{Password}</Label>
                    <div className="form-input position-relative">
                      <Input
                        type={showPassWord ? "text" : "password"}
                        placeholder="Enter your password"
                        onChange={handleUserValue}
                        value={password}
                        name="password"
                        disabled={isSubmitting}
                        className={error ? "border-danger" : ""}
                      />
                      <div className="show-hide">
                        <span
                          onClick={() =>
                            !isSubmitting && setShowPassWord(!showPassWord)
                          }
                          className={!showPassWord ? "show" : ""}
                          style={{
                            cursor: isSubmitting ? "not-allowed" : "pointer",
                          }}
                        >
                          {showPassWord ? (
                            <FiEyeOff size={16} />
                          ) : (
                            <FiEye size={16} />
                          )}
                        </span>
                      </div>
                    </div>
                  </FormGroup>
                  <FormGroup className="mb-0 form-group">
                    <div className="checkbox p-0">
                      <Input
                        id="checkbox1"
                        type="checkbox"
                        disabled={isSubmitting}
                      />
                      <Label className="text-muted" htmlFor="checkbox1">
                        {RememberPassword}
                      </Label>
                    </div>
                    <Link
                      className="link"
                      href="/pages/authentication/forget-pwd"
                    >
                      {ForgotPassword}
                    </Link>
                    <div className="text-end mt-3">
                      <Button
                        color="primary"
                        className="btn-block w-100"
                        type="submit"
                        disabled={isSubmitting}
                      >
                        {isSubmitting ? "Signing in..." : SignIn}
                      </Button>
                    </div>
                  </FormGroup>
                  <h6 className="text-muted mt-4 or">{SignInWith}</h6>
                  <div className="social mt-4">
                    <div className="btn-showcase">
                      <a
                        className="btn btn-light"
                        href="https://www.linkedin.com/login"
                        target="_blank"
                        rel="noreferrer"
                      >
                        {" "}
                        <Linkedin className="txt-linkedin" /> {linkedInHeading}
                      </a>
                      <a
                        className="btn btn-light"
                        href="https://twitter.com/login?lang=en"
                        target="_blank"
                        rel="noreferrer"
                      >
                        <Twitter className="txt-twitter" />
                        {TwitterHeading}
                      </a>
                      <a
                        className="btn btn-light"
                        href="https://www.facebook.com/"
                        target="_blank"
                        rel="noreferrer"
                      >
                        <Facebook className="txt-fb" />
                        {FacebookHeading}
                      </a>
                    </div>
                  </div>
                  <p className="mt-4 mb-0 text-center">
                    {DoNotAccount}
                    <Link
                      className="ms-2"
                      href="/pages/authentication/register-simple"
                    >
                      {CreateAccount}
                    </Link>
                  </p>
                </form>
              </div>
            </div>
          </div>
        </Col>
      </Row>
    </Container>
  );
};

export default Login;
