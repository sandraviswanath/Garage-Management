"use client";
import { usePathname } from "next/navigation";
import Layout from "@/components/layout";
import NoSsr from "@/utils/NoSsr";
import { CustomizerProvider } from "@/helper/Customizer/CustomizerProvider";
import TodoListProvider from "@/helper/TodoList/TodoListProvider";
import { ProjectProvider } from "@/helper/project/ProjectProvider";
import LayoutProvider from "@/helper/Layout/LayoutProvider";
import { BookmarkProvider } from "@/helper/Bookmark/BookmarkProvider";
import ContactProvider from "@/helper/Contacts/ContactProvider";
// import { TaskProvider } from "@/helper/Task/TaskProvider";
import { ToastContainer } from "react-toastify";
import { withoutLayoutThemePath } from "@/Data/OthersPageData";

export default function Providers({ children }: { children: React.ReactNode }) {
  const currentUrl = usePathname();

  let updatedPath;
  if (currentUrl?.includes("?")) {
    const tempt = currentUrl;
    updatedPath = tempt.split("?")[0];
  } else {
    updatedPath = currentUrl;
  }

  return (
    <NoSsr>
      {withoutLayoutThemePath.includes(updatedPath || "") ? (
        children
      ) : (
        <CustomizerProvider>
          <TodoListProvider>
            <ProjectProvider>
              <LayoutProvider>
                {/* <TaskProvider> */}
                <BookmarkProvider>
                  <ContactProvider>
                    <Layout>{children}</Layout>
                  </ContactProvider>
                </BookmarkProvider>
                {/* </TaskProvider> */}
              </LayoutProvider>
            </ProjectProvider>
          </TodoListProvider>
        </CustomizerProvider>
      )}
      <ToastContainer />
    </NoSsr>
  );
}
