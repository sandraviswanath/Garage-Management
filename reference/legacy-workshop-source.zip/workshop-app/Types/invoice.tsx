export interface InvoiceItem {
  id: number;
  description: string;
  type: "labor" | "part" | "service" | "other";
  quantity: number;
  unitPrice: number;
  total: number;
}

export interface Payment {
  id: number;
  date: string;
  amount: number;
  method: "cash" | "credit_card" | "bank_transfer" | "check";
  reference: string;
  status: "completed" | "pending" | "failed";
}

export interface Invoice {
  id: number;
  invoiceNumber: string;
  jobCardId: number;
  customerId: number;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  customerAddress: string;
  issueDate: string;
  dueDate: string;
  items: InvoiceItem[];
  subtotal: number;
  taxRate: number;
  taxAmount: number;
  discount: number;
  total: number;
  amountPaid: number;
  balanceDue: number;
  status:
    | "draft"
    | "sent"
    | "paid"
    | "overdue"
    | "partial"
    | "cancelled"
    | "unpaid";
  payments: Payment[];
  notes: string;
  terms: string;
  createdAt: string;
  updatedAt: string;
}

export interface JobCard {
  id: number;
  jobNumber: string;
  customerId: number;
  customerName: string;
  vehicle: string;
  licensePlate: string;
  serviceType: string;
  laborCost: number;
  partsCost: number;
  total_estimate: number;
  status: "open" | "in_progress" | "completed" | "invoiced" | "closed";
  completedDate?: string;
}
