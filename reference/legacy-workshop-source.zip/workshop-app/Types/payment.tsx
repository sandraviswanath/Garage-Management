export interface WorkshopPayment {
  id: number;
  invoiceId: number;
  invoiceNumber: string;
  customerId: number;
  customerName: string;
  amount: number;
  amountDue: number;
  balanceAfter: number;
  paymentMethod:
    | "cash"
    | "upi"
    | "credit_card"
    | "debit_card"
    | "bank_transfer"
    | "check"
    | "wallet";
  paymentDate: string;
  referenceNumber: string;
  status: "completed" | "pending" | "failed" | "refunded";
  notes?: string;
  receiptNumber: string;
  createdAt: string;
  updatedAt: string;
}

export interface PaymentMethodConfig {
  method: WorkshopPayment["paymentMethod"];
  label: string;
  icon: string;
  color: string;
}

export interface ReceiptData {
  receiptNumber: string;
  paymentDate: string;
  customerName: string;
  customerAddress: string;
  invoiceNumber: string;
  amount: number;
  paymentMethod: string;
  referenceNumber: string;
  balanceDue: number;
  amountPaid: number;
}

// For the payment form state
export interface PaymentFormData {
  invoiceId?: number;
  invoiceNumber?: string;
  customerId?: number;
  customerName?: string;
  amount?: number;
  amountDue?: number;
  balanceAfter?: number;
  paymentMethod: WorkshopPayment["paymentMethod"];
  paymentDate: string;
  referenceNumber: string;
  notes?: string;
  status: WorkshopPayment["status"];
}
