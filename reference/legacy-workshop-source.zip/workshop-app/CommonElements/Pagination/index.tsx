// import CardHead from "@/CommonElements/CardHead";
// import React from "react";
// import { Card, CardBody, Col } from "reactstrap";
// import IconList from "./IconList";

// const Pagination = () => {
//   return (
//     <Col md={6}>
//       <Card className="height-equal">
//         <CardHead
//           title="Pagination With Icons"
//           subTitle={[
//             {
//               text: "Use an icon or symbol in place of text for some pagination links.",
//             },
//           ]}
//         />
//         <CardBody>
//           <IconList />
//         </CardBody>
//       </Card>
//     </Col>
//   );
// };

// export default Pagination;

// import { Pagination, PaginationItem, PaginationLink } from "reactstrap";
// import { Href } from "@/utils/Constant";

// interface PaginationProps {
//   currentPage: number;
//   totalPages: number;
//   onPageChange: (page: number) => void;
//   showFirstLast?: boolean;
//   maxVisiblePages?: number;
//   className?: string;
// }

// const CustomPagination = ({
//   currentPage,
//   totalPages,
//   onPageChange,
//   showFirstLast = true,
//   maxVisiblePages = 5,
//   className = "pagination-secondary pagin-border-secondary mb-3 d-flex",
// }: PaginationProps) => {
//   // Generate page numbers with ellipsis
//   const generatePageNumbers = (): (number | string)[] => {
//     const pages: (number | string)[] = [];
//     const half = Math.floor(maxVisiblePages / 2);

//     let startPage = Math.max(1, currentPage - half);
//     let endPage = Math.min(totalPages, currentPage + half);

//     // Adjust if we're near the start
//     if (currentPage <= half) {
//       endPage = Math.min(totalPages, maxVisiblePages);
//     }

//     // Adjust if we're near the end
//     if (currentPage > totalPages - half) {
//       startPage = Math.max(1, totalPages - maxVisiblePages + 1);
//     }

//     // Add first page and ellipsis if needed
//     if (startPage > 1) {
//       pages.push(1);
//       if (startPage > 2) {
//         pages.push("...");
//       }
//     }

//     // Add page numbers
//     for (let i = startPage; i <= endPage; i++) {
//       pages.push(i);
//     }

//     // Add last page and ellipsis if needed
//     if (endPage < totalPages) {
//       if (endPage < totalPages - 1) {
//         pages.push("...");
//       }
//       pages.push(totalPages);
//     }

//     return pages;
//   };

//   const pageNumbers = generatePageNumbers();

//   const handlePageClick = (page: number | string) => {
//     if (typeof page === "number" && page !== currentPage) {
//       onPageChange(page);
//     }
//   };

//   return (
//     <Pagination className={className} aria-label="Page navigation example">
//       {showFirstLast && (
//         <PaginationItem disabled={currentPage === 1}>
//           <PaginationLink
//             first
//             href={Href}
//             onClick={(e) => {
//               e.preventDefault();
//               if (currentPage !== 1) handlePageClick(1);
//             }}
//           />
//         </PaginationItem>
//       )}

//       {pageNumbers.map((page, index) => (
//         <PaginationItem
//           key={index}
//           active={page === currentPage}
//           disabled={page === "..."}
//         >
//           <PaginationLink
//             href={Href}
//             onClick={(e) => {
//               e.preventDefault();
//               handlePageClick(page);
//             }}
//           >
//             {page}
//           </PaginationLink>
//         </PaginationItem>
//       ))}

//       {showFirstLast && (
//         <PaginationItem disabled={currentPage === totalPages}>
//           <PaginationLink
//             last
//             href={Href}
//             onClick={(e) => {
//               e.preventDefault();
//               if (currentPage !== totalPages) handlePageClick(totalPages);
//             }}
//           />
//         </PaginationItem>
//       )}
//     </Pagination>
//   );
// };

// export default CustomPagination;

import { Pagination, PaginationItem, PaginationLink } from "reactstrap";
import { Href } from "@/utils/Constant";

interface PaginationProps {
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
  showFirstLast?: boolean;
  maxVisiblePages?: number;
  className?: string;
  paginationType?:
    | "primary"
    | "secondary"
    | "success"
    | "danger"
    | "warning"
    | "info"
    | "light"
    | "dark";
}

const CustomPagination = ({
  currentPage,
  totalPages,
  onPageChange,
  showFirstLast = true,
  maxVisiblePages = 5,
  className = "mb-3 d-flex",
  paginationType = "primary",
}: PaginationProps) => {
  // Generate page numbers with ellipsis
  const generatePageNumbers = (): (number | string)[] => {
    const pages: (number | string)[] = [];
    const half = Math.floor(maxVisiblePages / 2);

    let startPage = Math.max(1, currentPage - half);
    let endPage = Math.min(totalPages, currentPage + half);

    // Adjust if we're near the start
    if (currentPage <= half) {
      endPage = Math.min(totalPages, maxVisiblePages);
    }

    // Adjust if we're near the end
    if (currentPage > totalPages - half) {
      startPage = Math.max(1, totalPages - maxVisiblePages + 1);
    }

    // Add first page and ellipsis if needed
    if (startPage > 1) {
      pages.push(1);
      if (startPage > 2) {
        pages.push("...");
      }
    }

    // Add page numbers
    for (let i = startPage; i <= endPage; i++) {
      pages.push(i);
    }

    // Add last page and ellipsis if needed
    if (endPage < totalPages) {
      if (endPage < totalPages - 1) {
        pages.push("...");
      }
      pages.push(totalPages);
    }

    return pages;
  };

  const pageNumbers = generatePageNumbers();

  const handlePageClick = (page: number | string) => {
    if (typeof page === "number" && page !== currentPage) {
      onPageChange(page);
    }
  };

  const handlePrevious = () => {
    if (currentPage > 1) {
      onPageChange(currentPage - 1);
    }
  };

  const handleNext = () => {
    if (currentPage < totalPages) {
      onPageChange(currentPage + 1);
    }
  };

  return (
    <Pagination
      className={`${className} pagination-${paginationType}`}
      aria-label="Page navigation example"
    >
      {/* Previous Button with Icon */}
      <PaginationItem disabled={currentPage === 1}>
        <PaginationLink
          href={Href}
          onClick={(e) => {
            e.preventDefault();
            handlePrevious();
          }}
        >
          <span aria-hidden="true">«</span>
          <span className="sr-only">Previous</span>
        </PaginationLink>
      </PaginationItem>

      {/* Page Numbers */}
      {pageNumbers.map((page, index) => (
        <PaginationItem
          key={index}
          active={page === currentPage}
          disabled={page === "..."}
        >
          <PaginationLink
            href={Href}
            onClick={(e) => {
              e.preventDefault();
              handlePageClick(page);
            }}
          >
            {page}
          </PaginationLink>
        </PaginationItem>
      ))}

      {/* Next Button with Icon */}
      <PaginationItem disabled={currentPage === totalPages}>
        <PaginationLink
          href={Href}
          onClick={(e) => {
            e.preventDefault();
            handleNext();
          }}
        >
          <span aria-hidden="true">»</span>
          <span className="sr-only">Next</span>
        </PaginationLink>
      </PaginationItem>
    </Pagination>
  );
};

export default CustomPagination;
