// import React from 'react';
// import * as Icon from 'react-feather';

// type fetherType = {
//     iconName: keyof typeof Icon,
//     className?: string
// }

// // iconName props is given name of the icon which is use to get the icon from common featureicons 
// // className props give style class for change icon style 

// const FeatherIconCom = ({ iconName, className }: fetherType) => {
//     const IconComp = Icon[iconName];
//     return <IconComp className={className} />;

// };

// export default FeatherIconCom;


import React from 'react';
import * as Icon from 'react-feather';
import { FaCar, FaTruck } from 'react-icons/fa';

type fetherType = {
  iconName: string;
  className?: string;
};

const FeatherIconCom = ({ iconName, className }: fetherType) => {
  // Normalize the name
  const name = iconName.toLowerCase();

  // Handle custom icons
  if (name === 'car') return <FaCar className={className} />;
  if (name === 'truck') return <FaTruck className={className} />;

  // Handle Feather icons (default)
  const IconComp = (Icon as any)[
    name.charAt(0).toUpperCase() + name.slice(1)
  ];
  return IconComp ? <IconComp className={className} /> : null;
};

export default FeatherIconCom;
