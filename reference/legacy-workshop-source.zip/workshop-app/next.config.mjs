// /** @type {import('next').NextConfig} */
// const nextConfig = {};

// export default nextConfig;

/** @type {import('next').NextConfig} */
const nextConfig = {
  eslint: {
    ignoreDuringBuilds: true, // Disables ESLint checks during build
  },

  async rewrites() {
    return [
      {
        source: "/api/:path*",
        destination: "https://our-demos.com/n/Work_shop/api/:path*",
      },

      // {
      //   source: "/admin/:path*",
      //   destination: "https://our-demos.com/n/Work_shop/admin/:path*",
      // },
      // {
      //   source: "/staff/:path*",
      //   destination: "https://our-demos.com/n/Work_shop/staff/:path*",
      // },
    ];
  },
};

export default nextConfig;
